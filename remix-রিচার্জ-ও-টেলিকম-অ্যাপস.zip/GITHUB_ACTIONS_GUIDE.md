# 🚀 GitHub-এ কোড পুশ এবং সরাসরি GitHub Actions দিয়ে APK বিল্ড করার গাইড

এই প্রজেক্টটি এখন এমনভাবে কনফিগার করা হয়েছে যাতে GitHub-এ আপলোড করার সাথে সাথে **GitHub Actions** ক্লাউডে স্বয়ংক্রিয়ভাবে আপনার **Android APK** তৈরি করে দেবে! আপনার নিজের কম্পিউটারে ভারী Android Studio ইনস্টল না থাকলেও চলবে।

---

## 📌 ধাপ ১: Google AI Studio থেকে GitHub-এ সরাসরি এক্সপোর্ট / পুশ করার নিয়ম
1. AI Studio ইন্টারফেসের উপরে ডানদিকের **সেটিংস বা ৩-ডট মেনু (Settings / ⋮)** আইকনে ক্লিক করুন।
2. সেখানে **"Export to GitHub"** অপশনটি নির্বাচন করুন।
3. আপনার GitHub অ্যাকাউন্ট কানেক্ট করে রিপোজিটরি নাম দিন (যেমন: `mapps-telecom`) এবং এক্সপোর্ট সম্পন্ন করুন।

*(অথবা আপনি চাইলে প্রজেক্টের ZIP ডাউনলোড করে আপনার কম্পিউটারে Git দিয়ে রিপোজিটরিতে `git push` করে দিতে পারেন)*:
```bash
git init
git add .
git commit -m "Initial commit with GitHub Actions APK build"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/mapps-telecom.git
git push -u origin main
```

---

## ⚡ ধাপ ২: স্বয়ংক্রিয় GitHub Actions দিয়ে APK বিল্ড হওয়া
প্রজেক্টে `.github/workflows/build-apk.yml` কনফিগার করা রয়েছে। 

১. GitHub-এ কোড পুশ করার সাথে সাথেই অথবা GitHub রিপোজিটরির **"Actions"** ট্যাবে যান।
২. **"Build and Release Android APK"** ওয়ার্কফ্লোটি স্বয়ংক্রিয়ভাবে চালু হয়ে যাবে:
   - এটি স্বয়ংক্রিয়ভাবে Web App বিল্ড করবে।
   - JDK 17 ও Gradle দিয়ে Android APK বিল্ড করবে।
৩. ৩-৪ মিনিটের মধ্যে বিল্ড সফল (Green Checkmark ✅) হয়ে যাবে।

---

## 📥 ধাপ ৩: তৈরি হওয়া APK ফাইল ডাউনলোড করার নিয়ম
1. আপনার GitHub রিপোজিটরির **Actions** ট্যাবে যান।
2. সর্বশেষ সম্পন্ন হওয়া রানটিতে (Workflow Run) ক্লিক করুন।
3. পেজের একদম নিচে **Artifacts** সেকশনে **`mapps-telecom-debug-apk`** নামের জিপ ফাইলটি দেখতে পাবেন।
4. সেটিতে ক্লিক করলেই আপনার রেডি **`app-debug.apk`** ডাউনলোড হয়ে যাবে! এটি সরাসরি যেকোনো অ্যান্ড্রয়েড ফোনে ইনস্টল করে ব্যবহার করতে পারবেন।
