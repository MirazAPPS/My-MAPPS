# ProGuard rules for M APPS Telecom
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
-keepclassmembers class com.mapps.telecom.WebAppInterface {
    public *;
}
