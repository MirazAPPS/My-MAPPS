/**
 * Generates the official WhatsApp / SMS receipt message strictly according to requirements:
 * 
 * Format:
 * M APPS টেলিকমে স্বাগতম 
 * [Status Message]
 * যোগাযোগ: [Admin Phone Number from Settings]
 * 
 * [Customer Name]
 * মোট বিক্রি: ৳[Total Sales]
 * মোট জমা: ৳[Total Received]
 * [Calculated Balance Line]
 */
export function generateCustomerReceiptMessage(
  customerName: string,
  totalSales: number,
  totalReceived: number,
  adminPhoneNumber: string
): string {
  const balance = totalSales - totalReceived;
  let statusMessage = '';
  let balanceLine = '';

  if (totalSales > totalReceived) {
    statusMessage = 'আপনার কিছু হিসাব বাকি আছে, দয়া করে পরিশোধ করুন';
    balanceLine = `বাকি অবশিষ্ট: ৳${balance.toLocaleString('en-IN')}`;
  } else if (totalReceived > totalSales) {
    statusMessage = 'আপনার অতিরিক্ত টাকা জমা আছে';
    balanceLine = `এডভান্স জমা: ৳${Math.abs(balance).toLocaleString('en-IN')}`;
  } else {
    statusMessage = 'আপনার সকল হিসাব পরিশোধিত আছে';
    balanceLine = 'বাকি অবশিষ্ট: ৳০';
  }

  // Format admin phone number nicely if provided
  const adminContact = (adminPhoneNumber || '01712345678').trim();

  return `M APPS টেলিকমে স্বাগতম 
${statusMessage}
যোগাযোগ: ${adminContact}

${customerName}
মোট বিক্রি: ৳${totalSales.toLocaleString('en-IN')}
মোট জমা: ৳${totalReceived.toLocaleString('en-IN')}
${balanceLine}`;
}

/**
 * Clean phone number and open WhatsApp once
 */
export function sendWhatsAppReceipt(customerPhone: string, message: string): void {
  const cleanPhone = customerPhone.replace(/[^0-9]/g, '');
  if (!cleanPhone) return;
  const fullPhone = cleanPhone.startsWith('88') ? cleanPhone : `88${cleanPhone}`;
  window.open(`https://wa.me/${fullPhone}?text=${encodeURIComponent(message)}`, '_blank');
}
