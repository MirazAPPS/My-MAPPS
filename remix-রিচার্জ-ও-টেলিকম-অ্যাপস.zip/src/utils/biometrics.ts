/**
 * Biometric authentication helper using WebAuthn / Platform Authenticator (Fingerprint, Face Unlock, Touch ID, PIN)
 */

export const isBiometricSupported = async (): Promise<boolean> => {
  if (typeof window === 'undefined') return false;
  if (!window.PublicKeyCredential) return false;

  try {
    if (PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable) {
      const available = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
      return Boolean(available);
    }
  } catch (err) {
    console.warn('Biometric support check error:', err);
  }

  return false;
};

// Check if biometric credential is saved for a specific phone number
export const hasBiometricEnrolled = (phone: string): boolean => {
  if (!phone) return false;
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  try {
    const record = localStorage.getItem(`mapps_bio_credential_${cleanPhone}`);
    return Boolean(record);
  } catch {
    return false;
  }
};

// Register/Enroll Biometrics for user with phone + pin
export const registerBiometrics = async (
  phone: string,
  userName: string,
  userPin: string
): Promise<{ success: boolean; error?: string }> => {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  if (!cleanPhone) {
    return { success: false, error: 'মোবাইল নাম্বার পাওয়া যায়নি' };
  }

  if (typeof window === 'undefined' || !window.PublicKeyCredential) {
    return { success: false, error: 'আপনার ডিভাইসে বায়োমেট্রিক সুবিধা সমর্থিত নয়' };
  }

  try {
    // Generate random challenge
    const challenge = new Uint8Array(32);
    window.crypto.getRandomValues(challenge);

    const userId = new TextEncoder().encode(cleanPhone);

    const credential = (await navigator.credentials.create({
      publicKey: {
        challenge,
        rp: {
          name: 'M APPS Telecom',
          id: window.location.hostname || 'localhost',
        },
        user: {
          id: userId,
          name: cleanPhone,
          displayName: userName || cleanPhone,
        },
        pubKeyCredParams: [
          { alg: -7, type: 'public-key' },  // ES256
          { alg: -257, type: 'public-key' }, // RS256
        ],
        authenticatorSelection: {
          authenticatorAttachment: 'platform',
          userVerification: 'required',
          residentKey: 'preferred',
        },
        timeout: 60000,
        attestation: 'none',
      },
    })) as PublicKeyCredential;

    if (credential && credential.id) {
      // Store encrypted/base64 credential record along with encrypted/stored pin for instant unlock
      const bioRecord = {
        credentialId: credential.id,
        phone: cleanPhone,
        userName,
        userPin, // Used to perform automatic verification on successful biometric fingerprint match
        registeredAt: new Date().toISOString(),
      };
      localStorage.setItem(`mapps_bio_credential_${cleanPhone}`, JSON.stringify(bioRecord));
      localStorage.setItem('mapps_last_bio_phone', cleanPhone);
      return { success: true };
    } else {
      return { success: false, error: 'বায়োমেট্রিক রেজিস্টার সম্পন্ন হয়নি' };
    }
  } catch (err: any) {
    console.error('Biometric registration error:', err);
    if (err.name === 'NotAllowedError') {
      return { success: false, error: 'বায়োমেট্রিক অনুমতি বাতিল করা হয়েছে' };
    }
    return { success: false, error: err.message || 'বায়োমেট্রিক যাচাইয়ে ত্রুটি হয়েছে' };
  }
};

// Authenticate using Biometrics (Fingerprint / Face / Platform Authenticator)
export const authenticateBiometrics = async (
  phone: string
): Promise<{ success: boolean; userPin?: string; error?: string }> => {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  if (!cleanPhone) {
    return { success: false, error: 'মোবাইল নাম্বার দেওয়া হয়নি' };
  }

  const rawRecord = localStorage.getItem(`mapps_bio_credential_${cleanPhone}`);
  if (!rawRecord) {
    return {
      success: false,
      error: 'এই নাম্বারে ফিঙ্গারপ্রিন্ট সেট করা নেই। পিন দিয়ে লগইন করে ফিঙ্গারপ্রিন্ট অন করুন।',
    };
  }

  let bioRecord: { credentialId?: string; userPin?: string } = {};
  try {
    bioRecord = JSON.parse(rawRecord);
  } catch {
    return { success: false, error: 'সংরক্ষিত বায়োমেট্রিক ডাটা সঠিক নয়' };
  }

  if (typeof window === 'undefined' || !window.PublicKeyCredential) {
    return { success: false, error: 'আপনার ডিভাইসে বায়োমেট্রিক সুবিধা সমর্থিত নয়' };
  }

  try {
    const challenge = new Uint8Array(32);
    window.crypto.getRandomValues(challenge);

    // Prepare credential request
    const getOptions: PublicKeyCredentialRequestOptions = {
      challenge,
      timeout: 60000,
      userVerification: 'required',
      rpId: window.location.hostname || 'localhost',
    };

    if (bioRecord.credentialId) {
      // Decode credential id if necessary or pass as base64 converted to buffer
      try {
        const rawId = Uint8Array.from(atob(bioRecord.credentialId.replace(/_/g, '/').replace(/-/g, '+')), (c) =>
          c.charCodeAt(0)
        );
        getOptions.allowCredentials = [
          {
            id: rawId,
            type: 'public-key',
            transports: ['internal'],
          },
        ];
      } catch {
        // If conversion fails, proceed without allowCredentials list so platform authenticator prompts user
      }
    }

    const assertion = await navigator.credentials.get({
      publicKey: getOptions,
    });

    if (assertion) {
      return {
        success: true,
        userPin: bioRecord.userPin,
      };
    } else {
      return { success: false, error: 'ফিঙ্গারপ্রিন্ট মেলেনি' };
    }
  } catch (err: any) {
    console.error('Biometric authentication error:', err);
    if (err.name === 'NotAllowedError') {
      return { success: false, error: 'ফিঙ্গারপ্রিন্ট যাচাই বাতিল করা হয়েছে' };
    }
    return { success: false, error: err.message || 'বায়োমেট্রিক যাচাই সম্ভব হয়নি' };
  }
};
