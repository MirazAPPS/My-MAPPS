import React, { useState, useEffect, useRef } from 'react';
import {
  UserProfile,
  AppSettings,
  DriveOffer,
  Transaction,
  ShopTransaction,
  CustomerAccount,
  CustomerTransaction,
  OperatorType,
  SocialCommunityLinks,
  SupportTicket,
  DriveOrder,
  AddMoneyRequest,
  RechargeRequest,
  PaymentNumbersConfig,
  SUPER_ADMIN_EMAIL,
} from './types';
import {
  initialUser,
  initialOffers,
  initialTransactions,
  initialShopTransactions,
  initialCustomers,
  initialSocialLinks,
  initialSupportTickets,
  initialUsersList,
  initialDriveOrders,
  initialPaymentNumbers,
  noticeText,
} from './data/mockData';
import {
  subscribeOffers,
  addOfferToFirestore,
  deleteOfferFromFirestore,
  subscribeAppSettings,
  updateAppSettingsInFirestore,
  subscribeUsersList,
  syncUserProfileToFirestore,
  deleteUserFromFirestore,
  approveUserInFirestore,
  rejectUserInFirestore,
  subscribeCustomers,
  saveCustomerToFirestore,
  deleteCustomerFromFirestore,
  subscribeDailyAccounts,
  saveDailyAccountToFirestore,
  deleteDailyAccountFromFirestore,
  subscribeTransactions,
  addTransactionToFirestore,
  addOrderToFirestore,
  subscribeGlobalDriveOrders,
  saveDriveOrderToFirestore,
  deleteDriveOrderFromFirestore,
  subscribeAddMoneyRequests,
  approveAddMoneyRequestInFirestore,
  rejectAddMoneyRequestInFirestore,
  deleteAddMoneyRequestFromFirestore,
  subscribeRechargeRequests,
  approveRechargeRequestInFirestore,
  cancelRechargeRequestInFirestore,
  deleteRechargeRequestFromFirestore,
  updateTransactionStatusInFirestore,
  deleteTransactionFromFirestore,
  updateTicketStatusInFirestore,
  replyTicketInFirestore,
  deleteTicketFromFirestore,
} from './lib/firebase';
import { playNotificationTone, playAdminAlertRing, getFormattedTodayDate } from './utils';
import { LoginScreen } from './components/LoginScreen';
import { Header } from './components/Header';
import { NoticeBanner } from './components/NoticeBanner';
import { ServicesGrid, ServiceKey } from './components/ServicesGrid';
import { SocialCommunityBar } from './components/SocialCommunityBar';
import { PromotionalOffers } from './components/PromotionalOffers';
import { BottomNav, TabType } from './components/BottomNav';
import { RechargeModal } from './components/RechargeModal';
import { AddMoneyModal } from './components/AddMoneyModal';
import { BuyOfferModal } from './components/BuyOfferModal';
import { DriveOffersDirectoryModal } from './components/DriveOffersDirectoryModal';
import { NidVerificationModal } from './components/NidVerificationModal';
import { TallyHubView } from './components/TallyHubView';
import { ShopLedgerView } from './components/ShopLedgerView';
import { CustomerLedgerListView } from './components/CustomerLedgerListView';
import { CustomerDetailView } from './components/CustomerDetailView';
import { TransactionsView } from './components/TransactionsView';
import { SupportHubView } from './components/SupportHubView';
import { SearchModal } from './components/SearchModal';
import { DrawerMenu } from './components/DrawerMenu';
import { AdminPanelView } from './components/AdminPanelView';
import { ProfileEditModal } from './components/ProfileEditModal';
import { AndroidApkModal } from './components/AndroidApkModal';
import { MobileQrModal } from './components/MobileQrModal';
import { SmartphoneFrame } from './components/SmartphoneFrame';

export default function App() {
  // Authentication State (Starts with Lock/Login Screen for production security)
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isQrModalOpen, setIsQrModalOpen] = useState(false);
  const [user, setUser] = useState<UserProfile>({
    ...initialUser,
    name: 'Miraz Hossain',
    email: 'mmirazgp@gmail.com',
    pin: '1986',
    shopName: 'মেসার্স রনি স্টোর ও টেলিকম',
    role: 'admin',
    appRole: 'super_admin',
    isSuperAdmin: true,
  });

  // App Settings State (Loaded from localStorage if available)
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem('telecom_app_settings');
      if (saved) {
        return {
          theme: 'blue',
          soundEnabled: true,
          notificationsEnabled: true,
          autoCopyOffers: true,
          language: 'bn',
          shopName: 'মেসার্স রনি স্টোর ও টেলিকম',
          ...JSON.parse(saved),
        };
      }
    } catch {}
    return {
      theme: 'blue',
      soundEnabled: true,
      notificationsEnabled: true,
      autoCopyOffers: true,
      language: 'bn',
      shopName: 'মেসার্স রনি স্টোর ও টেলিকম',
    };
  });

  // Social Community & Support State
  const [socialLinks, setSocialLinks] = useState<SocialCommunityLinks>(initialSocialLinks);
  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>(initialSupportTickets);
  const [paymentNumbers, setPaymentNumbers] = useState<PaymentNumbersConfig>(initialPaymentNumbers);

  // App Data State
  const [usersList, setUsersList] = useState<UserProfile[]>(initialUsersList);
  const [offers, setOffers] = useState<DriveOffer[]>(initialOffers);
  const [orders, setOrders] = useState<DriveOrder[]>(initialDriveOrders);
  const [addMoneyRequests, setAddMoneyRequests] = useState<AddMoneyRequest[]>([]);
  const [rechargeRequests, setRechargeRequests] = useState<RechargeRequest[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>(initialTransactions);
  const [shopTransactions, setShopTransactions] = useState<ShopTransaction[]>(initialShopTransactions);
  const [customers, setCustomers] = useState<CustomerAccount[]>(initialCustomers);
  const [notice, setNotice] = useState(noticeText);

  // Navigation State
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [tallySubView, setTallySubView] = useState<'hub' | 'shop' | 'customers' | 'customer_detail'>('hub');
  const [selectedCustomerIdForDetail, setSelectedCustomerIdForDetail] = useState<string | null>(null);

  // Modal States
  const [isRechargeOpen, setIsRechargeOpen] = useState(false);
  const [isAddMoneyOpen, setIsAddMoneyOpen] = useState(false);
  const [isDriveDirectoryOpen, setIsDriveDirectoryOpen] = useState(false);
  const [isNidModalOpen, setIsNidModalOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isProfileEditOpen, setIsProfileEditOpen] = useState(false);
  const [isAndroidApkOpen, setIsAndroidApkOpen] = useState(false);
  const [selectedOfferForBuy, setSelectedOfferForBuy] = useState<DriveOffer | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((cur) => (cur === msg ? null : cur));
    }, 3500);
  };

  const handleRefreshAllData = () => {
    showToast('✅ সমস্ত লাইভ ব্যালেন্স, অফার ও নোটিশ সফলভাবে আপডেট হয়েছে!');
    playNotificationTone();
  };

  // Previous counts for notification sound triggers (-1 indicates initial load not done yet)
  const prevAddMoneyCountRef = useRef<number>(-1);
  const prevRechargeCountRef = useRef<number>(-1);
  const prevOrdersCountRef = useRef<number>(-1);
  const prevPendingUsersCountRef = useRef<number>(-1);

  // Inactivity Auto-Lock System (5 Minutes = 300,000 ms)
  useEffect(() => {
    if (!isLoggedIn) return;

    let inactivityTimer: NodeJS.Timeout;

    const resetTimer = () => {
      clearTimeout(inactivityTimer);
      // Auto lock after 5 minutes of inactivity
      inactivityTimer = setTimeout(() => {
        setIsLoggedIn(false);
      }, 5 * 60 * 1000);
    };

    // User activity event triggers
    const activityEvents = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click'];
    activityEvents.forEach((eventName) => {
      window.addEventListener(eventName, resetTimer, { passive: true });
    });

    // Start initial timer
    resetTimer();

    return () => {
      clearTimeout(inactivityTimer);
      activityEvents.forEach((eventName) => {
        window.removeEventListener(eventName, resetTimer);
      });
    };
  }, [isLoggedIn]);

  // 1. Real-time Listeners for Global collections (Offers, Orders, App Settings, Users List, Add Money, Recharge)
  useEffect(() => {
    const unsubOffers = subscribeOffers((cloudOffers) => {
      if (cloudOffers) {
        setOffers(cloudOffers);
      }
    });

    const unsubOrders = subscribeGlobalDriveOrders((cloudOrders) => {
      if (cloudOrders) {
        const pendingCount = cloudOrders.filter((o) => o.status === 'pending').length;
        if (prevOrdersCountRef.current !== -1 && pendingCount > prevOrdersCountRef.current) {
          playAdminAlertRing();
        }
        prevOrdersCountRef.current = pendingCount;
        setOrders(cloudOrders);
      }
    });

    const unsubAddMoney = subscribeAddMoneyRequests((cloudReqs) => {
      if (cloudReqs) {
        const pendingCount = cloudReqs.filter((r) => r.status === 'pending').length;
        if (prevAddMoneyCountRef.current !== -1 && pendingCount > prevAddMoneyCountRef.current) {
          playAdminAlertRing();
        }
        prevAddMoneyCountRef.current = pendingCount;
        setAddMoneyRequests(cloudReqs);
      }
    });

    const unsubRecharge = subscribeRechargeRequests((cloudReqs) => {
      if (cloudReqs) {
        const pendingCount = cloudReqs.filter((r) => r.status === 'pending').length;
        if (prevRechargeCountRef.current !== -1 && pendingCount > prevRechargeCountRef.current) {
          playAdminAlertRing();
        }
        prevRechargeCountRef.current = pendingCount;
        setRechargeRequests(cloudReqs);
      }
    });

    const unsubSettings = subscribeAppSettings((data) => {
      if (data.notice !== undefined) setNotice(data.notice);
      if (data.settings) {
        setSettings((prev) => {
          const merged = { ...prev, ...data.settings };
          try {
            localStorage.setItem('telecom_app_settings', JSON.stringify(merged));
          } catch {}
          return merged;
        });
      }
      if (data.socialLinks) setSocialLinks((prev) => ({ ...prev, ...data.socialLinks }));
      if (data.paymentNumbers) {
        setPaymentNumbers((prev) => ({ ...prev, ...data.paymentNumbers }));
      } else if (data.settings?.paymentNumbers) {
        setPaymentNumbers((prev) => ({ ...prev, ...data.settings.paymentNumbers }));
      }
    });

    const unsubUsers = subscribeUsersList((cloudUsers) => {
      if (cloudUsers) {
        const pendingCount = cloudUsers.filter((u) => u.status === 'pending').length;
        if (pendingCount > prevPendingUsersCountRef.current && prevPendingUsersCountRef.current !== 0) {
          playNotificationTone();
        }
        prevPendingUsersCountRef.current = pendingCount;
        setUsersList(cloudUsers);
      }
    });

    return () => {
      unsubOffers();
      unsubOrders();
      unsubAddMoney();
      unsubRecharge();
      unsubSettings();
      unsubUsers();
    };
  }, []);

  // 2. Real-time Listeners for Authenticated User-scoped subcollections (Customers, Daily Accounts, Transactions)
  useEffect(() => {
    const userId = user.phone || 'guest_user';

    const unsubCust = subscribeCustomers(userId, (cloudCusts) => {
      if (cloudCusts) {
        setCustomers(cloudCusts);
      }
    });

    const unsubDaily = subscribeDailyAccounts(userId, (cloudDaily) => {
      if (cloudDaily) {
        setShopTransactions(cloudDaily);
      }
    });

    const unsubTx = subscribeTransactions(userId, (cloudTx) => {
      if (cloudTx) {
        setTransactions(cloudTx);
      }
    });

    return () => {
      unsubCust();
      unsubDaily();
      unsubTx();
    };
  }, [user.phone]);

  // Real-time synchronization: Reconcile any 'pending' transaction against resolved requests
  // Ensures home page never displays stale 'pending' when admin has already resolved or cleared them
  useEffect(() => {
    setTransactions((prevTx) => {
      let changed = false;
      const updated = prevTx.map((tx) => {
        if (tx.status === 'pending') {
          // 1. Match against recharge requests
          const matchedRecharge = rechargeRequests.find((r) => r.id === tx.id);
          if (matchedRecharge && matchedRecharge.status !== 'pending') {
            changed = true;
            return {
              ...tx,
              status: matchedRecharge.status === 'success' ? 'success' : 'failed',
              details: tx.details.includes('(প্রক্রিয়াধীন)')
                ? tx.details.replace(
                    '(প্রক্রিয়াধীন)',
                    matchedRecharge.status === 'success' ? 'সফল' : 'বাতিল'
                  )
                : tx.details,
            };
          }

          // 2. Match against drive orders
          const matchedOrder = orders.find((o) => o.id === tx.id);
          if (matchedOrder && matchedOrder.status !== 'pending') {
            changed = true;
            return {
              ...tx,
              status: matchedOrder.status === 'success' ? 'success' : 'failed',
            };
          }

          // 3. Match against add money requests
          const matchedAddMoney = addMoneyRequests.find((a) => a.id === tx.id);
          if (matchedAddMoney && matchedAddMoney.status !== 'pending') {
            changed = true;
            return {
              ...tx,
              status: matchedAddMoney.status === 'approved' ? 'success' : 'failed',
            };
          }
        }
        return tx;
      });

      return changed ? updated : prevTx;
    });
  }, [rechargeRequests, orders, addMoneyRequests]);

  // Service Grid Selection Handler
  const handleSelectService = (serviceKey: ServiceKey) => {
    switch (serviceKey) {
      case 'add_money':
        setIsAddMoneyOpen(true);
        break;
      case 'recharge':
        setIsRechargeOpen(true);
        break;
      case 'drive':
        setIsDriveDirectoryOpen(true);
        break;
      case 'tally':
        setActiveTab('khata');
        setTallySubView('hub');
        break;
      default:
        break;
    }
  };

  // Recharge Handler
  const handleRechargeComplete = (
    amount: number,
    phone: string,
    operator: string,
    req?: RechargeRequest
  ) => {
    const updatedBalance = Math.max(0, user.mainBalance - amount);
    setUser((prev) => {
      const u = {
        ...prev,
        mainBalance: updatedBalance,
      };
      syncUserProfileToFirestore(u.phone, u);
      return u;
    });

    const validOp = (operator.toLowerCase() as OperatorType) || 'gp';
    const now = new Date();
    const timeFormatted = now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', hour12: true });
    const todayDate = getFormattedTodayDate();
    const reqId = req?.id || `RC-${Date.now().toString().slice(-6)}`;

    if (req) {
      setRechargeRequests((prev) => [req, ...prev.filter((r) => r.id !== req.id)]);
    }

    // Set initial transaction status as pending (as it awaits admin approval)
    const newTrx: Transaction = {
      id: reqId,
      type: 'recharge',
      amount: amount,
      phoneNumber: phone,
      operator: validOp,
      operatorName: req?.operatorName || operator,
      date: todayDate,
      time: timeFormatted,
      createdAtMs: now.getTime(),
      timestamp: `আজ, ${timeFormatted}`,
      details: `${operator.toUpperCase()} রিচার্জ (প্রক্রিয়াধীন)`,
      status: 'pending',
      trxId: reqId,
    };
    setTransactions((prev) => [newTrx, ...prev.filter((t) => t.id !== reqId)]);
    addTransactionToFirestore(user.phone, newTrx);
    playAdminAlertRing();
  };

  // Add Money Handler
  const handleAddMoneyComplete = (
    amount: number,
    method: string,
    trxId: string,
    balanceType: 'main' | 'drive' | 'bank'
  ) => {
    setUser((prev) => {
      let u = { ...prev };
      if (balanceType === 'drive') {
        u = { ...prev, driveBalance: prev.driveBalance + amount };
      } else if (balanceType === 'bank') {
        u = { ...prev, bankBalance: prev.bankBalance + amount };
      } else {
        u = { ...prev, mainBalance: prev.mainBalance + amount };
      }
      syncUserProfileToFirestore(u.phone, u);
      return u;
    });

    const now = new Date();
    const timeFormatted = now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', hour12: true });
    const todayDate = getFormattedTodayDate();

    const newTrx: Transaction = {
      id: trxId || `TXN-${Math.floor(100000 + Math.random() * 900000)}`,
      type: 'add_money',
      amount: amount,
      phoneNumber: user.phone,
      paymentMethod: method as any,
      date: todayDate,
      time: timeFormatted,
      createdAtMs: now.getTime(),
      details: `${method} অটো অ্যাড মানি (${balanceType === 'main' ? 'মেইন' : balanceType === 'drive' ? 'ড্রাইভ' : 'ব্যাংক'} ব্যালেন্স)`,
      timestamp: `আজ, ${timeFormatted}`,
      status: 'success',
    };
    setTransactions((prev) => [newTrx, ...prev]);
    addTransactionToFirestore(user.phone, newTrx);
  };

  // Drive Offer Order Handlers
  const handleConfirmDriveOrder = (newOrder: DriveOrder) => {
    setOrders((prev) => [newOrder, ...prev.filter((o) => o.id !== newOrder.id)]);
    saveDriveOrderToFirestore(newOrder);

    const now = new Date();
    const timeFormatted = now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', hour12: true });
    const todayDate = getFormattedTodayDate();

    // Log drive order in transactions history as pending so user sees their purchase immediately
    const newTrx: Transaction = {
      id: newOrder.id,
      type: 'drive',
      amount: newOrder.amount,
      regularPriceTK: newOrder.regularPriceTK || (newOrder.amount + (newOrder.cashback || 0)),
      cashback: newOrder.cashback,
      phoneNumber: newOrder.customerPhone,
      operator: newOrder.operator,
      operatorName: newOrder.operatorName,
      packageName: newOrder.packageName,
      date: newOrder.date || todayDate,
      time: timeFormatted,
      createdAtMs: now.getTime(),
      minutes: newOrder.minutes,
      internetGB: newOrder.internetGB,
      sms: newOrder.sms,
      validityDays: newOrder.validityDays,
      details: newOrder.details || `${newOrder.operatorName} ড্রাইভ অফার`,
      timestamp: `আজ, ${timeFormatted}`,
      status: newOrder.status === 'cancelled' ? 'failed' : (newOrder.status || 'pending'),
    };
    setTransactions((prev) => [newTrx, ...prev.filter((t) => t.id !== newTrx.id)]);
    addTransactionToFirestore(user.phone, newTrx);
  };

  // Admin approves Drive Order (Status -> 'success' and commits to Customer Ledger / Shop Account)
  const handleApproveOrder = (order: DriveOrder) => {
    const approvedOrder: DriveOrder = {
      ...order,
      status: 'success',
    };

    // 1. Update in orders list & Firestore
    setOrders((prev) =>
      prev.map((o) => (o.id === order.id ? approvedOrder : o))
    );
    saveDriveOrderToFirestore(approvedOrder);

    // 2. Commit to Customer Ledger / Account Sheet (কাস্টমার হিসাবের খাতা)
    const now = new Date();
    const dateFormatted = now.toLocaleDateString('bn-BD', {
      day: 'numeric',
      month: 'short',
    });
    const fullDateFormatted = now.toLocaleDateString('bn-BD', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
    const timeFormatted = now.toLocaleTimeString('bn-BD', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });

    const cleanDriveItemName = order.details || `${order.operatorName} ${order.title}`;

    const newCustTrx: CustomerTransaction = {
      id: `CTX-${Date.now().toString().slice(-6)}`,
      itemName: cleanDriveItemName,
      quantity: '১ প্যাক',
      buyPrice: order.netCost,
      sellPrice: order.amount,
      depositAmount: order.amount,
      dueAmount: 0,
      date: dateFormatted,
      time: timeFormatted,
      note: `ড্রাইভ অর্ডার #${order.id} (সাকসেস)`,
    };

    const cleanOrderPhone = order.customerPhone.replace(/[^0-9]/g, '');
    const existingCustomer = customers.find(
      (c) => c.phone.replace(/[^0-9]/g, '') === cleanOrderPhone
    );

    if (existingCustomer) {
      handleAddCustomerTransaction(existingCustomer.id, newCustTrx);
    } else {
      const newCustomer: CustomerAccount = {
        id: `CUST-${Date.now().toString().slice(-6)}`,
        name: order.requesterName || `গ্রাহক ${order.customerPhone.slice(-4)}`,
        phone: order.customerPhone,
        avatarBg: 'bg-purple-600',
        avatarText: order.operatorName.charAt(0) || 'ক',
        transactions: [newCustTrx],
      };
      handleAddCustomer(newCustomer);
    }

    // 3. Commit to Shop Ledger / Account Sheet (দোকানের হিসাব)
    const newShopTrx: ShopTransaction = {
      id: `SHOP-${Date.now().toString().slice(-6)}`,
      itemName: `${cleanDriveItemName} (${order.customerPhone})`,
      buyPrice: order.netCost,
      sellPrice: order.amount,
      depositAmount: order.amount,
      dueAmount: 0,
      date: fullDateFormatted,
      time: timeFormatted,
      category: 'ড্রাইভ অফার',
    };
    handleAddShopTransaction(newShopTrx);

    // 4. Add/Update in Transactions History
    const nowTx = new Date();
    const timeTx = nowTx.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', hour12: true });
    const newTrx: Transaction = {
      id: order.id,
      type: 'drive',
      amount: order.amount,
      regularPriceTK: order.regularPriceTK || (order.amount + (order.cashback || 0)),
      cashback: order.cashback,
      phoneNumber: order.customerPhone,
      operator: order.operator,
      operatorName: order.operatorName,
      packageName: order.packageName,
      date: order.date || getFormattedTodayDate(),
      time: timeTx,
      createdAtMs: nowTx.getTime(),
      minutes: order.minutes,
      internetGB: order.internetGB,
      sms: order.sms,
      validityDays: order.validityDays,
      details: cleanDriveItemName,
      timestamp: `আজ, ${timeTx}`,
      status: 'success',
    };
    const targetUserPhone = order.requesterPhone || order.customerPhone || user.phone;
    setTransactions((prev) => [newTrx, ...prev.filter((t) => t.id !== order.id)]);
    addTransactionToFirestore(targetUserPhone, newTrx);
    if (targetUserPhone !== user.phone) {
      addTransactionToFirestore(user.phone, newTrx);
    }
  };

  // Admin cancels Drive Order
  const handleCancelOrder = (orderId: string, requesterPhone?: string) => {
    const existingOrder = orders.find((o) => o.id === orderId);
    const targetPhone = existingOrder?.requesterPhone || existingOrder?.customerPhone || requesterPhone || user.phone;

    setOrders((prev) => prev.filter((o) => o.id !== orderId));
    deleteDriveOrderFromFirestore(orderId);
    updateTransactionStatusInFirestore(targetPhone, orderId, 'failed', 'ড্রাইভ অর্ডার বাতিল');
    if (targetPhone !== user.phone) {
      updateTransactionStatusInFirestore(user.phone, orderId, 'failed', 'ড্রাইভ অর্ডার বাতিল');
    }
    setTransactions((prev) =>
      prev.map((t) =>
        t.id === orderId
          ? {
              ...t,
              status: 'failed',
              details: t.details.includes('(বাতিল)') ? t.details : `${t.details} (বাতিল)`,
            }
          : t
      )
    );
  };

  // Delete individual transaction from history & Firestore
  const handleDeleteTransaction = (txId: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== txId));
    deleteTransactionFromFirestore(user.phone, txId);
  };

  // Clear / reconcile all stuck pending transactions
  const handleClearPendingTransactions = () => {
    const pendingTxs = transactions.filter((t) => t.status === 'pending');
    setTransactions((prev) =>
      prev.map((t) => (t.status === 'pending' ? { ...t, status: 'success' } : t))
    );
    pendingTxs.forEach((t) => {
      updateTransactionStatusInFirestore(user.phone, t.id, 'success', 'সফল');
    });
  };

  // Khata / Tally Handlers
  const handleAddShopTransaction = (trx: ShopTransaction) => {
    setShopTransactions([trx, ...shopTransactions]);
    saveDailyAccountToFirestore(user.phone, trx);

    // If linked to a customer, also record into that customer's ledger automatically
    if (trx.linkedCustomerId) {
      const targetCustomerId = trx.linkedCustomerId;
      const custTrx: CustomerTransaction = {
        id: `CTX-${Date.now()}`,
        itemName: trx.itemName,
        quantity: trx.quantity || '১ টি',
        buyPrice: trx.buyPrice,
        sellPrice: trx.sellPrice,
        depositAmount: trx.depositAmount,
        dueAmount: trx.dueAmount,
        profit: trx.profit,
        date: trx.date,
        time: trx.time,
        note: trx.note || 'দোকানের হিসাব থেকে সিঙ্ককৃত',
        createdAtMs: Date.now(),
      };
      handleAddCustomerTransaction(targetCustomerId, custTrx);
    }
  };

  const handleUpdateShopTransaction = (trx: ShopTransaction) => {
    setShopTransactions(shopTransactions.map((t) => (t.id === trx.id ? trx : t)));
    saveDailyAccountToFirestore(user.phone, trx);
  };

  const handleDeleteShopTransaction = (id: string) => {
    setShopTransactions(shopTransactions.filter((t) => t.id !== id));
    deleteDailyAccountFromFirestore(user.phone, id);
  };

  const handleAddCustomer = (customer: CustomerAccount) => {
    setCustomers([customer, ...customers]);
    saveCustomerToFirestore(user.phone, customer);
  };

  const handleDeleteCustomer = (id: string) => {
    setCustomers(customers.filter((c) => c.id !== id));
    deleteCustomerFromFirestore(user.phone, id);
  };

  const handleAddCustomerTransaction = (customerId: string, trx: CustomerTransaction) => {
    const updatedCusts = customers.map((c) => {
      if (c.id === customerId) {
        const updated = {
          ...c,
          transactions: [trx, ...c.transactions],
        };
        saveCustomerToFirestore(user.phone, updated);
        return updated;
      }
      return c;
    });
    setCustomers(updatedCusts);
  };

  const handleUpdateCustomerTransaction = (customerId: string, trx: CustomerTransaction) => {
    const updatedCusts = customers.map((c) => {
      if (c.id === customerId) {
        const updated = {
          ...c,
          transactions: c.transactions.map((t) => (t.id === trx.id ? trx : t)),
        };
        saveCustomerToFirestore(user.phone, updated);
        return updated;
      }
      return c;
    });
    setCustomers(updatedCusts);
  };

  const handleDeleteCustomerTransaction = (customerId: string, trxId: string) => {
    const updatedCusts = customers.map((c) => {
      if (c.id === customerId) {
        const updated = {
          ...c,
          transactions: c.transactions.filter((t) => t.id !== trxId),
        };
        saveCustomerToFirestore(user.phone, updated);
        return updated;
      }
      return c;
    });
    setCustomers(updatedCusts);
  };

  // Support Handlers
  const handleSubmitSupportTicket = (ticket: SupportTicket) => {
    setSupportTickets([ticket, ...supportTickets]);
  };

  // Admin Action Handlers
  const handleAddOffer = (newOffer: DriveOffer) => {
    setOffers((prev) => [newOffer, ...prev]);
    addOfferToFirestore(newOffer);
  };

  const handleDeleteOffer = (id: string) => {
    setOffers((prev) => prev.filter((o) => String(o.id) !== String(id)));
    deleteOfferFromFirestore(id);
  };

  const handleUpdateBalance = (main: number, drive: number, bank: number) => {
    setUser((prev) => {
      const u = {
        ...prev,
        mainBalance: main,
        driveBalance: drive,
        bankBalance: bank,
      };
      syncUserProfileToFirestore(u.phone, u);
      return u;
    });
  };

  const handleUpdateNotice = (newNotice: string) => {
    setNotice(newNotice);
    updateAppSettingsInFirestore({ notice: newNotice });
  };

  const handleUpdateSocialLinks = (newLinks: SocialCommunityLinks) => {
    setSocialLinks(newLinks);
    updateAppSettingsInFirestore({ socialLinks: newLinks });
  };

  const handleUpdatePaymentNumbers = (newNumbers: PaymentNumbersConfig) => {
    setPaymentNumbers(newNumbers);
    updateAppSettingsInFirestore({
      paymentNumbers: newNumbers,
      settings: { ...settings, paymentNumbers: newNumbers },
    });
  };

  const handleUpdateSettings = (updated: AppSettings) => {
    setSettings(updated);
    try {
      localStorage.setItem('telecom_app_settings', JSON.stringify(updated));
    } catch {}
    updateAppSettingsInFirestore({ settings: updated });
  };

  const handleResolveTicket = (id: string) => {
    setSupportTickets((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status: 'resolved' as const } : t))
    );
    updateTicketStatusInFirestore(id, 'resolved');
  };

  const handleReplyTicket = (
    id: string,
    replyText: string,
    status: 'pending' | 'in_progress' | 'replied' | 'resolved' = 'replied'
  ) => {
    const timeNow = new Date().toLocaleString('bn-BD', {
      day: 'numeric',
      month: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
    setSupportTickets((prev) =>
      prev.map((t) =>
        t.id === id
          ? {
              ...t,
              adminReply: replyText,
              adminReplyAt: timeNow,
              adminName: user.name || 'এডমিন সাপোর্ট',
              status,
            }
          : t
      )
    );
    replyTicketInFirestore(id, {
      adminReply: replyText,
      status,
      adminName: user.name || 'এডমিন সাপোর্ট',
    });
    playNotificationTone();
  };

  const handleDeleteTicket = (id: string) => {
    setSupportTickets((prev) => prev.filter((t) => t.id !== id));
    deleteTicketFromFirestore(id);
  };

  const handleAddUser = (newUser: UserProfile) => {
    setUsersList((prev) => [newUser, ...prev]);
    syncUserProfileToFirestore(newUser.phone, newUser);
  };

  const handleDeleteUser = (phone: string) => {
    setUsersList((prev) => prev.filter((u) => u.phone !== phone));
    deleteUserFromFirestore(phone);
  };

  const handleApproveUser = (phone: string, roleDecision?: 'user' | 'dealer') => {
    const role = roleDecision === 'dealer' ? 'admin' : 'user';
    const accountType = roleDecision === 'dealer' ? 'Dealer' : 'Retailer';
    const actorInfo = {
      email: user?.email || SUPER_ADMIN_EMAIL,
      name: user?.name || 'Super Admin',
      phone: user?.phone || '01869875883',
    };
    approveUserInFirestore(phone, role, accountType, actorInfo);
    setUsersList((prevList) =>
      prevList.map((u) =>
        u.phone === phone
          ? {
              ...u,
              status: 'approved',
              role,
              accountType,
              appRole: roleDecision === 'dealer' ? 'dealer' : 'retailer',
              dealerStatus: roleDecision === 'dealer' ? 'active' : undefined,
              dealerPermissions:
                roleDecision === 'dealer'
                  ? {
                      manageOffers: true,
                      manageOrders: true,
                      manageAddMoney: true,
                      manageRecharge: true,
                      manageTickets: true,
                      viewUsers: false,
                    }
                  : undefined,
            }
          : u
      )
    );
    playNotificationTone();
  };

  const handleRejectUser = (phone: string) => {
    const actorInfo = {
      email: user?.email || SUPER_ADMIN_EMAIL,
      name: user?.name || 'Super Admin',
      phone: user?.phone || '01869875883',
    };
    rejectUserInFirestore(phone, actorInfo);
    setUsersList((prevList) =>
      prevList.map((u) => (u.phone === phone ? { ...u, status: 'rejected' } : u))
    );
  };

  const handleToggleBlockUser = (phone: string, isBlocked?: boolean, reason?: string) => {
    setUsersList((prevList) =>
      prevList.map((u) => {
        if (u.phone === phone) {
          const nextBlocked = isBlocked !== undefined ? isBlocked : !u.isBlocked;
          const updated = {
            ...u,
            isBlocked: nextBlocked,
            blockReason: nextBlocked ? (reason || 'এডমিন কর্তৃক ব্লক করা হয়েছে') : '',
          };
          syncUserProfileToFirestore(phone, updated);
          return updated;
        }
        return u;
      })
    );
  };

  const handleAdjustBalance = (
    phone: string,
    type: 'main' | 'drive' | 'bank',
    amount: number,
    mode: 'add' | 'deduct' | 'set' = 'add',
    note?: string
  ) => {
    let targetUserName = '';
    setUsersList((prevList) =>
      prevList.map((u) => {
        if (u.phone === phone) {
          targetUserName = u.name;
          const key = type === 'main' ? 'mainBalance' : type === 'drive' ? 'driveBalance' : 'bankBalance';
          const currentBal = u[key] || 0;
          let newBal = currentBal;
          if (mode === 'add') {
            newBal = currentBal + amount;
          } else if (mode === 'deduct') {
            newBal = Math.max(0, currentBal - amount);
          } else if (mode === 'set') {
            newBal = Math.max(0, amount);
          }
          const updated = {
            ...u,
            [key]: newBal,
          };
          syncUserProfileToFirestore(phone, updated);
          return updated;
        }
        return u;
      })
    );

    if (user.phone === phone) {
      const key = type === 'main' ? 'mainBalance' : type === 'drive' ? 'driveBalance' : 'bankBalance';
      const currentBal = user[key] || 0;
      let newBal = currentBal;
      if (mode === 'add') {
        newBal = currentBal + amount;
      } else if (mode === 'deduct') {
        newBal = Math.max(0, currentBal - amount);
      } else if (mode === 'set') {
        newBal = Math.max(0, amount);
      }
      setUser((prev) => ({
        ...prev,
        [key]: newBal,
      }));
    }

    // Add transaction entry for audit trail
    const typeLabel = type === 'drive' ? 'ড্রাইভ' : type === 'bank' ? 'ব্যাংক' : 'মেইন';
    const modeLabel = mode === 'add' ? 'যোগ' : mode === 'deduct' ? 'কর্তন' : 'সমন্বয়';
    const newTrx: Transaction = {
      id: 'ADJ-' + Date.now().toString().slice(-6),
      type: 'add_money',
      amount: amount,
      phoneNumber: phone,
      details: note ? `ব্যালেন্স ${modeLabel}: ${note}` : `এডমিন ব্যালেন্স ${modeLabel} (${typeLabel})`,
      status: 'success',
      timestamp: `আজ, ${new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' })}`,
      date: getFormattedTodayDate(),
    };
    setTransactions((prev) => [newTrx, ...prev]);
    addTransactionToFirestore(phone, newTrx);
  };

  // Add Money Request Handlers
  const handleApproveAddMoney = (req: AddMoneyRequest) => {
    // 1. Mark request as approved in Firestore and credit user
    const creditAmount = req.totalCredit || req.amount;
    approveAddMoneyRequestInFirestore(req.id, req.userPhone, creditAmount, req.balanceType);

    // 2. Update local state
    const targetPhone = req.userPhone;
    const balanceKey = req.balanceType === 'drive' ? 'driveBalance' : req.balanceType === 'bank' ? 'bankBalance' : 'mainBalance';

    if (user.phone === targetPhone) {
      setUser((prev) => ({
        ...prev,
        [balanceKey]: (prev[balanceKey] || 0) + creditAmount,
      }));
    }

    setUsersList((prevList) =>
      prevList.map((u) => {
        if (u.phone === targetPhone) {
          return {
            ...u,
            [balanceKey]: (u[balanceKey] || 0) + creditAmount,
          };
        }
        return u;
      })
    );

    // 3. Add to Transactions
    const nowReq = new Date();
    const timeReq = nowReq.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', hour12: true });
    const newTrx: Transaction = {
      id: req.id,
      type: 'add_money',
      amount: creditAmount,
      phoneNumber: req.userPhone,
      date: getFormattedTodayDate(),
      time: timeReq,
      createdAtMs: nowReq.getTime(),
      details: `${req.gateway} অ্যাড মানি অনুমোদিত (${req.balanceType === 'drive' ? 'ড্রাইভ' : req.balanceType === 'bank' ? 'ব্যাংক' : 'মেইন'} ব্যালেন্স)`,
      timestamp: `আজ, ${timeReq}`,
      status: 'success',
      trxId: req.trxId,
    };
    setTransactions((prev) => [newTrx, ...prev.filter((t) => t.id !== req.id)]);
    addTransactionToFirestore(req.userPhone, newTrx);
    playNotificationTone();
  };

  const handleRejectAddMoney = (id: string, userPhone?: string) => {
    rejectAddMoneyRequestInFirestore(id);
    updateTransactionStatusInFirestore(userPhone || user.phone, id, 'failed');
    setTransactions((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status: 'failed' } : t))
    );
    setAddMoneyRequests((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status: 'rejected' } : r))
    );
  };

  const handleDeleteAddMoney = (id: string) => {
    deleteAddMoneyRequestFromFirestore(id);
    setAddMoneyRequests((prev) => prev.filter((r) => r.id !== id));
  };

  // Recharge Request Handlers
  const handleApproveRecharge = (id: string, userPhone?: string, operatorName?: string) => {
    approveRechargeRequestInFirestore(id);
    updateTransactionStatusInFirestore(userPhone || user.phone, id, 'success');
    setTransactions((prev) =>
      prev.map((t) =>
        t.id === id
          ? {
              ...t,
              status: 'success',
              details: t.details.includes('(প্রক্রিয়াধীন)')
                ? t.details.replace('(প্রক্রিয়াধীন)', 'সফল')
                : t.details,
            }
          : t
      )
    );
    setRechargeRequests((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status: 'success' } : r))
    );
    playNotificationTone();
  };

  const handleCancelRecharge = (
    id: string,
    userPhone?: string,
    amount?: number,
    operatorName?: string
  ) => {
    cancelRechargeRequestInFirestore(id, userPhone, amount);
    updateTransactionStatusInFirestore(userPhone || user.phone, id, 'failed');
    setTransactions((prev) =>
      prev.map((t) =>
        t.id === id
          ? {
              ...t,
              status: 'failed',
              details: t.details.includes('(প্রক্রিয়াধীন)')
                ? t.details.replace('(প্রক্রিয়াধীন)', 'বাতিল ও রিফান্ড')
                : t.details,
            }
          : t
      )
    );
    setRechargeRequests((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status: 'cancelled' } : r))
    );
    // Refund balance to user locally if specified
    if (userPhone && amount && amount > 0) {
      if (user.phone === userPhone) {
        setUser((prev) => ({ ...prev, mainBalance: prev.mainBalance + amount }));
      }
      setUsersList((prevList) =>
        prevList.map((u) => {
          if (u.phone === userPhone) {
            return { ...u, mainBalance: (u.mainBalance || 0) + amount };
          }
          return u;
        })
      );
    }
  };

  const handleDeleteRecharge = (id: string) => {
    deleteRechargeRequestFromFirestore(id);
    setRechargeRequests((prev) => prev.filter((r) => r.id !== id));
  };

  const handleUpdateUser = (updated: UserProfile) => {
    setUser(updated);
    setUsersList((prevList) =>
      prevList.map((u) => (u.phone === updated.phone ? { ...u, ...updated } : u))
    );
    if (updated.phone) {
      syncUserProfileToFirestore(updated.phone, updated);
    }
  };

  // Main Mobile Content (Login Screen or Full App Dashboard)
  const mobileAppBody = !isLoggedIn ? (
        <LoginScreen
          currentUser={user}
          registeredUsers={usersList}
          settings={settings}
          socialLinks={socialLinks}
          onOpenAndroidApk={() => setIsAndroidApkOpen(true)}
          onLoginSuccess={(loggedUser) => {
            setUser(loggedUser);
            if (!usersList.some((u) => u.phone === loggedUser.phone)) {
              setUsersList((prev) => [...prev, loggedUser]);
            }
            // If user is admin, directly set activeTab to admin dashboard
            if (loggedUser.role === 'admin') {
              setActiveTab('admin');
            } else {
              setActiveTab('home');
            }
            setIsLoggedIn(true);
          }}
        />
      ) : (
        <main
          className={`w-full ${
            settings.darkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#f8fafc] text-slate-950'
          } h-full flex flex-col justify-between overflow-hidden relative transition-colors duration-300`}
        >
          {/* Top Profile Header - Fixed in place at the top on Home tab */}
          {activeTab === 'home' && (
            <div className="shrink-0 z-30 w-full">
              <Header
                user={user}
                settings={settings}
                onUpdateSettings={handleUpdateSettings}
                onUpdateUser={handleUpdateUser}
                onOpenSearch={() => setIsSearchOpen(true)}
                onOpenDrawer={() => setIsDrawerOpen(true)}
                onOpenAddMoney={() => setIsAddMoneyOpen(true)}
                onOpenProfileEdit={() => setIsProfileEditOpen(true)}
                onRefreshData={handleRefreshAllData}
                onOpenQrScanner={() => setIsQrModalOpen(true)}
                onOpenAndroidApk={() => setIsAndroidApkOpen(true)}
              />
            </div>
          )}

          {/* Scrollable Body */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden no-scrollbar pb-3">
            {/* 1. Home Tab matching Screenshot 2 */}
            {activeTab === 'home' && (
              <div className="animate-fadeIn">
                {/* Scrolling News / Notice */}
                <NoticeBanner notice={notice} />

                {/* Services Grid (অ্যাড মানি, মোবাইল রিচার্জ, ড্রাইভ অফার, অফার হিসাব, ইত্যাদি) */}
                <ServicesGrid
                  onSelectService={handleSelectService}
                  language={settings.language}
                />

                {/* Promotional Offers Cards matching Screenshot 2 */}
                <PromotionalOffers
                  offers={offers}
                  transactions={transactions}
                  socialLinks={socialLinks}
                  language={settings.language}
                  onSelectOffer={(offer) => setSelectedOfferForBuy(offer)}
                  onSeeAll={() => setIsDriveDirectoryOpen(true)}
                  onSelectTransaction={() => setActiveTab('transactions')}
                  onDeleteTransaction={handleDeleteTransaction}
                />

                {/* Official Community Channels (WhatsApp, Telegram, YouTube, Facebook) */}
                <div className="mt-3 px-1">
                  <SocialCommunityBar
                    socialLinks={socialLinks}
                    offers={offers}
                    user={user}
                  />
                </div>
              </div>
            )}

            {/* 2. Tally Khata Tab */}
            {activeTab === 'khata' && (
              <div className="animate-fadeIn">
                {tallySubView === 'hub' && (
                  <TallyHubView
                    user={user}
                    shopTransactions={shopTransactions}
                    customers={customers}
                    onOpenShopLedger={() => setTallySubView('shop')}
                    onOpenCustomerLedger={() => setTallySubView('customers')}
                    onAddTransaction={handleAddShopTransaction}
                    onUpdateTransaction={handleUpdateShopTransaction}
                    onDeleteTransaction={handleDeleteShopTransaction}
                    onOpenProfileEdit={() => setIsProfileEditOpen(true)}
                    onRefreshData={handleRefreshAllData}
                    onBack={() => setActiveTab('home')}
                  />
                )}

                {tallySubView === 'shop' && (
                  <ShopLedgerView
                    user={user}
                    transactions={shopTransactions}
                    customers={customers}
                    onBack={() => setTallySubView('hub')}
                    onAddTransaction={handleAddShopTransaction}
                    onUpdateTransaction={handleUpdateShopTransaction}
                    onDeleteTransaction={handleDeleteShopTransaction}
                    onAddCustomerTransaction={handleAddCustomerTransaction}
                  />
                )}

                {tallySubView === 'customers' && (
                  <CustomerLedgerListView
                    customers={customers}
                    onBack={() => setTallySubView('hub')}
                    onSelectCustomer={(cust) => {
                      setSelectedCustomerIdForDetail(cust.id);
                      setTallySubView('customer_detail');
                    }}
                    onAddCustomer={handleAddCustomer}
                    onDeleteCustomer={handleDeleteCustomer}
                  />
                )}

                {tallySubView === 'customer_detail' && (
                  (() => {
                    const activeCustomer = customers.find((c) => c.id === selectedCustomerIdForDetail);
                    if (!activeCustomer) {
                      return (
                        <CustomerLedgerListView
                          customers={customers}
                          onBack={() => setTallySubView('hub')}
                          onSelectCustomer={(cust) => {
                            setSelectedCustomerIdForDetail(cust.id);
                            setTallySubView('customer_detail');
                          }}
                          onAddCustomer={handleAddCustomer}
                          onDeleteCustomer={handleDeleteCustomer}
                        />
                      );
                    }
                    return (
                      <CustomerDetailView
                        customer={activeCustomer}
                        settings={settings}
                        socialLinks={socialLinks}
                        onBack={() => setTallySubView('customers')}
                        onAddTransaction={(customerId, trx) => handleAddCustomerTransaction(customerId, trx)}
                        onUpdateCustomerTransaction={(customerId, trx) => handleUpdateCustomerTransaction(customerId, trx)}
                        onDeleteCustomerTransaction={(customerId, trxId) => handleDeleteCustomerTransaction(customerId, trxId)}
                        onDeleteCustomer={(customerId) => {
                          handleDeleteCustomer(customerId);
                          setTallySubView('customers');
                        }}
                      />
                    );
                  })()
                )}
              </div>
            )}

            {/* 3. Transactions History Tab */}
            {activeTab === 'transactions' && (
              <div className="animate-fadeIn">
                <TransactionsView
                  transactions={transactions}
                  orders={orders}
                  rechargeRequests={rechargeRequests}
                  onBackToHome={() => setActiveTab('home')}
                  onDeleteTransaction={handleDeleteTransaction}
                  onClearPendingTransactions={handleClearPendingTransactions}
                />
              </div>
            )}

            {/* 4. 24/7 Support & Help Center Tab */}
            {activeTab === 'support' && (
              <div className="animate-fadeIn">
                <SupportHubView
                  socialLinks={socialLinks}
                  user={user}
                  supportTickets={supportTickets}
                  onBackToHome={() => setActiveTab('home')}
                  onSubmitTicket={handleSubmitSupportTicket}
                />
              </div>
            )}

            {/* 5. Dedicated Admin Panel Dashboard Tab (Admin Role) */}
            {activeTab === 'admin' && user.role === 'admin' && (
              <div className="animate-fadeIn">
                <AdminPanelView
                  user={user}
                  offers={offers}
                  orders={orders}
                  addMoneyRequests={addMoneyRequests}
                  rechargeRequests={rechargeRequests}
                  onAddOffer={handleAddOffer}
                  onDeleteOffer={handleDeleteOffer}
                  onUpdateBalance={handleUpdateBalance}
                  currentNotice={notice}
                  onUpdateNotice={handleUpdateNotice}
                  socialLinks={socialLinks}
                  onUpdateSocialLinks={handleUpdateSocialLinks}
                  paymentNumbers={paymentNumbers}
                  onUpdatePaymentNumbers={handleUpdatePaymentNumbers}
                  supportTickets={supportTickets}
                  onResolveTicket={handleResolveTicket}
                  onReplyTicket={handleReplyTicket}
                  onDeleteTicket={handleDeleteTicket}
                  users={usersList}
                  onAddUser={handleAddUser}
                  onUpdateUser={handleUpdateUser}
                  onDeleteUser={handleDeleteUser}
                  onToggleBlockUser={handleToggleBlockUser}
                  onAdjustBalance={handleAdjustBalance}
                  onApproveUser={handleApproveUser}
                  onRejectUser={handleRejectUser}
                  onApproveOrder={handleApproveOrder}
                  onCancelOrder={handleCancelOrder}
                  onApproveAddMoney={handleApproveAddMoney}
                  onRejectAddMoney={handleRejectAddMoney}
                  onDeleteAddMoney={handleDeleteAddMoney}
                  onApproveRecharge={handleApproveRecharge}
                  onCancelRecharge={handleCancelRecharge}
                  onDeleteRecharge={handleDeleteRecharge}
                  settings={settings}
                  onUpdateSettings={setSettings}
                  onOpenProfileEdit={() => setIsProfileEditOpen(true)}
                  onBackToHome={() => setActiveTab('home')}
                />
              </div>
            )}
          </div>

          {/* Fixed Bottom Navigation Bar */}
          <div className="shrink-0 z-40 bg-white/98 dark:bg-slate-900/98 backdrop-blur-md">
            <BottomNav
              activeTab={activeTab}
              onChangeTab={(tab) => {
                setActiveTab(tab);
                if (tab === 'khata') {
                  setTallySubView('hub');
                }
              }}
              userRole={user.role}
              isDarkMode={settings.darkMode}
              theme={settings.theme}
            />
          </div>

          {/* Modals */}
          <RechargeModal
            isOpen={isRechargeOpen}
            onClose={() => setIsRechargeOpen(false)}
            user={user}
            onRechargeComplete={handleRechargeComplete}
          />

          <AddMoneyModal
            isOpen={isAddMoneyOpen}
            onClose={() => setIsAddMoneyOpen(false)}
            user={user}
            paymentNumbers={paymentNumbers}
            onAddMoneyComplete={handleAddMoneyComplete}
          />

          <BuyOfferModal
            offer={selectedOfferForBuy}
            onClose={() => setSelectedOfferForBuy(null)}
            user={user}
            socialLinks={socialLinks}
            onConfirmOrder={handleConfirmDriveOrder}
          />

          <DriveOffersDirectoryModal
            isOpen={isDriveDirectoryOpen}
            onClose={() => setIsDriveDirectoryOpen(false)}
            offers={offers}
            socialLinks={socialLinks}
            language={settings.language}
            onSelectOffer={(offer) => setSelectedOfferForBuy(offer)}
          />

          <NidVerificationModal
            isOpen={isNidModalOpen}
            onClose={() => setIsNidModalOpen(false)}
            user={user}
          />

          <SearchModal
            isOpen={isSearchOpen}
            onClose={() => setIsSearchOpen(false)}
            offers={offers}
            onSelectOffer={(offer) => setSelectedOfferForBuy(offer)}
          />

          <DrawerMenu
            isOpen={isDrawerOpen}
            onClose={() => setIsDrawerOpen(false)}
            user={user}
            settings={settings}
            socialLinks={socialLinks}
            onUpdateUser={handleUpdateUser}
            onUpdateSettings={handleUpdateSettings}
            onLogout={() => setIsLoggedIn(false)}
            onRefreshData={handleRefreshAllData}
            onOpenQrScanner={() => setIsQrModalOpen(true)}
            onOpenAndroidApk={() => setIsAndroidApkOpen(true)}
          />

          <ProfileEditModal
            isOpen={isProfileEditOpen}
            onClose={() => setIsProfileEditOpen(false)}
            user={user}
            onUpdateUser={handleUpdateUser}
          />
        </main>
      );

  return (
    <SmartphoneFrame
      isDarkMode={settings.darkMode}
      appName={settings.appName || 'M APPS'}
      isLoggedIn={isLoggedIn}
      onToggleLoginView={() => setIsLoggedIn(!isLoggedIn)}
      onOpenQrScanner={() => setIsQrModalOpen(true)}
    >
      {mobileAppBody}

      {/* Floating Global Toast Notification */}
      {toastMessage && (
        <div
          role="alert"
          className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 text-white px-4 py-2.5 rounded-2xl shadow-2xl border border-white/20 text-xs font-black animate-fadeIn flex items-center gap-2 backdrop-blur-md max-w-[90vw] text-center"
        >
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Mobile QR & Scanner In-App Modal */}
      <MobileQrModal
        isOpen={isQrModalOpen}
        onClose={() => setIsQrModalOpen(false)}
        appName={settings.appName}
      />

      {/* Android APK Download & Installation Modal */}
      <AndroidApkModal
        isOpen={isAndroidApkOpen}
        onClose={() => setIsAndroidApkOpen(false)}
        appName={settings.appName || 'M APPS'}
        isDarkMode={settings.darkMode}
        isBangla={settings.language !== 'en'}
      />
    </SmartphoneFrame>
  );
}
