import { DriveOffer, OperatorType, SocialCommunityLinks, Transaction } from './types';

/**
 * Get Bengali name for operator
 */
export function getOperatorBnName(op?: OperatorType | string): string {
  switch (op?.toLowerCase()) {
    case 'gp':
    case 'grameenphone':
      return 'জিপি';
    case 'robi':
      return 'রবি';
    case 'banglalink':
    case 'bl':
      return 'বাংলালিংক';
    case 'airtel':
      return 'এয়ারটেল';
    case 'teletalk':
      return 'টেলিটক';
    case 'skitto':
      return 'স্কিটো';
    default:
      return op || 'জিপি';
  }
}

/**
 * Get formatted date with leading zeros (e.g. 02/09/2026)
 */
export function getFormattedTodayDate(): string {
  const now = new Date();
  const day = String(now.getDate()).padStart(2, '0');
  const month = String(now.getMonth() + 1).padStart(2, '0');
  return `${day}/${month}/${now.getFullYear()}`;
}

/**
 * Get operator emoji and Bengali full name for Drive Offer share list
 */
export function getOperatorFullNameWithEmoji(op?: OperatorType | string): { emoji: string; name: string } {
  switch (op?.toLowerCase()) {
    case 'gp':
    case 'grameenphone':
      return { emoji: '🔵', name: 'গ্রামীণফোন' };
    case 'robi':
      return { emoji: '🔴', name: 'রবি' };
    case 'banglalink':
    case 'bl':
      return { emoji: '🟠', name: 'বাংলালিংক' };
    case 'airtel':
      return { emoji: '🔴', name: 'এয়ারটেল' };
    case 'teletalk':
      return { emoji: '🟢', name: 'টেলিটক' };
    case 'skitto':
      return { emoji: '🟣', name: 'স্কিটো' };
    default:
      return { emoji: '🔵', name: op || 'টেলিকম' };
  }
}

/**
 * Authentic brand colors and styles for each telecom operator
 */
export function getOperatorBrandTheme(op?: OperatorType | string): {
  key: string;
  name: string;
  primaryColor: string;
  headerGradient: string;
  activeChip: string;
  selectedCard: string;
  badgeBg: string;
  lightBg: string;
  btnGradient: string;
} {
  switch (op?.toLowerCase()) {
    case 'gp':
    case 'grameenphone':
      return {
        key: 'gp',
        name: 'গ্রামীণফোন',
        primaryColor: '#0072CE',
        headerGradient: 'from-[#005ed9] via-[#0072CE] to-[#004b99]',
        activeChip: 'bg-[#0072CE] text-white shadow-md shadow-sky-500/30 ring-2 ring-sky-300',
        selectedCard: 'border-[#0072CE] bg-sky-50/90 ring-2 ring-[#0072CE]/30 text-[#005599]',
        badgeBg: 'bg-[#0072CE]',
        lightBg: 'bg-sky-50 text-sky-900 border-sky-200',
        btnGradient: 'from-[#005ed9] to-[#0072CE] hover:from-[#004fa8] hover:to-[#005ed9]',
      };
    case 'robi':
      return {
        key: 'robi',
        name: 'রবি',
        primaryColor: '#ED1C24',
        headerGradient: 'from-[#d32f2f] via-[#ED1C24] to-[#990000]',
        activeChip: 'bg-[#ED1C24] text-white shadow-md shadow-red-500/30 ring-2 ring-red-300',
        selectedCard: 'border-[#ED1C24] bg-red-50/90 ring-2 ring-[#ED1C24]/30 text-[#990000]',
        badgeBg: 'bg-[#ED1C24]',
        lightBg: 'bg-red-50 text-red-900 border-red-200',
        btnGradient: 'from-[#d32f2f] to-[#ED1C24] hover:from-[#b71c1c] hover:to-[#d32f2f]',
      };
    case 'banglalink':
    case 'bl':
      return {
        key: 'banglalink',
        name: 'বাংলালিংক',
        primaryColor: '#FF5B00',
        headerGradient: 'from-[#e65100] via-[#FF5B00] to-[#bf360c]',
        activeChip: 'bg-[#FF5B00] text-white shadow-md shadow-orange-500/30 ring-2 ring-orange-300',
        selectedCard: 'border-[#FF5B00] bg-orange-50/90 ring-2 ring-[#FF5B00]/30 text-[#bf360c]',
        badgeBg: 'bg-[#FF5B00]',
        lightBg: 'bg-orange-50 text-orange-900 border-orange-200',
        btnGradient: 'from-[#e65100] to-[#FF5B00] hover:from-[#bf360c] hover:to-[#e65100]',
      };
    case 'airtel':
      return {
        key: 'airtel',
        name: 'এয়ারটেল',
        primaryColor: '#E30613',
        headerGradient: 'from-[#c62828] via-[#E30613] to-[#800000]',
        activeChip: 'bg-[#E30613] text-white shadow-md shadow-rose-500/30 ring-2 ring-rose-300',
        selectedCard: 'border-[#E30613] bg-rose-50/90 ring-2 ring-[#E30613]/30 text-[#800000]',
        badgeBg: 'bg-[#E30613]',
        lightBg: 'bg-rose-50 text-rose-900 border-rose-200',
        btnGradient: 'from-[#c62828] to-[#E30613] hover:from-[#800000] hover:to-[#c62828]',
      };
    case 'teletalk':
      return {
        key: 'teletalk',
        name: 'টেলিটক',
        primaryColor: '#008752',
        headerGradient: 'from-[#00796b] via-[#008752] to-[#004d40]',
        activeChip: 'bg-[#008752] text-white shadow-md shadow-emerald-500/30 ring-2 ring-emerald-300',
        selectedCard: 'border-[#008752] bg-emerald-50/90 ring-2 ring-[#008752]/30 text-[#004d40]',
        badgeBg: 'bg-[#008752]',
        lightBg: 'bg-emerald-50 text-emerald-900 border-emerald-200',
        btnGradient: 'from-[#00796b] to-[#008752] hover:from-[#004d40] hover:to-[#00796b]',
      };
    case 'skitto':
      return {
        key: 'skitto',
        name: 'স্কিটো',
        primaryColor: '#7B1FA2',
        headerGradient: 'from-[#6a1b9a] via-[#7B1FA2] to-[#4a148c]',
        activeChip: 'bg-[#7B1FA2] text-white shadow-md shadow-purple-500/30 ring-2 ring-purple-300',
        selectedCard: 'border-[#7B1FA2] bg-purple-50/90 ring-2 ring-[#7B1FA2]/30 text-[#4a148c]',
        badgeBg: 'bg-[#7B1FA2]',
        lightBg: 'bg-purple-50 text-purple-900 border-purple-200',
        btnGradient: 'from-[#6a1b9a] to-[#7B1FA2] hover:from-[#4a148c] hover:to-[#6a1b9a]',
      };
    default:
      return {
        key: 'gp',
        name: 'গ্রামীণফোন',
        primaryColor: '#0072CE',
        headerGradient: 'from-[#005ed9] via-[#0072CE] to-[#004b99]',
        activeChip: 'bg-[#0072CE] text-white shadow-md shadow-sky-500/30 ring-2 ring-sky-300',
        selectedCard: 'border-[#0072CE] bg-sky-50/90 ring-2 ring-[#0072CE]/30 text-[#005599]',
        badgeBg: 'bg-[#0072CE]',
        lightBg: 'bg-sky-50 text-sky-900 border-sky-200',
        btnGradient: 'from-[#005ed9] to-[#0072CE] hover:from-[#004fa8] hover:to-[#005ed9]',
      };
  }
}

/**
 * Check if a transaction occurred today (resets strictly at 12:00 midnight)
 * Once midnight arrives or the next day begins, previous hits are not included.
 */
export function isTodayTransaction(tx: Transaction): boolean {
  if (!tx) return false;
  const now = new Date();
  const todayYear = now.getFullYear();
  const todayMonth = now.getMonth();
  const todayDate = now.getDate();

  // 1. Strict Millisecond timestamp check (Most authoritative)
  let timeMs = tx.createdAtMs;
  if (!timeMs && (tx as any).createdAt) {
    const parsed = new Date((tx as any).createdAt).getTime();
    if (!isNaN(parsed)) timeMs = parsed;
  }
  if (timeMs && typeof timeMs === 'number' && !isNaN(timeMs)) {
    const txDate = new Date(timeMs);
    return (
      txDate.getFullYear() === todayYear &&
      txDate.getMonth() === todayMonth &&
      txDate.getDate() === todayDate
    );
  }

  // 2. Strict Date string comparison (e.g. 12/09/2026, 2026-09-12, 12-09-2026)
  if (tx.date) {
    const trimmed = String(tx.date).trim();
    // Parse DD/MM/YYYY or DD-MM-YYYY
    const dmyMatch = trimmed.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
    if (dmyMatch) {
      const matchDay = parseInt(dmyMatch[1], 10);
      const matchMonth = parseInt(dmyMatch[2], 10) - 1;
      const matchYear = parseInt(dmyMatch[3], 10);
      return matchYear === todayYear && matchMonth === todayMonth && matchDay === todayDate;
    }

    // Parse YYYY-MM-DD
    const ymdMatch = trimmed.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})$/);
    if (ymdMatch) {
      const matchYear = parseInt(ymdMatch[1], 10);
      const matchMonth = parseInt(ymdMatch[2], 10) - 1;
      const matchDay = parseInt(ymdMatch[3], 10);
      return matchYear === todayYear && matchMonth === todayMonth && matchDay === todayDate;
    }

    // If tx.date exists but does NOT match today, it's definitely from another day
    return false;
  }

  // 3. Extract date from timestamp if formatted
  if (tx.timestamp) {
    const dateMatch = tx.timestamp.match(/(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/);
    if (dateMatch) {
      const matchDay = parseInt(dateMatch[1], 10);
      const matchMonth = parseInt(dateMatch[2], 10) - 1;
      const matchYear = parseInt(dateMatch[3], 10);
      return matchYear === todayYear && matchMonth === todayMonth && matchDay === todayDate;
    }
  }

  return false;
}

/**
 * Convert numbers to Bengali digits
 */
export const toBangla = (num: number | string): string => {
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return String(num).replace(/\d/g, (d) => bnDigits[parseInt(d, 10)]);
};

/**
 * Clean and format any BD WhatsApp number for wa.me links
/**
 * Ensures a Bangladeshi mobile phone number is strictly formatted as 11 digits (01XXXXXXXXX)
 * Fixes the 12-digit bug caused by double zero '001...', extra country codes, or input errors.
 */
export function cleanBDPhoneForDial(phone?: string | null): string {
  if (!phone) return '';
  // Remove all non-digits
  let digits = String(phone).replace(/[^0-9]/g, '');
  if (!digits) return '';

  // Remove country code 880 or 88 from start
  if (digits.startsWith('880')) {
    digits = digits.substring(3);
  } else if (digits.startsWith('88')) {
    digits = digits.substring(2);
  }

  // Strip all leading zeros
  digits = digits.replace(/^0+/, '');

  // In Bangladesh mobile numbers start with 1 (e.g. 17XXXXXXXX - 10 digits)
  // If digits length is 10 or more, take the last 10 digits and prepend 0
  if (digits.length >= 10) {
    const last10 = digits.slice(-10);
    return `0${last10}`;
  }

  if (digits.length > 0) {
    return `0${digits}`;
  }

  return '';
}

/**
 * Format any Bangladeshi phone number to international WhatsApp format (8801XXXXXXXXX)
 * Handles: +88017..., 88017..., 0017..., 017..., 17...
 */
export function formatBDWhatsAppNumber(rawNumber?: string): string {
  const cleaned = cleanBDPhoneForDial(rawNumber);
  if (!cleaned) return '8801712345678';
  return `88${cleaned}`;
}

/**
 * Generate formatted WhatsApp order message exactly matching specification:
 *
 * 📱 M APPS অফার অর্ডার কনফার্ম করুন
 * 📦 জিপি (2/9/2026)
 * 💸 মাত্র 899 টাকা
 * 🚀 50 জিবি + 1500 মিনিট
 * ⏰ মেয়াদ: 30 দিন
 * 🎁 ক্যাশব্যাক: 100৳
 * ❌ রেগুলার দাম: 999৳
 * 📦 নাম্বার: 01301035400
 */
export function generateWhatsAppOrderMessage(
  customerPhone: string,
  offer: {
    operator?: OperatorType | string;
    operatorName?: string;
    packageName?: string;
    date?: string;
    internetGB?: number;
    minutes?: number;
    sms?: number;
    validityDays?: number | string;
    regularPriceTK?: number;
    priceTK?: number;
    amount?: number;
    cashbackTK?: number;
    cashback?: number;
  }
): string {
  const opBn = getOperatorBnName(offer.operator);
  const offerDate = offer.date || getFormattedTodayDate();

  const currentPrice = Number(offer.priceTK ?? offer.amount ?? 0);
  const regPrice = Number(offer.regularPriceTK || currentPrice);
  const cashback = Number(
    offer.cashbackTK ?? offer.cashback ?? (regPrice > currentPrice ? regPrice - currentPrice : 0)
  );

  const specsList: string[] = [];
  if (offer.internetGB && offer.internetGB > 0) specsList.push(`${offer.internetGB} জিবি`);
  if (offer.minutes && offer.minutes > 0) specsList.push(`${offer.minutes} মিনিট`);
  if (offer.sms && offer.sms > 0) specsList.push(`${offer.sms} এসএমএস`);
  
  const specs = specsList.length > 0 
    ? specsList.join(' + ') 
    : (offer.packageName || 'ড্রাইভ অফার');

  const lines: string[] = [
    '📱 M APPS অফার অর্ডার কনফার্ম করুন',
    `📦 ${opBn} (${offerDate})`,
    `💸 মাত্র ${currentPrice} টাকা`,
    `🚀 ${specs}`,
    `⏰ মেয়াদ: ${offer.validityDays || 30} দিন`,
  ];

  if (cashback > 0) {
    lines.push(`🎁 ক্যাশব্যাক: ${cashback}৳`);
  }

  if (regPrice > 0) {
    lines.push(`❌ রেগুলার দাম: ${regPrice}৳`);
  }

  lines.push(`📦 নাম্বার: ${customerPhone}`);

  return lines.join('\n');
}

/**
 * Generate a clean WhatsApp chat order message URL
 */
export function getWhatsAppDriveOrderUrl(
  customerPhone: string,
  offer: DriveOffer,
  socialLinks?: SocialCommunityLinks
): string {
  const targetNumber =
    offer.whatsappNumber ||
    socialLinks?.whatsappSupportNumber ||
    socialLinks?.adminContactNumber ||
    socialLinks?.supportPhone ||
    '01712345678';
  const formattedPhone = formatBDWhatsAppNumber(targetNumber);
  const message = generateWhatsAppOrderMessage(customerPhone, offer);

  return `https://wa.me/${formattedPhone}?text=${encodeURIComponent(message)}`;
}

/**
 * Generate a WhatsApp chat URL for a specific package/offer
 */
export function getWhatsAppOfferUrl(
  offer: DriveOffer,
  socialLinks?: SocialCommunityLinks,
  customNote?: string
): string {
  const targetNumber = offer.whatsappNumber || socialLinks?.whatsappSupportNumber || '01712345678';
  const formattedPhone = formatBDWhatsAppNumber(targetNumber);
  const message = generateWhatsAppOrderMessage(customNote || 'উল্লেখ নেই', offer);

  return `https://wa.me/${formattedPhone}?text=${encodeURIComponent(message)}`;
}

/**
 * Generate text representation of a single offer for sharing
 * Exactly matching user specification:
 * 🔥 আজকের স্পেশাল ড্রাইভ অফার! (02/09/2026) 🔥
 * ━━━━━━━━━━━━━━━━━━━━
 * 🔵 গ্রামীণফোন ➔ মাত্র 899 টাকায়
 * └ 50 GB | 1500 Min |
 */
export function formatSingleOfferShareText(offer: DriveOffer): string {
  const today = getFormattedTodayDate();
  const { emoji, name } = getOperatorFullNameWithEmoji(offer.operator);
  const currentPrice = Number(offer.priceTK || 0);
  const regPrice = Number(offer.regularPriceTK || currentPrice);
  const cashback = Number(offer.cashbackTK || (regPrice > currentPrice ? regPrice - currentPrice : 0));

  const specsList: string[] = [];
  if (offer.internetGB && offer.internetGB > 0) specsList.push(`${offer.internetGB} GB`);
  if (offer.minutes && offer.minutes > 0) specsList.push(`${offer.minutes} Min`);
  if (offer.sms && offer.sms > 0) specsList.push(`${offer.sms} SMS`);
  if (specsList.length === 0 && offer.packageName) specsList.push(offer.packageName);
  if (offer.validityDays) specsList.push(`${offer.validityDays} দিন`);
  if (cashback > 0) specsList.push(`ক্যাশব্যাক: ${cashback}৳`);

  const specsLine = `└ ${specsList.join(' | ')} |`;

  const lines: string[] = [
    `🔥 আজকের স্পেশাল ড্রাইভ অফার! (${today}) 🔥`,
    `━━━━━━━━━━━━━━━━━━━━`,
    `${emoji} ${name} ➔ মাত্র ${currentPrice} টাকায়`,
    specsLine,
    `━━━━━━━━━━━━━━━━━━━━`,
    `⚡ দ্রুত অফার নিতে এখনই যোগাযোগ করুন!`,
  ];

  return lines.join('\n');
}

/**
 * Generate text representation of ALL active offers in folder for sharing
 * Exactly formatted as:
 * 🔥 আজকের স্পেশাল ড্রাইভ অফার! (02/09/2026) 🔥
 * ━━━━━━━━━━━━━━━━━━━━
 * 🔵 গ্রামীণফোন ➔ মাত্র 899 টাকায়
 * └ 50 GB | 1500 Min |
 *
 * 🔴 রবি ➔ মাত্র 498 টাকায়
 * └ 35 GB | 800 Min |
 */
export function formatAllOffersShareText(offers: DriveOffer[], folderTitle?: string): string {
  const today = getFormattedTodayDate();

  if (offers.length === 0) {
    return `🔥 আজকের স্পেশাল ড্রাইভ অফার! (${today}) 🔥\n━━━━━━━━━━━━━━━━━━━━\nবর্তমানে কোনো সক্রিয় অফার নেই।`;
  }

  const lines: string[] = [
    `🔥 আজকের স্পেশাল ড্রাইভ অফার! (${today}) 🔥`,
    `━━━━━━━━━━━━━━━━━━━━`,
  ];

  offers.forEach((offer, idx) => {
    const { emoji, name } = getOperatorFullNameWithEmoji(offer.operator);
    const currentPrice = Number(offer.priceTK || 0);
    const regPrice = Number(offer.regularPriceTK || currentPrice);
    const cashback = Number(offer.cashbackTK || (regPrice > currentPrice ? regPrice - currentPrice : 0));

    const specsList: string[] = [];
    if (offer.internetGB && offer.internetGB > 0) specsList.push(`${offer.internetGB} GB`);
    if (offer.minutes && offer.minutes > 0) specsList.push(`${offer.minutes} Min`);
    if (offer.sms && offer.sms > 0) specsList.push(`${offer.sms} SMS`);
    if (specsList.length === 0 && offer.packageName) specsList.push(offer.packageName);
    if (offer.validityDays) specsList.push(`${offer.validityDays} দিন`);
    if (cashback > 0) specsList.push(`ক্যাশব্যাক: ${cashback}৳`);

    const specsLine = `└ ${specsList.join(' | ')} |`;

    lines.push(`${emoji} ${name} ➔ মাত্র ${currentPrice} টাকায়`);
    lines.push(specsLine);
    if (idx < offers.length - 1) {
      lines.push('');
    }
  });

  lines.push(`━━━━━━━━━━━━━━━━━━━━`);
  lines.push(`⚡ দ্রুত ড্রাইভ অফার নিতে অ্যাপে অর্ডার করুন অথবা যোগাযোগ করুন!`);

  return lines.join('\n');
}

/**
 * Share text via Web Share API or Clipboard with toast callback
 */
export async function shareContent(
  title: string,
  text: string,
  onCopied?: (msg: string) => void
): Promise<boolean> {
  if (navigator.share) {
    try {
      await navigator.share({
        title,
        text,
      });
      return true;
    } catch (err: any) {
      // If user dismissed share, don't fall back to error
      if (err?.name === 'AbortError') {
        return false;
      }
    }
  }

  // Fallback: Copy to clipboard
  try {
    await navigator.clipboard.writeText(text);
    if (onCopied) {
      onCopied('অফারের তথ্য কপি করা হয়েছে! যেকোনো জায়গায় পেস্ট করে শেয়ার করতে পারেন।');
    }
    return true;
  } catch {
    // If clipboard fails, try prompt
    return false;
  }
}

/**
 * Share single transaction history card text
 */
export function formatTransactionShareText(trx: Transaction): string {
  const opBn = getOperatorBnName(trx.operator);
  const now = new Date();
  const trxDate = trx.date || getFormattedTodayDate();
  const trxTime = trx.time || now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' });
  const currentPrice = Number(trx.amount || 0);
  const regPrice = Number(trx.regularPriceTK || currentPrice);
  const cashback = Number(trx.cashback || (regPrice > currentPrice ? regPrice - currentPrice : 0));

  const specsList: string[] = [];
  if (trx.internetGB && trx.internetGB > 0) specsList.push(`${trx.internetGB} জিবি`);
  if (trx.minutes && trx.minutes > 0) specsList.push(`${trx.minutes} মিনিট`);
  if (trx.sms && trx.sms > 0) specsList.push(`${trx.sms} এসএমএস`);
  const specs = specsList.join(' ') || trx.details;

  const lines: string[] = [
    `[${opBn}] > ${trxDate} / ${trxTime}`,
    specs,
    `রেগুলার দাম ${regPrice}৳❌ | বর্তমান দাম ${currentPrice}৳✅ | ক্যাশব্যাক ${cashback}৳ | নম্বর ${trx.phoneNumber || 'N/A'}`
  ];

  return lines.join('\n');
}

/**
 * Open WhatsApp directly (compatible with Web and Mobile App/PWA)
 */
export function openWhatsAppChat(url: string) {
  try {
    const newWindow = window.open(url, '_blank');
    if (!newWindow || newWindow.closed || typeof newWindow.closed === 'undefined') {
      window.location.href = url;
    }
  } catch {
    window.location.href = url;
  }
}

/**
 * Check if app sound effects are globally enabled in user settings
 */
export function isAppSoundEnabled(): boolean {
  try {
    const raw = localStorage.getItem('telecom_app_settings');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (typeof parsed.soundEnabled === 'boolean') {
        return parsed.soundEnabled;
      }
    }
  } catch {}
  return true;
}

/**
 * Play a crystal-clear notification chime using Web Audio API
 */
export function playNotificationTone(force?: boolean) {
  if (!force && !isAppSoundEnabled()) return;
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }

    const now = ctx.currentTime;
    
    // First high chime
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(880, now); // A5
    osc1.frequency.exponentialRampToValueAtTime(1320, now + 0.12);
    gain1.gain.setValueAtTime(0.3, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.25);

    // Second pleasant confirming chime
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(1320, now + 0.15); // E6
    osc2.frequency.exponentialRampToValueAtTime(1760, now + 0.35); // A6
    gain2.gain.setValueAtTime(0.35, now + 0.15);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.15);
    osc2.stop(now + 0.45);
  } catch {
    // ignore audio autoplay policy errors
  }
}

/**
 * Loud, unmistakable incoming request ringtone for Admin Panel (Add Money & Recharge)
 */
export function playAdminAlertRing(force?: boolean) {
  if (!force && !isAppSoundEnabled()) return;
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }

    const now = ctx.currentTime;
    // 3 rhythmic ringing alert bursts
    const tones = [
      { time: 0.0, freq: 880 },
      { time: 0.16, freq: 1174.66 },
      { time: 0.32, freq: 1479.98 },
      { time: 0.52, freq: 1760.00 },
    ];

    tones.forEach(({ time, freq }) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + time);
      gain.gain.setValueAtTime(0.45, now + time);
      gain.gain.exponentialRampToValueAtTime(0.001, now + time + 0.14);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + time);
      osc.stop(now + time + 0.15);
    });
  } catch {
    // ignore audio autoplay policy errors
  }
}

/**
 * Voice synthesis pronunciation helper
 */
export function speakText(text: string, lang: 'bn' | 'en' = 'bn', force?: boolean) {
  if (!force && !isAppSoundEnabled()) return;
  try {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang === 'bn' ? 'bn-BD' : 'en-US';
    utterance.rate = 0.95;
    utterance.pitch = 1.0;
    window.speechSynthesis.speak(utterance);
  } catch {
    // ignore speech synthesis errors
  }
}


