import {
  DriveOffer,
  Transaction,
  TallyEntry,
  UserProfile,
  ShopTransaction,
  CustomerAccount,
  SocialCommunityLinks,
  SupportTicket,
  DriveOrder,
  PaymentNumbersConfig,
} from '../types';

export const initialShopTransactions: ShopTransaction[] = [];

export const initialCustomers: CustomerAccount[] = [];

export const initialUser: UserProfile = {
  name: 'Miraz Hossain',
  phone: '01869875883',
  email: 'mmirazgp@gmail.com',
  pin: '1986',
  shopName: 'মেসার্স রনি স্টোর ও টেলিকম',
  mainBalance: 0,
  driveBalance: 0,
  bankBalance: 0,
  accountType: 'Admin',
  appRole: 'super_admin',
  isSuperAdmin: true,
  role: 'admin',
  status: 'approved',
};

export const initialUsersList: UserProfile[] = [];

export const packageTypesList = [
  'কম্বো প্যাক',
  'বান্ডেল প্যাক',
  'মিনিট প্যাক',
  'ডাটা প্যাক',
  'ফ্যামিলি প্যাক',
  'গিফট প্যাক',
  'ওটিপি প্যাক',
];

export const initialOffers: DriveOffer[] = [
  {
    id: 'offer-gp-promo',
    operator: 'gp',
    operatorName: 'গ্রামীণফোন',
    packageName: 'কম্বো প্যাক',
    internetGB: 50,
    minutes: 1500,
    validityDays: 30,
    regularPriceTK: 899,
    priceTK: 699,
    cashbackTK: 200,
    isPopular: true,
  },
  {
    id: 'offer-bl-promo',
    operator: 'banglalink',
    operatorName: 'বাংলালিংক',
    packageName: 'ধামাকা কম্বো',
    internetGB: 40,
    minutes: 1000,
    validityDays: 30,
    regularPriceTK: 799,
    priceTK: 580,
    cashbackTK: 219,
    isPopular: true,
  },
  {
    id: 'offer-robi-promo',
    operator: 'robi',
    operatorName: 'রবি',
    packageName: 'মেগা বান্ডেল',
    internetGB: 45,
    minutes: 1200,
    validityDays: 30,
    regularPriceTK: 850,
    priceTK: 640,
    cashbackTK: 210,
    isPopular: true,
  },
  {
    id: 'offer-airtel-promo',
    operator: 'airtel',
    operatorName: 'এয়ারটেল',
    packageName: 'সুপার প্যাক',
    internetGB: 35,
    minutes: 800,
    validityDays: 30,
    regularPriceTK: 699,
    priceTK: 499,
    cashbackTK: 200,
    isPopular: true,
  },
];

export const initialTransactions: Transaction[] = [];

export const initialTallyEntries: TallyEntry[] = [];

export const quickRechargeAmounts = [20, 30, 50, 100, 200, 300, 500, 1000];

export const noticeText = 'স্বাগতম! টেলিকম ড্রাইভ ও রিচার্জ সেবায় আপনাকে ধন্যবাদ।';

export const initialSocialLinks: SocialCommunityLinks = {
  whatsappGroup: '',
  whatsappSupportNumber: '',
  telegramChannel: '',
  telegramSupport: '',
  facebookPage: '',
  youtubeChannel: '',
  supportPhone: '',
  supportHours: 'সকাল ৯টা - রাত ১১টা (জরুরি সেবা ২৪/৭)',
  emergencyNotice: 'যেকোনো রিচার্জ বা ব্যালেন্স সংক্রান্ত জরুরি প্রয়োজনে সরাসরি কল করুন বা WhatsApp এ মেসেজ দিন।',
};

export const initialSupportTickets: SupportTicket[] = [];

export const initialDriveOrders: DriveOrder[] = [];

export const initialPaymentNumbers: PaymentNumbersConfig = {
  bKash: '',
  bKashType: 'Send Money (Personal)',
  bKashEnabled: false,

  Nagad: '',
  NagadType: 'Send Money (Personal)',
  NagadEnabled: false,

  Rocket: '',
  RocketType: 'Send Money (Personal)',
  RocketEnabled: false,

  Upay: '',
  UpayType: 'Send Money (Personal)',
  UpayEnabled: false,

  bankName: '',
  bankAccountName: '',
  bankAccountNumber: '',
  bankBranchRouting: '',
  bankType: 'Current / Savings',
  bankEnabled: false,
};
