import React, { useState } from 'react';
import {
  X,
  CreditCard,
  CheckCircle2,
  AlertCircle,
  Search,
  ShieldCheck,
  Smartphone,
  Copy,
  Check,
  UserCheck,
  FileText,
  Calendar,
  User,
  ArrowLeft,
} from 'lucide-react';
import { UserProfile } from '../types';

interface NidVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
}

export const NidVerificationModal: React.FC<NidVerificationModalProps> = ({
  isOpen,
  onClose,
  user,
}) => {
  const [nidNumber, setNidNumber] = useState('19942692518000123');
  const [dob, setDob] = useState('1994-08-15');
  const [customerName, setCustomerName] = useState('মোঃ আব্দুল্লাহ আল মামুন');
  const [fatherName, setFatherName] = useState('মোঃ রফিকুল ইসলাম');
  const [motherName, setMotherName] = useState('মোছাঃ রহিমা খাতুন');
  const [searched, setSearched] = useState(false);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nidNumber || nidNumber.length < 10) return;

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSearched(true);
    }, 800);
  };

  const handleCopyInfo = () => {
    const text = `📋 *ভোটার আইডি / এনআইডি তথ্য*\n` +
      `👤 নাম: ${customerName}\n` +
      `🆔 NID নম্বর: ${nidNumber}\n` +
      `📅 জন্ম তারিখ: ${dob}\n` +
      `👨 পিতার নাম: ${fatherName}\n` +
      `👩 মাতার নাম: ${motherName}\n` +
      `📶 রেজিস্টার্ড সিম সংখ্যা: ৪ টি (অনুমোদিত ১৫ টির মধ্যে)\n` +
      `✅ বায়োমেট্রিক স্ট্যাটাস: ভেরিফাইড (সক্রিয়)\n` +
      `🏪 রিটেইলার শপ: ${user.shopName || 'টেলিকম রিচার্জ সেন্টার'}`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-[420px] w-full p-5 shadow-2xl border border-slate-100 space-y-4 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
              title="পেছনে যান"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="w-9 h-9 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center shadow-xs shrink-0">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 text-base leading-tight">
                ভোটার আইডি ও সিম ভেরিফিকেশন
              </h3>
              <span className="text-[11px] text-slate-500 font-medium">
                NID যাচাই ও নতুন সিম রেজিস্ট্রেশন
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 transition-colors cursor-pointer"
            title="বন্ধ করুন"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Input Form */}
        <form onSubmit={handleSearch} className="space-y-3 text-xs">
          <div>
            <label className="font-bold text-slate-700 block mb-1 text-center">
              ভোটার আইডি / এনআইডি নম্বর (১০ / ১৩ / ১৭ ডিজিট)
            </label>
            <div className="relative flex items-center justify-center">
              <CreditCard className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
              <input
                type="text"
                required
                value={nidNumber}
                onChange={(e) => setNidNumber(e.target.value)}
                placeholder="যেমন: 19942692518000123"
                className="w-full px-9 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-slate-900 outline-none focus:border-rose-600 text-center"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="font-bold text-slate-700 block mb-1 text-center">
                জন্ম তারিখ
              </label>
              <div className="relative flex items-center justify-center">
                <Calendar className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
                <input
                  type="date"
                  required
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  className="w-full pl-8 pr-2 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-rose-600 text-center"
                />
              </div>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1 text-center">
                গ্রাহকের নাম (ঐচ্ছিক)
              </label>
              <div className="relative flex items-center justify-center">
                <User className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="গ্রাহকের নাম"
                  className="w-full px-8 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-rose-600 text-center"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full max-w-[300px] mx-auto py-3 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white font-semibold text-[16px] rounded-xl shadow-md shadow-rose-600/20 flex items-center justify-center gap-2 transition-all active:scale-98"
          >
            {loading ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                এনআইডি সার্ভার যাচাই হচ্ছে...
              </span>
            ) : (
              <>
                <Search className="w-4 h-4" />
                <span>ভোটার আইডি তথ্য অনুসন্ধান করুন</span>
              </>
            )}
          </button>
        </form>

        {/* Verification Result Card */}
        {searched && (
          <div className="space-y-3 pt-2 animate-fadeIn">
            {/* Bangladesh Smart NID Card Layout Preview */}
            <div className="rounded-2xl p-4 bg-gradient-to-br from-emerald-900 via-teal-950 to-slate-900 text-white shadow-xl border border-emerald-500/30 relative overflow-hidden">
              {/* Background watermark badge */}
              <div className="absolute -right-6 -bottom-6 w-28 h-28 rounded-full bg-emerald-500/10 flex items-center justify-center pointer-events-none">
                <ShieldCheck className="w-20 h-20 text-emerald-400/20" />
              </div>

              <div className="flex items-center justify-between pb-2.5 border-b border-emerald-500/30">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-rose-600 border border-white/50 flex items-center justify-center text-[9px] font-black text-white">
                    BD
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-300 block">
                      গণপ্রজাতন্ত্রী বাংলাদেশ সরকার
                    </span>
                    <span className="text-[9px] text-slate-300">
                      National Identity Card / জাতীয় পরিচয়পত্র
                    </span>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-400/30 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  যাচাইকৃত
                </span>
              </div>

              {/* Card Details */}
              <div className="grid grid-cols-3 gap-3 mt-3">
                {/* Left Photo Placeholder */}
                <div className="col-span-1 flex flex-col items-center">
                  <div className="w-18 h-22 rounded-xl bg-slate-800 border-2 border-emerald-400/40 flex flex-col items-center justify-center text-slate-400 p-1 shadow-inner">
                    <UserCheck className="w-8 h-8 text-emerald-400 mb-1" />
                    <span className="text-[8px] font-bold text-center text-slate-300">বায়োমেট্রিক ছবি</span>
                  </div>
                </div>

                {/* Right Details */}
                <div className="col-span-2 space-y-1 text-xs">
                  <div>
                    <span className="text-[9px] text-slate-400 block leading-none">নাম:</span>
                    <span className="font-extrabold text-sm text-white">{customerName}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-slate-400 block leading-none">পিতা:</span>
                    <span className="font-semibold text-slate-200 text-xs">{fatherName}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-slate-400 block leading-none">মাতা:</span>
                    <span className="font-semibold text-slate-200 text-xs">{motherName}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-slate-400 block leading-none">জন্ম তারিখ / NID:</span>
                    <span className="font-mono font-bold text-emerald-300 text-[11px] block">{dob}</span>
                    <span className="font-mono font-bold text-white text-xs block">{nidNumber}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* SIM Biometric Registration Info */}
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-700 flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4 text-purple-600" />
                  সিম রেজিস্ট্রেশন কোটা (BTRC)
                </span>
                <span className="font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 text-[11px]">
                  ৪/১৫ টি সিম রেজিস্টার্ড
                </span>
              </div>

              <div className="grid grid-cols-4 gap-1.5 text-center text-[10px] font-bold">
                <div className="p-1.5 bg-blue-50 text-blue-700 rounded-lg border border-blue-100">
                  GP: ২ টি
                </div>
                <div className="p-1.5 bg-red-50 text-red-700 rounded-lg border border-red-100">
                  Robi: ১ টি
                </div>
                <div className="p-1.5 bg-orange-50 text-orange-700 rounded-lg border border-orange-100">
                  BL: ১ টি
                </div>
                <div className="p-1.5 bg-emerald-50 text-emerald-700 rounded-lg border border-emerald-100">
                  বাকি: ১১ টি
                </div>
              </div>
            </div>

            {/* Copy & Share Action */}
            <button
              type="button"
              onClick={handleCopyInfo}
              className="w-full py-2.5 bg-slate-900 hover:bg-black text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all shadow-xs active:scale-98"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>ভোটার আইডি তথ্য কপি সম্পন্ন!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>সিম রেজিস্ট্রেশনের জন্য তথ্য কপি করুন</span>
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
