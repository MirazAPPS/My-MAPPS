import React, { useState } from 'react';
import {
  ArrowLeft,
  Share2,
  Search,
  ShoppingCart,
  Wallet,
  CreditCard,
  Plus,
  Edit2,
  Trash2,
  MessageCircle,
  X,
  Check,
  User,
  TrendingUp,
  Coins,
  CheckCircle2,
} from 'lucide-react';
import { AppSettings, CustomerAccount, CustomerTransaction, SocialCommunityLinks } from '../types';
import { generateCustomerReceiptMessage, sendWhatsAppReceipt } from '../utils/receipt';

interface CustomerDetailViewProps {
  customer: CustomerAccount;
  settings?: AppSettings;
  socialLinks?: SocialCommunityLinks;
  onBack: () => void;
  onAddTransaction: (customerId: string, trx: CustomerTransaction) => void;
  onUpdateCustomerTransaction: (customerId: string, trx: CustomerTransaction) => void;
  onDeleteCustomerTransaction: (customerId: string, trxId: string) => void;
  onDeleteCustomer?: (customerId: string) => void;
}

export const CustomerDetailView: React.FC<CustomerDetailViewProps> = ({
  customer,
  settings,
  socialLinks,
  onBack,
  onAddTransaction,
  onUpdateCustomerTransaction,
  onDeleteCustomerTransaction,
  onDeleteCustomer,
}) => {
  const [searchItem, setSearchItem] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTrx, setEditingTrx] = useState<CustomerTransaction | null>(null);

  // Quick Deposit Modal state (for collecting payment on due later)
  const [quickDepositTrx, setQuickDepositTrx] = useState<CustomerTransaction | null>(null);
  const [quickDepositAmount, setQuickDepositAmount] = useState('');

  // Form State
  const [itemName, setItemName] = useState('');
  const [quantity, setQuantity] = useState('');
  const [buyPrice, setBuyPrice] = useState('');
  const [sellPrice, setSellPrice] = useState('');
  const [depositAmount, setDepositAmount] = useState('');
  const [profitInput, setProfitInput] = useState('');
  const [note, setNote] = useState('');
  const [sendReceiptOnSubmit, setSendReceiptOnSubmit] = useState(false);

  // ৪টি অপশন: কেনা, বিক্রি, জমা ও লাভ
  // গুরুত্বপূর্ণ: ব্যবহারকারী যে যে অপশনে ক্লিক করবে শুধু সেই অপশনগুলোর ইনপুট দেখাবে। ব্যবহারকারী চাইলে ১টি, ২টি বা সবকটি একসাথে সিলেক্ট করতে পারবেন।
  const [activeOptions, setActiveOptions] = useState<{
    buy: boolean;
    sell: boolean;
    deposit: boolean;
    profit: boolean;
  }>({
    buy: false,
    sell: true,
    deposit: false,
    profit: true,
  });

  const toggleOption = (opt: 'buy' | 'sell' | 'deposit' | 'profit') => {
    setActiveOptions((prev) => {
      const nextState = !prev[opt];
      if (!nextState) {
        if (opt === 'buy') setBuyPrice('');
        if (opt === 'sell') setSellPrice('');
        if (opt === 'deposit') setDepositAmount('');
        if (opt === 'profit') setProfitInput('');
      }
      return { ...prev, [opt]: nextState };
    });
  };

  const handleSelectAllOptions = () => {
    setActiveOptions({
      buy: true,
      sell: true,
      deposit: true,
      profit: true,
    });
  };

  const handleClearAllOptions = () => {
    setActiveOptions({
      buy: false,
      sell: false,
      deposit: false,
      profit: false,
    });
    setBuyPrice('');
    setSellPrice('');
    setDepositAmount('');
    setProfitInput('');
  };

  // Live calculation in form
  const numBuy = activeOptions.buy ? parseFloat(buyPrice) || 0 : 0;
  const numSell = activeOptions.sell ? parseFloat(sellPrice) || 0 : 0;
  // If customer doesn't pay, deposit is 0 and due = sellPrice (automatically set 'বাকি' = বিক্রি)
  const numDeposit = activeOptions.deposit ? parseFloat(depositAmount) || 0 : 0;
  const calculatedDue = numSell > 0 ? Math.max(0, numSell - numDeposit) : 0;
  const autoProfit = numBuy > 0 && numSell > 0 ? numSell - numBuy : 0;
  const calculatedProfit = activeOptions.profit && profitInput !== ''
    ? parseFloat(profitInput) || 0
    : autoProfit;

  // Totals for this customer
  const totalBuy = (customer.transactions || []).reduce((acc, t) => acc + (Number(t.buyPrice) || 0), 0);
  const totalSell = (customer.transactions || []).reduce((acc, t) => {
    if (t.itemName && t.itemName.includes('পূর্বের বাকি') && (Number(t.buyPrice) || 0) === 0) {
      return acc;
    }
    return acc + (Number(t.sellPrice) || 0);
  }, 0);
  const allCharges = (customer.transactions || []).reduce((acc, t) => acc + (Number(t.sellPrice) || 0), 0);
  const totalDeposit = (customer.transactions || []).reduce((acc, t) => acc + (Number(t.depositAmount) || 0), 0);
  // বাকি = মোট বিক্রি − মোট জমা (সঠিক গাণিতিক বিয়োগ)
  const totalDue = Math.max(0, allCharges - totalDeposit);
  // জমা আছে = মোট জমা − মোট বিক্রি (উদ্বৃত্ত জমা)
  const totalSurplus = Math.max(0, totalDeposit - allCharges);
  const totalProfit = (customer.transactions || []).reduce((acc, t) => {
    if (t.profit != null && t.profit !== undefined && t.profit !== 0) {
      return acc + Number(t.profit);
    }
    const buy = Number(t.buyPrice) || 0;
    const sell = Number(t.sellPrice) || 0;
    if (buy > 0 && sell > 0) {
      return acc + (sell - buy);
    }
    return acc;
  }, 0);

  // Resolve Admin Contact Number from dynamic Firestore settings
  const adminContactNumber =
    settings?.adminContactNumber ||
    socialLinks?.adminContactNumber ||
    socialLinks?.supportPhone ||
    '01712345678';

  const formatTk = (amount: number) => {
    if (amount < 0) {
      return `৳-${Math.abs(amount).toLocaleString('en-IN')}`;
    }
    return `৳${amount.toLocaleString('en-IN')}`;
  };

  // Helper to extract timestamp for customer transactions
  const getCustomerTrxTimestamp = (trx: CustomerTransaction): number => {
    if (trx.createdAtMs && typeof trx.createdAtMs === 'number') {
      return trx.createdAtMs;
    }
    const match = trx.id?.match(/CTX-(\d+)/);
    if (match && Number(match[1]) > 1000000000) {
      return Number(match[1]);
    }
    const parsed = Date.parse(trx.date);
    if (!isNaN(parsed)) return parsed;
    return 0;
  };

  // Sort transactions strictly descending (newest on top)
  const sortedTransactions = [...(customer.transactions || [])].sort(
    (a, b) => getCustomerTrxTimestamp(b) - getCustomerTrxTimestamp(a)
  );

  const filteredTransactions = sortedTransactions.filter(
    (t) =>
      t.itemName.toLowerCase().includes(searchItem.toLowerCase()) ||
      (t.quantity && t.quantity.toLowerCase().includes(searchItem.toLowerCase()))
  );

  const handleOpenAdd = () => {
    setEditingTrx(null);
    setItemName('');
    setQuantity('');
    setBuyPrice('');
    setSellPrice('');
    setDepositAmount('');
    setProfitInput('');
    setNote('');
    setSendReceiptOnSubmit(false);
    // এন্ট্রি করার জন্য ডিফল্টভাবে বিক্রি ও লাভ থাকবে। কেনা এবং জমা ফাঁকা ঘর যাতে অপ্রয়োজনীয়ভাবে ০০ না দেখায় তাই ডিফল্টভাবে হাইড থাকবে
    setActiveOptions({
      buy: false,
      sell: true,
      deposit: false,
      profit: true,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (trx: CustomerTransaction) => {
    setEditingTrx(trx);
    setItemName(trx.itemName);
    setQuantity(trx.quantity || '');
    const hasBuy = trx.buyPrice != null && Number(trx.buyPrice) > 0;
    const hasSell = trx.sellPrice != null && Number(trx.sellPrice) > 0;
    const hasDeposit = trx.depositAmount != null && Number(trx.depositAmount) > 0;
    const hasProfit = (trx.profit != null && Number(trx.profit) !== 0) || (hasBuy && hasSell);

    setBuyPrice(hasBuy ? trx.buyPrice.toString() : '');
    setSellPrice(hasSell ? trx.sellPrice.toString() : '');
    setDepositAmount(hasDeposit ? trx.depositAmount.toString() : '');
    setProfitInput(trx.profit != null ? trx.profit.toString() : '');
    setNote(trx.note || '');
    setSendReceiptOnSubmit(false);

    setActiveOptions({
      buy: hasBuy,
      sell: hasSell,
      deposit: hasDeposit,
      profit: hasProfit,
    });
    setIsModalOpen(true);
  };

  const handleSetFullDue = () => {
    setDepositAmount('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemName.trim()) return;

    const bPrice = activeOptions.buy ? parseFloat(buyPrice) || 0 : 0;
    const sPrice = activeOptions.sell ? parseFloat(sellPrice) || 0 : 0;
    const dAmount = activeOptions.deposit ? parseFloat(depositAmount) || 0 : 0;
    const due = sPrice > 0 ? Math.max(0, sPrice - dAmount) : 0;
    const profit = calculatedProfit;

    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
    const dateStr = now.toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'short',
    });

    if (editingTrx) {
      onUpdateCustomerTransaction(customer.id, {
        ...editingTrx,
        itemName: itemName.trim(),
        quantity,
        buyPrice: bPrice,
        sellPrice: sPrice,
        depositAmount: dAmount,
        dueAmount: due,
        profit: profit,
        note,
      });
    } else {
      const newTrx: CustomerTransaction = {
        id: `CTX-${Date.now()}`,
        itemName: itemName.trim(),
        quantity: quantity || '১ টি',
        buyPrice: bPrice,
        sellPrice: sPrice,
        depositAmount: dAmount,
        dueAmount: due,
        profit: profit,
        date: dateStr,
        time: timeStr,
        note,
        createdAtMs: Date.now(),
      };
      onAddTransaction(customer.id, newTrx);

      // If user enabled WhatsApp receipt on submit, trigger receipt strictly once
      if (sendReceiptOnSubmit) {
        const newTotalSell = allCharges + sPrice;
        const newTotalDeposit = totalDeposit + dAmount;

        const receiptMsg = generateCustomerReceiptMessage(
          customer.name,
          newTotalSell,
          newTotalDeposit,
          adminContactNumber
        );
        sendWhatsAppReceipt(customer.phone, receiptMsg);
      }
    }
    setIsModalOpen(false);
  };

  // Quick Deposit Handler: "পরে টাকা দিলে জমায় যোগ হবে এবং বাকি অটোমেটিক কমে যাবে। সম্পূর্ণ টাকা দিলে বাকি ০ হয়ে Paid/Success দেখাতে পারে।"
  const handleOpenQuickDeposit = (trx: CustomerTransaction) => {
    setQuickDepositTrx(trx);
    setQuickDepositAmount('');
  };

  const handleApplyQuickDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickDepositTrx) return;
    const addedAmount = parseFloat(quickDepositAmount) || 0;
    if (addedAmount <= 0) return;

    const currentDeposit = Number(quickDepositTrx.depositAmount) || 0;
    const currentSell = Number(quickDepositTrx.sellPrice) || 0;
    const newDeposit = currentDeposit + addedAmount;
    const newDue = Math.max(0, currentSell - newDeposit);

    onUpdateCustomerTransaction(customer.id, {
      ...quickDepositTrx,
      depositAmount: newDeposit,
      dueAmount: newDue,
    });

    setQuickDepositTrx(null);
    setQuickDepositAmount('');
  };

  const handleSendWhatsAppReceiptMessage = () => {
    const message = generateCustomerReceiptMessage(
      customer.name,
      allCharges,
      totalDeposit,
      adminContactNumber
    );
    sendWhatsAppReceipt(customer.phone, message);
  };

  const handleShare = () => {
    const message = generateCustomerReceiptMessage(
      customer.name,
      allCharges,
      totalDeposit,
      adminContactNumber
    );
    if (navigator.share) {
      navigator
        .share({
          title: `M APPS টেলিকম - ${customer.name} রসিদ`,
          text: message,
        })
        .catch(() => {});
    } else {
      navigator.clipboard.writeText(message);
      alert('রসিদের বার্তা ক্লিপবোর্ডে কপি করা হয়েছে!');
    }
  };

  const dotColors = ['bg-sky-500', 'bg-rose-500', 'bg-emerald-500', 'bg-amber-500', 'bg-purple-500'];

  return (
    <div className="w-full bg-[#f8fafc] pb-8 animate-fadeIn text-slate-900">
      {/* Top Violet Header matching all 3 Tally Pages */}
      <div
        className="bg-gradient-to-r from-[#1e1b4b] via-[#312e81] to-[#4338ca] text-white px-5 pb-5 rounded-b-[28px] shadow-md shadow-indigo-950/15"
        style={{
          paddingTop: 'max(14px, calc(env(safe-area-inset-top, 0px) + 10px))',
        }}
      >
        <div className="flex items-center justify-between mb-3">
          <button
            type="button"
            onClick={onBack}
            className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors cursor-pointer"
            title="ফিরে যান"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleShare}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white font-bold text-xs sm:text-sm transition-colors cursor-pointer border border-white/20 shadow-xs"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>রসিদ শেয়ার</span>
            </button>

            <button
              type="button"
              onClick={handleSendWhatsAppReceiptMessage}
              title="হোয়াটসঅ্যাপে তাৎক্ষণিক রসিদ পাঠান"
              className="w-8 h-8 rounded-full bg-emerald-500 hover:bg-emerald-600 flex items-center justify-center text-white cursor-pointer transition-colors shadow-xs"
            >
              <MessageCircle className="w-4 h-4" />
            </button>

            {onDeleteCustomer && (
              <button
                type="button"
                onClick={() => {
                  if (window.confirm(`আপনি কি নিশ্চিত যে কাস্টমার '${customer.name}' ডিলিট করতে চান?`)) {
                    onDeleteCustomer(customer.id);
                  }
                }}
                title="কাস্টমার ডিলিট করুন"
                className="w-8 h-8 rounded-full bg-rose-500/80 hover:bg-rose-600 flex items-center justify-center text-white cursor-pointer transition-colors shadow-xs"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Customer Profile Row */}
        <div className="flex items-center gap-3.5 mb-3">
          <div className="w-14 h-14 rounded-full bg-white/20 border-2 border-white/50 flex items-center justify-center text-white font-black text-xl shadow-md shrink-0">
            {customer.avatarText || customer.name.charAt(0)}
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-white leading-tight">
              {customer.name}
            </h1>
            <span className="text-xs sm:text-sm text-indigo-200 font-mono block mt-0.5 font-medium">
              {customer.phone}
            </span>
          </div>
        </div>

        {/* Search Bar matching all other screens */}
        <div className="bg-white rounded-2xl p-2 px-3 flex items-center gap-2 shadow-xs">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            value={searchItem}
            onChange={(e) => setSearchItem(e.target.value)}
            placeholder="পণ্য বা লেনদেনের বিবরণ দিয়ে খুঁজুন"
            className="w-full text-xs sm:text-sm font-semibold text-slate-800 outline-none placeholder:text-slate-400"
          />
        </div>
      </div>

      {/* ৫টি সুসংগঠিত সামারি কার্ড (মোট কেনা, মোট বিক্রি, মোট লাভ, মোট জমা, মোট বাকি) */}
      <div className="px-4 -mt-3">
        <div className="bg-white rounded-3xl p-3.5 shadow-md border border-slate-100 space-y-2.5">
          {/* Row 1: মোট কেনা, মোট বিক্রি, মোট লাভ */}
          <div className="grid grid-cols-3 gap-2 text-center">
            {/* মোট কেনা */}
            <div className="flex flex-col items-center justify-center p-2 rounded-2xl bg-indigo-50/60 border border-indigo-100/50">
              <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center mb-1 shadow-2xs">
                <ShoppingCart className="w-4 h-4 stroke-[2.5]" />
              </div>
              <span className="text-[11px] font-bold text-slate-600">মোট কেনা</span>
              <span className="text-xs sm:text-sm font-black text-indigo-700 mt-0.5 tracking-tight">
                {formatTk(totalBuy)}
              </span>
              <span className="text-[9px] text-slate-400 font-medium">ক্রয় মূল্য</span>
            </div>

            {/* মোট বিক্রি */}
            <div className="flex flex-col items-center justify-center p-2 rounded-2xl bg-rose-50/60 border border-rose-100/50">
              <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center mb-1 shadow-2xs">
                <ShoppingCart className="w-4 h-4 stroke-[2.5]" />
              </div>
              <span className="text-[11px] font-bold text-slate-600">মোট বিক্রি</span>
              <span className="text-xs sm:text-sm font-black text-rose-600 mt-0.5 tracking-tight">
                {formatTk(totalSell)}
              </span>
              <span className="text-[9px] text-slate-400 font-medium">বিক্রয় মূল্য</span>
            </div>

            {/* মোট লাভ */}
            <div className="flex flex-col items-center justify-center p-2 rounded-2xl bg-emerald-50/60 border border-emerald-100/50">
              <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center mb-1 shadow-2xs">
                <Wallet className="w-4 h-4 stroke-[2.5]" />
              </div>
              <span className="text-[11px] font-bold text-slate-600">মোট লাভ</span>
              <span className="text-xs sm:text-sm font-black text-emerald-600 mt-0.5 tracking-tight">
                {totalProfit >= 0 ? `+${formatTk(totalProfit)}` : formatTk(totalProfit)}
              </span>
              <span className="text-[9px] text-emerald-600 font-medium">প্রফিট</span>
            </div>
          </div>

          {/* Row 2: মোট জমা ও মোট বাকি */}
          <div className="grid grid-cols-2 gap-2 text-center">
            {/* মোট জমা */}
            <div className="flex items-center justify-between p-2.5 px-3 rounded-2xl bg-emerald-50/50 border border-emerald-100/60">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center shadow-2xs">
                  <Wallet className="w-3.5 h-3.5 stroke-[2.5]" />
                </div>
                <div className="text-left">
                  <span className="text-[11px] font-bold text-slate-600 block leading-tight">মোট জমা</span>
                  <span className="text-[9px] text-slate-400 font-medium">প্রাপ্ত নগদ</span>
                </div>
              </div>
              <span className="text-xs sm:text-sm font-black text-emerald-600 tracking-tight">
                {formatTk(totalDeposit)}
              </span>
            </div>

            {/* মোট বাকি অথবা জমা আছে */}
            {totalDue > 0 || totalSurplus === 0 ? (
              <div className="flex items-center justify-between p-2.5 px-3 rounded-2xl bg-amber-50/50 border border-amber-100/60">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center shadow-2xs">
                    <CreditCard className="w-3.5 h-3.5 stroke-[2.5]" />
                  </div>
                  <div className="text-left">
                    <span className="text-[11px] font-bold text-slate-600 block leading-tight">মোট বাকি</span>
                    <span className="text-[9px] text-slate-400 font-medium">পাওনা টাকা</span>
                  </div>
                </div>
                <span className="text-xs sm:text-sm font-black text-amber-600 tracking-tight">
                  {formatTk(totalDue)}
                </span>
              </div>
            ) : (
              <div className="flex items-center justify-between p-2.5 px-3 rounded-2xl bg-emerald-50/60 border border-emerald-200/80 shadow-2xs">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center shadow-2xs">
                    <Coins className="w-3.5 h-3.5 stroke-[2.5]" />
                  </div>
                  <div className="text-left">
                    <span className="text-[11px] font-bold text-slate-600 block leading-tight">জমা আছে</span>
                    <span className="text-[9px] text-emerald-600 font-medium">উদ্বৃত্ত জমা</span>
                  </div>
                </div>
                <span className="text-xs sm:text-sm font-black text-emerald-600 tracking-tight">
                  +{formatTk(totalSurplus)}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Action Buttons: WhatsApp Reminder & Add Transaction */}
      <div className="px-4 mt-3.5 flex items-center gap-2.5">
        <button
          type="button"
          onClick={handleOpenAdd}
          className="flex-1 py-3.5 sm:py-4 bg-[#4323d4] hover:bg-[#371cb8] text-white font-black text-sm sm:text-base rounded-2xl shadow-lg shadow-indigo-600/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer"
        >
          <Plus className="w-5 h-5" />
          <span>নতুন লেনদেন যোগ করুন</span>
        </button>

        <button
          type="button"
          onClick={handleSendWhatsAppReceiptMessage}
          title="WhatsApp এ অফিসিয়াল রসিদ পাঠান"
          className="py-3.5 sm:py-4 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl shadow-md transition-colors flex items-center justify-center cursor-pointer gap-1.5 font-bold text-xs sm:text-sm"
        >
          <MessageCircle className="w-4 h-4" />
          <span>রসিদ</span>
        </button>
      </div>

      {/* Customer Itemized Transactions List */}
      <div className="px-4 mt-4 space-y-3">
        <div className="flex items-center justify-between mb-1">
          <h2 className="text-sm sm:text-base font-extrabold text-slate-900">
            লেনদেন বিবরণী
          </h2>
          <span className="text-xs font-semibold text-slate-500">
            মোট লেনদেন: {filteredTransactions.length}
          </span>
        </div>

        {filteredTransactions.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-3xl border border-slate-200 text-slate-400 text-xs">
            এই গ্রাহকের কোনো লেনদেন নেই
          </div>
        ) : (
          filteredTransactions.map((trx, idx) => {
            const dotColor = dotColors[idx % dotColors.length];
            const itemBuy = Number(trx.buyPrice) || 0;
            const itemSell = Number(trx.sellPrice) || 0;
            const itemDeposit = Number(trx.depositAmount) || 0;
            const itemDue = Number(trx.dueAmount) || 0;
            const hasBuy = itemBuy > 0;
            const hasSell = itemSell > 0;
            const hasDeposit = itemDeposit > 0;
            const hasDue = itemDue > 0;
            const hasBothPrices = itemBuy > 0 && itemSell > 0;
            const itemProfit = trx.profit != null && trx.profit !== undefined && trx.profit !== 0
              ? Number(trx.profit)
              : (hasBothPrices ? itemSell - itemBuy : 0);
            const isPaid = hasSell && itemDue === 0 && itemDeposit > 0;

            return (
              <div
                key={trx.id}
                className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden hover:border-indigo-200 transition-all"
              >
                {/* Main Card Body */}
                <div className="p-3.5 space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    {/* Left: Avatar + Title + Quantity/Time */}
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <div className="w-11 h-11 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-600 font-black text-sm">
                          <User className="w-5 h-5 text-slate-500" />
                        </div>
                        <div
                          className={`w-2.5 h-2.5 rounded-full ${dotColor} absolute -left-1 top-1/2 -translate-y-1/2`}
                        />
                      </div>

                      <div>
                        <h3 className="text-sm font-black text-slate-900 leading-tight">
                          {trx.itemName}
                        </h3>
                        <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                          {trx.quantity && <span>পরিমাণ: {trx.quantity}</span>}
                          <span>সময়: {trx.time}</span>
                        </div>
                      </div>
                    </div>

                    {/* Right: বিক্রির ক্ষেত্রে মূল Card/Banner-এ শুধু অফারের বিক্রয় মূল্য ও লাভ দেখাবে */}
                    <div className="flex items-center gap-2">
                      {hasSell ? (
                        <div className="text-right">
                          <span className="text-[10px] text-slate-400 font-bold block">বিক্রয় মূল্য</span>
                          <span className="text-sm font-black text-rose-600 tracking-tight leading-none">
                            {formatTk(trx.sellPrice)}
                          </span>
                          {itemProfit !== 0 && (
                            <span
                              className={`text-[10px] font-black px-1.5 py-0.5 rounded-md inline-flex items-center gap-0.5 mt-1 ${
                                itemProfit >= 0
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/80'
                                  : 'bg-rose-50 text-rose-700 border border-rose-200/80'
                              }`}
                            >
                              <TrendingUp className="w-2.5 h-2.5" />
                              <span>{itemProfit >= 0 ? `লাভ: +${formatTk(itemProfit)}` : `ক্ষতি: ${formatTk(itemProfit)}`}</span>
                            </span>
                          )}
                        </div>
                      ) : hasBothPrices ? (
                        <span
                          className={`text-[11px] font-black px-2.5 py-1 rounded-xl flex items-center gap-1 ${
                            itemProfit >= 0
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/80'
                              : 'bg-rose-50 text-rose-700 border border-rose-200/80'
                          }`}
                        >
                          <TrendingUp className="w-3 h-3" />
                          <span>{itemProfit >= 0 ? `লাভ: +${formatTk(itemProfit)}` : `ক্ষতি: ${formatTk(itemProfit)}`}</span>
                        </span>
                      ) : null}

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(trx)}
                          className="w-8 h-8 rounded-lg bg-slate-50 hover:bg-indigo-50 text-indigo-600 flex items-center justify-center transition-colors cursor-pointer"
                          title="সম্পাদনা করুন"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() => onDeleteCustomerTransaction(customer.id, trx.id)}
                          className="w-8 h-8 rounded-lg bg-slate-50 hover:bg-rose-50 text-rose-500 flex items-center justify-center transition-colors cursor-pointer"
                          title="মুছে ফেলুন"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Financial Breakdown Row: যে তথ্য ইনপুট দেওয়া হয়নি সম্পূর্ণ Hide থাকবে। বাকি থাকলে বাকি দেখাবে, পেইড হলে অটোমেটিক হাইড হয়ে যাবে */}
                  {(hasBuy || hasDeposit || hasDue) && (
                    <div className="pt-2 border-t border-slate-100 flex items-center gap-1.5 text-center text-xs flex-wrap">
                      {hasBuy && (
                        <div className="flex-1 min-w-[70px] p-1.5 rounded-xl bg-slate-50 border border-slate-100/80">
                          <span className="text-[10px] text-slate-400 block font-medium">কেনা</span>
                          <span className="font-extrabold text-slate-700 truncate block">
                            {formatTk(trx.buyPrice)}
                          </span>
                        </div>
                      )}

                      {hasDeposit && (
                        <div className="flex-1 min-w-[70px] p-1.5 rounded-xl bg-emerald-50/60 border border-emerald-100/60">
                          <span className="text-[10px] text-emerald-600 block font-medium">জমা</span>
                          <span className="font-extrabold text-emerald-600 truncate block">
                            {formatTk(trx.depositAmount)}
                          </span>
                        </div>
                      )}

                      {hasDue && (
                        <div className="flex-1 min-w-[80px] p-1.5 rounded-xl bg-amber-50/60 border border-amber-200/70">
                          <span className="text-[10px] text-amber-700 block font-bold">বাকি/অবশিষ্ট</span>
                          <span className="font-black text-amber-600 truncate block">
                            {formatTk(trx.dueAmount)}
                          </span>
                        </div>
                      )}

                      {hasDue && (
                        <button
                          type="button"
                          onClick={() => handleOpenQuickDeposit(trx)}
                          className="px-2.5 py-1.5 rounded-xl bg-emerald-50 text-emerald-700 hover:bg-emerald-100 font-bold transition-colors cursor-pointer border border-emerald-200 flex items-center gap-1 text-[11px] shrink-0"
                          title="টাকা জমা নিন এবং বাকি কমান"
                        >
                          <Coins className="w-3 h-3 text-emerald-600" />
                          <span>+ জমা নিন</span>
                        </button>
                      )}
                    </div>
                  )}

                  {/* Optional Note */}
                  {trx.note && (
                    <div className="text-xs bg-slate-50 p-2 rounded-xl text-slate-600 font-medium">
                      নোট: {trx.note}
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Quick Deposit Modal for Customer: "পরে টাকা দিলে জমায় যোগ হবে এবং বাকি অটোমেটিক কমে যাবে" */}
      {quickDepositTrx && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
          style={{
            paddingTop: 'max(16px, calc(env(safe-area-inset-top, 0px) + 12px))',
            paddingBottom: 'max(16px, calc(env(safe-area-inset-bottom, 0px) + 16px))',
          }}
        >
          <div className="bg-white rounded-3xl max-w-[360px] w-full p-5 shadow-2xl border border-slate-100 animate-fadeIn space-y-3 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <Coins className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">টাকা জমা নিন</h3>
                  <p className="text-[11px] text-slate-500">{customer.name} • {quickDepositTrx.itemName}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setQuickDepositTrx(null)}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-between">
              <span className="text-xs font-bold text-amber-800">বর্তমান বাকি:</span>
              <span className="text-sm font-black text-amber-700">{formatTk(quickDepositTrx.dueAmount)}</span>
            </div>

            <form onSubmit={handleApplyQuickDeposit} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">জমা টাকার পরিমাণ (৳) *</label>
                <input
                  type="number"
                  required
                  autoFocus
                  value={quickDepositAmount}
                  onChange={(e) => setQuickDepositAmount(e.target.value)}
                  placeholder={`যেমন: ${quickDepositTrx.dueAmount}`}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-black text-emerald-600 text-base outline-none focus:border-emerald-600"
                />
              </div>

              {/* One-click full pay button */}
              <button
                type="button"
                onClick={() => setQuickDepositAmount(String(quickDepositTrx.dueAmount))}
                className="w-full py-1.5 bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold rounded-xl text-xs hover:bg-emerald-100 cursor-pointer"
              >
                পুরো বাকি {formatTk(quickDepositTrx.dueAmount)} একবারে পরিশোধ
              </button>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md shadow-emerald-600/25 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>জমা সংরক্ষণ করুন ও বাকি কমান</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
          style={{
            paddingTop: 'max(16px, calc(env(safe-area-inset-top, 0px) + 12px))',
            paddingBottom: 'max(16px, calc(env(safe-area-inset-bottom, 0px) + 16px))',
          }}
        >
          <div className="bg-white rounded-3xl max-w-[400px] w-full p-5 shadow-2xl border border-slate-100 animate-fadeIn space-y-3.5 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-black text-slate-900 text-base">
                {editingTrx ? 'লেনদেন সম্পাদনা' : 'গ্রাহকের নতুন লেনদেন'}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3 text-xs">
              {/* পণ্যের নাম বা অফার */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">পণ্যের নাম বা অফার *</label>
                <input
                  type="text"
                  required
                  value={itemName}
                  onChange={(e) => setItemName(e.target.value)}
                  placeholder="যেমন: চাল, সয়াবিন তেল বা GP 30GB প্যাক"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-indigo-600"
                />
              </div>

              {/* পরিমাণ / বিবরণ */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">পরিমাণ / বিবরণ (ঐচ্ছিক)</label>
                <input
                  type="text"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  placeholder="যেমন: ৫ কেজি, ১ লিটার বা ১টি"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-indigo-600"
                />
              </div>

              {/* ৪টি অপশন সিলেকশন বার: কেনা, বিক্রি, জমা ও লাভ */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-bold text-slate-700 block">
                    হিসাবের অপশন নির্বাচন করুন:
                  </label>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={handleSelectAllOptions}
                      className="text-[10px] font-black text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 px-2 py-0.5 rounded-md cursor-pointer transition-colors"
                    >
                      সব সিলেক্ট
                    </button>
                    <button
                      type="button"
                      onClick={handleClearAllOptions}
                      className="text-[10px] font-bold text-slate-500 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 px-1.5 py-0.5 rounded-md cursor-pointer transition-colors"
                    >
                      ক্লিয়ার
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-1.5 text-center">
                  {/* ১. কেনা */}
                  <button
                    type="button"
                    onClick={() => toggleOption('buy')}
                    className={`py-2 px-1 rounded-xl font-black text-xs transition-all border cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
                      activeOptions.buy
                        ? 'bg-indigo-600 text-white border-indigo-700 shadow-sm'
                        : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                    }`}
                  >
                    <span>🛒 কেনা</span>
                    <span className="text-[9px] opacity-80">{activeOptions.buy ? '✓ সক্রিয়' : '+ যোগ'}</span>
                  </button>

                  {/* ২. বিক্রি */}
                  <button
                    type="button"
                    onClick={() => toggleOption('sell')}
                    className={`py-2 px-1 rounded-xl font-black text-xs transition-all border cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
                      activeOptions.sell
                        ? 'bg-rose-600 text-white border-rose-700 shadow-sm'
                        : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                    }`}
                  >
                    <span>🛍️ বিক্রি</span>
                    <span className="text-[9px] opacity-80">{activeOptions.sell ? '✓ সক্রিয়' : '+ যোগ'}</span>
                  </button>

                  {/* ৩. জমা */}
                  <button
                    type="button"
                    onClick={() => toggleOption('deposit')}
                    className={`py-2 px-1 rounded-xl font-black text-xs transition-all border cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
                      activeOptions.deposit
                        ? 'bg-emerald-600 text-white border-emerald-700 shadow-sm'
                        : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                    }`}
                  >
                    <span>💵 জমা</span>
                    <span className="text-[9px] opacity-80">{activeOptions.deposit ? '✓ সক্রিয়' : '+ যোগ'}</span>
                  </button>

                  {/* ৪. লাভ */}
                  <button
                    type="button"
                    onClick={() => toggleOption('profit')}
                    className={`py-2 px-1 rounded-xl font-black text-xs transition-all border cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
                      activeOptions.profit
                        ? 'bg-purple-600 text-white border-purple-700 shadow-sm'
                        : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                    }`}
                  >
                    <span>📈 লাভ</span>
                    <span className="text-[9px] opacity-80">{activeOptions.profit ? '✓ সক্রিয়' : '+ যোগ'}</span>
                  </button>
                </div>
              </div>

              {/* Dynamic Inputs: ব্যবহারকারী যে অপশনে ক্লিক করবে শুধু সেই অপশনের ইনপুট দেখাবে। কোনো ফাঁকা বক্স দেখানো যাবে না */}
              <div className="space-y-2.5">
                {/* কেনা মূল্য */}
                {activeOptions.buy && (
                  <div className="p-3 bg-indigo-50/60 border border-indigo-200/80 rounded-2xl animate-fadeIn">
                    <div className="flex items-center justify-between mb-1">
                      <label className="font-bold text-indigo-950">কেনা দাম (৳)</label>
                      <span className="text-[10px] text-indigo-600 font-bold">ক্রয় খরচ</span>
                    </div>
                    <input
                      type="number"
                      autoFocus
                      value={buyPrice}
                      onChange={(e) => setBuyPrice(e.target.value)}
                      placeholder="কেনা দাম লিখুন"
                      className="w-full p-2 bg-white border border-indigo-200 rounded-xl font-bold text-slate-900 outline-none focus:border-indigo-600"
                    />
                  </div>
                )}

                {/* বিক্রি মূল্য */}
                {activeOptions.sell && (
                  <div className="p-3 bg-rose-50/60 border border-rose-200/80 rounded-2xl animate-fadeIn">
                    <div className="flex items-center justify-between mb-1">
                      <label className="font-bold text-rose-950">বিক্রি মূল্য (৳)</label>
                      <span className="text-[10px] text-rose-600 font-bold">বিক্রয় মূল্য</span>
                    </div>
                    <input
                      type="number"
                      value={sellPrice}
                      onChange={(e) => setSellPrice(e.target.value)}
                      placeholder="অফারের বিক্রয় মূল্য লিখুন"
                      className="w-full p-2 bg-white border border-rose-200 rounded-xl font-bold text-rose-600 outline-none focus:border-rose-600"
                    />
                  </div>
                )}

                {/* জমা টাকা */}
                {activeOptions.deposit && (
                  <div className="p-3 bg-emerald-50/60 border border-emerald-200/80 rounded-2xl animate-fadeIn space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="font-bold text-emerald-950">জমা (৳)</label>
                      <button
                        type="button"
                        onClick={handleSetFullDue}
                        className="text-[10px] font-bold text-amber-700 bg-amber-100/80 px-2 py-0.5 rounded cursor-pointer hover:bg-amber-200"
                      >
                        পুরো বাকি
                      </button>
                    </div>
                    <input
                      type="number"
                      value={depositAmount}
                      onChange={(e) => setDepositAmount(e.target.value)}
                      placeholder="কাস্টমার কত টাকা জমা দিয়েছেন লিখুন"
                      className="w-full p-2 bg-white border border-emerald-200 rounded-xl font-bold text-emerald-600 outline-none focus:border-emerald-600"
                    />
                  </div>
                )}

                {/* লাভ ইনপুট / অটো হিসাব */}
                {activeOptions.profit && (
                  <div className="p-3 bg-purple-50/60 border border-purple-200/80 rounded-2xl animate-fadeIn">
                    <div className="flex items-center justify-between mb-1">
                      <label className="font-bold text-purple-950">লাভ / প্রফিট (৳)</label>
                      <span className="text-[10px] text-purple-600 font-bold">
                        {numBuy > 0 && numSell > 0 ? `অটো হিসাব: ${formatTk(autoProfit)}` : 'ম্যানুয়াল বা কাস্টম'}
                      </span>
                    </div>
                    <input
                      type="number"
                      value={profitInput !== '' ? profitInput : (autoProfit !== 0 ? String(autoProfit) : '')}
                      onChange={(e) => setProfitInput(e.target.value)}
                      placeholder={autoProfit !== 0 ? String(autoProfit) : 'লাভের পরিমাণ লিখুন'}
                      className="w-full p-2 bg-white border border-purple-200 rounded-xl font-bold text-purple-700 outline-none focus:border-purple-600"
                    />
                  </div>
                )}

                {/* কোনো অপশন সক্রিয় না থাকলে নির্দেশিকা */}
                {!activeOptions.buy && !activeOptions.sell && !activeOptions.deposit && !activeOptions.profit && (
                  <div className="p-4 text-center rounded-2xl bg-slate-50 border border-dashed border-slate-200 text-slate-400">
                    উপরের ৪টি অপশন (কেনা / বিক্রি / জমা / লাভ) থেকে ক্লিক করে হিসাবের তথ্য যোগ করুন।
                  </div>
                )}
              </div>

              {/* অটোমেটিক বাকি স্ট্যাটাস প্রিভিউ: কাস্টমার বাকি রাখলে দেখাবে, পেইড হলে অটোমেটিক হাইড হয়ে যাবে */}
              {numSell > 0 && calculatedDue > 0 && (
                <div className="p-3 rounded-2xl border space-y-1 bg-amber-50/70 border-amber-200">
                  <div className="flex items-center justify-between">
                    <span className="text-amber-800 font-bold text-xs">বাকি / অবশিষ্ট:</span>
                    <span className="font-black text-sm text-amber-600">
                      {formatTk(calculatedDue)}
                    </span>
                  </div>
                  <p className="text-[10px] text-amber-700 font-semibold pt-1 border-t border-amber-200/80">
                    কাস্টমার বাকি রেখেছেন, তাই বাকি ঘরে অটোমেটিক ৳{calculatedDue.toLocaleString('en-IN')} যোগ হবে।
                  </p>
                </div>
              )}

              {/* নোট বা মন্তব্য */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">নোট বা মন্তব্য (ঐচ্ছিক)</label>
                <input
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="যেমন: কাল বাকি পরিশোধ করবে"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 outline-none focus:border-indigo-600"
                />
              </div>

              {!editingTrx && (
                <label className="flex items-center gap-2 p-2.5 bg-emerald-50/70 border border-emerald-200 rounded-xl cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={sendReceiptOnSubmit}
                    onChange={(e) => setSendReceiptOnSubmit(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded-md focus:ring-0 cursor-pointer"
                  />
                  <span className="text-[11px] font-bold text-emerald-950 flex items-center gap-1">
                    <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                    <span>লেনদেন সম্পন্ন হলে WhatsApp এ রসিদ পাঠান</span>
                  </span>
                </label>
              )}

              <button
                type="submit"
                className="w-full py-3.5 bg-[#4323d4] hover:bg-[#2e1ea8] text-white font-extrabold text-xs rounded-xl shadow-md shadow-indigo-700/20 flex items-center justify-center gap-1.5 transition-all mt-2 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{editingTrx ? 'হিসাব আপডেট করুন' : 'হিসাব সংরক্ষণ করুন'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
