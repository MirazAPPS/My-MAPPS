import React from 'react';
import { OperatorType } from '../types';

interface LogoProps {
  className?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | number;
}

const getSizeClass = (size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | number, defaultClass = 'w-10 h-10'): string => {
  if (!size) return defaultClass;
  if (typeof size === 'number') return `w-[${size}px] h-[${size}px]`;
  switch (size) {
    case 'xs':
      return 'w-6 h-6';
    case 'sm':
      return 'w-8 h-8';
    case 'md':
      return 'w-10 h-10';
    case 'lg':
      return 'w-12 h-12';
    case 'xl':
      return 'w-14 h-14';
    default:
      return defaultClass;
  }
};

/**
 * Grameenphone (GP) - Iconic 3-Petal Blue Propeller Flower Logo
 */
export const GPLogo: React.FC<LogoProps> = ({ className, size }) => {
  const sizeClass = getSizeClass(size, 'w-10 h-10');
  return (
    <div
      className={`relative flex items-center justify-center rounded-2xl bg-white border border-sky-100 shadow-xs shrink-0 overflow-hidden ${sizeClass} ${className || ''}`}
      title="গ্রামীণফোন (GP)"
    >
      <svg viewBox="0 0 100 100" className="w-[84%] h-[84%] drop-shadow-xs" fill="none">
        {/* Top Left Petal */}
        <path
          d="M50 50 C 35 32, 22 20, 36 8 C 50 -4, 62 14, 50 50 Z"
          fill="url(#gpGrad1)"
        />
        {/* Top Right Petal */}
        <path
          d="M50 50 C 68 35, 82 22, 94 36 C 106 50, 88 62, 50 50 Z"
          fill="url(#gpGrad2)"
        />
        {/* Bottom Petal */}
        <path
          d="M50 50 C 42 70, 36 86, 20 82 C 4 78, 14 58, 50 50 Z"
          fill="url(#gpGrad3)"
        />
        {/* Gradients */}
        <defs>
          <linearGradient id="gpGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00c8ff" />
            <stop offset="100%" stopColor="#0077c8" />
          </linearGradient>
          <linearGradient id="gpGrad2" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#0099e6" />
            <stop offset="100%" stopColor="#005599" />
          </linearGradient>
          <linearGradient id="gpGrad3" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#0070ba" />
            <stop offset="100%" stopColor="#003d73" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
};

export const GrameenphoneLogo = GPLogo;

/**
 * Robi - Iconic 3D Origami Diamond / Flame Polyhedron Logo
 */
export const RobiLogo: React.FC<LogoProps> = ({ className, size }) => {
  const sizeClass = getSizeClass(size, 'w-10 h-10');
  return (
    <div
      className={`relative flex items-center justify-center rounded-2xl bg-white border border-rose-100 shadow-xs shrink-0 overflow-hidden ${sizeClass} ${className || ''}`}
      title="রবি (Robi)"
    >
      <svg viewBox="0 0 100 100" className="w-[82%] h-[82%] drop-shadow-xs">
        {/* Facet 1 - Top Center Red */}
        <polygon points="50,12 24,68 50,54" fill="#E60000" />
        {/* Facet 2 - Top Right Orange */}
        <polygon points="50,12 76,68 50,54" fill="#FF4D00" />
        {/* Facet 3 - Bottom Left Dark Maroon */}
        <polygon points="24,68 50,88 50,54" fill="#990000" />
        {/* Facet 4 - Bottom Right Amber */}
        <polygon points="76,68 50,88 50,54" fill="#FF9900" />
        {/* Facet 5 - Inner Highlights */}
        <polygon points="50,12 50,54 36,40" fill="#FF1F1F" />
        <polygon points="50,12 64,40 50,54" fill="#FF7700" />
        {/* Central Core Reflection */}
        <polygon points="50,54 38,62 50,74" fill="#CC0000" />
        <polygon points="50,54 62,62 50,74" fill="#FF8800" />
      </svg>
    </div>
  );
};

/**
 * Banglalink - Iconic Tiger Slash / Stripes Vibrant Orange Logo
 */
export const BanglalinkLogo: React.FC<LogoProps> = ({ className, size }) => {
  const sizeClass = getSizeClass(size, 'w-10 h-10');
  return (
    <div
      className={`relative flex items-center justify-center rounded-2xl bg-gradient-to-tr from-[#ff5500] to-[#ff7700] border border-orange-400 shadow-xs shrink-0 overflow-hidden ${sizeClass} ${className || ''}`}
      title="বাংলালিংক (Banglalink)"
    >
      <svg viewBox="0 0 100 100" className="w-full h-full p-1.5">
        {/* Tiger stripes in dynamic diagonal slash */}
        <path d="M16 12 L 32 12 L 20 88 L 6 88 Z" fill="#18181b" />
        <path d="M42 12 L 58 12 L 44 88 L 30 88 Z" fill="#18181b" />
        <path d="M68 12 L 84 12 L 68 88 L 54 88 Z" fill="#18181b" />
        <path d="M92 12 L 98 12 L 90 88 L 78 88 Z" fill="#18181b" />
        {/* Subtle BL brand text highlight */}
        <rect x="22" y="38" width="56" height="24" rx="6" fill="#ffffff" opacity="0.92" />
        <text
          x="50"
          y="55"
          fontFamily="system-ui, -apple-system, sans-serif"
          fontWeight="900"
          fontSize="17"
          fill="#ff5500"
          textAnchor="middle"
          letterSpacing="-0.5"
        >
          bl
        </text>
      </svg>
    </div>
  );
};

/**
 * Airtel - Iconic Red Circle with Fluid White Loop 'a' Logo
 */
export const AirtelLogo: React.FC<LogoProps> = ({ className, size }) => {
  const sizeClass = getSizeClass(size, 'w-10 h-10');
  return (
    <div
      className={`relative flex items-center justify-center rounded-2xl bg-white border border-rose-100 shadow-xs shrink-0 overflow-hidden ${sizeClass} ${className || ''}`}
      title="এয়ারটেল (Airtel)"
    >
      <div className="w-[84%] h-[84%] rounded-full bg-gradient-to-tr from-[#d90429] to-[#ef233c] flex items-center justify-center shadow-xs">
        <svg viewBox="0 0 100 100" className="w-4/5 h-4/5">
          {/* Airtel signature looped lowercase 'a' glyph */}
          <path
            d="M 32 64 C 28 54, 32 40, 48 36 C 64 32, 70 42, 68 56 C 66 68, 52 70, 42 66 C 32 62, 34 50, 46 48 C 58 46, 68 50, 68 54 C 68 64, 58 72, 46 72"
            stroke="#ffffff"
            strokeWidth="8"
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
          />
          <circle cx="50" cy="50" r="4" fill="#ffffff" />
        </svg>
      </div>
    </div>
  );
};

/**
 * Teletalk - Iconic Emerald Green Dual Waves with Red Spark Logo
 */
export const TeletalkLogo: React.FC<LogoProps> = ({ className, size }) => {
  const sizeClass = getSizeClass(size, 'w-10 h-10');
  return (
    <div
      className={`relative flex items-center justify-center rounded-2xl bg-white border border-emerald-100 shadow-xs shrink-0 overflow-hidden ${sizeClass} ${className || ''}`}
      title="টেলিটক (Teletalk)"
    >
      <div className="flex flex-col items-center justify-center w-full px-0.5">
        <svg viewBox="0 0 100 65" className="w-[88%] h-auto">
          {/* Red Spark Center */}
          <circle cx="50" cy="18" r="6.5" fill="#e11d48" />
          {/* Inner Green Arc */}
          <path
            d="M 28 42 Q 50 16 72 42"
            stroke="#16a34a"
            strokeWidth="9"
            fill="none"
            strokeLinecap="round"
          />
          {/* Outer Green Arc */}
          <path
            d="M 12 54 Q 50 6 88 54"
            stroke="#22c55e"
            strokeWidth="7"
            fill="none"
            strokeLinecap="round"
          />
        </svg>
        <span className="text-[8px] font-black text-emerald-800 tracking-tighter leading-none mt-0.5">
          teletalk
        </span>
      </div>
    </div>
  );
};

/**
 * Skitto - Iconic Electric Yellow Smiley Sunglasses / Playful Logo
 */
export const SkittoLogo: React.FC<LogoProps> = ({ className, size }) => {
  const sizeClass = getSizeClass(size, 'w-10 h-10');
  return (
    <div
      className={`relative flex items-center justify-center rounded-2xl bg-gradient-to-tr from-[#ffe600] to-[#fff04d] border border-amber-300 shadow-xs shrink-0 overflow-hidden ${sizeClass} ${className || ''}`}
      title="স্কিটো (Skitto)"
    >
      <div className="flex flex-col items-center justify-center">
        {/* Playful cute eyes/sunglasses */}
        <div className="flex items-center gap-1 mb-0.5">
          <div className="w-2.5 h-2.5 rounded-full bg-slate-900 flex items-center justify-center">
            <div className="w-0.5 h-0.5 rounded-full bg-white ml-0.5" />
          </div>
          <div className="w-2.5 h-2.5 rounded-full bg-slate-900 flex items-center justify-center">
            <div className="w-0.5 h-0.5 rounded-full bg-white ml-0.5" />
          </div>
        </div>
        <span className="font-black text-slate-950 text-[9px] tracking-tight leading-none">
          skitto
        </span>
      </div>
    </div>
  );
};

/**
 * MFS Logos (bKash, Nagad, Rocket, Upay)
 */
export const BKashLogo: React.FC<LogoProps> = ({ className, size }) => {
  const sizeClass = getSizeClass(size, 'w-10 h-10');
  return (
    <div
      className={`relative flex items-center justify-center rounded-2xl bg-[#e2136e] shadow-xs shrink-0 overflow-hidden ${sizeClass} ${className || ''}`}
      title="বিকাশ (bKash)"
    >
      <svg viewBox="0 0 100 100" className="w-4/5 h-4/5 drop-shadow-xs">
        <polygon points="10,42 50,14 90,42 72,86 28,86" fill="#ffffff" />
        <polygon points="50,26 76,46 62,78 38,78 24,46" fill="#e2136e" />
        <polygon points="50,38 66,52 56,68 44,68 34,52" fill="#ffffff" />
      </svg>
    </div>
  );
};

export const NagadLogo: React.FC<LogoProps> = ({ className, size }) => {
  const sizeClass = getSizeClass(size, 'w-10 h-10');
  return (
    <div
      className={`relative flex items-center justify-center rounded-2xl bg-gradient-to-tr from-[#f7941d] to-[#ee1c25] text-white shadow-xs shrink-0 overflow-hidden font-black text-xs ${sizeClass} ${className || ''}`}
      title="নগদ (Nagad)"
    >
      <div className="flex flex-col items-center justify-center leading-none">
        <span className="text-[10px] tracking-tight">নগদ</span>
      </div>
    </div>
  );
};

export const RocketLogo: React.FC<LogoProps> = ({ className, size }) => {
  const sizeClass = getSizeClass(size, 'w-10 h-10');
  return (
    <div
      className={`relative flex items-center justify-center rounded-2xl bg-gradient-to-tr from-[#7c28d6] to-[#9945ff] text-white shadow-xs shrink-0 overflow-hidden font-black text-xs ${sizeClass} ${className || ''}`}
      title="রকেট (Rocket)"
    >
      <div className="flex flex-col items-center justify-center leading-none">
        <span className="text-[10px] tracking-tight">রকেট</span>
      </div>
    </div>
  );
};

export const UpayLogo: React.FC<LogoProps> = ({ className, size }) => {
  const sizeClass = getSizeClass(size, 'w-10 h-10');
  return (
    <div
      className={`relative flex items-center justify-center rounded-2xl bg-gradient-to-tr from-[#fbc02d] to-[#ffeb3b] text-slate-900 shadow-xs shrink-0 overflow-hidden font-black text-xs ${sizeClass} ${className || ''}`}
      title="উপায় (Upay)"
    >
      <div className="flex flex-col items-center justify-center leading-none">
        <span className="text-[10px] tracking-tight font-extrabold">upay</span>
      </div>
    </div>
  );
};

/**
 * Universal Operator Logo Dispatcher
 */
export const OperatorLogo: React.FC<{
  operator: OperatorType | string;
  className?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | number;
}> = ({ operator, className, size }) => {
  const opNormalized = (operator || '').toLowerCase();

  switch (opNormalized) {
    case 'gp':
    case 'grameenphone':
    case 'গ্রামীণফোন':
      return <GPLogo className={className} size={size} />;
    case 'robi':
    case 'রবি':
      return <RobiLogo className={className} size={size} />;
    case 'banglalink':
    case 'bl':
    case 'বাংলালিংক':
      return <BanglalinkLogo className={className} size={size} />;
    case 'teletalk':
    case 'টেলিটক':
      return <TeletalkLogo className={className} size={size} />;
    case 'airtel':
    case 'এয়ারটেল':
      return <AirtelLogo className={className} size={size} />;
    case 'skitto':
    case 'স্কিটো':
      return <SkittoLogo className={className} size={size} />;
    default:
      return <GPLogo className={className} size={size} />;
  }
};
