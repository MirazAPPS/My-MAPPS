import React, { useState } from 'react';
import {
  LifeBuoy,
  PhoneCall,
  MessageCircle,
  Send,
  X,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ChevronRight,
  ShieldAlert,
  ShieldCheck,
  SendHorizontal,
  Headphones,
  HelpCircle,
  Smartphone,
} from 'lucide-react';
import { SocialCommunityLinks, SupportTicket, UserProfile } from '../types';
import { cleanBDPhoneForDial } from '../utils';

interface EmergencySupportWidgetProps {
  socialLinks: SocialCommunityLinks;
  user: UserProfile;
  supportTickets: SupportTicket[];
  onSubmitTicket: (ticket: SupportTicket) => void;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

export const EmergencySupportWidget: React.FC<EmergencySupportWidgetProps> = ({
  socialLinks,
  user,
  supportTickets,
  onSubmitTicket,
  isOpen,
  onOpenChange,
}) => {
  const [activeTab, setActiveTab] = useState<'quick' | 'form' | 'history'>('quick');

  // Form State
  const [issueType, setIssueType] = useState<SupportTicket['issueType']>('recharge_pending');
  const [trxId, setTrxId] = useState('');
  const [message, setMessage] = useState('');
  const [phone, setPhone] = useState(user.phone);
  const [submittedSuccess, setSubmittedSuccess] = useState(false);

  const issueLabels: Record<SupportTicket['issueType'], string> = {
    recharge_pending: 'রিচার্জ পেন্ডিং / সম্পন্ন হয়নি',
    wrong_number: 'ভুল নম্বরে রিচার্জ চলে গেছে',
    offer_not_active: 'ড্রাইভ অফার এমবি/মিনিট আসেনি',
    balance_issue: 'অটো অ্যাড মানি ব্যালেন্স আসেনি',
    other: 'অন্যান্য জরুরি সমস্যা',
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    const newTicket: SupportTicket = {
      id: `TKT-${Math.floor(100 + Math.random() * 900)}`,
      customerName: user.name || 'সম্মানিত গ্রাহক',
      phone: phone || user.phone,
      issueType,
      message,
      trxId: trxId.trim() || undefined,
      createdAt: 'এইমাত্র',
      status: 'pending',
    };

    onSubmitTicket(newTicket);
    setSubmittedSuccess(true);

    // Auto open WhatsApp with the formatted complain message for immediate admin reaction
    const complainText = `🆘 *জরুরি কাস্টমার সাপোর্ট রিকোয়েস্ট*\n` +
      `👤 গ্রাহক: ${newTicket.customerName} (${newTicket.phone})\n` +
      `⚠️ সমস্যার ধরন: ${issueLabels[newTicket.issueType]}\n` +
      (newTicket.trxId ? `🆔 ট্রানজেকশন ID: ${newTicket.trxId}\n` : '') +
      `📝 বিস্তারিত: ${newTicket.message}\n\n` +
      `⚡ অনুগ্রহ করে দ্রুত সমাধান করুন।`;

    setTimeout(() => {
      setSubmittedSuccess(false);
      setMessage('');
      setTrxId('');
      setActiveTab('history');
      const cleanPhone = socialLinks.whatsappSupportNumber.replace(/[^0-9]/g, '');
      const waUrl = `https://wa.me/88${cleanPhone}?text=${encodeURIComponent(complainText)}`;
      window.open(waUrl, '_blank');
    }, 1500);
  };

  return (
    <>
      {/* Floating Emergency Help Button on Right Side - Positioned strictly inside the app container */}
      <div className="fixed bottom-[130px] left-0 right-0 max-w-[430px] mx-auto pointer-events-none z-50 px-4 flex justify-end">
        <button
          type="button"
          id="emergency-support-btn"
          onClick={() => onOpenChange(true)}
          className="pointer-events-auto group flex items-center gap-1.5 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white px-3.5 py-2 rounded-full shadow-2xl shadow-red-600/50 border-2 border-white active:scale-95 transition-all duration-300 ring-2 ring-red-500/30 cursor-pointer"
          title="জরুরি হেল্প ও সাপোর্ট"
        >
          <div className="relative">
            <Headphones className="w-4 h-4 text-white" />
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-emerald-400 rounded-full ring-1 ring-white animate-pulse" />
          </div>
          <span className="text-[11px] font-black tracking-tight text-white drop-shadow-xs">
            জরুরি হেল্প
          </span>
        </button>
      </div>

      {/* Emergency Help Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-[410px] w-full p-5 shadow-2xl border border-slate-100 space-y-4 max-h-[92vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center shadow-xs">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-base leading-tight">
                    জরুরি হেল্প ও কাস্টমার সাপোর্ট
                  </h3>
                  <span className="text-[11px] text-slate-500 font-medium">
                    সরাসরি হেল্প ডেস্কে যোগাযোগ ও অভিযোগ
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => onOpenChange(false)}
                className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Emergency Notice Banner if available */}
            {socialLinks.emergencyNotice && (
              <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <p className="text-[11px] text-amber-900 font-medium leading-relaxed">
                  {socialLinks.emergencyNotice}
                </p>
              </div>
            )}

            {/* Tab Switches */}
            <div className="flex bg-slate-100 p-1 rounded-2xl gap-1">
              <button
                type="button"
                onClick={() => setActiveTab('quick')}
                className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all ${
                  activeTab === 'quick' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500'
                }`}
              >
                তাৎক্ষণিক যোগাযোগ
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('form')}
                className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all ${
                  activeTab === 'form' ? 'bg-white text-rose-600 shadow-xs' : 'text-slate-500'
                }`}
              >
                অভিযোগ ফরম
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('history')}
                className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all ${
                  activeTab === 'history' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500'
                }`}
              >
                হিস্ট্রি ({supportTickets.length})
              </button>
            </div>

            {/* Tab 1: Instant Quick Contact */}
            {activeTab === 'quick' && (
              <div className="space-y-3">
                {/* 1. Direct Phone Hotline */}
                {socialLinks.supportPhoneEnabled !== false && Boolean(cleanBDPhoneForDial(socialLinks.supportPhone || socialLinks.adminContactNumber)) && (
                  <a
                    href={`tel:${cleanBDPhoneForDial(socialLinks.supportPhone || socialLinks.adminContactNumber)}`}
                    className="p-3.5 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-2xl flex items-center justify-between shadow-md shadow-emerald-500/20 active:scale-98 transition-transform group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
                        <PhoneCall className="w-5 h-5 text-white animate-bounce" />
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-100 block">
                          জরুরি হটলাইন কল
                        </span>
                        <h4 className="text-sm font-black tracking-wide">
                          {cleanBDPhoneForDial(socialLinks.supportPhone || socialLinks.adminContactNumber)}
                        </h4>
                      </div>
                    </div>
                    <span className="text-[11px] font-extrabold bg-white text-emerald-800 px-3 py-1.5 rounded-xl shadow-xs">
                      কল করুন
                    </span>
                  </a>
                )}

                {/* 2. WhatsApp Direct Live Chat */}
                {socialLinks.whatsappSupportEnabled !== false && Boolean(cleanBDPhoneForDial(socialLinks.whatsappSupportNumber || socialLinks.supportPhone || socialLinks.adminContactNumber)) && (
                  <a
                    href={`https://wa.me/88${cleanBDPhoneForDial(socialLinks.whatsappSupportNumber || socialLinks.supportPhone || socialLinks.adminContactNumber).replace(/^0/, '')}?text=${encodeURIComponent('আসসালামু আলাইকুম, রিচার্জ/অ্যাপ সংক্রান্ত জরুরি সাপোর্টের জন্য নক দিয়েছি।')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="p-3.5 bg-gradient-to-r from-emerald-600 to-green-600 text-white rounded-2xl flex items-center justify-between shadow-md shadow-green-600/20 active:scale-98 transition-transform"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
                        <MessageCircle className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-green-100 block">
                          WhatsApp লাইভ চ্যাট
                        </span>
                        <h4 className="text-xs font-bold">
                          অফিসিয়াল হোয়াটসঅ্যাপ সাপোর্ট
                        </h4>
                      </div>
                    </div>
                    <span className="text-[11px] font-extrabold bg-white text-emerald-800 px-3 py-1.5 rounded-xl shadow-xs">
                      মেসেজ দিন
                    </span>
                  </a>
                )}

                {/* 3. Telegram Admin Help Desk */}
                {socialLinks.telegramChannelEnabled !== false && Boolean((socialLinks.telegramSupport || socialLinks.telegramChannel)?.trim()) && (
                  <a
                    href={socialLinks.telegramSupport || socialLinks.telegramChannel}
                    target="_blank"
                    rel="noreferrer"
                    className="p-3.5 bg-gradient-to-r from-sky-500 to-blue-600 text-white rounded-2xl flex items-center justify-between shadow-md shadow-sky-500/20 active:scale-98 transition-transform"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
                        <Send className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-sky-100 block">
                          Telegram সাপোর্ট
                        </span>
                        <h4 className="text-xs font-bold">
                          টেলিগ্রাম ইনস্ট্যান্ট কেয়ার
                        </h4>
                      </div>
                    </div>
                    <span className="text-[11px] font-extrabold bg-white text-sky-800 px-3 py-1.5 rounded-xl shadow-xs">
                      চ্যাট করুন
                    </span>
                  </a>
                )}

                {/* 4. Digital Chat Live Helpdesk */}
                {socialLinks.digitalChatEnabled !== false && Boolean(socialLinks.digitalChatUrl?.trim()) && (
                  <a
                    href={socialLinks.digitalChatUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-3.5 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-2xl flex items-center justify-between shadow-md shadow-indigo-500/20 active:scale-98 transition-transform"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
                        <HelpCircle className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-100 block">
                          ডিজিটাল হেল্পডেস্ক
                        </span>
                        <h4 className="text-xs font-bold">
                          স্মার্ট লাইভ সাপোর্ট
                        </h4>
                      </div>
                    </div>
                    <span className="text-[11px] font-extrabold bg-white text-indigo-800 px-3 py-1.5 rounded-xl shadow-xs">
                      লাইভ চ্যাট
                    </span>
                  </a>
                )}

                {/* 5. Imo Support */}
                {socialLinks.imoEnabled !== false && Boolean(socialLinks.imoNumber?.trim()) && (
                  <a
                    href={`tel:${socialLinks.imoNumber}`}
                    className="p-3.5 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-2xl flex items-center justify-between shadow-md shadow-cyan-500/20 active:scale-98 transition-transform"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
                        <Smartphone className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-100 block">
                          IMO সাপোর্ট
                        </span>
                        <h4 className="text-xs font-bold">
                          {socialLinks.imoNumber}
                        </h4>
                      </div>
                    </div>
                    <span className="text-[11px] font-extrabold bg-white text-cyan-800 px-3 py-1.5 rounded-xl shadow-xs">
                      IMO কল
                    </span>
                  </a>
                )}

                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-center">
                  <span className="text-[11px] text-slate-500 font-medium block">
                    সাপোর্ট সময়সূচি: <strong className="text-slate-800">{socialLinks.supportHours}</strong>
                  </span>
                </div>
              </div>
            )}

            {/* Tab 2: Issue / Complain Submission Form */}
            {activeTab === 'form' && (
              <div>
                {submittedSuccess ? (
                  <div className="p-6 text-center space-y-3 bg-emerald-50 rounded-2xl border border-emerald-200">
                    <div className="w-12 h-12 rounded-full bg-emerald-500 text-white flex items-center justify-center mx-auto shadow-md">
                      <CheckCircle2 className="w-7 h-7" />
                    </div>
                    <h4 className="font-extrabold text-slate-900 text-sm">
                      অভিযোগ সফলভাবে গ্রহণ করা হয়েছে!
                    </h4>
                    <p className="text-xs text-slate-600">
                      দ্রুত সমাধানের জন্য স্বয়ংক্রিয়ভাবে WhatsApp ওপেন হচ্ছে...
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleFormSubmit} className="space-y-3 text-xs">
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">
                        সমস্যার ক্যাটাগরি নির্বাচন করুন
                      </label>
                      <select
                        value={issueType}
                        onChange={(e) => setIssueType(e.target.value as any)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-rose-600"
                      >
                        <option value="recharge_pending">⏳ রিচার্জ পেন্ডিং / আটকে গেছে</option>
                        <option value="wrong_number">❌ ভুল নম্বরে রিচার্জ চলে গেছে</option>
                        <option value="offer_not_active">📦 ড্রাইভ অফার এমবি/মিনিট আসেনি</option>
                        <option value="balance_issue">💳 অটো অ্যাড মানি ব্যালেন্স আসেনি</option>
                        <option value="other">💬 অন্যান্য জরুরি সমস্যা</option>
                      </select>
                    </div>

                    <div>
                      <label className="font-bold text-slate-700 block mb-1">
                        আপনার মোবাইল নাম্বার
                      </label>
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-rose-600"
                      />
                    </div>

                    <div>
                      <label className="font-bold text-slate-700 block mb-1">
                        ট্রানজেকশন ID / রিচার্জের নম্বর (যদি থাকে)
                      </label>
                      <input
                        type="text"
                        placeholder="যেমন: GP992837 বা 017XXXXXXXX"
                        value={trxId}
                        onChange={(e) => setTrxId(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-slate-900 outline-none focus:border-rose-600"
                      />
                    </div>

                    <div>
                      <label className="font-bold text-slate-700 block mb-1">
                        বিস্তারিত সমস্যা লিখুন
                      </label>
                      <textarea
                        rows={3}
                        required
                        placeholder="কখন রিচার্জ দিয়েছেন, কি সমস্যা হয়েছে বিস্তারিত লিখুন..."
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-900 outline-none focus:border-rose-600"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs rounded-xl shadow-md shadow-rose-600/20 flex items-center justify-center gap-2 transition-all active:scale-98"
                    >
                      <SendHorizontal className="w-4 h-4" />
                      <span>অভিযোগ জমা দিন ও WhatsApp এ সাপোর্ট নিন</span>
                    </button>
                  </form>
                )}
              </div>
            )}

            {/* Tab 3: History & Ticket Status */}
            {activeTab === 'history' && (
              <div className="space-y-2.5 max-h-[300px] overflow-y-auto">
                {supportTickets.length === 0 ? (
                  <div className="py-8 text-center text-slate-400 text-xs">
                    কোনো পূর্বের অভিযোগ পাওয়া যায়নি।
                  </div>
                ) : (
                  supportTickets.map((tkt) => (
                    <div
                      key={tkt.id}
                      className="p-3 bg-slate-50 rounded-2xl border border-slate-200/70 space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[10px] font-bold text-slate-500">
                          {tkt.id} • {tkt.createdAt}
                        </span>
                        <span
                          className={`text-[10px] font-black px-2.5 py-0.5 rounded-full ${
                            tkt.status === 'resolved'
                              ? 'bg-emerald-100 text-emerald-800'
                              : tkt.status === 'replied'
                              ? 'bg-teal-100 text-teal-800'
                              : tkt.status === 'in_progress'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {tkt.status === 'resolved'
                            ? '✓ সমাধান সম্পন্ন'
                            : tkt.status === 'replied'
                            ? '💬 জবাব এসেছে'
                            : tkt.status === 'in_progress'
                            ? '⏳ প্রক্রিয়াধীন'
                            : '⚠️ অপেক্ষমাণ'}
                        </span>
                      </div>

                      <h5 className="font-bold text-xs text-slate-900">
                        {issueLabels[tkt.issueType] || tkt.issueType}
                      </h5>

                      <p className="text-[11px] text-slate-700 leading-snug bg-white p-2 rounded-xl border border-slate-100">
                        {tkt.message}
                      </p>

                      {tkt.trxId && (
                        <div className="text-[10px] font-mono font-bold text-indigo-700 bg-indigo-50/60 px-2 py-0.5 rounded-md inline-block">
                          Ref / TrxID: {tkt.trxId}
                        </div>
                      )}

                      {/* Admin Reply */}
                      {tkt.adminReply ? (
                        <div className="mt-2 p-2.5 rounded-xl bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200 shadow-2xs space-y-1">
                          <div className="flex items-center justify-between gap-1">
                            <span className="text-[10px] font-black text-emerald-900 flex items-center gap-1">
                              <ShieldCheck className="w-3 h-3 text-emerald-600 shrink-0" />
                              <span>এডমিনের জবাব:</span>
                            </span>
                            {tkt.adminReplyAt && (
                              <span className="text-[9px] text-emerald-700 font-bold">
                                {tkt.adminReplyAt}
                              </span>
                            )}
                          </div>
                          <p className="text-xs font-black text-slate-900 leading-relaxed bg-white/90 p-2 rounded-lg border border-emerald-100">
                            {tkt.adminReply}
                          </p>
                        </div>
                      ) : (
                        tkt.status === 'pending' && (
                          <div className="mt-1.5 p-1.5 bg-amber-50 rounded-lg border border-amber-200/60 text-[10px] text-amber-900 font-medium flex items-center gap-1">
                            <Clock className="w-3 h-3 text-amber-600 shrink-0" />
                            <span>অভিযোগটি জমা হয়েছে, এডমিন শীঘ্রই উত্তর দিবেন।</span>
                          </div>
                        )
                      )}
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};
