import React, { useState } from 'react';
import {
  X,
  Tag,
  MapPin,
  Share2,
  Check,
  ArrowLeft,
  ShoppingBag,
  Sparkles,
  Smartphone,
} from 'lucide-react';
import { DriveOffer, OperatorType, SocialCommunityLinks } from '../types';
import { OperatorLogo } from './OperatorLogos';
import {
  getOperatorBnName,
  getFormattedTodayDate,
  formatSingleOfferShareText,
  formatAllOffersShareText,
  shareContent,
  getOperatorBrandTheme,
} from '../utils';

interface DriveOffersDirectoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  offers: DriveOffer[];
  socialLinks?: SocialCommunityLinks;
  language?: 'bn' | 'en';
  onSelectOffer: (offer: DriveOffer) => void;
}

export const DriveOffersDirectoryModal: React.FC<DriveOffersDirectoryModalProps> = ({
  isOpen,
  onClose,
  offers,
  socialLinks,
  language = 'bn',
  onSelectOffer,
}) => {
  const isBangla = language !== 'en';
  const [selectedOp, setSelectedOp] = useState<OperatorType | 'all'>('all');
  const [selectedDivision, setSelectedDivision] = useState('all');
  const [selectedPackage, setSelectedPackage] = useState('all');
  const [copiedToast, setCopiedToast] = useState<string | null>(null);
  const [sharedOfferId, setSharedOfferId] = useState<string | null>(null);
  const [isSharingAll, setIsSharingAll] = useState(false);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setCopiedToast(msg);
    setTimeout(() => setCopiedToast(null), 3000);
  };

  const filtered = offers.filter((o) => {
    const matchOp = selectedOp === 'all' || o.operator === selectedOp;
    const matchDiv =
      selectedDivision === 'all' ||
      !o.division ||
      o.division === 'All Bangladesh' ||
      o.division.includes(selectedDivision);
    const matchPkg =
      selectedPackage === 'all' ||
      o.packageName === selectedPackage;
    return matchOp && matchDiv && matchPkg;
  });

  const handleShareAll = async () => {
    setIsSharingAll(true);
    const text = formatAllOffersShareText(
      filtered.length > 0 ? filtered : offers,
      selectedOp !== 'all' ? `${getOperatorBnName(selectedOp)} অফার` : 'ড্রাইভ অফার'
    );
    await shareContent('সকল ড্রাইভ অফার', text, showToast);
    setIsSharingAll(false);
  };

  const handleShareSingle = async (e: React.MouseEvent, offer: DriveOffer) => {
    e.stopPropagation();
    setSharedOfferId(offer.id);
    const text = formatSingleOfferShareText(offer);
    await shareContent(`${getOperatorBnName(offer.operator)} ড্রাইভ অফার`, text, showToast);
    setTimeout(() => setSharedOfferId(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl max-w-[430px] w-full overflow-hidden shadow-2xl border border-slate-100 flex flex-col max-h-[90vh] animate-fadeIn">
        {/* Header - Grameenphone Blue Theme */}
        <div className="bg-gradient-to-r from-[#005ed9] via-[#0072CE] to-[#004b99] px-4 py-3.5 text-white flex items-center justify-between shrink-0 shadow-sm">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors cursor-pointer"
              title="পেছনে যান"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
              <Tag className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-base leading-tight">ড্রাইভ অফার ফোল্ডার</h3>
              <span className="text-[11px] text-sky-100">মোট সক্রিয় অফার: {filtered.length} টি</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              id="top-drive-offers-share-btn"
              onClick={handleShareAll}
              disabled={isSharingAll}
              className="h-8 px-3 rounded-full bg-white/25 hover:bg-white/35 active:scale-95 flex items-center gap-1.5 text-white text-xs font-black transition-all cursor-pointer shadow-2xs border border-white/25"
              title="শেয়ার করুন"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>শেয়ার</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Toast Alert */}
        {copiedToast && (
          <div className="bg-emerald-600 text-white text-xs font-bold px-4 py-2 text-center animate-fadeIn shrink-0">
            {copiedToast}
          </div>
        )}

        {/* Filters and All Share Section */}
        <div className="p-3.5 border-b border-slate-100 space-y-2.5 shrink-0 bg-slate-50/80">
          {/* Top 'All Share' Button with GP Blue Theme */}
          <button
            type="button"
            id="share-all-drive-offers-btn"
            onClick={handleShareAll}
            className="w-full py-2.5 px-4 bg-gradient-to-r from-[#005ed9] via-[#0072CE] to-[#004b99] hover:from-[#004fa8] hover:to-[#005ed9] text-white rounded-2xl text-xs font-black flex items-center justify-center gap-2 shadow-sm shadow-sky-600/25 transition-all active:scale-[0.98] cursor-pointer"
          >
            <Share2 className="w-4 h-4" />
            <span>🔥 আজকের ড্রাইভ অফার লিস্ট শেয়ার করুন</span>
            <span className="text-[10px] bg-white/25 px-2 py-0.5 rounded-full font-extrabold">
              {filtered.length} টি
            </span>
          </button>

          {/* Operator Chips with authentic brand colors */}
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar pt-0.5">
            {[
              { key: 'all', label: 'সকল' },
              { key: 'gp', label: 'জিপি' },
              { key: 'robi', label: 'রবি' },
              { key: 'banglalink', label: 'বাংলালিংক' },
              { key: 'airtel', label: 'এয়ারটেল' },
              { key: 'teletalk', label: 'টেলিটক' },
              { key: 'skitto', label: 'স্কিটো' },
            ].map((op) => {
              const isSelected = selectedOp === op.key;
              const brand = getOperatorBrandTheme(op.key === 'all' ? 'gp' : op.key);
              return (
                <button
                  key={op.key}
                  type="button"
                  onClick={() => setSelectedOp(op.key as any)}
                  className={`px-3.5 py-1.5 text-xs font-black rounded-xl whitespace-nowrap transition-all cursor-pointer ${
                    isSelected
                      ? `${brand.activeChip} scale-105`
                      : 'bg-white text-slate-800 border-2 border-slate-200 hover:bg-slate-100 font-extrabold'
                  }`}
                >
                  {op.label}
                </button>
              );
            })}
          </div>

          {/* Division & Package Dropdowns */}
          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center gap-1.5 bg-white border-2 border-slate-200 rounded-xl px-2.5 py-1.5 shadow-2xs">
              <MapPin className="w-4 h-4 text-[#0072CE] shrink-0 stroke-[2.5]" />
              <select
                value={selectedDivision}
                onChange={(e) => setSelectedDivision(e.target.value)}
                className="w-full bg-transparent text-xs font-extrabold text-slate-900 outline-none cursor-pointer"
              >
                <option value="all">সকল বিভাগ / এলাকা</option>
                <option value="Dhaka">ঢাকা বিভাগ</option>
                <option value="Chittagong">চট্টগ্রাম বিভাগ</option>
                <option value="Rajshahi">রাজশাহী বিভাগ</option>
                <option value="Khulna">খুলনা বিভাগ</option>
                <option value="Sylhet">সিলেট বিভাগ</option>
                <option value="Barisal">বরিশাল বিভাগ</option>
                <option value="Rangpur">রংপুর বিভাগ</option>
                <option value="Mymensingh">ময়মনসিংহ বিভাগ</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5 bg-white border-2 border-slate-200 rounded-xl px-2.5 py-1.5 shadow-2xs">
              <Tag className="w-4 h-4 text-[#0072CE] shrink-0 stroke-[2.5]" />
              <select
                value={selectedPackage}
                onChange={(e) => setSelectedPackage(e.target.value)}
                className="w-full bg-transparent text-xs font-extrabold text-slate-900 outline-none cursor-pointer"
              >
                <option value="all">সকল প্যাকেজ ধরন</option>
                <option value="কম্বো প্যাক">কম্বো প্যাক</option>
                <option value="বান্ডেল প্যাক">বান্ডেল প্যাক</option>
                <option value="মিনিট প্যাক">মিনিট প্যাক</option>
                <option value="ডাটা প্যাক">ডাটা প্যাক</option>
                <option value="ফ্যামিলি প্যাক">ফ্যামিলি প্যাক</option>
                <option value="গিফট প্যাক">গিফট প্যাক</option>
                <option value="ওটিপি প্যাক">ওটিপি প্যাক</option>
              </select>
            </div>
          </div>
        </div>

        {/* Offers List */}
        <div className="p-3.5 overflow-y-auto space-y-3 flex-1">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs bg-slate-50 rounded-2xl border border-dashed border-slate-200 p-6 space-y-1">
              <p className="font-bold">এই ফিল্টারে কোনো অফার নেই</p>
              <p className="text-[10px]">উপরে 'সকল' ফিল্টার সিলেক্ট করে দেখুন।</p>
            </div>
          ) : (
            filtered.map((offer) => {
              const opDisplay = isBangla
                ? getOperatorBnName(offer.operator)
                : (offer.operator === 'gp' ? 'GP' : (offer.operatorName || offer.operator.toUpperCase()));
              const offerDate = offer.date || getFormattedTodayDate();
              const currentPrice = Number(offer.priceTK || 0);
              const regPrice = Number(offer.regularPriceTK || currentPrice);
              const cashback = Number(
                offer.cashbackTK || (regPrice > currentPrice ? regPrice - currentPrice : 0)
              );

              // Dynamic Specs String
              const specsList: string[] = [];
              if (offer.internetGB && offer.internetGB > 0) {
                specsList.push(isBangla ? `${offer.internetGB} জিবি` : `${offer.internetGB} GB`);
              }
              if (offer.minutes && offer.minutes > 0) {
                specsList.push(isBangla ? `${offer.minutes} মিনিট` : `${offer.minutes} Min`);
              }
              if (offer.sms && offer.sms > 0) {
                specsList.push(isBangla ? `${offer.sms} এসএমএস` : `${offer.sms} SMS`);
              }
              const specs = specsList.join(' | ') || offer.packageName || (isBangla ? 'স্পেশাল প্যাকেজ' : 'Special Package');

              return (
                <div
                  key={offer.id}
                  id={`drive-offer-card-${offer.id}`}
                  className="w-full bg-white hover:bg-purple-50/20 border-2 border-slate-200 hover:border-purple-400 rounded-2xl p-4 space-y-3 transition-all shadow-xs"
                >
                  {/* Row 1: [লোগো] > জিপি > 1/9/2026 [শেয়ার বাটন] */}
                  <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                    <div className="flex items-center gap-2">
                      <OperatorLogo operator={offer.operator} className="w-6 h-6 shrink-0 shadow-2xs" />
                      <span className="text-xs sm:text-sm font-black text-slate-950">
                        {opDisplay} &gt; {offerDate}
                      </span>
                      {offer.packageName && (
                        <span className="text-[10px] sm:text-xs font-black px-2 py-0.5 bg-purple-100 text-purple-900 rounded-md border border-purple-300">
                          {offer.packageName}
                        </span>
                      )}
                    </div>

                    {/* Single Share Button */}
                    <button
                      type="button"
                      onClick={(e) => handleShareSingle(e, offer)}
                      className="p-1.5 px-2 text-purple-800 hover:bg-purple-100 border-2 border-purple-300 rounded-xl transition-all active:scale-95 flex items-center gap-1.5 text-xs font-black cursor-pointer shadow-2xs"
                      title={isBangla ? 'এই অফারটি শেয়ার করুন' : 'Share this offer'}
                    >
                      {sharedOfferId === offer.id ? (
                        <>
                          <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />
                          <span className="text-emerald-700">{isBangla ? 'কপি হয়েছে' : 'Copied'}</span>
                        </>
                      ) : (
                        <>
                          <Share2 className="w-4 h-4" />
                          <span>{isBangla ? 'শেয়ার' : 'Share'}</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Row 2: ৫০ জিবি | ১৫০০ মিনিট | ৫০০ এসএমএস */}
                  <div className="text-base sm:text-lg font-black text-slate-950 tracking-tight">
                    {specs}
                  </div>

                  {/* Row 3: মেয়াদ: ৩০ দিন | রেগুলার দাম: ৯৯৯৳ ❌ | বর্তমান দাম: ৮৯৯৳ ✅ | ক্যাশব্যাক: ১০০৳ */}
                  <div className="text-xs sm:text-[13px] font-bold text-slate-700 flex flex-wrap items-center gap-x-2 gap-y-1.5">
                    {offer.validityDays && (
                      <span className="text-slate-900 font-extrabold">
                        {isBangla ? `মেয়াদ: ${offer.validityDays} দিন` : `Validity: ${offer.validityDays} Days`}
                      </span>
                    )}
                    {regPrice > 0 && (
                      <>
                        <span className="text-slate-400 font-black">|</span>
                        <span className="text-slate-600 line-through font-bold">
                          {isBangla ? `রেগুলার দাম: ${regPrice}৳ ❌` : `Regular: ${regPrice}৳ ❌`}
                        </span>
                      </>
                    )}
                    <span className="text-slate-400 font-black">|</span>
                    <span className="text-indigo-950 font-black bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded-md">
                      {isBangla ? `বর্তমান দাম: ${currentPrice}৳ ✅` : `Price: ${currentPrice}৳ ✅`}
                    </span>
                    {cashback > 0 && (
                      <>
                        <span className="text-slate-400 font-black">|</span>
                        <span className="text-emerald-900 font-black bg-emerald-100 px-2 py-0.5 rounded-md border border-emerald-300">
                          {isBangla ? `ক্যাশব্যাক: ${cashback}৳` : `Cashback: ${cashback}৳`}
                        </span>
                      </>
                    )}
                  </div>

                  {/* Row 4: অর্ডার কনফার্ম বাটন */}
                  <div className="pt-1 flex items-center justify-between gap-2">
                    <span className="text-xs text-slate-700 font-extrabold">
                      {offer.division
                        ? (isBangla ? `বিভাগ: ${offer.division}` : `Division: ${offer.division}`)
                        : (isBangla ? 'সমগ্র বাংলাদেশ' : 'All Bangladesh')}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        onSelectOffer(offer);
                        onClose();
                      }}
                      className={`px-4 py-2 bg-gradient-to-r ${getOperatorBrandTheme(offer.operator).btnGradient} text-white text-xs sm:text-sm font-black rounded-xl shadow-sm flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer`}
                    >
                      <ShoppingBag className="w-4 h-4" />
                      <span>{isBangla ? 'অর্ডার কনফার্ম করুন' : 'Confirm Order'}</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

