import React from 'react';
import {
  MessageCircle,
  Send,
  Sparkles,
  PhoneCall,
  ExternalLink,
  ChevronRight,
  Zap,
  Users,
  Megaphone,
  Bot,
  HelpCircle,
  Folder,
} from 'lucide-react';
import { SocialCommunityLinks, DriveOffer, UserProfile } from '../types';

interface AppFoldersSectionProps {
  socialLinks: SocialCommunityLinks;
  user: UserProfile;
  offers: DriveOffer[];
  onOpenMessenger: (type: 'whatsapp' | 'telegram' | 'direct_msg' | 'ussd_tools') => void;
  onOpenAiAssistant: () => void;
}

export const AppFoldersSection: React.FC<AppFoldersSectionProps> = ({
  socialLinks,
  user,
  offers,
  onOpenMessenger,
  onOpenAiAssistant,
}) => {
  const folders = [
    {
      id: 'folder-wa',
      name: 'WhatsApp হাব',
      subtitle: 'সাপোর্ট ও গ্রুপ',
      icon: MessageCircle,
      iconColor: 'text-emerald-600',
      bgGradient: 'from-emerald-500/10 to-teal-500/15',
      borderColor: 'border-emerald-200/80 hover:border-emerald-400',
      badge: 'সরাসরি চ্যাট',
      badgeBg: 'bg-emerald-100 text-emerald-800',
      action: () => onOpenMessenger('whatsapp'),
      items: ['২৪/৭ সাপোর্ট', 'রিসেলার গ্রুপ', 'অফার চ্যানেল'],
    },
    {
      id: 'folder-tg',
      name: 'Telegram চ্যানেল',
      subtitle: 'ড্রাইভ অফার ও বট',
      icon: Send,
      iconColor: 'text-sky-500',
      bgGradient: 'from-sky-500/10 to-blue-500/15',
      borderColor: 'border-sky-200/80 hover:border-sky-400',
      badge: 'লাইভ নোটিশ',
      badgeBg: 'bg-sky-100 text-sky-800',
      action: () => onOpenMessenger('telegram'),
      items: ['অফিসিয়াল ড্রাইভ', 'অটো বট', 'কমিউনিটি'],
    },
    {
      id: 'folder-ai',
      name: 'টেলিকম AI',
      subtitle: 'অফার জেনারেটর',
      icon: Sparkles,
      iconColor: 'text-purple-600',
      bgGradient: 'from-purple-500/10 to-pink-500/15',
      borderColor: 'border-purple-200/80 hover:border-purple-400',
      badge: 'ChatGPT AI',
      badgeBg: 'bg-purple-100 text-purple-800',
      action: onOpenAiAssistant,
      items: ['অফার লিস্ট মেকার', 'সোশ্যাল পোস্ট', 'AI সাপোর্ট'],
    },
    {
      id: 'folder-ussd',
      name: 'সিম USSD কোড',
      subtitle: 'ব্যালেন্স ও টুলস',
      icon: PhoneCall,
      iconColor: 'text-amber-600',
      bgGradient: 'from-amber-500/10 to-orange-500/15',
      borderColor: 'border-amber-200/80 hover:border-amber-400',
      badge: 'সকল সিম',
      badgeBg: 'bg-amber-100 text-amber-800',
      action: () => onOpenMessenger('ussd_tools'),
      items: ['ব্যালেন্স কোড', 'NID টেস্ট', 'হেল্পলাইন'],
    },
  ];

  return (
    <div className="px-4 py-2 space-y-2.5">
      {/* Section Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Folder className="w-4 h-4 text-orange-600" />
          <h3 className="text-xs font-extrabold text-slate-900 tracking-tight">
            কমিউনিকেশন ও স্মার্ট অ্যাপস ফোল্ডার
          </h3>
        </div>
        <span className="text-[10px] font-bold text-slate-400">
          WhatsApp • Telegram • AI
        </span>
      </div>

      {/* 4 App Folder Cards Grid */}
      <div className="grid grid-cols-2 gap-2">
        {folders.map((fld) => {
          const Icon = fld.icon;
          return (
            <button
              key={fld.id}
              type="button"
              onClick={fld.action}
              className={`p-3 rounded-2xl bg-white border ${fld.borderColor} shadow-2xs hover:shadow-md transition-all text-left flex flex-col justify-between group cursor-pointer active:scale-98`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div
                    className={`w-9 h-9 rounded-xl bg-gradient-to-br ${fld.bgGradient} flex items-center justify-center border border-slate-100 shadow-2xs group-hover:scale-105 transition-transform`}
                  >
                    <Icon className={`w-5 h-5 ${fld.iconColor}`} />
                  </div>
                  <span
                    className={`text-[9.5px] font-extrabold px-2 py-0.5 rounded-full ${fld.badgeBg}`}
                  >
                    {fld.badge}
                  </span>
                </div>

                <h4 className="font-extrabold text-xs text-slate-900 leading-tight">
                  {fld.name}
                </h4>
                <p className="text-[10px] text-slate-500 font-medium mt-0.5">
                  {fld.subtitle}
                </p>
              </div>

              {/* Tags / Sub-items preview */}
              <div className="flex items-center gap-1 mt-2.5 pt-2 border-t border-slate-100 text-[9.5px] text-slate-600 flex-wrap">
                <span className="truncate">{fld.items.join(' • ')}</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Quick Interactive Direct Tools Banner */}
      <div className="p-2.5 rounded-2xl bg-gradient-to-r from-emerald-50 via-teal-50 to-sky-50 border border-emerald-200/80 flex items-center justify-between gap-2 shadow-2xs">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
            <Zap className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <h5 className="font-extrabold text-[11px] text-emerald-950 truncate">
              নম্বর সেভ না করেই WhatsApp বার্তা পাঠান
            </h5>
            <p className="text-[9.5px] text-emerald-700 font-medium truncate">
              যেকোনো গ্রাহকের নম্বরে সরাসরি রিচার্জ ও অফার কনফার্মেশন
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => onOpenMessenger('direct_msg')}
          className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[10.5px] rounded-xl shadow-xs shrink-0 flex items-center gap-1 active:scale-95 transition-all cursor-pointer"
        >
          <span>মেসেজ দিন</span>
          <ChevronRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};
