import React from 'react';

export interface MAppsLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
  className?: string;
  customLogoUrl?: string;
  appName?: string;
  appTagline?: string;
  logoPreset?: 'default_vector' | 'falcon' | 'emerald_5g' | 'ruby_flash' | 'golden_crown' | 'blue_tech' | 'custom';
}

export const MAppsLogo: React.FC<MAppsLogoProps> = ({
  size = 'lg',
  showSubtitle = true,
  className = '',
  customLogoUrl,
  appName = 'M APPS',
  appTagline = 'মোবাইল রিচার্জ অ্যাপ',
  logoPreset = 'default_vector',
}) => {
  // Dimensions based on size
  const sizeConfig = {
    xs: { box: 'w-10 h-10', svgW: 40, svgH: 40, titleSize: 'text-xs', subSize: 'text-[8px]', iconSize: 'w-6 h-6', radius: 'rounded-xl' },
    sm: { box: 'w-14 h-14', svgW: 56, svgH: 56, titleSize: 'text-sm', subSize: 'text-[9px]', iconSize: 'w-8 h-8', radius: 'rounded-2xl' },
    md: { box: 'w-20 h-20', svgW: 80, svgH: 80, titleSize: 'text-base', subSize: 'text-[11px]', iconSize: 'w-12 h-12', radius: 'rounded-[22px]' },
    lg: { box: 'w-28 h-28', svgW: 112, svgH: 112, titleSize: 'text-xl', subSize: 'text-xs', iconSize: 'w-16 h-16', radius: 'rounded-[28px]' },
    xl: { box: 'w-36 h-36', svgW: 144, svgH: 144, titleSize: 'text-2xl', subSize: 'text-sm', iconSize: 'w-20 h-20', radius: 'rounded-[32px]' },
  }[size];

  // Helper to render graphic inside logo card
  const renderLogoGraphic = () => {
    // 0. Default Authentic App Logo from user (or custom image if set)
    const logoSrc = customLogoUrl && customLogoUrl.trim().length > 0 ? customLogoUrl : '/app-logo.png';
    if (logoPreset === 'default_vector' || (customLogoUrl && customLogoUrl.trim().length > 0)) {
      return (
        <div className="w-full h-full flex items-center justify-center p-0.5 relative z-10">
          <img
            src={logoSrc}
            alt={appName || 'App Logo'}
            className="w-full h-full object-contain drop-shadow-md rounded-2xl"
            onError={(e) => {
              (e.currentTarget as HTMLElement).style.display = 'none';
            }}
          />
        </div>
      );
    }

    // 2. Preset 2: Falcon Telecom (Golden Falcon & Shield)
    if (logoPreset === 'falcon') {
      return (
        <svg viewBox="0 0 100 100" className="w-full h-full relative z-10 drop-shadow-xs" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="falconGold" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#f59e0b" />
              <stop offset="50%" stopColor="#d97706" />
              <stop offset="100%" stopColor="#b45309" />
            </linearGradient>
          </defs>
          <path d="M50 12 L82 26 L82 52 C82 72 68 86 50 92 C32 86 18 72 18 52 L18 26 Z" fill="url(#falconGold)" />
          <path d="M50 20 L76 31 L76 52 C76 68 64 80 50 85 C36 80 24 68 24 52 L24 31 Z" fill="#1e1b4b" />
          {/* Falcon Wings */}
          <path d="M50 32 L34 48 L44 54 L32 62 L48 64 L50 74 L52 64 L68 62 L56 54 L66 48 Z" fill="#fbbf24" />
          <circle cx="50" cy="46" r="4" fill="#ffffff" />
        </svg>
      );
    }

    // 3. Preset 3: Emerald 5G Ultra Speed
    if (logoPreset === 'emerald_5g') {
      return (
        <svg viewBox="0 0 100 100" className="w-full h-full relative z-10 drop-shadow-xs" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="emerald5g" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#10b981" />
              <stop offset="100%" stopColor="#047857" />
            </linearGradient>
          </defs>
          <circle cx="50" cy="50" r="38" fill="url(#emerald5g)" />
          <circle cx="50" cy="50" r="30" stroke="#a7f3d0" strokeWidth="2" strokeDasharray="4 3" />
          <text x="32" y="58" fontFamily="Arial, sans-serif" fontWeight="900" fontSize="24" fill="#ffffff">5G</text>
          <path d="M68 38 L76 34 M72 44 L80 44 M68 50 L76 54" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" />
        </svg>
      );
    }

    // 4. Preset 4: Ruby Flash Recharge
    if (logoPreset === 'ruby_flash') {
      return (
        <svg viewBox="0 0 100 100" className="w-full h-full relative z-10 drop-shadow-xs" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="rubyFlash" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#e11d48" />
              <stop offset="100%" stopColor="#9f1239" />
            </linearGradient>
          </defs>
          <rect x="15" y="15" width="70" height="70" rx="20" fill="url(#rubyFlash)" />
          {/* Lightning Bolt */}
          <path d="M54 24 L32 52 L48 52 L42 76 L68 46 L52 46 Z" fill="#fef08a" stroke="#ffffff" strokeWidth="1.5" />
        </svg>
      );
    }

    // 5. Preset 5: Golden Crown VIP
    if (logoPreset === 'golden_crown') {
      return (
        <svg viewBox="0 0 100 100" className="w-full h-full relative z-10 drop-shadow-xs" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="crownGrad" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#f59e0b" />
              <stop offset="50%" stopColor="#fbbf24" />
              <stop offset="100%" stopColor="#d97706" />
            </linearGradient>
          </defs>
          <circle cx="50" cy="50" r="38" fill="#1e1b4b" stroke="url(#crownGrad)" strokeWidth="3" />
          <path d="M28 62 L32 38 L42 48 L50 32 L58 48 L68 38 L72 62 Z" fill="url(#crownGrad)" />
          <circle cx="32" cy="36" r="2.5" fill="#ffffff" />
          <circle cx="50" cy="30" r="3" fill="#ffffff" />
          <circle cx="68" cy="36" r="2.5" fill="#ffffff" />
          <rect x="28" y="64" width="44" height="4" rx="2" fill="#fbbf24" />
        </svg>
      );
    }

    // 6. Preset 6: Blue Tech Telecom
    if (logoPreset === 'blue_tech') {
      return (
        <svg viewBox="0 0 100 100" className="w-full h-full relative z-10 drop-shadow-xs" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="blueTech" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#2563eb" />
              <stop offset="100%" stopColor="#1e40af" />
            </linearGradient>
          </defs>
          <rect x="16" y="16" width="68" height="68" rx="20" fill="url(#blueTech)" />
          {/* Signal Tower */}
          <path d="M50 26 L50 74 M36 74 L64 74 M42 42 L58 42 M38 56 L62 56" stroke="#ffffff" strokeWidth="3.5" strokeLinecap="round" />
          <circle cx="50" cy="26" r="4" fill="#38bdf8" />
          <path d="M32 30 C 38 24, 62 24, 68 30" stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" fill="none" />
        </svg>
      );
    }

    // Default 1: Authentic M APPS Vector Artwork (Emerald Green Phone + Pink APPS)
    return (
      <svg
        viewBox="0 0 200 200"
        className="w-full h-full relative z-10 drop-shadow-xs"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="phoneGreenGrad" x1="40" y1="20" x2="160" y2="180" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#059669" />
            <stop offset="50%" stopColor="#0d9488" />
            <stop offset="100%" stopColor="#047857" />
          </linearGradient>
          <linearGradient id="pinkAppsGrad" x1="70" y1="80" x2="140" y2="100" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#e11d48" />
            <stop offset="50%" stopColor="#ec4899" />
            <stop offset="100%" stopColor="#db2777" />
          </linearGradient>
          <linearGradient id="waveBlueGrad" x1="80" y1="10" x2="120" y2="40" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#0284c7" />
            <stop offset="100%" stopColor="#38bdf8" />
          </linearGradient>
        </defs>

        {/* Top-Left Wireless Waves */}
        <path d="M82 32 C 86 26, 96 22, 106 24" stroke="url(#waveBlueGrad)" strokeWidth="3.5" strokeLinecap="round" />
        <path d="M87 38 C 91 33, 98 30, 105 32" stroke="url(#waveBlueGrad)" strokeWidth="3" strokeLinecap="round" />
        <path d="M93 43 C 96 40, 100 38, 104 39" stroke="url(#waveBlueGrad)" strokeWidth="2.5" strokeLinecap="round" />

        {/* Angled Smartphone Body (Emerald Green Ribbon Style) */}
        <g transform="rotate(22 100 100)">
          <path
            d="M 68 28 L 132 28 C 140 28, 144 32, 144 40 L 144 54 L 130 54 L 130 40 L 70 40 L 70 54 L 56 54 L 56 40 C 56 32, 60 28, 68 28 Z"
            fill="url(#phoneGreenGrad)"
          />
          <rect x="85" y="33" width="30" height="3" rx="1.5" fill="white" />
          <path
            d="M 130 54 L 144 54 L 144 145 C 144 155, 138 162, 128 165 L 110 165 L 110 152 L 130 152 Z"
            fill="url(#phoneGreenGrad)"
          />
          <path
            d="M 52 135 C 50 155, 68 172, 95 174 C 122 176, 148 165, 152 148 C 153 144, 150 142, 146 144 C 132 155, 110 162, 88 158 C 68 154, 58 142, 54 133 Z"
            fill="url(#phoneGreenGrad)"
          />
          <path
            d="M 62 148 C 60 166, 80 182, 108 184 C 136 186, 160 172, 164 150 C 165 146, 161 144, 157 146 C 142 160, 118 168, 94 164 C 76 160, 66 150, 62 148 Z"
            fill="url(#phoneGreenGrad)"
            opacity="0.85"
          />
        </g>

        {/* Right Side Signal Waves */}
        <path d="M 148 76 C 153 79, 155 84, 154 89" stroke="url(#waveBlueGrad)" strokeWidth="2.5" strokeLinecap="round" />
        <path d="M 144 79 C 147 81, 149 84, 148 87" stroke="url(#waveBlueGrad)" strokeWidth="2" strokeLinecap="round" />

        {/* Stylized Script "M" */}
        <path
          d="M 38 98 C 34 94, 34 85, 42 78 C 50 72, 58 74, 58 84 C 58 92, 52 104, 46 112 C 43 116, 40 118, 36 116 C 32 113, 34 105, 42 96 C 48 89, 58 82, 68 76 C 75 72, 80 75, 78 83 C 75 92, 68 107, 64 116 C 62 120, 65 122, 69 119 C 78 111, 88 95, 94 82 C 98 74, 104 74, 103 82 C 101 94, 94 112, 90 120 C 87 125, 84 125, 82 121 C 80 116, 85 102, 89 91"
          stroke="url(#phoneGreenGrad)"
          strokeWidth="4.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />

        {/* Bold Magenta "APPS" text */}
        <text
          x="96"
          y="107"
          fontFamily="'Inter', 'Arial Black', sans-serif"
          fontWeight="900"
          fontSize="34"
          letterSpacing="-0.5"
          fill="url(#pinkAppsGrad)"
        >
          APPS
        </text>
      </svg>
    );
  };

  return (
    <div className={`flex flex-col items-center justify-center text-center ${className}`}>
      {/* Crisp Vector / Image Container Card */}
      <div
        className={`${sizeConfig.box} ${sizeConfig.radius} bg-white p-2 shadow-xl shadow-emerald-500/15 border border-emerald-100/80 flex items-center justify-center relative transform transition-transform hover:scale-105 duration-300 group overflow-hidden`}
      >
        {/* Soft emerald glow background */}
        <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500/10 via-teal-500/5 to-pink-500/10 opacity-70 pointer-events-none" />

        {renderLogoGraphic()}
      </div>

      {/* App Title & Subtitle */}
      {showSubtitle && (
        <div className="mt-3">
          <div className="flex items-center justify-center gap-1.5">
            <span className="font-extrabold text-2xl tracking-tight bg-gradient-to-r from-emerald-600 via-teal-600 to-pink-600 bg-clip-text text-transparent">
              {appName}
            </span>
          </div>
          {appTagline && (
            <p className="text-purple-950 font-bold text-xs tracking-wide mt-0.5">
              {appTagline}
            </p>
          )}
        </div>
      )}
    </div>
  );
};
