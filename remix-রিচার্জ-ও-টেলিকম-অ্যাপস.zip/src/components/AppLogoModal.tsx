import React, { useState, useRef } from 'react';
import {
  Sparkles,
  Upload,
  Image as ImageIcon,
  CheckCircle,
  RefreshCw,
  Trash2,
  Globe,
  Palette,
  Check,
  X,
  Smartphone,
} from 'lucide-react';
import { AppSettings } from '../types';
import { MAppsLogo } from './MAppsLogo';

interface AppLogoModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (updated: AppSettings) => void;
  onShowToast?: (msg: string) => void;
}

export const AppLogoModal: React.FC<AppLogoModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onShowToast,
}) => {
  const [appName, setAppName] = useState(settings.appName || 'M APPS');
  const [appTagline, setAppTagline] = useState(settings.appTagline || 'মোবাইল রিচার্জ অ্যাপ');
  const [appLogoUrl, setAppLogoUrl] = useState(settings.appLogoUrl || '');
  const [logoPreset, setLogoPreset] = useState<AppSettings['logoPreset']>(
    settings.logoPreset || 'default_vector'
  );
  const [imageUrlInput, setImageUrlInput] = useState('');
  const [isSavedRecently, setIsSavedRecently] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const presetOptions = [
    {
      id: 'default_vector' as const,
      name: 'M APPS মূল লোগো',
      badge: 'ডিফল্ট',
      description: 'অরিজিনাল এমারেল্ড ফোন ও ম্যাজেন্টা APPS',
    },
    {
      id: 'falcon' as const,
      name: 'গোল্ডেন ফ্যালকন টেলিকম',
      badge: 'গোল্ডেন',
      description: 'ভিআইপি ফ্যালকন ও গোল্ডেন শিল্ড',
    },
    {
      id: 'emerald_5g' as const,
      name: 'এমারেল্ড ৫জি ফাস্ট',
      badge: '৫জি স্পিড',
      description: 'আল্ট্রা হাই-স্পিড ৫জি পালস ও রিং',
    },
    {
      id: 'ruby_flash' as const,
      name: 'রুবি ফ্ল্যাশ রিচার্জ',
      badge: 'ফ্ল্যাশ',
      description: 'ইনস্ট্যান্ট পাওয়ার লাইটনিং বোল্ট',
    },
    {
      id: 'golden_crown' as const,
      name: 'রয়্যাল ভিআইপি ক্রাউন',
      badge: 'রয়্যাল',
      description: 'এলিট ডিলার ও প্রিমিয়াম ক্রাউন',
    },
    {
      id: 'blue_tech' as const,
      name: 'সাইবার ব্লু টেলিকম',
      badge: 'মডার্ন',
      description: 'ডিজিটাল নেটওয়ার্ক টাওয়ার ও সিগন্যাল',
    },
  ];

  // Handle File Upload from Device
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 3 * 1024 * 1024) {
      alert('ইমেজের সাইজ ৩ মেগাবাইটের কম হতে হবে!');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      if (base64) {
        setAppLogoUrl(base64);
        setLogoPreset('custom');
        if (onShowToast) onShowToast('লোগো ইমেজ সফলভাবে আপলোড হয়েছে!');
      }
    };
    reader.readAsDataURL(file);
  };

  // Handle URL Apply
  const handleApplyUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!imageUrlInput.trim()) return;
    setAppLogoUrl(imageUrlInput.trim());
    setLogoPreset('custom');
    setImageUrlInput('');
    if (onShowToast) onShowToast('অনলাইন ইমেজ লিংক সংযুক্ত হয়েছে!');
  };

  // Save Settings
  const handleSave = () => {
    const updated: AppSettings = {
      ...settings,
      appName: appName.trim() || 'M APPS',
      appTagline: appTagline.trim(),
      appLogoUrl: logoPreset === 'custom' ? appLogoUrl : undefined,
      logoPreset: logoPreset,
    };
    onUpdateSettings(updated);
    setIsSavedRecently(true);
    if (onShowToast) onShowToast('অ্যাপ লোগো ও ব্র্যান্ডিং সফলভাবে সেভ হয়েছে!');
    setTimeout(() => {
      setIsSavedRecently(false);
      onClose();
    }, 1200);
  };

  // Reset to Default
  const handleResetToDefault = () => {
    setAppName('M APPS');
    setAppTagline('মোবাইল রিচার্জ অ্যাপ');
    setAppLogoUrl('');
    setLogoPreset('default_vector');

    const updated: AppSettings = {
      ...settings,
      appName: 'M APPS',
      appTagline: 'মোবাইল রিচার্জ অ্যাপ',
      appLogoUrl: undefined,
      logoPreset: 'default_vector',
    };
    onUpdateSettings(updated);
    if (onShowToast) onShowToast('ডিফল্ট লোগো রিস্টোর করা হয়েছে!');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn overflow-y-auto"
    >
      <div className="bg-white rounded-3xl w-full max-w-md p-5 border border-indigo-200 shadow-2xl space-y-4 my-auto relative max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 sticky top-0 bg-white z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-600 text-white flex items-center justify-center shadow-md shadow-indigo-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900 leading-tight">
                অ্যাপ লোগো পরিবর্তন
              </h3>
              <p className="text-[10px] text-slate-500 font-medium">
                হেডার, লগইন স্ক্রিন ও অ্যাপ আইকন কাস্টমাইজ করুন
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Logo Preview Box */}
        <div className="p-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl text-white flex items-center gap-4 border border-indigo-900/50 shadow-md">
          <div className="w-16 h-16 rounded-2xl bg-white/10 border border-white/20 p-2 flex items-center justify-center shrink-0 shadow-inner">
            {logoPreset === 'custom' && appLogoUrl ? (
              <img
                src={appLogoUrl}
                alt="App Logo"
                className="w-full h-full object-contain rounded-xl"
              />
            ) : (
              <MAppsLogo
                size="md"
                preset={logoPreset}
                customLogoUrl={logoPreset === 'custom' ? appLogoUrl : undefined}
                appName={appName}
                showText={false}
              />
            )}
          </div>
          <div className="min-w-0">
            <span className="text-[10px] font-bold text-indigo-300 uppercase tracking-widest block">
              লাইভ প্রিভিউ
            </span>
            <h4 className="text-base font-black text-white truncate">{appName}</h4>
            <p className="text-[11px] text-slate-300 truncate">{appTagline}</p>
          </div>
        </div>

        {/* Success Alert */}
        {isSavedRecently && (
          <div className="p-2.5 bg-emerald-50 border border-emerald-300 rounded-xl text-xs font-bold text-emerald-800 flex items-center gap-2 animate-fadeIn">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>লোগো ও অ্যাপের নাম সফলভাবে আপডেট হয়েছে!</span>
          </div>
        )}

        {/* App Name & Tagline Inputs */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div>
            <label className="text-[11px] font-bold text-slate-700 block mb-1">
              অ্যাপের নাম:
            </label>
            <input
              type="text"
              value={appName}
              onChange={(e) => setAppName(e.target.value)}
              placeholder="যেমন: M APPS"
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-indigo-500 focus:bg-white"
            />
          </div>
          <div>
            <label className="text-[11px] font-bold text-slate-700 block mb-1">
              ট্যাগলাইন / স্লোগান:
            </label>
            <input
              type="text"
              value={appTagline}
              onChange={(e) => setAppTagline(e.target.value)}
              placeholder="যেমন: রিচার্জ ও টেলিকম"
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 outline-none focus:border-indigo-500 focus:bg-white"
            />
          </div>
        </div>

        {/* Preset Logos Selection */}
        <div className="space-y-2">
          <label className="text-[11px] font-extrabold text-slate-800 block">
            রেডিমেড প্রফেশনাল লোগো স্টাইল নির্বাচন করুন:
          </label>
          <div className="grid grid-cols-2 gap-2">
            {presetOptions.map((opt) => {
              const isSelected = logoPreset === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setLogoPreset(opt.id)}
                  className={`p-2.5 rounded-2xl border text-left flex items-center gap-2.5 transition-all cursor-pointer ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/70 shadow-sm ring-2 ring-indigo-500/30'
                      : 'border-slate-200 bg-slate-50/60 hover:bg-slate-100/60'
                  }`}
                >
                  <div className="w-9 h-9 rounded-xl bg-white border border-slate-200 flex items-center justify-center shrink-0 p-1">
                    <MAppsLogo size="sm" preset={opt.id} showText={false} />
                  </div>
                  <div className="min-w-0">
                    <span className="text-[11px] font-bold text-slate-900 block truncate leading-tight">
                      {opt.name}
                    </span>
                    <span className="text-[9px] text-slate-500 block truncate">
                      {opt.badge}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Custom Upload or Image URL */}
        <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-extrabold text-slate-800 flex items-center gap-1.5">
              <Upload className="w-3.5 h-3.5 text-indigo-600" />
              অথবা আপনার নিজস্ব লোগো আপলোড করুন:
            </span>
            {logoPreset === 'custom' && (
              <span className="text-[10px] font-black text-indigo-600 bg-indigo-100 px-2 py-0.5 rounded-md">
                সক্রিয়
              </span>
            )}
          </div>

          <input
            type="file"
            ref={fileInputRef}
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
          />

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 py-2 px-3 bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 font-bold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
            >
              <ImageIcon className="w-4 h-4 text-indigo-600" />
              <span>মোবাইল থেকে ছবি বাছুন</span>
            </button>

            {logoPreset === 'custom' && appLogoUrl && (
              <button
                type="button"
                onClick={() => {
                  setAppLogoUrl('');
                  setLogoPreset('default_vector');
                }}
                className="p-2 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 rounded-xl cursor-pointer"
                title="কাস্টম লোগো মুছে ফেলুন"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* URL Input */}
          <form onSubmit={handleApplyUrl} className="flex items-center gap-1.5 pt-1">
            <input
              type="url"
              value={imageUrlInput}
              onChange={(e) => setImageUrlInput(e.target.value)}
              placeholder="বা অনলাইন ইমেজ লিংক পেস্ট করুন..."
              className="flex-1 p-2 bg-white border border-slate-200 rounded-xl text-[11px] text-slate-900 outline-none focus:border-indigo-500"
            />
            <button
              type="submit"
              className="py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[11px] rounded-xl cursor-pointer shrink-0"
            >
              প্রয়োগ
            </button>
          </form>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
          <button
            type="button"
            onClick={handleResetToDefault}
            className="py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer transition-colors"
          >
            ডিফল্ট রিস্টোর
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="flex-1 py-2.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white text-xs font-black rounded-xl shadow-md flex items-center justify-center gap-1.5 cursor-pointer transition-all active:scale-98"
          >
            <Check className="w-4 h-4" />
            <span>লোগো নিশ্চিত করুন</span>
          </button>
        </div>
      </div>
    </div>
  );
};
