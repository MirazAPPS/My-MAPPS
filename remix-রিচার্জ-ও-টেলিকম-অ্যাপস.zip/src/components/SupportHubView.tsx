import React, { useState } from 'react';
import {
  Headphones,
  PhoneCall,
  MessageCircle,
  Send,
  SendHorizontal,
  CheckCircle2,
  AlertTriangle,
  Clock,
  HelpCircle,
  ChevronRight,
  ShieldAlert,
  ShieldCheck,
  ArrowLeft,
} from 'lucide-react';
import { SocialCommunityLinks, SupportTicket, UserProfile } from '../types';
import { cleanBDPhoneForDial } from '../utils';

interface SupportHubViewProps {
  socialLinks: SocialCommunityLinks;
  user: UserProfile;
  supportTickets: SupportTicket[];
  onSubmitTicket: (ticket: SupportTicket) => void;
  onBackToHome?: () => void;
}

export const SupportHubView: React.FC<SupportHubViewProps> = ({
  socialLinks,
  user,
  supportTickets,
  onSubmitTicket,
  onBackToHome,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'quick' | 'form' | 'history'>('quick');

  // Form State
  const [issueType, setIssueType] = useState<SupportTicket['issueType']>('recharge_pending');
  const [trxId, setTrxId] = useState('');
  const [message, setMessage] = useState('');
  const [phone, setPhone] = useState(user.phone);
  const [submittedSuccess, setSubmittedSuccess] = useState(false);

  const issueLabels: Record<SupportTicket['issueType'], string> = {
    recharge_pending: 'রিচার্জ পেন্ডিং / সম্পন্ন হয়নি',
    wrong_number: 'ভুল নম্বরে রিচার্জ চলে গেছে',
    offer_not_active: 'ড্রাইভ অফার এমবি/মিনিট আসেনি',
    balance_issue: 'অটো অ্যাড মানি ব্যালেন্স আসেনি',
    other: 'অন্যান্য জরুরি সমস্যা',
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    const newTicket: SupportTicket = {
      id: `TKT-${Math.floor(100 + Math.random() * 900)}`,
      customerName: user.name || 'সম্মানিত গ্রাহক',
      phone: phone || user.phone,
      issueType,
      message,
      trxId: trxId.trim() || undefined,
      createdAt: 'এইমাত্র',
      status: 'pending',
    };

    onSubmitTicket(newTicket);
    setSubmittedSuccess(true);

    const complainText =
      `🆘 *জরুরি কাস্টমার সাপোর্ট রিকোয়েস্ট*\n` +
      `👤 গ্রাহক: ${newTicket.customerName} (${newTicket.phone})\n` +
      `⚠️ সমস্যার ধরন: ${issueLabels[newTicket.issueType]}\n` +
      (newTicket.trxId ? `🆔 ট্রানজেকশন ID: ${newTicket.trxId}\n` : '') +
      `📝 বিস্তারিত: ${newTicket.message}\n\n` +
      `⚡ অনুগ্রহ করে দ্রুত সমাধান করুন।`;

    setTimeout(() => {
      setSubmittedSuccess(false);
      setMessage('');
      setTrxId('');
      setActiveSubTab('history');
      const cleanPhone = socialLinks.whatsappSupportNumber.replace(/[^0-9]/g, '');
      const waUrl = `https://wa.me/88${cleanPhone}?text=${encodeURIComponent(complainText)}`;
      window.open(waUrl, '_blank');
    }, 1500);
  };

  return (
    <div
      className="p-4 space-y-4 w-full pb-8 animate-fadeIn"
      style={{
        paddingTop: 'max(14px, calc(env(safe-area-inset-top, 0px) + 12px))',
      }}
    >
      {/* Top Back Navigation Bar */}
      {onBackToHome && (
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={onBackToHome}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 bg-white px-3 py-1.5 rounded-full border border-slate-200 shadow-2xs hover:bg-slate-50 transition-all active:scale-95 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>হোমে ফিরুন</span>
          </button>
          <span className="text-[11px] font-bold text-slate-400">হেল্পডেস্ক</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="p-5 rounded-3xl bg-gradient-to-r from-rose-600 via-pink-600 to-purple-600 text-white shadow-xl flex items-center justify-between">
        <div>
          <span className="text-[11px] font-bold text-rose-100 uppercase tracking-wider block">
            ২৪/৭ কাস্টমার কেয়ার
          </span>
          <h2 className="text-xl font-extrabold tracking-tight mt-0.5">
            হেল্প ও সাপোর্ট সেন্টার
          </h2>
          <p className="text-xs text-white/90 mt-1">
            যেকোনো রিচার্জ বা অফার সমস্যায় সার্বক্ষণিক সহায়তা
          </p>
        </div>
        <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shadow-inner">
          <Headphones className="w-6 h-6" />
        </div>
      </div>

      {/* Emergency Notice if any */}
      {socialLinks.emergencyNotice && (
        <div className="p-3.5 bg-amber-50 rounded-2xl border border-amber-200 flex items-start gap-2.5">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <p className="text-xs text-amber-900 font-medium leading-relaxed">
            {socialLinks.emergencyNotice}
          </p>
        </div>
      )}

      {/* Navigation Sub-tabs */}
      <div className="flex bg-slate-100 p-1.5 rounded-2xl gap-1">
        <button
          type="button"
          onClick={() => setActiveSubTab('quick')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
            activeSubTab === 'quick' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500'
          }`}
        >
          সরাসরি যোগাযোগ
        </button>
        <button
          type="button"
          onClick={() => setActiveSubTab('form')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
            activeSubTab === 'form' ? 'bg-white text-rose-600 shadow-xs' : 'text-slate-500'
          }`}
        >
          অভিযোগ ফরম
        </button>
        <button
          type="button"
          onClick={() => setActiveSubTab('history')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
            activeSubTab === 'history' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500'
          }`}
        >
          টিকেট হিস্ট্রি ({supportTickets.length})
        </button>
      </div>

      {/* Tab 1: Quick Contact */}
      {activeSubTab === 'quick' && (
        <div className="space-y-3">
          {/* 1. Hotline Call (Phone) */}
          {socialLinks.supportPhoneEnabled !== false && Boolean(cleanBDPhoneForDial(socialLinks.supportPhone || socialLinks.adminContactNumber)) && (
            <a
              href={`tel:${cleanBDPhoneForDial(socialLinks.supportPhone || socialLinks.adminContactNumber)}`}
              className="p-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-2xl flex items-center justify-between shadow-md shadow-emerald-500/20 active:scale-98 transition-transform"
            >
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-white/20 flex items-center justify-center">
                  <PhoneCall className="w-5 h-5 text-white animate-bounce" />
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-100 block">
                    জরুরি হটলাইন কল (Phone)
                  </span>
                  <h4 className="text-base font-black tracking-wide">
                    {cleanBDPhoneForDial(socialLinks.supportPhone || socialLinks.adminContactNumber)}
                  </h4>
                </div>
              </div>
              <span className="text-xs font-extrabold bg-white text-emerald-800 px-3.5 py-1.5 rounded-xl shadow-xs">
                কল করুন
              </span>
            </a>
          )}

          {/* 2. WhatsApp Direct */}
          {socialLinks.whatsappSupportEnabled !== false && Boolean(cleanBDPhoneForDial(socialLinks.whatsappSupportNumber || socialLinks.supportPhone || socialLinks.adminContactNumber)) && (
            <a
              href={`https://wa.me/88${cleanBDPhoneForDial(socialLinks.whatsappSupportNumber || socialLinks.supportPhone || socialLinks.adminContactNumber).replace(/^0/, '')}?text=${encodeURIComponent('আসসালামু আলাইকুম, রিচার্জ/অ্যাপ সংক্রান্ত জরুরি সাপোর্টের জন্য নক দিয়েছি।')}`}
              target="_blank"
              rel="noreferrer"
              className="p-4 bg-gradient-to-r from-emerald-600 to-green-600 text-white rounded-2xl flex items-center justify-between shadow-md shadow-green-600/20 active:scale-98 transition-transform"
            >
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-white/20 flex items-center justify-center">
                  <MessageCircle className="w-5 h-5 text-white" />
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-green-100 block">
                    WhatsApp লাইভ চ্যাট
                  </span>
                  <h4 className="text-sm font-bold">
                    অফিসিয়াল হোয়াটসঅ্যাপ সাপোর্ট
                  </h4>
                </div>
              </div>
              <span className="text-xs font-extrabold bg-white text-emerald-800 px-3.5 py-1.5 rounded-xl shadow-xs">
                মেসেজ দিন
              </span>
            </a>
          )}

          {/* 3. Digital Chat */}
          {socialLinks.digitalChatEnabled !== false && (
            <a
              href={socialLinks.digitalChatUrl || `https://wa.me/88${(socialLinks.whatsappSupportNumber || socialLinks.supportPhone).replace(/[^0-9]/g, '')}`}
              target="_blank"
              rel="noreferrer"
              className="p-4 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-2xl flex items-center justify-between shadow-md shadow-indigo-500/20 active:scale-98 transition-transform"
            >
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-white/20 flex items-center justify-center">
                  <HelpCircle className="w-5 h-5 text-white" />
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-100 block">
                    ডিজিটাল লাইভ চ্যাট
                  </span>
                  <h4 className="text-sm font-bold">
                    স্মার্ট ডিজিটাল হেল্পডেস্ক
                  </h4>
                </div>
              </div>
              <span className="text-xs font-extrabold bg-white text-indigo-800 px-3.5 py-1.5 rounded-xl shadow-xs">
                লাইভ চ্যাট
              </span>
            </a>
          )}

          {/* 4. Messenger Direct */}
          {socialLinks.messengerEnabled !== false && socialLinks.messengerId && (
            <a
              href={socialLinks.messengerId.startsWith('http') ? socialLinks.messengerId : `https://m.me/${socialLinks.messengerId.replace(/[^a-zA-Z0-9._]/g, '')}`}
              target="_blank"
              rel="noreferrer"
              className="p-4 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-2xl flex items-center justify-between shadow-md shadow-blue-500/20 active:scale-98 transition-transform"
            >
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-white/20 flex items-center justify-center">
                  <SendHorizontal className="w-5 h-5 text-white" />
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-blue-100 block">
                    মেসেঞ্জার সাপোর্ট
                  </span>
                  <h4 className="text-sm font-bold">
                    Facebook Messenger Help
                  </h4>
                </div>
              </div>
              <span className="text-xs font-extrabold bg-white text-blue-800 px-3.5 py-1.5 rounded-xl shadow-xs">
                মেসেজ দিন
              </span>
            </a>
          )}

          {/* 5. Imo Support */}
          {socialLinks.imoEnabled !== false && socialLinks.imoNumber && (
            <a
              href={`tel:${socialLinks.imoNumber}`}
              className="p-4 bg-gradient-to-r from-sky-500 to-cyan-600 text-white rounded-2xl flex items-center justify-between shadow-md shadow-sky-500/20 active:scale-98 transition-transform"
            >
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-white/20 flex items-center justify-center">
                  <MessageCircle className="w-5 h-5 text-white" />
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-sky-100 block">
                    ইমো সাপোর্ট (Imo)
                  </span>
                  <h4 className="text-sm font-bold">
                    {socialLinks.imoNumber}
                  </h4>
                </div>
              </div>
              <span className="text-xs font-extrabold bg-white text-sky-800 px-3.5 py-1.5 rounded-xl shadow-xs">
                ইমোতে যুক্ত হন
              </span>
            </a>
          )}

          {/* Telegram Care (if configured) */}
          {socialLinks.telegramSupport && (
            <a
              href={socialLinks.telegramSupport}
              target="_blank"
              rel="noreferrer"
              className="p-4 bg-gradient-to-r from-sky-500 to-blue-600 text-white rounded-2xl flex items-center justify-between shadow-md shadow-sky-500/20 active:scale-98 transition-transform"
            >
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-white/20 flex items-center justify-center">
                  <Send className="w-5 h-5 text-white" />
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-sky-100 block">
                    Telegram সাপোর্ট
                  </span>
                  <h4 className="text-sm font-bold">
                    টেলিগ্রাম ইনস্ট্যান্ট কেয়ার
                  </h4>
                </div>
              </div>
              <span className="text-xs font-extrabold bg-white text-sky-800 px-3.5 py-1.5 rounded-xl shadow-xs">
                চ্যাট করুন
              </span>
            </a>
          )}

          {/* Support Hours Card */}
          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-center space-y-1">
            <span className="text-xs text-slate-700 font-bold block">
              কাস্টমার সাপোর্ট সময়সূচি: <strong className="text-indigo-700">{socialLinks.supportHours || 'সকাল ১০টা - রাত ১০টা'}</strong>
            </span>
            {socialLinks.adminContactNumber && (
              <span className="text-[11px] text-slate-500 font-medium block">
                এডমিন কন্টাক্ট নম্বর: <strong className="text-slate-800">{socialLinks.adminContactNumber}</strong>
              </span>
            )}
          </div>
        </div>
      )}

      {/* Tab 2: Issue / Complain Submission Form */}
      {activeSubTab === 'form' && (
        <div className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm">
          {submittedSuccess ? (
            <div className="p-6 text-center space-y-3 bg-emerald-50 rounded-2xl border border-emerald-200">
              <div className="w-12 h-12 rounded-full bg-emerald-500 text-white flex items-center justify-center mx-auto shadow-md">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h4 className="font-extrabold text-slate-900 text-sm">
                অভিযোগ সফলভাবে জমা হয়েছে!
              </h4>
              <p className="text-xs text-slate-600">
                দ্রুত সমাধানের জন্য স্বয়ংক্রিয়ভাবে WhatsApp ওপেন হচ্ছে...
              </p>
            </div>
          ) : (
            <form onSubmit={handleFormSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1 text-center">
                  সমস্যার ক্যাটাগরি নির্বাচন করুন
                </label>
                <select
                  value={issueType}
                  onChange={(e) => setIssueType(e.target.value as any)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-rose-600 text-center"
                >
                  <option value="recharge_pending">⏳ রিচার্জ পেন্ডিং / আটকে গেছে</option>
                  <option value="wrong_number">❌ ভুল নম্বরে রিচার্জ চলে গেছে</option>
                  <option value="offer_not_active">📦 ড্রাইভ অফার এমবি/মিনিট আসেনি</option>
                  <option value="balance_issue">💳 অটো অ্যাড মানি ব্যালেন্স আসেনি</option>
                  <option value="other">💬 অন্যান্য জরুরি সমস্যা</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1 text-center">
                  আপনার মোবাইল নাম্বার
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-rose-600 text-center"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1 text-center">
                  ট্রানজেকশন ID / রিচার্জের নম্বর (যদি থাকে)
                </label>
                <input
                  type="text"
                  placeholder="যেমন: GP992837 বা 017XXXXXXXX"
                  value={trxId}
                  onChange={(e) => setTrxId(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-mono text-slate-900 outline-none focus:border-rose-600 text-center"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1 text-center">
                  বিস্তারিত সমস্যা লিখুন
                </label>
                <textarea
                  rows={3}
                  required
                  placeholder="কখন রিচার্জ দিয়েছেন, কি সমস্যা হয়েছে বিস্তারিত লিখুন..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-900 outline-none focus:border-rose-600 text-center"
                />
              </div>

              <button
                type="submit"
                className="w-full max-w-[300px] mx-auto py-3 bg-rose-600 hover:bg-rose-700 text-white font-semibold text-[16px] rounded-xl shadow-md shadow-rose-600/20 flex items-center justify-center gap-2 transition-all active:scale-98 cursor-pointer"
              >
                <SendHorizontal className="w-4 h-4" />
                <span>অভিযোগ জমা দিন ও WhatsApp এ সাপোর্ট নিন</span>
              </button>
            </form>
          )}
        </div>
      )}

      {/* Tab 3: History & Ticket Status */}
      {activeSubTab === 'history' && (
        <div className="space-y-2.5">
          {supportTickets.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs bg-white rounded-3xl border border-slate-100">
              কোনো পূর্বের অভিযোগ পাওয়া যায়নি।
            </div>
          ) : (
            supportTickets.map((tkt) => (
              <div
                key={tkt.id}
                className="p-3.5 bg-white rounded-2xl border border-slate-200/80 shadow-xs space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[10px] font-bold text-slate-500">
                    {tkt.id} • {tkt.createdAt}
                  </span>
                  <span
                    className={`text-[10px] font-black px-2.5 py-0.5 rounded-full ${
                      tkt.status === 'resolved'
                        ? 'bg-emerald-100 text-emerald-800'
                        : tkt.status === 'replied'
                        ? 'bg-teal-100 text-teal-800'
                        : tkt.status === 'in_progress'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {tkt.status === 'resolved'
                      ? '✓ সমাধান সম্পন্ন'
                      : tkt.status === 'replied'
                      ? '💬 জবাব এসেছে'
                      : tkt.status === 'in_progress'
                      ? '⏳ প্রক্রিয়াধীন'
                      : '⚠️ অপেক্ষমাণ'}
                  </span>
                </div>

                <h5 className="font-bold text-xs text-slate-900">
                  {issueLabels[tkt.issueType] || tkt.issueType}
                </h5>

                <p className="text-[11px] text-slate-700 leading-snug bg-slate-50 p-2 rounded-xl border border-slate-100">
                  {tkt.message}
                </p>

                {tkt.trxId && (
                  <div className="text-[10px] font-mono font-bold text-indigo-700 bg-indigo-50/60 px-2 py-0.5 rounded-md inline-block">
                    Ref / TrxID: {tkt.trxId}
                  </div>
                )}

                {/* Admin Reply Box */}
                {tkt.adminReply ? (
                  <div className="mt-2.5 p-3 rounded-xl bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200/90 shadow-2xs space-y-1.5">
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-[10px] font-black text-emerald-900 flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>এডমিন সাপোর্ট থেকে জবাব:</span>
                      </span>
                      {tkt.adminReplyAt && (
                        <span className="text-[9px] text-emerald-700 font-bold">
                          {tkt.adminReplyAt}
                        </span>
                      )}
                    </div>
                    <p className="text-xs font-black text-slate-900 leading-relaxed bg-white/80 p-2 rounded-lg border border-emerald-100">
                      {tkt.adminReply}
                    </p>
                    <div className="text-[9px] text-emerald-800 font-semibold text-right">
                      প্রেরক: {tkt.adminName || 'অফিসিয়াল এডমিন সাপোর্ট'}
                    </div>
                  </div>
                ) : (
                  tkt.status === 'pending' && (
                    <div className="mt-1.5 p-2 bg-amber-50/80 rounded-xl border border-amber-200/70 text-[10px] text-amber-900 font-medium flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      <span>আপনার অভিযোগটি জমা হয়েছে। এডমিন যাচাই করে এখানে সরাসরি জবাব দিবেন।</span>
                    </div>
                  )
                )}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
