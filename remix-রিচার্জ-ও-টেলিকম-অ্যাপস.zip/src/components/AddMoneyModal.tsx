import React, { useState, useEffect } from 'react';
import { X, Copy, Check, ShieldCheck, Wallet, ArrowRight, Sparkles, ArrowLeft, Building2 } from 'lucide-react';
import { BKashLogo, NagadLogo, RocketLogo, UpayLogo } from './OperatorLogos';
import { UserProfile, AddMoneyRequest, PaymentNumbersConfig } from '../types';
import { verifyAndProcessAddMoneyInFirestore } from '../lib/firebase';
import confetti from 'canvas-confetti';

interface AddMoneyModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  paymentNumbers?: PaymentNumbersConfig;
  onAddMoneyComplete?: (
    amount: number,
    method: string,
    trxId: string,
    balanceType: 'main' | 'drive' | 'bank'
  ) => void;
}

export const AddMoneyModal: React.FC<AddMoneyModalProps> = ({
  isOpen,
  onClose,
  user,
  paymentNumbers,
  onAddMoneyComplete,
}) => {
  // Only enable gateways that are explicitly ON and have a valid number configured by Admin
  const isBkashEnabled = Boolean(paymentNumbers?.bKashEnabled && paymentNumbers?.bKash?.trim());
  const isNagadEnabled = Boolean(paymentNumbers?.NagadEnabled && paymentNumbers?.Nagad?.trim());
  const isRocketEnabled = Boolean(paymentNumbers?.RocketEnabled && paymentNumbers?.Rocket?.trim());
  const isUpayEnabled = Boolean(paymentNumbers?.UpayEnabled && paymentNumbers?.Upay?.trim());
  const isBankEnabled = Boolean(
    paymentNumbers?.bankEnabled &&
    (paymentNumbers?.bankAccountNumber?.trim() || paymentNumbers?.bankName?.trim())
  );

  const availableGateways = [
    { id: 'bKash' as const, name: 'বিকাশ', enabled: isBkashEnabled, logo: <BKashLogo className="w-6 h-6 mb-1" /> },
    { id: 'Nagad' as const, name: 'নগদ', enabled: isNagadEnabled, logo: <NagadLogo className="w-6 h-6 mb-1" /> },
    { id: 'Rocket' as const, name: 'রকেট', enabled: isRocketEnabled, logo: <RocketLogo className="w-6 h-6 mb-1" /> },
    { id: 'Upay' as const, name: 'উপায়', enabled: isUpayEnabled, logo: <UpayLogo className="w-6 h-6 mb-1" /> },
    { id: 'Bank' as const, name: 'ব্যাংক', enabled: isBankEnabled, logo: <Building2 className="w-6 h-6 mb-1 text-emerald-600" /> },
  ].filter((g) => g.enabled);

  const initialGateway = availableGateways[0]?.id || 'bKash';
  const [gateway, setGateway] = useState<'bKash' | 'Nagad' | 'Rocket' | 'Upay' | 'Bank'>(initialGateway);

  useEffect(() => {
    if (availableGateways.length > 0 && !availableGateways.some((g) => g.id === gateway)) {
      setGateway(availableGateways[0].id);
    }
  }, [availableGateways, gateway]);

  const [balanceType, setBalanceType] = useState<'main' | 'drive' | 'bank'>('main');
  const [amount, setAmount] = useState('500');
  const [senderNumber, setSenderNumber] = useState('');
  const [trxId, setTrxId] = useState('');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  if (!isOpen) return null;

  const currentNumbers: Record<'bKash' | 'Nagad' | 'Rocket' | 'Upay' | 'Bank', string> = {
    bKash: paymentNumbers?.bKash?.trim() || '',
    Nagad: paymentNumbers?.Nagad?.trim() || '',
    Rocket: paymentNumbers?.Rocket?.trim() || '',
    Upay: paymentNumbers?.Upay?.trim() || '',
    Bank: paymentNumbers?.bankAccountNumber?.trim() || '',
  };

  const currentTypes: Record<'bKash' | 'Nagad' | 'Rocket' | 'Upay' | 'Bank', string> = {
    bKash: paymentNumbers?.bKashType || 'Send Money (Personal)',
    Nagad: paymentNumbers?.NagadType || 'Send Money (Personal)',
    Rocket: paymentNumbers?.RocketType || 'Send Money (Personal)',
    Upay: paymentNumbers?.UpayType || 'Send Money (Personal)',
    Bank: `${paymentNumbers?.bankName || 'ব্যাংক'} - ${paymentNumbers?.bankAccountName || 'অ্যাকাউন্ট'}`,
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleAddMoneySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);

    if (isNaN(numAmount) || numAmount < 10) {
      setError('সর্বনিম্ন অ্যাড মানি ১০ টাকা');
      return;
    }
    if (!trxId || trxId.trim().length < 4) {
      setError('সঠিক ও পূর্ণাঙ্গ ট্রানজেকশন আইডি (TrxID) লিখুন');
      return;
    }

    setIsSubmitting(true);
    setError('');

    const bonus = Math.round(numAmount * 0.025); // 2.5% bonus commission
    const totalCredit = numAmount + bonus;
    const cleanTrxId = trxId.trim().toUpperCase();
    const reqId = `REQ-${Date.now().toString().slice(-6)}`;

    // 1. Create Add Money Request object
    const addMoneyReq: AddMoneyRequest = {
      id: reqId,
      userId: user.phone || 'user',
      userPhone: user.phone || '01700000000',
      userName: user.name || 'গ্রাহক',
      gateway: gateway === 'Bank' ? ('bKash' as any) : gateway,
      amount: numAmount,
      bonus,
      totalCredit,
      balanceType,
      trxId: cleanTrxId,
      senderNumber: senderNumber.trim() || undefined,
      status: 'approved',
      createdAt: new Date().toISOString(),
      timestamp: 'আজ, এইমাত্র',
    };

    // 2. Database verification: check duplicate TrxID and auto-add balance in Firestore
    const verifyResult = await verifyAndProcessAddMoneyInFirestore(addMoneyReq);

    if (!verifyResult.success) {
      setError(verifyResult.message);
      setIsSubmitting(false);
      return;
    }

    // 3. Call handler to update App user balances locally
    if (onAddMoneyComplete) {
      onAddMoneyComplete(totalCredit, gateway, cleanTrxId, balanceType);
    }

    try {
      confetti({ particleCount: 70, spread: 60, origin: { y: 0.5 } });
    } catch {}

    setSuccessMessage(verifyResult.message);
    setIsSubmitting(false);
    setSuccess(true);
  };

  const handleClose = () => {
    setSuccess(false);
    setTrxId('');
    setSenderNumber('');
    setAmount('500');
    setError('');
    setSuccessMessage('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-[420px] w-full overflow-hidden shadow-2xl border border-slate-100 animate-fadeIn">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-700 px-4 py-3.5 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleClose}
              className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors cursor-pointer"
              title="পেছনে যান"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">অটো অ্যাড মানি</h3>
              <span className="text-[11px] text-emerald-100">ফায়ারবেস লাইভ সংযোগ ও ২.৫% বোনাস</span>
            </div>
          </div>
          <button
            type="button"
            onClick={handleClose}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors cursor-pointer"
            title="বন্ধ করুন"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {!success ? (
          <form onSubmit={handleAddMoneySubmit} className="p-4 sm:p-5 space-y-3.5 max-h-[82vh] overflow-y-auto">
            {/* Single Current Balance Deposit Account */}
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1.5">
                ডিপোজিট অ্যাকাউন্ট (ব্যালেন্স)
              </label>
              <div className="flex items-center justify-between p-3 bg-emerald-50/80 border border-emerald-200 rounded-2xl">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-black text-sm shadow-xs">
                    ৳
                  </div>
                  <div>
                    <span className="text-xs font-black text-emerald-950 block">কারেন্ট ব্যালেন্স (Current Balance)</span>
                    <span className="text-[11px] text-emerald-700 font-medium">মোবাইল রিচার্জ ও সকল সেবার সক্রিয় ব্যালেন্স</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-500 font-bold block">বর্তমান ব্যালেন্স</span>
                  <span className="text-xs font-black text-emerald-800 font-mono">
                    ৳{user.mainBalance.toLocaleString('bn-BD')}
                  </span>
                </div>
              </div>
            </div>

            {/* Gateway selector */}
            {availableGateways.length === 0 ? (
              <div className="p-4 bg-amber-50/80 border border-amber-200 rounded-2xl text-center space-y-1 my-2">
                <Wallet className="w-8 h-8 text-amber-500 mx-auto" />
                <p className="text-xs font-bold text-amber-900">বর্তমানে কোনো পেমেন্ট মেথড সক্রিয় নেই</p>
                <p className="text-[11px] text-amber-700">
                  এডমিন কর্তৃক কোনো ওয়ালেট নম্বর চালু করা হয়নি। ব্যালেন্স নিতে সরাসরি এডমিনের সাথে যোগাযোগ করুন।
                </p>
              </div>
            ) : (
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1.5">
                  পেমেন্ট মেথড নির্বাচন করুন
                </label>
                <div
                  className={`grid gap-1.5 ${
                    availableGateways.length === 1
                      ? 'grid-cols-1'
                      : availableGateways.length === 2
                      ? 'grid-cols-2'
                      : availableGateways.length === 3
                      ? 'grid-cols-3'
                      : availableGateways.length === 4
                      ? 'grid-cols-4'
                      : 'grid-cols-5'
                  }`}
                >
                  {availableGateways.map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setGateway(m.id)}
                      className={`flex flex-col items-center justify-center p-2 rounded-2xl border transition-all cursor-pointer ${
                        gateway === m.id
                          ? 'border-emerald-600 bg-emerald-50/60 ring-2 ring-emerald-500/20 font-bold'
                          : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100'
                      }`}
                    >
                      {m.logo}
                      <span className="text-[10px] text-slate-800 font-bold">{m.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Merchant / Personal Number or Bank Details with Copy */}
            {availableGateways.length > 0 && (
              gateway === 'Bank' ? (
                <div className="bg-emerald-50/60 border border-emerald-200 rounded-2xl p-3 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-emerald-900 text-xs flex items-center gap-1">
                      <Building2 className="w-3.5 h-3.5" />
                      <span>{paymentNumbers?.bankName || 'ব্যাংক অ্যাকাউন্ট বিবরণ'}</span>
                    </span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                      {paymentNumbers?.bankType || 'Current / Savings'}
                    </span>
                  </div>
                  <div className="space-y-1 bg-white p-2.5 rounded-xl border border-emerald-100">
                    {paymentNumbers?.bankAccountName && (
                      <div className="text-[11px] text-slate-600">
                        অ্যাকাউন্ট নাম: <span className="font-bold text-slate-900">{paymentNumbers.bankAccountName}</span>
                      </div>
                    )}
                    <div className="flex items-center justify-between pt-1">
                      <div>
                        <span className="text-[10px] text-slate-500 block">হিসাব নম্বর (A/C No):</span>
                        <span className="font-mono font-black text-sm text-emerald-800 tracking-wider">
                          {paymentNumbers?.bankAccountNumber || ''}
                        </span>
                      </div>
                      {paymentNumbers?.bankAccountNumber && (
                        <button
                          type="button"
                          onClick={() => copyToClipboard(paymentNumbers.bankAccountNumber || '')}
                          className="flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 px-2.5 py-1 rounded-lg transition-colors cursor-pointer border border-emerald-200"
                        >
                          {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copied ? 'কপি হয়েছে' : 'কপি'}</span>
                        </button>
                      )}
                    </div>
                    {paymentNumbers?.bankBranchRouting && (
                      <div className="text-[10px] text-slate-500 border-t border-slate-100 pt-1 mt-1">
                        শাখা ও রাউটিং: <span className="font-medium text-slate-700">{paymentNumbers.bankBranchRouting}</span>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-3 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-600 font-medium">এডমিন {gateway} নম্বর:</span>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                      {currentTypes[gateway]}
                    </span>
                  </div>
                  <div className="flex items-center justify-between bg-white border border-slate-200 rounded-xl px-3 py-2">
                    <span className="font-mono font-bold text-base text-slate-900 tracking-wider">
                      {currentNumbers[gateway]}
                    </span>
                    {currentNumbers[gateway] && (
                      <button
                        type="button"
                        onClick={() => copyToClipboard(currentNumbers[gateway])}
                        className="flex items-center gap-1 text-xs font-bold text-emerald-700 hover:text-emerald-800 bg-emerald-50 hover:bg-emerald-100 px-2.5 py-1 rounded-lg transition-colors cursor-pointer border border-emerald-200"
                      >
                        {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{copied ? 'কপি হয়েছে' : 'কপি করুন'}</span>
                      </button>
                    )}
                  </div>
                </div>
              )
            )}

            {/* Amount */}
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1 text-center">
                টাকার পরিমাণ (টাকা)
              </label>
              <div className="relative flex items-center justify-center">
                <span className="absolute left-3 font-bold text-emerald-600 text-lg pointer-events-none">৳</span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="500"
                  className="w-full px-9 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 text-base outline-none focus:border-emerald-600 focus:bg-white text-center"
                />
              </div>

              {/* Bonus / Commission hint */}
              {parseFloat(amount) > 0 && (
                <div className="mt-1 flex items-center justify-between text-xs text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200/80">
                  <span>কমিশন (২.৫%): +৳{Math.round(parseFloat(amount) * 0.025)}</span>
                  <span className="font-bold">কারেন্ট ব্যালেন্সে মোট যোগ: ৳{parseFloat(amount) + Math.round(parseFloat(amount) * 0.025)}</span>
                </div>
              )}
            </div>

            {/* Sender Number & TrxID */}
            <div className="grid grid-cols-1 gap-2">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1 text-center">
                  যে নম্বর থেকে পাঠিয়েছেন (অপশনাল)
                </label>
                <input
                  type="text"
                  value={senderNumber}
                  onChange={(e) => setSenderNumber(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-sm text-slate-900 outline-none focus:border-emerald-600 focus:bg-white text-center"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1 text-center">
                  ট্রানজেকশন আইডি (TrxID) *
                </label>
                <input
                  type="text"
                  value={trxId}
                  onChange={(e) => setTrxId(e.target.value)}
                  placeholder="যেমন: BK9A8B7C6D"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-slate-900 uppercase text-sm outline-none focus:border-emerald-600 focus:bg-white text-center"
                />
              </div>
            </div>

            {error && (
              <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-600 rounded-xl text-xs font-semibold text-center">
                {error}
              </div>
            )}

            {/* Submit */}
            <button
              id="submit-add-money-btn"
              type="submit"
              disabled={isSubmitting || availableGateways.length === 0}
              className={`w-full max-w-[300px] mx-auto py-3 text-white font-semibold text-[16px] rounded-xl shadow-md flex items-center justify-center gap-2 transition-all ${
                availableGateways.length === 0
                  ? 'bg-slate-300 shadow-none cursor-not-allowed text-slate-500'
                  : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 shadow-emerald-500/25 cursor-pointer'
              }`}
            >
              {isSubmitting ? (
                <span>যাচাই ও সেভ হচ্ছে...</span>
              ) : (
                <>
                  <span>ব্যালেন্স যোগ ও রিকোয়েস্ট জমা দিন</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        ) : (
          <div className="p-6 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center">
              <Sparkles className="w-9 h-9" />
            </div>
            <div>
              <h3 className="text-xl font-extrabold text-slate-900">ব্যালেন্স সফলভাবে যোগ হয়েছে!</h3>
              <p className="text-xs text-slate-600 mt-1 font-medium">
                {successMessage || 'ফায়ারস্টোরে TrxID ভেরিফাই হয়েছে এবং আপনার ব্যালেন্স আপডেট হয়েছে।'}
              </p>
            </div>
            <button
              type="button"
              onClick={handleClose}
              className="w-full max-w-[300px] mx-auto py-3 bg-slate-900 text-white font-semibold text-[16px] rounded-xl cursor-pointer block text-center"
            >
              সম্পন্ন
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
