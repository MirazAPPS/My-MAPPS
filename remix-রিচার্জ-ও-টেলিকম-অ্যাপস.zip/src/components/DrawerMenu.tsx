import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  User,
  Phone,
  Mail,
  HelpCircle,
  MessageCircle,
  Send,
  LogOut,
  KeyRound,
  Sparkles,
  ChevronRight,
  Share2,
  Palette,
  Settings,
  Bell,
  Volume2,
  VolumeX,
  Globe,
  Store,
  Check,
  Copy,
  ExternalLink,
  Youtube,
  Facebook,
  Shield,
  RefreshCw,
  Edit3,
  Moon,
  Sun,
  ArrowLeft,
  Camera,
  Upload,
  Trash2,
  QrCode,
  Smartphone,
  Fingerprint,
} from 'lucide-react';
import { UserProfile, AppSettings, SocialCommunityLinks } from '../types';
import { speakText } from '../utils';
import {
  isBiometricSupported,
  hasBiometricEnrolled,
  registerBiometrics,
} from '../utils/biometrics';

interface DrawerMenuProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  settings: AppSettings;
  socialLinks?: SocialCommunityLinks;
  onUpdateUser: (user: UserProfile) => void;
  onUpdateSettings: (settings: AppSettings) => void;
  onLogout: () => void;
  onRefreshData?: () => void;
  onOpenQrScanner?: () => void;
  onOpenAndroidApk?: () => void;
}

// Helper to compress and optimize uploaded profile images for fast Firestore storage
const compressAndResizeImage = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new window.Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 360;
        let width = img.width;
        let height = img.height;
        if (width > height) {
          if (width > maxDim) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          }
        } else {
          if (height > maxDim) {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        resolve(dataUrl);
      };
      img.onerror = () => resolve(e.target?.result as string);
      img.src = e.target?.result as string;
    };
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });
};

export const DrawerMenu: React.FC<DrawerMenuProps> = ({
  isOpen,
  onClose,
  user,
  settings,
  socialLinks,
  onUpdateUser,
  onUpdateSettings,
  onLogout,
  onRefreshData,
  onOpenQrScanner,
  onOpenAndroidApk,
}) => {
  // Sub-modal states
  const [activeModal, setActiveModal] = useState<
    'none' | 'profile' | 'pin' | 'theme' | 'share' | 'settings' | 'update'
  >('none');
  const [isUpdatingData, setIsUpdatingData] = useState(false);
  const [updateSuccess, setUpdateSuccess] = useState(false);

  // Profile Form State
  const [editName, setEditName] = useState(user.name);
  const [editEmail, setEditEmail] = useState(user.email || '');
  const [editPhone, setEditPhone] = useState(user.phone);
  const [editShopName, setEditShopName] = useState(user.shopName || 'মেসার্স রনি স্টোর ও টেলিকম');
  const [editAccountType, setEditAccountType] = useState(user.accountType);
  const [editProfileImage, setEditProfileImage] = useState(user.profileImage || '');
  const [imageUploading, setImageUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setEditName(user.name);
    setEditEmail(user.email || '');
    setEditPhone(user.phone);
    setEditShopName(user.shopName || 'মেসার্স রনি স্টোর ও টেলিকম');
    setEditAccountType(user.accountType);
    setEditProfileImage(user.profileImage || '');
  }, [user]);

  const handleImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setImageUploading(true);
      const compressed = await compressAndResizeImage(file);
      setEditProfileImage(compressed);
    } catch (err) {
      console.error('Image compression error:', err);
    } finally {
      setImageUploading(false);
    }
  };

  const handleRemoveImage = () => {
    setEditProfileImage('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // PIN Form State
  const [oldPin, setOldPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [pinError, setPinError] = useState('');
  const [pinSuccess, setPinSuccess] = useState(false);

  // Biometrics in Drawer Settings
  const [bioSupported, setBioSupported] = useState(false);
  const [isBioEnrolled, setIsBioEnrolled] = useState(false);
  const [bioMsg, setBioMsg] = useState('');
  const [bioLoading, setBioLoading] = useState(false);

  useEffect(() => {
    isBiometricSupported().then((supported) => {
      setBioSupported(supported);
    });
    if (user?.phone) {
      setIsBioEnrolled(hasBiometricEnrolled(user.phone));
    }
  }, [user?.phone, isOpen]);

  const handleToggleBiometrics = async () => {
    if (!user?.phone) return;
    setBioMsg('');
    const cleanPhone = user.phone.replace(/[^0-9]/g, '');

    if (isBioEnrolled) {
      try {
        localStorage.removeItem(`mapps_bio_credential_${cleanPhone}`);
        setIsBioEnrolled(false);
        setBioMsg('ফিঙ্গারপ্রিন্ট লগইন বন্ধ করা হয়েছে');
      } catch (err) {
        console.error(err);
      }
      return;
    }

    setBioLoading(true);
    try {
      const res = await registerBiometrics(cleanPhone, user.name, user.pin || '1234');
      if (res.success) {
        setIsBioEnrolled(true);
        setBioMsg('ফিঙ্গারপ্রিন্ট সফলভাবে চালু করা হয়েছে!');
      } else {
        setBioMsg(res.error || 'ফিঙ্গারপ্রিন্ট সেট করা যায়নি');
      }
    } catch (err: any) {
      setBioMsg(err.message || 'বায়োমেট্রিক সেটআপে সমস্যা হয়েছে');
    } finally {
      setBioLoading(false);
    }
  };

  // Share Copy state
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedPromo, setCopiedPromo] = useState(false);

  if (!isOpen) return null;

  const customShareUrl = settings.appDownloadUrl?.trim() || socialLinks?.appDownloadUrl?.trim() || '';
  const fallbackUrl = typeof window !== 'undefined' && window.location.origin && !window.location.origin.includes('localhost')
    ? window.location.origin
    : 'https://ais-pre-zllaqzcthprk7px5g7rrfo-495811225278.asia-east1.run.app';
  const appShareUrl = customShareUrl || fallbackUrl;
  const sharePromoText = `🔥 সেরা টেলিকম রিচার্জ ও ড্রাইভ অফার অ্যাপ!\n🏪 শপ: ${user.shopName || user.name}\n⚡ সবচেয়ে কম দামে রবি, জিপি, বাংলালিংক, এয়ারটেল ড্রাইভ প্যাক কিনুন ও ব্যবসা পরিচালনা করুন।\n📲 অ্যাপ লিঙ্ক:\n${appShareUrl}`;

  const themes: {
    id: AppSettings['theme'];
    name: string;
    gradient: string;
    bgClass: string;
  }[] = [
    {
      id: 'purple',
      name: 'রয়্যাল পার্পল (ডিফল্ট)',
      gradient: 'from-[#ea3888] via-[#a825ea] to-[#462bf4]',
      bgClass: 'bg-gradient-to-r from-[#ea3888] via-[#a825ea] to-[#462bf4]',
    },
    {
      id: 'blue',
      name: 'ওশান ব্লু (Ocean Blue)',
      gradient: 'from-[#0284c7] via-[#2563eb] to-[#4f46e5]',
      bgClass: 'bg-gradient-to-r from-[#0284c7] via-[#2563eb] to-[#4f46e5]',
    },
    {
      id: 'green',
      name: 'এমারেল্ড গ্রিন (Emerald)',
      gradient: 'from-[#059669] via-[#0d9488] to-[#0284c7]',
      bgClass: 'bg-gradient-to-r from-[#059669] via-[#0d9488] to-[#0284c7]',
    },
    {
      id: 'orange',
      name: 'সানসেট অরেঞ্জ (Sunset)',
      gradient: 'from-[#ea580c] via-[#e11d48] to-[#9333ea]',
      bgClass: 'bg-gradient-to-r from-[#ea580c] via-[#e11d48] to-[#9333ea]',
    },
    {
      id: 'red',
      name: 'রুবি রেড (Crimson)',
      gradient: 'from-[#dc2626] via-[#e11d48] to-[#7c3aed]',
      bgClass: 'bg-gradient-to-r from-[#dc2626] via-[#e11d48] to-[#7c3aed]',
    },
    {
      id: 'dark',
      name: 'ডার্ক মেটালিক (Dark)',
      gradient: 'from-[#1e293b] via-[#0f172a] to-[#334155]',
      bgClass: 'bg-gradient-to-r from-[#1e293b] via-[#0f172a] to-[#334155]',
    },
  ];

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateUser({
      ...user,
      name: editName,
      email: editEmail,
      phone: editPhone,
      shopName: editShopName,
      accountType: editAccountType,
      profileImage: editProfileImage,
      avatarUrl: editProfileImage,
    });
    setActiveModal('none');
  };

  const handleChangePin = (e: React.FormEvent) => {
    e.preventDefault();
    setPinError('');
    if (oldPin !== user.pin) {
      setPinError('বর্তমান পিন সঠিক নয়');
      return;
    }
    if (newPin.length !== 4 || !/^\d+$/.test(newPin)) {
      setPinError('নতুন পিন অবশ্যই ৪ সংখ্যার হতে হবে');
      return;
    }
    if (newPin !== confirmPin) {
      setPinError('নতুন পিন মিলছে না');
      return;
    }

    onUpdateUser({
      ...user,
      pin: newPin,
    });
    setPinSuccess(true);
    setTimeout(() => {
      setPinSuccess(false);
      setOldPin('');
      setNewPin('');
      setConfirmPin('');
      setActiveModal('none');
    }, 1500);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appShareUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleCopyPromo = () => {
    navigator.clipboard.writeText(sharePromoText);
    setCopiedPromo(true);
    setTimeout(() => setCopiedPromo(false), 2000);
  };

  const handleNativeShare = () => {
    if (navigator.share) {
      navigator
        .share({
          title: 'টেলিকম রিচার্জ ও ড্রাইভ অফার অ্যাপ',
          text: sharePromoText,
          url: appShareUrl,
        })
        .catch(() => {});
    } else {
      handleCopyPromo();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/65 backdrop-blur-xs flex justify-end">
      <div
        className={`w-full max-w-[340px] ${
          settings.darkMode ? 'bg-slate-900 text-slate-100' : 'bg-white text-slate-800'
        } h-full shadow-2xl flex flex-col justify-between px-5 animate-slideLeft overflow-y-auto`}
        style={{
          paddingTop: 'max(20px, calc(env(safe-area-inset-top, 0px) + 14px))',
          paddingBottom: 'max(20px, calc(env(safe-area-inset-bottom, 0px) + 16px))',
        }}
      >
        {/* Top Header & User Card */}
        <div>
          <div className={`flex items-center justify-between pb-3 border-b ${settings.darkMode ? 'border-slate-800' : 'border-slate-150'}`}>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className={`w-8 h-8 rounded-full ${settings.darkMode ? 'bg-slate-800 hover:bg-slate-750 text-slate-300' : 'bg-slate-100 hover:bg-slate-200 text-slate-700'} flex items-center justify-center transition-colors cursor-pointer`}
                title="হোমে ফিরুন"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h3 className={`font-extrabold ${settings.darkMode ? 'text-white' : 'text-slate-900'} text-base`}>
                প্রোফাইল ও সেটিংস
              </h3>
            </div>
            <button
              type="button"
              onClick={onClose}
              className={`w-8 h-8 rounded-full ${settings.darkMode ? 'bg-slate-800 hover:bg-slate-750 text-slate-400' : 'bg-slate-100 hover:bg-slate-200 text-slate-600'} flex items-center justify-center transition-colors cursor-pointer`}
              title="বন্ধ করুন"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* User Profile Card */}
          <div className={`mt-3.5 p-4 rounded-2xl ${settings.darkMode ? 'bg-slate-850/90 border border-slate-800' : 'bg-gradient-to-br from-sky-50 via-blue-50/50 to-slate-50 border border-sky-100'} flex items-center justify-between relative group`}>
            <div className="flex items-center gap-3">
              <div
                onClick={() => setActiveModal('profile')}
                className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#005ed9] to-[#0072CE] text-white flex items-center justify-center font-black text-lg shadow-md overflow-hidden relative cursor-pointer group/avatar shrink-0 border border-sky-200/60"
                title="প্রোফাইল ছবি দেখতে ও পরিবর্তন করতে ক্লিক করুন"
              >
                {user.profileImage ? (
                  <img
                    src={user.profileImage}
                    alt={user.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span>{user.name ? user.name.charAt(0).toUpperCase() : 'M'}</span>
                )}
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover/avatar:opacity-100 transition-opacity">
                  <Camera className="w-4 h-4 text-white" />
                </div>
              </div>
              <div>
                <h4 className={`font-extrabold ${settings.darkMode ? 'text-white' : 'text-slate-900'} text-sm leading-tight`}>
                  {user.name}
                </h4>
                <span className="text-[11px] text-slate-500 font-mono block mt-0.5">
                  {user.phone}
                </span>
                {user.email && (
                  <span className="text-[10px] text-pink-700 font-medium flex items-center gap-1 mt-0.5 truncate max-w-[160px]">
                    <Mail className="w-2.5 h-2.5 shrink-0" />
                    {user.email}
                  </span>
                )}
                <span className="inline-block mt-1 text-[10px] font-bold bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full">
                  {user.accountType}
                </span>
              </div>
            </div>

            {/* Edit Button */}
            <button
              type="button"
              onClick={() => setActiveModal('profile')}
              className={`w-8 h-8 rounded-xl ${settings.darkMode ? 'bg-slate-800 text-sky-400 hover:bg-slate-750 border border-slate-700' : 'bg-white text-indigo-600 border border-indigo-100 hover:bg-indigo-50'} shadow-2xs flex items-center justify-center transition-colors cursor-pointer`}
              title="প্রোফাইল পরিবর্তন"
            >
              <Edit3 className="w-4 h-4" />
            </button>
          </div>

          {/* Shop Name Display */}
          {user.shopName && (
            <div className={`mt-2 px-3 py-2 ${settings.darkMode ? 'bg-slate-800/80 border-slate-700/60 text-slate-200' : 'bg-slate-50 border-slate-200/70 text-slate-800'} rounded-xl border flex items-center gap-2 text-xs`}>
              <Store className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
              <span className="font-bold truncate">{user.shopName}</span>
            </div>
          )}

          {/* Core Feature Setting Menus */}
          <div className="mt-4 space-y-2">
            <h5 className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider px-1">
              অ্যাপ সেটিংস ও কাস্টমাইজেশন
            </h5>

            {/* 1. Dark Mode / Light Mode */}
            <div className={`w-full flex items-center justify-between p-3 rounded-xl ${
              settings.darkMode ? 'bg-slate-800/90 text-white border-slate-700/80' : 'bg-slate-50 text-slate-800 border-slate-100'
            } font-bold text-xs border`}>
              <div className="flex items-center gap-2.5">
                <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                  settings.darkMode ? 'bg-indigo-900/40 text-indigo-400' : 'bg-amber-500/10 text-amber-600'
                }`}>
                  {settings.darkMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
                </div>
                <div className="text-left">
                  <span>ডার্ক মোড / লাইট মোড</span>
                  <span className={`block text-[10px] ${settings.darkMode ? 'text-slate-400' : 'text-slate-400'} font-normal`}>
                    {settings.darkMode ? 'ডার্ক থিম সক্রিয়' : 'উজ্জ্বল লাইট থিম'}
                  </span>
                </div>
              </div>
              <button
                type="button"
                id="drawer-darkmode-toggle"
                onClick={() => {
                  const nextDark = !settings.darkMode;
                  onUpdateSettings({
                    ...settings,
                    darkMode: nextDark,
                    theme: nextDark ? 'dark' : (settings.theme === 'dark' ? 'purple' : settings.theme),
                  });
                }}
                className={`w-11 h-6 rounded-full transition-colors relative p-0.5 cursor-pointer ${
                  settings.darkMode ? 'bg-indigo-600' : 'bg-slate-300'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform flex items-center justify-center ${
                    settings.darkMode ? 'translate-x-5' : 'translate-x-0'
                  }`}
                >
                  {settings.darkMode ? (
                    <Moon className="w-2.5 h-2.5 text-indigo-600" />
                  ) : (
                    <Sun className="w-2.5 h-2.5 text-amber-500" />
                  )}
                </div>
              </button>
            </div>

            {/* 3. Language Selection */}
            <div className={`w-full flex items-center justify-between p-3 rounded-xl ${
              settings.darkMode ? 'bg-slate-800/90 text-white border-slate-700/80' : 'bg-slate-50 text-slate-800 border-slate-100'
            } font-bold text-xs border`}>
              <div className="flex items-center gap-2.5">
                <div className={`w-7 h-7 rounded-lg ${settings.darkMode ? 'bg-sky-950/60 text-sky-400' : 'bg-sky-100 text-sky-600'} flex items-center justify-center`}>
                  <Globe className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <span>ভাষা নির্বাচন করুন</span>
                  <span className={`block text-[10px] ${settings.darkMode ? 'text-slate-400' : 'text-slate-400'} font-normal`}>
                    {settings.language === 'en' ? 'English (Active)' : 'বাংলা (সক্রিয়)'}
                  </span>
                </div>
              </div>
              <div className={`flex items-center gap-1 p-1 rounded-xl border ${settings.darkMode ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'} shadow-2xs`}>
                <button
                  type="button"
                  id="drawer-lang-bn"
                  onClick={() => {
                    onUpdateSettings({ ...settings, language: 'bn' });
                    speakText('বাংলা ভাষা নির্বাচন করা হয়েছে', 'bn');
                  }}
                  className={`px-2 py-1 rounded-lg text-[10px] font-black transition-all ${
                    settings.language !== 'en'
                      ? 'bg-purple-600 text-white shadow-xs'
                      : settings.darkMode ? 'text-slate-400 hover:text-slate-200' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  বাংলা
                </button>
                <button
                  type="button"
                  id="drawer-lang-en"
                  onClick={() => {
                    onUpdateSettings({ ...settings, language: 'en' });
                    speakText('English language selected', 'en');
                  }}
                  className={`px-2 py-1 rounded-lg text-[10px] font-black transition-all ${
                    settings.language === 'en'
                      ? 'bg-purple-600 text-white shadow-xs'
                      : settings.darkMode ? 'text-slate-400 hover:text-slate-200' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  ENG
                </button>
              </div>
            </div>

            {/* 4. Theme Changer */}
            <button
              type="button"
              onClick={() => setActiveModal('theme')}
              className={`w-full flex items-center justify-between p-3 rounded-xl ${
                settings.darkMode ? 'bg-slate-800/90 hover:bg-slate-800 text-white border-slate-700/80' : 'bg-slate-50 hover:bg-indigo-50/60 text-slate-800 border-slate-100'
              } font-bold text-xs transition-colors border cursor-pointer`}
            >
              <div className="flex items-center gap-2.5">
                <div className={`w-7 h-7 rounded-lg ${settings.darkMode ? 'bg-purple-950/60 text-purple-400' : 'bg-purple-100 text-purple-600'} flex items-center justify-center`}>
                  <Palette className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <span>অ্যাপের থিম পরিবর্তন</span>
                  <span className={`block text-[10px] ${settings.darkMode ? 'text-slate-400' : 'text-slate-400'} font-normal`}>
                    কালার প্যালেট ও মোড
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-3.5 rounded-full bg-purple-600 border border-white shadow-2xs inline-block" />
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </div>
            </button>

            {/* Android APK Download & Install Action */}
            {onOpenAndroidApk && (
              <button
                type="button"
                id="drawer-download-apk-btn"
                onClick={() => {
                  onClose();
                  onOpenAndroidApk();
                }}
                className={`w-full flex items-center justify-between p-3 rounded-xl ${
                  settings.darkMode
                    ? 'bg-gradient-to-r from-emerald-950/70 to-teal-950/70 hover:from-emerald-900/80 hover:to-teal-900/80 text-white border-emerald-700/60'
                    : 'bg-gradient-to-r from-emerald-50 to-teal-50 hover:from-emerald-100 hover:to-teal-100 text-slate-800 border-emerald-200'
                } font-bold text-xs transition-colors border cursor-pointer shadow-xs`}
              >
                <div className="flex items-center gap-2.5">
                  <div className={`w-7 h-7 rounded-lg ${settings.darkMode ? 'bg-emerald-900/70 text-emerald-300' : 'bg-emerald-600 text-white'} flex items-center justify-center shadow-xs`}>
                    <Smartphone className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <span className="text-emerald-700 dark:text-emerald-300 font-black">অ্যান্ড্রয়েড অ্যাপ (APK) ডাউনলোড</span>
                    <span className="block text-[10px] text-slate-500 dark:text-slate-400 font-medium">
                      ১-ক্লিকে ফোনে ইনস্টল বা APK ফাইল নিন
                    </span>
                  </div>
                </div>
                <span className="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-black rounded-md shadow-xs">
                  APK
                </span>
              </button>
            )}

            {/* 5. Share App */}
            <button
              type="button"
              onClick={() => setActiveModal('share')}
              className={`w-full flex items-center justify-between p-3 rounded-xl ${
                settings.darkMode ? 'bg-slate-800/90 hover:bg-slate-800 text-white border-slate-700/80' : 'bg-slate-50 hover:bg-indigo-50/60 text-slate-800 border-slate-100'
              } font-bold text-xs transition-colors border cursor-pointer`}
            >
              <div className="flex items-center gap-2.5">
                <div className={`w-7 h-7 rounded-lg ${settings.darkMode ? 'bg-pink-950/60 text-pink-400' : 'bg-pink-100 text-pink-600'} flex items-center justify-center`}>
                  <Share2 className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <span>অ্যাপস লিংক শেয়ার করুন</span>
                  <span className={`block text-[10px] ${settings.darkMode ? 'text-slate-400' : 'text-slate-400'} font-normal`}>
                    রেফারেল লিংক ও প্রচার
                  </span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>

            {/* 6. PIN & Security */}
            <button
              type="button"
              onClick={() => setActiveModal('pin')}
              className={`w-full flex items-center justify-between p-3 rounded-xl ${
                settings.darkMode ? 'bg-slate-800/90 hover:bg-slate-800 text-white border-slate-700/80' : 'bg-slate-50 hover:bg-indigo-50/60 text-slate-800 border-slate-100'
              } font-bold text-xs transition-colors border cursor-pointer`}
            >
              <div className="flex items-center gap-2.5">
                <div className={`w-7 h-7 rounded-lg ${settings.darkMode ? 'bg-emerald-950/60 text-emerald-400' : 'bg-emerald-100 text-emerald-600'} flex items-center justify-center`}>
                  <KeyRound className="w-4 h-4" />
                </div>
                <span>পিন ও সিকিউরিটি</span>
              </div>
              <span className="text-[10px] font-bold text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                সক্রিয়
              </span>
            </button>

            {/* 7. General App Preferences */}
            <button
              type="button"
              onClick={() => setActiveModal('settings')}
              className={`w-full flex items-center justify-between p-3 rounded-xl ${
                settings.darkMode ? 'bg-slate-800/90 hover:bg-slate-800 text-white border-slate-700/80' : 'bg-slate-50 hover:bg-indigo-50/60 text-slate-800 border-slate-100'
              } font-bold text-xs transition-colors border cursor-pointer`}
            >
              <div className="flex items-center gap-2.5">
                <div className={`w-7 h-7 rounded-lg ${settings.darkMode ? 'bg-amber-950/60 text-amber-400' : 'bg-amber-100 text-amber-600'} flex items-center justify-center`}>
                  <Settings className="w-4 h-4" />
                </div>
                <span>অ্যাপ পরিচালনা সেটিংস</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>

            {/* 8. App & Data Update Center */}
            <button
              type="button"
              id="drawer-app-update-center-btn"
              onClick={() => {
                setActiveModal('update');
                setUpdateSuccess(false);
              }}
              className="w-full flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 hover:from-emerald-100 hover:to-teal-100 text-slate-900 font-extrabold text-xs transition-colors border border-emerald-200 cursor-pointer shadow-2xs"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                  <RefreshCw className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <div className="flex items-center gap-1.5">
                    <span className="font-black text-emerald-950">অ্যাপ ও ডেটা আপডেট</span>
                    <span className="text-[9px] font-black px-1.5 py-0.5 bg-emerald-600 text-white rounded-full">
                      v৩.০.১
                    </span>
                  </div>
                  <span className="block text-[10px] text-emerald-700 font-medium">
                    লাইভ ব্যালেন্স, নোটিশ ও অফার সিঙ্ক
                  </span>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-emerald-600" />
            </button>

            {/* 9. Mobile QR Code & Phone Scanner */}
            {onOpenQrScanner && (
              <button
                type="button"
                id="drawer-mobile-qr-scanner-btn"
                onClick={() => {
                  onClose();
                  onOpenQrScanner();
                }}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-purple-50 hover:bg-purple-100/80 text-purple-950 font-extrabold text-xs transition-colors border border-purple-200 cursor-pointer shadow-2xs"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-purple-600 text-white flex items-center justify-center shadow-xs">
                    <QrCode className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <span className="font-black text-purple-950">মোবাইল স্ক্যানার ও কিউআর</span>
                    <span className="block text-[10px] text-purple-700 font-medium">
                      ফোনে সরাসরি অ্যাপটি ব্যবহার করতে স্ক্যান করুন
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-purple-600" />
              </button>
            )}
          </div>

          {/* Social Channels / Community Section in Drawer */}
          {(() => {
            const activeSocials = [
              socialLinks?.whatsappGroupEnabled !== false && socialLinks?.whatsappGroup?.trim()
                ? {
                    id: 'drawer-soc-wa',
                    title: 'WhatsApp গ্রুপ',
                    url: socialLinks.whatsappGroup,
                    icon: MessageCircle,
                    color: 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border-emerald-100',
                    iconColor: 'text-emerald-600',
                  }
                : null,
              socialLinks?.telegramChannelEnabled !== false && socialLinks?.telegramChannel?.trim()
                ? {
                    id: 'drawer-soc-tg',
                    title: 'Telegram চ্যানেল',
                    url: socialLinks.telegramChannel,
                    icon: Send,
                    color: 'bg-sky-50 text-sky-800 hover:bg-sky-100 border-sky-100',
                    iconColor: 'text-sky-600',
                  }
                : null,
              socialLinks?.facebookPageEnabled !== false && socialLinks?.facebookPage?.trim()
                ? {
                    id: 'drawer-soc-fb',
                    title: 'Facebook পেজ',
                    url: socialLinks.facebookPage,
                    icon: Facebook,
                    color: 'bg-indigo-50 text-indigo-800 hover:bg-indigo-100 border-indigo-100',
                    iconColor: 'text-indigo-600',
                  }
                : null,
              socialLinks?.youtubeChannelEnabled !== false && socialLinks?.youtubeChannel?.trim()
                ? {
                    id: 'drawer-soc-yt',
                    title: 'YouTube চ্যানেল',
                    url: socialLinks.youtubeChannel,
                    icon: Youtube,
                    color: 'bg-rose-50 text-rose-800 hover:bg-rose-100 border-rose-100',
                    iconColor: 'text-rose-600',
                  }
                : null,
            ].filter(Boolean) as {
              id: string;
              title: string;
              url: string;
              icon: React.ComponentType<{ className?: string }>;
              color: string;
              iconColor: string;
            }[];

            if (activeSocials.length === 0) return null;

            return (
              <div className="mt-5 space-y-2">
                <h5 className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider px-1">
                  মার্কেটিং ও অফিসিয়াল চ্যানেল
                </h5>

                <div className="grid grid-cols-2 gap-2">
                  {activeSocials.map((soc) => {
                    const IconComp = soc.icon;
                    return (
                      <a
                        key={soc.id}
                        id={soc.id}
                        href={soc.url}
                        target="_blank"
                        rel="noreferrer"
                        className={`flex items-center gap-2 p-2.5 rounded-xl font-bold text-[11px] transition-colors border ${soc.color}`}
                      >
                        <IconComp className={`w-4 h-4 shrink-0 ${soc.iconColor}`} />
                        <span className="truncate">{soc.title}</span>
                      </a>
                    );
                  })}
                </div>
              </div>
            );
          })()}
        </div>

        {/* Bottom Log out button */}
        <div className="pt-4 border-t border-slate-100 space-y-2">
          <button
            id="drawer-logout-btn"
            type="button"
            onClick={() => {
              onClose();
              onLogout();
            }}
            className="w-full py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>লগ আউট করুন</span>
          </button>
          <span className="text-center block text-[10px] text-slate-400 font-medium">
            {settings?.appName || 'M APPS'} • {settings?.appTagline || 'মোবাইল রিচার্জ অ্যাপ'} • ভার্সন ৩.০.০
          </span>
        </div>
      </div>

      {/* 1. Edit Profile Modal */}
      {activeModal === 'profile' && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-[380px] w-full p-5 shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveModal('none')}
                  className="w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-700 transition-colors cursor-pointer"
                  title="মেন্যুতে ফিরে যান"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <User className="w-5 h-5 text-indigo-600" />
                <h3 className="font-extrabold text-slate-900 text-sm">প্রোফাইল তথ্য সম্পাদন</h3>
              </div>
              <button
                type="button"
                onClick={() => setActiveModal('none')}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 cursor-pointer"
                title="বন্ধ করুন"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-3 text-xs">
              {/* Profile Photo Upload & Preview */}
              <div className="flex flex-col items-center justify-center p-3.5 bg-gradient-to-b from-indigo-50/80 to-purple-50/50 rounded-2xl border border-indigo-100/80">
                <div className="relative group">
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="w-20 h-20 rounded-2xl overflow-hidden border-2 border-white shadow-md bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center text-white text-2xl font-black cursor-pointer hover:opacity-95 transition-opacity"
                    title="ছবি পরিবর্তন করতে ক্লিক করুন"
                  >
                    {editProfileImage ? (
                      <img
                        src={editProfileImage}
                        alt="Profile Preview"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <span>{editName ? editName.charAt(0).toUpperCase() : 'U'}</span>
                    )}
                  </div>

                  {/* Camera icon button overlay */}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute -bottom-1 -right-1 w-7 h-7 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full shadow-md flex items-center justify-center transition-transform active:scale-95 cursor-pointer border-2 border-white"
                    title="ছবি নির্বাচন করুন"
                  >
                    <Camera className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Hidden File Input */}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageFileChange}
                  className="hidden"
                />

                {/* Upload & Remove Action Buttons */}
                <div className="flex items-center gap-2 mt-3">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={imageUploading}
                    className="px-3 py-1.5 bg-white hover:bg-indigo-50 text-indigo-700 font-extrabold text-[11px] rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer border border-indigo-200 shadow-2xs active:scale-95"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>
                      {imageUploading
                        ? 'আপলোড হচ্ছে...'
                        : editProfileImage
                        ? 'ছবি পরিবর্তন'
                        : 'প্রোফাইল ছবি দিন'}
                    </span>
                  </button>

                  {editProfileImage && (
                    <button
                      type="button"
                      onClick={handleRemoveImage}
                      className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 font-bold text-[11px] rounded-xl flex items-center gap-1 transition-colors cursor-pointer border border-rose-200 active:scale-95"
                      title="ছবি মুছে ফেলুন"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>মুছুন</span>
                    </button>
                  )}
                </div>
                <p className="text-[10px] text-slate-500 mt-1.5 font-medium text-center">
                  ক্যামেরা বা ফোন গ্যালারি থেকে আপনার ছবি দিন
                </p>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">আপনার পূর্ণ নাম</label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-indigo-600"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">দোকান / ব্যবসার নাম</label>
                <input
                  type="text"
                  value={editShopName}
                  onChange={(e) => setEditShopName(e.target.value)}
                  placeholder="যেমন: মেসার্স রনি টেলিকম"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-indigo-600"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">জিমেইল আইডি (Gmail ID)</label>
                <div className="relative flex items-center">
                  <div className="absolute left-3 text-pink-600">
                    <Mail className="w-3.5 h-3.5" />
                  </div>
                  <input
                    type="email"
                    value={editEmail}
                    onChange={(e) => setEditEmail(e.target.value)}
                    placeholder="yourname@gmail.com"
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-900 outline-none focus:border-indigo-600 font-mono text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">মোবাইল নাম্বার</label>
                <input
                  type="tel"
                  required
                  value={editPhone}
                  onChange={(e) => setEditPhone(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-indigo-600"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">অ্যাকাউন্টের ধরন</label>
                <select
                  value={editAccountType}
                  onChange={(e) => setEditAccountType(e.target.value as any)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-indigo-600"
                >
                  <option value="Retailer">Retailer (রিটেইলার)</option>
                  <option value="Dealer">Dealer (ডিলার)</option>
                  <option value="Reseller">Reseller (রিসেলার)</option>
                  <option value="Personal">Personal (ব্যক্তিগত)</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#4323d4] hover:bg-[#3418ba] text-white font-extrabold text-xs rounded-xl shadow-md shadow-indigo-600/20 flex items-center justify-center gap-1.5 transition-all mt-2"
              >
                <Check className="w-4 h-4" />
                <span>পরিবর্তন সংরক্ষণ করুন</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 2. Change PIN Modal */}
      {activeModal === 'pin' && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-[380px] w-full p-5 shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveModal('none')}
                  className="w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-700 transition-colors cursor-pointer"
                  title="মেন্যুতে ফিরে যান"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <KeyRound className="w-5 h-5 text-indigo-600" />
                <h3 className="font-extrabold text-slate-900 text-sm">সিকিউরিটি পিন পরিবর্তন</h3>
              </div>
              <button
                type="button"
                onClick={() => setActiveModal('none')}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 cursor-pointer"
                title="বন্ধ করুন"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {pinSuccess ? (
              <div className="p-6 text-center space-y-2">
                <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6" />
                </div>
                <h4 className="font-extrabold text-slate-900 text-sm">পিন সফলভাবে পরিবর্তন হয়েছে!</h4>
              </div>
            ) : (
              <form onSubmit={handleChangePin} className="space-y-3 text-xs">
                {pinError && (
                  <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-600 rounded-xl font-bold text-center">
                    {pinError}
                  </div>
                )}

                <div>
                  <label className="font-bold text-slate-700 block mb-1">বর্তমান ৪ সংখ্যার পিন</label>
                  <input
                    type="password"
                    maxLength={4}
                    required
                    value={oldPin}
                    onChange={(e) => setOldPin(e.target.value)}
                    placeholder="••••"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-center text-base tracking-widest font-black text-slate-900 outline-none focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">নতুন ৪ সংখ্যার পিন</label>
                  <input
                    type="password"
                    maxLength={4}
                    required
                    value={newPin}
                    onChange={(e) => setNewPin(e.target.value)}
                    placeholder="••••"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-center text-base tracking-widest font-black text-slate-900 outline-none focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">নতুন পিন পুনরায় লিখুন</label>
                  <input
                    type="password"
                    maxLength={4}
                    required
                    value={confirmPin}
                    onChange={(e) => setConfirmPin(e.target.value)}
                    placeholder="••••"
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-center text-base tracking-widest font-black text-slate-900 outline-none focus:border-indigo-600"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#4323d4] hover:bg-[#3418ba] text-white font-extrabold text-xs rounded-xl shadow-md shadow-indigo-600/20 flex items-center justify-center gap-1.5 transition-all mt-2"
                >
                  <Check className="w-4 h-4" />
                  <span>পিন আপডেট করুন</span>
                </button>
              </form>
            )}

            {/* Biometric Quick Login Management Section */}
            <div className="pt-3 border-t border-slate-100">
              <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-200/80">
                <div className="flex items-center gap-2.5">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                    isBioEnrolled ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'
                  }`}>
                    <Fingerprint className="w-4 h-4" />
                  </div>
                  <div>
                    <h5 className="font-bold text-slate-900 text-xs">ফিঙ্গারপ্রিন্ট লগইন</h5>
                    <p className="text-[10px] text-slate-500">
                      {isBioEnrolled ? 'বর্তমানে চালু আছে' : 'দ্রুত ও সহজে লগইন'}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleToggleBiometrics}
                  disabled={bioLoading}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                    isBioEnrolled
                      ? 'bg-rose-100 text-rose-700 hover:bg-rose-200'
                      : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-xs'
                  }`}
                >
                  {bioLoading ? 'অপেক্ষা করুন...' : isBioEnrolled ? 'বন্ধ করুন' : 'চালু করুন'}
                </button>
              </div>
              {bioMsg && (
                <p className="text-[11px] text-center font-bold text-slate-600 mt-2">
                  {bioMsg}
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 3. Theme Customizer Modal */}
      {activeModal === 'theme' && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-[380px] w-full p-5 shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveModal('none')}
                  className="w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-700 transition-colors cursor-pointer"
                  title="মেন্যুতে ফিরে যান"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <Palette className="w-5 h-5 text-purple-600" />
                <h3 className="font-extrabold text-slate-900 text-sm">অ্যাপ থিম ও রঙ পরিবর্তন</h3>
              </div>
              <button
                type="button"
                onClick={() => setActiveModal('none')}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 cursor-pointer"
                title="বন্ধ করুন"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              {themes.map((t) => {
                const isSelected = settings.theme === t.id;
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => {
                      onUpdateSettings({ ...settings, theme: t.id });
                    }}
                    className={`w-full p-3 rounded-2xl border flex items-center justify-between transition-all ${
                      isSelected
                        ? 'border-purple-600 bg-purple-50/60 shadow-xs'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-xl ${t.bgClass} shadow-xs shrink-0`} />
                      <span className="font-extrabold text-xs text-slate-800">{t.name}</span>
                    </div>

                    {isSelected && (
                      <div className="w-6 h-6 rounded-full bg-purple-600 text-white flex items-center justify-center">
                        <Check className="w-3.5 h-3.5" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => setActiveModal('none')}
              className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-xs rounded-xl shadow-md transition-all mt-2"
            >
              থিম প্রয়োগ সম্পন্ন
            </button>
          </div>
        </div>
      )}

      {/* 4. Share App Modal */}
      {activeModal === 'share' && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-[380px] w-full p-5 shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveModal('none')}
                  className="w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-700 transition-colors cursor-pointer"
                  title="মেন্যুতে ফিরে যান"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <Share2 className="w-5 h-5 text-pink-600" />
                <h3 className="font-extrabold text-slate-900 text-sm">অ্যাপস লিংক শেয়ার করুন</h3>
              </div>
              <button
                type="button"
                onClick={() => setActiveModal('none')}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 cursor-pointer"
                title="বন্ধ করুন"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* App Link Box */}
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black text-slate-700 block">আপনার রেফারেল ডাউনলোড লিংক</span>
                <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-200">
                  {customShareUrl ? '✓ এডমিন নির্ধারিত লিংক' : '✓ অটোমেটিক লাইভ লিংক'}
                </span>
              </div>
              <div className="flex items-center gap-2 bg-white p-2 rounded-xl border border-slate-200">
                <span className="text-xs font-mono font-bold text-indigo-900 truncate flex-1">
                  {appShareUrl}
                </span>
                <button
                  type="button"
                  onClick={handleCopyLink}
                  className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-[11px] font-bold rounded-lg transition-colors shrink-0 flex items-center gap-1 cursor-pointer"
                >
                  {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600 stroke-[3]" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedLink ? 'কপি হয়েছে' : 'কপি'}</span>
                </button>
              </div>
            </div>

            {/* Ready Promo Text Box */}
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5">
              <span className="text-[11px] font-bold text-slate-500 block">প্রস্তুত প্রচার মেসেজ</span>
              <div className="text-[11px] text-slate-700 bg-white p-2.5 rounded-xl border border-slate-200 whitespace-pre-wrap font-sans max-h-24 overflow-y-auto">
                {sharePromoText}
              </div>
              <button
                type="button"
                onClick={handleCopyPromo}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors"
              >
                {copiedPromo ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedPromo ? 'মেসেজ কপি হয়েছে!' : 'সম্পূর্ণ মেসেজ কপি করুন'}</span>
              </button>
            </div>

            {/* Quick Share Buttons */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(sharePromoText)}`, '_blank');
                }}
                className="py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp শেয়ার</span>
              </button>

              <button
                type="button"
                onClick={handleNativeShare}
                className="py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors"
              >
                <Share2 className="w-4 h-4" />
                <span>অন্যান্য অ্যাপ</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. General App Preferences Modal */}
      {activeModal === 'settings' && (
        <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-[380px] w-full p-5 shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveModal('none')}
                  className="w-7 h-7 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-700 transition-colors cursor-pointer"
                  title="মেন্যুতে ফিরে যান"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <Settings className="w-5 h-5 text-amber-600" />
                <h3 className="font-extrabold text-slate-900 text-sm">অ্যাপ পরিচালনা সেটিংস</h3>
              </div>
              <button
                type="button"
                onClick={() => setActiveModal('none')}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 cursor-pointer"
                title="বন্ধ করুন"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              {/* Dark Mode toggle */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200/70 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center">
                    <Moon className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-slate-900 block">ডার্ক মোড / লাইট মোড</span>
                    <span className="text-[10px] text-slate-500">ডার্ক থিম এবং চোখের আরাম</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const nextDark = !settings.darkMode;
                    onUpdateSettings({
                      ...settings,
                      darkMode: nextDark,
                      theme: nextDark ? 'dark' : (settings.theme === 'dark' ? 'purple' : settings.theme),
                    });
                  }}
                  className={`w-12 h-6 rounded-full transition-colors relative p-0.5 cursor-pointer ${
                    settings.darkMode ? 'bg-indigo-600' : 'bg-slate-300'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform flex items-center justify-center ${
                      settings.darkMode ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  >
                    {settings.darkMode ? (
                      <Moon className="w-2.5 h-2.5 text-indigo-600" />
                    ) : (
                      <Sun className="w-2.5 h-2.5 text-amber-500" />
                    )}
                  </div>
                </button>
              </div>

              {/* Notification toggle */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200/70 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center">
                    <Bell className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-slate-900 block">অফার নোটিফিকেশন</span>
                    <span className="text-[10px] text-slate-500">নতুন অফার আসলে নোটিফিকেশন পান</span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.notificationsEnabled}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, notificationsEnabled: e.target.checked })
                  }
                  className="w-5 h-5 accent-indigo-600 rounded-md cursor-pointer"
                />
              </div>

              {/* Sound Effect toggle */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200/70 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center">
                    <Volume2 className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-slate-900 block">লেনদেন সাউন্ড ইফেক্ট</span>
                    <span className="text-[10px] text-slate-500">রিচার্জ সফল হলে অডিও সংকেত</span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.soundEnabled}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, soundEnabled: e.target.checked })
                  }
                  className="w-5 h-5 accent-emerald-600 rounded-md cursor-pointer"
                />
              </div>

              {/* Language toggle */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200/70 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-sky-100 text-sky-600 flex items-center justify-center">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-slate-900 block">ভাষা (Language)</span>
                    <span className="text-[10px] text-slate-500">অ্যাপের ভাষা নির্বাচন করুন</span>
                  </div>
                </div>
                <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200">
                  <button
                    type="button"
                    onClick={() => {
                      onUpdateSettings({ ...settings, language: 'bn' });
                      speakText('বাংলা ভাষা নির্বাচন করা হয়েছে', 'bn');
                    }}
                    className={`px-2 py-1 rounded-lg text-[10px] font-bold ${
                      settings.language === 'bn' ? 'bg-sky-600 text-white' : 'text-slate-600'
                    }`}
                  >
                    বাংলা
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onUpdateSettings({ ...settings, language: 'en' });
                      speakText('English language selected', 'en');
                    }}
                    className={`px-2 py-1 rounded-lg text-[10px] font-bold ${
                      settings.language === 'en' ? 'bg-sky-600 text-white' : 'text-slate-600'
                    }`}
                  >
                    English
                  </button>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setActiveModal('none')}
              className="w-full py-3 bg-slate-900 hover:bg-black text-white font-extrabold text-xs rounded-xl shadow-md transition-all mt-2"
            >
              বন্ধ করুন
            </button>
          </div>
        </div>
      )}

      {/* 6. App Update & Data Center Modal */}
      {activeModal === 'update' && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-slate-100 space-y-4 animate-scaleUp">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <RefreshCw className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">অ্যাপ ও ডেটা আপডেট সেন্টার</h3>
                  <span className="text-[10px] text-slate-500 font-medium">ভার্সন ৩.০.১ (লেটেস্ট)</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveModal('none')}
                className="w-7 h-7 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center hover:bg-slate-200 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-200 flex items-start gap-2.5">
                <Shield className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-black text-emerald-950">সিস্টেম সম্পূর্ণ আপ-টু-ডেট</h4>
                  <p className="text-[11px] text-emerald-800 leading-relaxed font-medium mt-0.5">
                    ফায়ারস্টোর ডাটাবেস, লাইভ রিচার্জ গেটওয়ে ও এডমিন ব্যালেন্স কন্ট্রোল মডিউল সক্রিয় আছে।
                  </p>
                </div>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-slate-600 font-bold">অ্যাপ্লিকেশন নাম:</span>
                  <span className="font-extrabold text-slate-900">{settings?.appName || 'M APPS'}</span>
                </div>
                <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-slate-600 font-bold">সফটওয়্যার সংস্করণ:</span>
                  <span className="font-extrabold text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded-full text-[11px]">
                    v৩.০.১ (Latest)
                  </span>
                </div>
                <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-slate-600 font-bold">ক্লাউড ডাটাবেস:</span>
                  <span className="font-extrabold text-indigo-700 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    সংযুক্ত ও সিঙ্কড
                  </span>
                </div>
              </div>

              {updateSuccess && (
                <div className="p-3 bg-teal-50 border border-teal-200 rounded-xl flex items-center gap-2 text-xs font-black text-teal-900 animate-fadeIn">
                  <Check className="w-4 h-4 text-teal-600 shrink-0" />
                  <span>সকল ব্যালেন্স, অফার ও নোটিশ সফলভাবে আপডেট হয়েছে!</span>
                </div>
              )}
            </div>

            <div className="pt-2 flex flex-col gap-2">
              <button
                type="button"
                id="modal-trigger-refresh-sync-btn"
                disabled={isUpdatingData}
                onClick={() => {
                  setIsUpdatingData(true);
                  if (onRefreshData) {
                    onRefreshData();
                  }
                  speakText('অ্যাপের সকল ডেটা সফলভাবে আপডেট করা হয়েছে', 'bn');
                  setTimeout(() => {
                    setIsUpdatingData(false);
                    setUpdateSuccess(true);
                  }, 800);
                }}
                className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
              >
                <RefreshCw className={`w-4 h-4 ${isUpdatingData ? 'animate-spin' : ''}`} />
                <span>{isUpdatingData ? 'আপডেট করা হচ্ছে...' : 'এখনই রিফ্রেশ ও আপডেট করুন'}</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveModal('none')}
                className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
