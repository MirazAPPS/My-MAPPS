import React, { useState } from 'react';
import {
  X,
  Smartphone,
  CheckCircle2,
  AlertTriangle,
  Phone,
  Sparkles,
  Receipt,
  ArrowLeft,
  Lock,
  Check,
} from 'lucide-react';
import { OperatorType, UserProfile, Transaction, RechargeRequest } from '../types';
import { OperatorLogo } from './OperatorLogos';
import { quickRechargeAmounts } from '../data/mockData';
import { saveRechargeRequestToFirestore } from '../lib/firebase';
import { getOperatorBrandTheme } from '../utils';
import confetti from 'canvas-confetti';

interface RechargeModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onRechargeComplete?: (amount: number, phone: string, operator: string, req?: RechargeRequest) => void;
}

interface OperatorDef {
  key: OperatorType;
  name: string;
  prefixes: string[];
  subname: string;
}

const OPERATORS_CONFIG: OperatorDef[] = [
  { key: 'gp', name: 'গ্রামীনফোন', prefixes: ['017', '013'], subname: 'GP (017, 013)' },
  { key: 'robi', name: 'রবি', prefixes: ['018'], subname: 'Robi (018)' },
  { key: 'banglalink', name: 'বাংলালিংক', prefixes: ['019', '014'], subname: 'BL (019, 014)' },
  { key: 'airtel', name: 'এয়ারটেল', prefixes: ['016'], subname: 'Airtel (016)' },
  { key: 'teletalk', name: 'টেলিটক', prefixes: ['015'], subname: 'Teletalk (015)' },
  { key: 'skitto', name: 'স্কিটো', prefixes: ['017', '013'], subname: 'Skitto (017, 013)' },
];

/**
 * Detects which operator a Bangladeshi number prefix belongs to
 */
const detectOperatorByPrefix = (phone: string): OperatorDef | null => {
  const clean = phone.replace(/[^0-9]/g, '');
  if (clean.length < 3) return null;
  for (const op of OPERATORS_CONFIG) {
    if (op.prefixes.some((p) => clean.startsWith(p))) {
      return op;
    }
  }
  return null;
};

export const RechargeModal: React.FC<RechargeModalProps> = ({
  isOpen,
  onClose,
  user,
  onRechargeComplete,
}) => {
  const [operator, setOperator] = useState<OperatorType>('gp');
  const [connectionType, setConnectionType] = useState<'prepaid' | 'postpaid' | 'skitto'>('prepaid');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [amount, setAmount] = useState<string>('50');
  const [pin, setPin] = useState('1234');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [completedTrx, setCompletedTrx] = useState<Transaction | null>(null);

  if (!isOpen) return null;

  const currentOpDef = OPERATORS_CONFIG.find((o) => o.key === operator) || OPERATORS_CONFIG[0];
  const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
  const detectedOp = detectOperatorByPrefix(cleanPhone);

  // Check mismatch between selected operator and entered phone number
  const isOperatorMismatch = (() => {
    if (cleanPhone.length < 3) return false;
    const matchesCurrent = currentOpDef.prefixes.some((p) => cleanPhone.startsWith(p));
    return !matchesCurrent;
  })();

  const mismatchMessage = (() => {
    if (!isOperatorMismatch) return '';
    if (detectedOp) {
      return `নির্বাচিত অপারেটর "${currentOpDef.name}", কিন্তু আপনি দিয়েছেন ${detectedOp.name}-এর নম্বর (${cleanPhone.slice(0, 3)}...)! গ্রামীণফোন/সঠিক অপারেটরের নম্বর দিন অথবা সঠিক লোগো সিলেক্ট করুন।`;
    }
    return `নির্বাচিত অপারেটর "${currentOpDef.name}"-এর জন্য নম্বরটি ${currentOpDef.prefixes.join(' অথবা ')} দিয়ে শুরু হতে হবে।`;
  })();

  const handleSelectOperator = (opKey: OperatorType) => {
    setOperator(opKey);
    setError('');
    // If skitto is selected, set account type to skitto automatically
    if (opKey === 'skitto') {
      setConnectionType('skitto');
    } else if (connectionType === 'skitto') {
      setConnectionType('prepaid');
    }
  };

  const handleQuickNumber = (num: string) => {
    setPhoneNumber(num);
    setError('');
  };

  // Direct Submission: "ওকে ক্লিক করবে চলে যাবে"
  const handleOkSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const numAmount = parseFloat(amount);

    // 1. Phone number length validation
    if (!cleanPhone || cleanPhone.length !== 11) {
      setError('অনুগ্রহ করে সঠিক ১১ ডিজিটের মোবাইল নম্বর প্রদান করুন (যেমন: 017XXXXXXXX)।');
      return;
    }

    // 2. Strict Operator Logo vs Number Match Validation
    // "যদি গ্রামীনের লোগো সিলেট করে এবং নাম্বার যদি অন্য অপারেট দেয় তাহলে এরর দেখাবে"
    const isMatched = currentOpDef.prefixes.some((p) => cleanPhone.startsWith(p));
    if (!isMatched) {
      if (detectedOp) {
        setError(
          `অপারেটর ও নম্বরে অমিল! নির্বাচিত অপারেটর "${currentOpDef.name}", কিন্তু নম্বরটি ${detectedOp.name}-এর (${cleanPhone.slice(0, 3)}...)। ${currentOpDef.name} নম্বরের শুরুতে ${currentOpDef.prefixes.join(' বা ')} দিন অথবা লোগো পরিবর্তন করুন।`
        );
      } else {
        setError(
          `অপারেটর ও নম্বরে অমিল! ${currentOpDef.name}-এর জন্য নম্বরটি অবশ্যই ${currentOpDef.prefixes.join(' বা ')} দিয়ে শুরু হতে হবে।`
        );
      }
      return;
    }

    // 3. Amount validation
    if (isNaN(numAmount) || numAmount < 10) {
      setError('সর্বনিম্ন রিচার্জ পরিমাণ ১০ টাকা।');
      return;
    }

    if (numAmount > user.mainBalance) {
      setError(`আপনার ব্যালেন্স অপর্যাপ্ত! বর্তমান কারেন্ট ব্যালেন্স ৳${user.mainBalance.toLocaleString('bn-BD')}`);
      return;
    }

    // 4. PIN validation (default fallback if empty)
    const effectivePin = pin || '1234';
    if (effectivePin.length < 4) {
      setError('অনুগ্রহ করে ৪ ডিজিটের পিন নম্বর প্রদান করুন।');
      return;
    }

    setError('');
    setIsSubmitting(true);

    const reqId = `RC-${Date.now().toString().slice(-6)}`;
    const opName = currentOpDef.name;

    // Create real Recharge Request in Firestore
    const rechargeReq: RechargeRequest = {
      id: reqId,
      userId: user.phone || 'user',
      userPhone: user.phone || '01700000000',
      userName: user.name || 'গ্রাহক',
      operator,
      operatorName: opName,
      connectionType,
      recipientPhone: cleanPhone,
      amount: numAmount,
      status: 'pending',
      createdAt: new Date().toISOString(),
      timestamp: 'আজ, এইমাত্র',
    };

    try {
      await saveRechargeRequestToFirestore(rechargeReq);
    } catch (err) {
      console.warn('Firestore recharge request notice:', err);
    }

    const newTrx: Transaction = {
      id: reqId,
      type: 'recharge',
      operator: operator,
      phoneNumber: cleanPhone,
      amount: numAmount,
      status: 'pending',
      timestamp: 'আজ, এইমাত্র',
      details: `${opName} (${connectionType === 'prepaid' ? 'প্রিপেইড' : connectionType === 'postpaid' ? 'পোস্টপেইড' : 'স্কিটো'}) রিচার্জ (প্রক্রিয়াধীন)`,
      trxId: reqId,
    };

    if (onRechargeComplete) {
      onRechargeComplete(numAmount, cleanPhone, operator, rechargeReq);
    }

    // Confetti effect
    try {
      confetti({
        particleCount: 90,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch {}

    setIsSubmitting(false);
    setCompletedTrx(newTrx);
  };

  const resetForm = () => {
    setPhoneNumber('');
    setAmount('50');
    setPin('1234');
    setError('');
    setCompletedTrx(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-[430px] w-full overflow-hidden shadow-2xl border border-slate-100 animate-fadeIn">
        {/* Header - Adapts dynamically to selected operator's genuine brand color */}
        <div className={`bg-gradient-to-r ${getOperatorBrandTheme(operator).headerGradient} px-4 py-3.5 text-white flex items-center justify-between transition-colors duration-300`}>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center backdrop-blur-sm shadow-xs">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base leading-tight">মোবাইল রিচার্জ</h3>
              <span className="text-[11px] text-white/90 font-medium">
                কারেন্ট ব্যালেন্স: ৳{user.mainBalance.toLocaleString('bn-BD')}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={resetForm}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors cursor-pointer"
            title="বন্ধ করুন"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body Form */}
        {!completedTrx ? (
          <form onSubmit={handleOkSubmit} className="p-4 space-y-3.5 max-h-[82vh] overflow-y-auto">
            {/* 1. Mobile Number Input */}
            <div>
              <div className="flex flex-col items-center justify-center mb-1">
                <label className="text-xs font-black text-slate-800 flex items-center justify-center gap-1.5 text-center">
                  <Phone className="w-3.5 h-3.5 text-blue-600" />
                  <span>১. মোবাইল নম্বর লিখুন বা সিলেক্ট করুন *</span>
                </label>
                {user.phone && (
                  <button
                    type="button"
                    onClick={() => handleQuickNumber(user.phone)}
                    className="text-[10px] font-bold text-blue-600 hover:text-blue-800 bg-blue-50 px-2 py-0.5 rounded-md transition-colors cursor-pointer mt-0.5"
                  >
                    আমার নম্বর
                  </button>
                )}
              </div>

              <div className="relative flex items-center justify-center">
                <div className="absolute left-3 flex items-center pointer-events-none">
                  <OperatorLogo operator={operator} className="w-5 h-5 rounded-md" />
                </div>
                <input
                  id="recharge-phone-input"
                  type="tel"
                  maxLength={11}
                  required
                  value={phoneNumber}
                  onChange={(e) => {
                    setPhoneNumber(e.target.value);
                    setError('');
                  }}
                  placeholder="017XXXXXXXX"
                  className={`w-full px-10 py-2.5 bg-slate-50 border rounded-xl font-mono font-black text-base outline-none transition-all text-center ${
                    isOperatorMismatch
                      ? 'border-rose-500 bg-rose-50/50 text-rose-900 focus:border-rose-600 focus:ring-2 focus:ring-rose-400/20'
                      : cleanPhone.length === 11 && !isOperatorMismatch
                      ? 'border-emerald-500 bg-emerald-50/30 text-slate-900 focus:border-emerald-600'
                      : 'border-slate-200 text-slate-900 focus:border-blue-600 focus:bg-white'
                  }`}
                />
                {cleanPhone.length > 0 && (
                  <div className="absolute right-3 flex items-center">
                    {isOperatorMismatch ? (
                      <AlertTriangle className="w-4 h-4 text-rose-600 animate-pulse" />
                    ) : cleanPhone.length === 11 ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    ) : null}
                  </div>
                )}
              </div>

              {/* Real-time Match / Mismatch Status Alert */}
              {isOperatorMismatch && (
                <div className="mt-1.5 p-2 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-start gap-1.5 animate-fadeIn">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
                  <div className="flex-1">
                    <span>{mismatchMessage}</span>
                    {detectedOp && (
                      <div className="mt-1">
                        <button
                          type="button"
                          onClick={() => handleSelectOperator(detectedOp.key)}
                          className="px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded text-[10px] font-black transition-all cursor-pointer shadow-2xs"
                        >
                          অপারেটর পরিবর্তন করে {detectedOp.name} করুন
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {!isOperatorMismatch && cleanPhone.length >= 3 && (
                <div className="mt-1 flex items-center gap-1 text-[11px] font-bold text-emerald-700 animate-fadeIn">
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span>
                    {currentOpDef.name} নম্বর নিশ্চিত ({currentOpDef.prefixes.join('/')})
                  </span>
                </div>
              )}

              {/* Quick Preset Number Test Buttons */}
              <div className="flex items-center gap-1 mt-1.5 overflow-x-auto pb-0.5 text-[10px]">
                <span className="text-slate-400 shrink-0 font-medium">কুইক টেস্ট:</span>
                <button
                  type="button"
                  onClick={() => handleQuickNumber('01700000000')}
                  className="px-1.5 py-0.5 bg-slate-100 hover:bg-sky-50 text-slate-700 hover:text-sky-700 rounded border border-slate-200 shrink-0 font-mono font-bold cursor-pointer"
                  title="গ্রামীণফোন নম্বর টেস্ট"
                >
                  GP (017)
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickNumber('01800000000')}
                  className="px-1.5 py-0.5 bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-700 rounded border border-slate-200 shrink-0 font-mono font-bold cursor-pointer"
                  title="রবি নম্বর টেস্ট (এরর যাচাই করতে)"
                >
                  Robi (018)
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickNumber('01900000000')}
                  className="px-1.5 py-0.5 bg-slate-100 hover:bg-amber-50 text-slate-700 hover:text-amber-700 rounded border border-slate-200 shrink-0 font-mono font-bold cursor-pointer"
                  title="বাংলালিংক নম্বর টেস্ট"
                >
                  BL (019)
                </button>
              </div>
            </div>

            {/* 2. Operator Logo Selection */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-black text-slate-800">
                  ২. অপারেটর লোগো সিলেক্ট করুন *
                </label>
                <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md">
                  সিলেক্টেড: {currentOpDef.name}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2">
                {OPERATORS_CONFIG.map((op) => {
                  const isSelected = operator === op.key;
                  const brand = getOperatorBrandTheme(op.key);
                  return (
                    <button
                      key={op.key}
                      type="button"
                      id={`select-operator-${op.key}`}
                      onClick={() => handleSelectOperator(op.key)}
                      className={`relative flex flex-col items-center justify-center p-2 rounded-2xl border transition-all cursor-pointer ${
                        isSelected
                          ? `${brand.selectedCard} shadow-md scale-[1.02]`
                          : 'border-slate-200 bg-slate-50/60 hover:bg-slate-100 hover:border-slate-300'
                      }`}
                    >
                      <div className="relative">
                        <OperatorLogo operator={op.key} className="w-9 h-9 shrink-0 mb-1" />
                        {isSelected && (
                          <div className={`absolute -top-1 -right-1 w-4 h-4 ${brand.badgeBg} text-white rounded-full flex items-center justify-center shadow-xs`}>
                            <Check className="w-2.5 h-2.5 stroke-[3]" />
                          </div>
                        )}
                      </div>
                      <span
                        className={`text-xs truncate max-w-full leading-tight ${
                          isSelected ? 'font-black' : 'font-bold text-slate-700'
                        }`}
                      >
                        {op.name}
                      </span>
                      <span className="text-[9px] text-slate-400 font-mono leading-none mt-0.5">
                        {op.prefixes.join(', ')}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. Account Type Selection */}
            <div>
              <label className="text-xs font-black text-slate-800 block mb-1.5">
                ৩. অ্যাকাউন্ট সিলেক্ট করুন *
              </label>
              <div className="grid grid-cols-3 gap-2 bg-slate-100 p-1.5 rounded-2xl border border-slate-200">
                {[
                  { key: 'prepaid', label: 'প্রিপেইড' },
                  { key: 'postpaid', label: 'পোস্টপেইড' },
                  { key: 'skitto', label: 'স্কিটো' },
                ].map((acc) => {
                  const isSelected = connectionType === acc.key;
                  return (
                    <button
                      key={acc.key}
                      type="button"
                      onClick={() => {
                        setConnectionType(acc.key as any);
                        if (acc.key === 'skitto') {
                          setOperator('skitto');
                        }
                      }}
                      className={`py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-white text-blue-700 shadow-sm shadow-slate-300 ring-1 ring-blue-200'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {acc.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 4. Amount Input & Quick Chips */}
            <div>
              <div className="flex flex-col items-center justify-center mb-1">
                <label className="text-xs font-black text-slate-800 text-center">
                  ৪. রিচার্জের পরিমাণ (টাকা) *
                </label>
                <span className="text-[10px] text-slate-500 font-bold mt-0.5">সর্বনিম্ন ১০ ৳</span>
              </div>
              <div className="relative flex items-center justify-center">
                <span className="absolute left-3.5 font-black text-blue-600 text-lg pointer-events-none">৳</span>
                <input
                  id="recharge-amount-input"
                  type="number"
                  min={10}
                  max={user.mainBalance || 10000}
                  required
                  value={amount}
                  onChange={(e) => {
                    setAmount(e.target.value);
                    setError('');
                  }}
                  placeholder="50"
                  className="w-full px-9 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono font-black text-slate-900 text-lg outline-none focus:border-blue-600 focus:bg-white text-center"
                />
              </div>

              {/* Quick Amount Chips */}
              <div className="flex items-center justify-center gap-1.5 mt-2 overflow-x-auto pb-1">
                {quickRechargeAmounts.map((qAmt) => (
                  <button
                    key={qAmt}
                    type="button"
                    onClick={() => {
                      setAmount(qAmt.toString());
                      setError('');
                    }}
                    className={`px-3 py-1 rounded-xl text-xs font-black border transition-all shrink-0 cursor-pointer ${
                      amount === qAmt.toString()
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    ৳{qAmt}
                  </button>
                ))}
              </div>
            </div>

            {/* 5. Quick PIN */}
            <div>
              <div className="flex flex-col items-center justify-center mb-1">
                <label className="text-xs font-black text-slate-800 flex items-center justify-center gap-1 text-center">
                  <Lock className="w-3.5 h-3.5 text-blue-600" />
                  <span>৫. আপনার পিন নম্বর (PIN)</span>
                </label>
              </div>
              <input
                type="password"
                maxLength={6}
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="1234"
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-slate-900 text-sm tracking-widest outline-none focus:border-blue-600 focus:bg-white text-center"
              />
            </div>

            {/* Error Display */}
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-300 text-rose-700 rounded-2xl text-xs font-extrabold flex items-start gap-2 animate-fadeIn shadow-xs">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            {/* OK Submit Button ("ওকে ক্লিক করবে চলে যাবে") */}
            <button
              id="recharge-ok-submit-btn"
              type="submit"
              disabled={isSubmitting}
              className={`w-full max-w-[300px] mx-auto py-3 text-white font-semibold text-[16px] rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer ${
                isOperatorMismatch
                  ? 'bg-gradient-to-r from-rose-600 to-red-600 shadow-rose-600/30'
                  : `bg-gradient-to-r ${getOperatorBrandTheme(operator).btnGradient} shadow-md active:scale-98`
              }`}
            >
              {isSubmitting ? (
                <span>রিচার্জ পাঠানো হচ্ছে...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-5 h-5" />
                  <span>ওকে (রিচার্জ পাঠান)</span>
                </>
              )}
            </button>
          </form>
        ) : (
          /* Step: Success Receipt */
          <div className="p-5 text-center space-y-4 animate-fadeIn">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center shadow-md shadow-emerald-500/20">
              <Sparkles className="w-9 h-9 animate-bounce" />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-900">রিচার্জ সফলভাবে পাঠানো হয়েছে!</h3>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                আপনার অনুরোধটি গ্রহণ করা হয়েছে। অ্যাডমিন অতি দ্রুত ব্যালেন্স যুক্ত করে দেবেন।
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-left text-xs space-y-2 font-medium">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">অপারেটর:</span>
                <div className="flex items-center gap-1.5 font-black text-slate-900">
                  <OperatorLogo operator={operator} className="w-4 h-4" />
                  <span>{currentOpDef.name}</span>
                </div>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">মোবাইল নম্বর:</span>
                <span className="font-mono font-black text-slate-900">{completedTrx.phoneNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">অ্যাকাউন্ট:</span>
                <span className="font-bold text-slate-800">
                  {connectionType === 'prepaid' ? 'প্রিপেইড' : connectionType === 'postpaid' ? 'পোস্টপেইড' : 'স্কিটো'}
                </span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-2">
                <span className="text-slate-700 font-bold">টাকার পরিমাণ:</span>
                <span className="font-mono font-black text-emerald-600 text-base">৳{completedTrx.amount}</span>
              </div>
              <div className="flex justify-between text-[11px] text-slate-400">
                <span>ট্রানজেকশন আইডি:</span>
                <span className="font-mono">{completedTrx.trxId}</span>
              </div>
            </div>

            <button
              id="recharge-success-close-btn"
              type="button"
              onClick={resetForm}
              className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold text-sm rounded-xl shadow-md shadow-emerald-600/20 cursor-pointer transition-all active:scale-98"
            >
              ঠিক আছে / সম্পন্ন
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
