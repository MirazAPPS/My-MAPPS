import React, { useState } from 'react';
import {
  ArrowLeft,
  Search,
  ShoppingCart,
  Store,
  Wallet,
  CreditCard,
  Plus,
  Minus,
  Edit2,
  Trash2,
  X,
  Check,
  TrendingUp,
  User,
  CheckCircle2,
  Coins,
  AlertCircle,
} from 'lucide-react';
import { CustomerAccount, CustomerTransaction, ShopTransaction, UserProfile } from '../types';

interface ShopLedgerViewProps {
  user: UserProfile;
  transactions: ShopTransaction[];
  customers?: CustomerAccount[];
  onBack: () => void;
  onAddTransaction: (trx: ShopTransaction) => void;
  onUpdateTransaction: (trx: ShopTransaction) => void;
  onDeleteTransaction: (id: string) => void;
  onAddCustomerTransaction?: (customerId: string, trx: CustomerTransaction) => void;
}

export const getShopTransactionTimestamp = (trx: ShopTransaction): number => {
  if (trx.createdAtMs && typeof trx.createdAtMs === 'number') {
    return trx.createdAtMs;
  }
  const match = trx.id?.match(/SHOP-(\d+)/);
  if (match && Number(match[1]) > 1000000000) {
    return Number(match[1]);
  }
  if (trx.date === 'আজ') {
    return Date.now();
  }
  if (trx.date === 'গতকাল') {
    return Date.now() - 24 * 60 * 60 * 1000;
  }
  const parsed = Date.parse(trx.date);
  if (!isNaN(parsed)) {
    return parsed;
  }
  return 0;
};

const toBengaliDigits = (val: number | string): string => {
  return String(val).replace(/\d/g, (d) => '০১২৩৪৫৬৭৮৯'[parseInt(d, 10)]);
};

export const formatShopTransactionDate = (trx: ShopTransaction): string => {
  const ts = getShopTransactionTimestamp(trx);
  if (!ts) {
    return trx.date || 'আজ';
  }

  const trxDate = new Date(ts);
  const now = new Date();

  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const yesterdayStart = todayStart - 24 * 60 * 60 * 1000;
  const trxDayStart = new Date(trxDate.getFullYear(), trxDate.getMonth(), trxDate.getDate()).getTime();

  if (trxDayStart === todayStart || trx.date === 'আজ') {
    return 'আজ';
  }
  if (trxDayStart === yesterdayStart || trx.date === 'গতকাল') {
    return 'গতকাল';
  }

  const day = trxDate.getDate().toString().padStart(2, '0');
  const monthNames = [
    'জানু', 'ফেব্রু', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
    'জুলাই', 'আগস্ট', 'সেপ্টে', 'অক্টো', 'নভে', 'ডিসে'
  ];
  const month = monthNames[trxDate.getMonth()] || '';
  return `${toBengaliDigits(day)} ${month}`;
};

export const ShopLedgerView: React.FC<ShopLedgerViewProps> = ({
  user,
  transactions,
  customers = [],
  onBack,
  onAddTransaction,
  onUpdateTransaction,
  onDeleteTransaction,
}) => {
  const [searchDate, setSearchDate] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTrx, setEditingTrx] = useState<ShopTransaction | null>(null);

  // Quick Deposit Modal state (for collecting payment on due later)
  const [quickDepositTrx, setQuickDepositTrx] = useState<ShopTransaction | null>(null);
  const [quickDepositAmount, setQuickDepositAmount] = useState('');

  // Form State: কেনা, বিক্রি, জমা অপশনাল এবং ইনপুট বক্সে সর্বদা '0' থাকবে, কোনো খালি ঘর দেখাবে না
  const [itemName, setItemName] = useState('পণ্য বিক্রি / হিসাব');
  const [buyPrice, setBuyPrice] = useState('0');
  const [sellPrice, setSellPrice] = useState('0');
  const [depositAmount, setDepositAmount] = useState('0');
  const [profitInput, setProfitInput] = useState('');
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [category, setCategory] = useState('মুদি/পণ্য');

  // Input numeric helpers to guarantee no empty/broken input boxes
  const handlePriceChange = (
    setter: React.Dispatch<React.SetStateAction<string>>,
    value: string
  ) => {
    const clean = value.replace(/[^0-9.]/g, '');
    setter(clean);
  };

  const handlePriceBlur = (
    currentValue: string,
    setter: React.Dispatch<React.SetStateAction<string>>
  ) => {
    if (!currentValue || isNaN(Number(currentValue))) {
      setter('0');
    } else {
      const num = parseFloat(currentValue);
      setter(String(num));
    }
  };

  const handleStepAmount = (
    currentValue: string,
    setter: React.Dispatch<React.SetStateAction<string>>,
    delta: number
  ) => {
    const current = parseFloat(currentValue) || 0;
    const next = Math.max(0, current + delta);
    setter(String(next));
  };

  // Auto calculate due, surplus deposit, and profit in form
  const numBuy = parseFloat(buyPrice) || 0;
  const numSell = parseFloat(sellPrice) || 0;
  const numDeposit = parseFloat(depositAmount) || 0;

  // ব্যবহারকারীর নিয়ম অনুযায়ী:
  // ১) যদি জমা না থাকে বা বিক্রির চেয়ে কম হয় তাহলে বাকি দেখাবে
  const calculatedDue = numSell > numDeposit ? numSell - numDeposit : 0;
  // ২) জমার পরিমাণ যদি বিক্রির চেয়ে বেশি থাকে তাহলে জমা আছে দেখাবে
  const calculatedSurplus = numDeposit > numSell ? numDeposit - numSell : 0;
  const isSurplusDeposit = numDeposit > numSell;
  const isNoDeposit = numDeposit === 0 && numSell > 0;
  const isFullyPaid = numSell > 0 && numDeposit === numSell;
  
  // Profit: either user-entered profit or (sell - buy)
  const autoCalculatedProfit = numBuy > 0 && numSell > 0 ? Math.max(0, numSell - numBuy) : 0;
  const calculatedProfit = profitInput !== ''
    ? parseFloat(profitInput) || 0
    : autoCalculatedProfit;

  // 5 Grand Totals for Shop Ledger: মোট কেনা, মোট বিক্রি, মোট জমা, বাকি/অবশিষ্ট ও মোট লাভ
  const totalBuy = transactions.reduce((acc, t) => acc + (Number(t.buyPrice) || 0), 0);
  const totalSell = transactions.reduce((acc, t) => acc + (Number(t.sellPrice) || 0), 0);
  const totalDeposit = transactions.reduce((acc, t) => acc + (Number(t.depositAmount) || 0), 0);
  // বাকি ও জমা আছে হিসাব (সঠিক গাণিতিক বিয়োগ)
  // ১) যদি জমা না থাকে বা বিক্রির চেয়ে কম হয় তাহলে বাকি দেখাবে
  const totalDue = totalSell > totalDeposit ? totalSell - totalDeposit : 0;
  // ২) জমার পরিমাণ যদি বিক্রির চেয়ে বেশি থাকে তাহলে জমা আছে দেখাবে
  const totalSurplus = totalDeposit > totalSell ? totalDeposit - totalSell : 0;
  const totalProfit = transactions.reduce((acc, t) => {
    if (t.profit != null && t.profit !== undefined && t.profit !== 0) {
      return acc + Number(t.profit);
    }
    const buy = Number(t.buyPrice) || 0;
    const sell = Number(t.sellPrice) || 0;
    if (buy > 0 && sell > 0) {
      return acc + (sell - buy);
    }
    return acc;
  }, 0);

  const formatTk = (amount: number | string | undefined | null) => {
    const num = Number(amount) || 0;
    if (num < 0) {
      return `৳-${Math.abs(num).toLocaleString('en-IN')}`;
    }
    return `৳${num.toLocaleString('en-IN')}`;
  };

  const handleOpenAddModal = () => {
    setEditingTrx(null);
    setItemName('পণ্য বিক্রি / হিসাব');
    setBuyPrice('0');
    setSellPrice('0');
    setDepositAmount('0');
    setProfitInput('');
    setSelectedCustomerId('');
    setCategory('মুদি/পণ্য');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (trx: ShopTransaction) => {
    setEditingTrx(trx);
    setItemName(trx.itemName || 'পণ্য বিক্রি / হিসাব');
    setBuyPrice(trx.buyPrice != null ? String(trx.buyPrice) : '0');
    setSellPrice(trx.sellPrice != null ? String(trx.sellPrice) : '0');
    setDepositAmount(trx.depositAmount != null ? String(trx.depositAmount) : '0');
    setProfitInput(trx.profit != null ? trx.profit.toString() : '');
    setSelectedCustomerId(trx.linkedCustomerId || '');
    setCategory(trx.category || 'মুদি/পণ্য');
    setIsModalOpen(true);
  };

  const handleSetFullDue = () => {
    setDepositAmount('0');
  };

  const handleSetFullPaid = () => {
    setDepositAmount(sellPrice);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalItemName = itemName.trim() || 'পণ্য বিক্রি / হিসাব';

    const bPrice = parseFloat(buyPrice) || 0;
    const sPrice = parseFloat(sellPrice) || 0;
    const dAmount = parseFloat(depositAmount) || 0;
    // কাস্টমার টাকা না দিলে অটোমেটিক বাকি দেখাবে (due = sPrice - dAmount)
    const due = sPrice > 0 ? Math.max(0, sPrice - dAmount) : 0;
    const profit = calculatedProfit;

    const matchedCust = customers.find((c) => c.id === selectedCustomerId);

    if (editingTrx) {
      onUpdateTransaction({
        ...editingTrx,
        itemName: finalItemName,
        buyPrice: bPrice,
        sellPrice: sPrice,
        depositAmount: dAmount,
        dueAmount: due,
        profit: profit,
        category,
        linkedCustomerId: selectedCustomerId || editingTrx.linkedCustomerId,
        customerName: matchedCust ? matchedCust.name : editingTrx.customerName,
        customerPhone: matchedCust ? matchedCust.phone : editingTrx.customerPhone,
      });
    } else {
      const now = new Date();
      const timeStr = now.toLocaleTimeString('bn-BD', {
        hour: '2-digit',
        minute: '2-digit',
      });
      const newTrx: ShopTransaction = {
        id: `SHOP-${Date.now()}`,
        itemName: finalItemName,
        buyPrice: bPrice,
        sellPrice: sPrice,
        depositAmount: dAmount,
        dueAmount: due,
        profit: profit,
        date: 'আজ',
        time: timeStr,
        category,
        createdAtMs: Date.now(),
        linkedCustomerId: selectedCustomerId || undefined,
        customerName: matchedCust ? matchedCust.name : undefined,
        customerPhone: matchedCust ? matchedCust.phone : undefined,
      };
      onAddTransaction(newTrx);
    }
    setIsModalOpen(false);
  };

  // Quick Deposit Handler: "পরে টাকা দিলে জমায় যোগ হবে এবং বাকি অটোমেটিক কমে যাবে। সম্পূর্ণ টাকা দিলে বাকি ০ হয়ে Paid/Success দেখাতে পারে।"
  const handleOpenQuickDeposit = (trx: ShopTransaction) => {
    setQuickDepositTrx(trx);
    setQuickDepositAmount('');
  };

  const handleApplyQuickDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickDepositTrx) return;
    const addedAmount = parseFloat(quickDepositAmount) || 0;
    if (addedAmount <= 0) return;

    const currentDeposit = Number(quickDepositTrx.depositAmount) || 0;
    const currentSell = Number(quickDepositTrx.sellPrice) || 0;
    const newDeposit = currentDeposit + addedAmount;
    const newDue = Math.max(0, currentSell - newDeposit);

    onUpdateTransaction({
      ...quickDepositTrx,
      depositAmount: newDeposit,
      dueAmount: newDue,
    });

    setQuickDepositTrx(null);
    setQuickDepositAmount('');
  };

  // 1. Strictly sort transactions descending by timestamp:
  // Today's new transactions at the very top, yesterday's next, and earlier dates in serial order (7th, 6th, 5th, 4th, 3rd...)
  const sortedTransactions = [...transactions].sort((a, b) => {
    const timeA = getShopTransactionTimestamp(a);
    const timeB = getShopTransactionTimestamp(b);
    return timeB - timeA;
  });

  // 2. Filter transactions by search query
  const filteredTransactions = sortedTransactions.filter((trx) => {
    if (!searchDate.trim() || searchDate.trim() === 'আজকের হিসাব') {
      return true;
    }
    const query = searchDate.trim().toLowerCase();
    const formattedDate = formatShopTransactionDate(trx).toLowerCase();
    const itemName = trx.itemName.toLowerCase();
    const category = (trx.category || '').toLowerCase();
    const rawDate = (trx.date || '').toLowerCase();
    return (
      formattedDate.includes(query) ||
      itemName.includes(query) ||
      category.includes(query) ||
      rawDate.includes(query)
    );
  });

  return (
    <div className="w-full bg-[#f8fafc] pb-8 text-slate-900 animate-fadeIn">
      {/* Uniform Premium Header */}
      <div
        className="bg-gradient-to-r from-[#1e1b4b] via-[#312e81] to-[#4338ca] text-white px-5 pb-5 rounded-b-[28px] shadow-md shadow-indigo-950/15"
        style={{
          paddingTop: 'max(14px, calc(env(safe-area-inset-top, 0px) + 10px))',
        }}
      >
        <div className="flex items-center justify-between mb-3">
          <button
            type="button"
            onClick={onBack}
            className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors cursor-pointer"
            title="ফিরে যান"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="text-center flex-1 pr-1">
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
              দোকানের হিসাব
            </h1>
            <p className="text-xs sm:text-sm text-indigo-200 mt-0.5 font-medium">
              {user.shopName || 'মেসার্স রনি টেলিকম ও জেনারেল স্টোর'}
            </p>
          </div>

          <div className="w-9 h-9" />
        </div>
      </div>

      {/* 5 Unified Summary Metric Cards: কেনা, বিক্রি, লাভ, জমা, বাকি */}
      <div className="px-4 -mt-3">
        <div className="bg-white rounded-3xl p-3.5 shadow-md border border-slate-100 space-y-2.5">
          {/* Top 3 Cards: কেনা, বিক্রি, লাভ - লোগো বামে এবং টেক্সট বোল্ড */}
          <div className="grid grid-cols-3 gap-2">
            {/* মোট কেনা */}
            <div className="flex items-center justify-start gap-2 p-2 rounded-xl bg-indigo-50/90 border border-indigo-200">
              <div className="w-8 h-8 rounded-full bg-white text-indigo-700 flex items-center justify-center shadow-xs border border-indigo-200 shrink-0">
                <ShoppingCart className="w-4 h-4 stroke-[2.8]" />
              </div>
              <div className="flex flex-col min-w-0 text-left">
                <span className="text-[11px] font-black text-slate-800 leading-none">কেনা</span>
                <span className="text-xs sm:text-sm font-black text-indigo-700 tracking-tight mt-0.5">
                  {formatTk(totalBuy)}
                </span>
              </div>
            </div>

            {/* মোট বিক্রি */}
            <div className="flex items-center justify-start gap-2 p-2 rounded-xl bg-rose-50/90 border border-rose-200">
              <div className="w-8 h-8 rounded-full bg-white text-rose-600 flex items-center justify-center shadow-xs border border-rose-200 shrink-0">
                <Store className="w-4 h-4 stroke-[2.8]" />
              </div>
              <div className="flex flex-col min-w-0 text-left">
                <span className="text-[11px] font-black text-slate-800 leading-none">বিক্রি</span>
                <span className="text-xs sm:text-sm font-black text-rose-600 tracking-tight mt-0.5">
                  {formatTk(totalSell)}
                </span>
              </div>
            </div>

            {/* মোট লাভ */}
            <div className="flex items-center justify-start gap-2 p-2 rounded-xl bg-emerald-50/90 border border-emerald-300">
              <div className="w-8 h-8 rounded-full bg-white text-emerald-700 flex items-center justify-center shadow-xs border border-emerald-300 shrink-0">
                <TrendingUp className="w-4 h-4 stroke-[2.8]" />
              </div>
              <div className="flex flex-col min-w-0 text-left">
                <span className="text-[11px] font-black text-emerald-900 leading-none">লাভ</span>
                <span className="text-xs sm:text-sm font-black text-emerald-600 tracking-tight mt-0.5">
                  {totalProfit >= 0 ? `+${formatTk(totalProfit)}` : formatTk(totalProfit)}
                </span>
              </div>
            </div>
          </div>

          {/* Bottom 2 Cards: মোট জমা ও মোট বাকি */}
          <div className="grid grid-cols-2 gap-2 text-center">
            {/* মোট জমা */}
            <div className="flex items-center justify-between p-2.5 px-3 rounded-2xl bg-emerald-50/80 border border-emerald-200">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-white text-emerald-700 flex items-center justify-center shadow-sm border border-emerald-200 shrink-0">
                  <Wallet className="w-4 h-4 stroke-[2.8]" />
                </div>
                <div className="text-left">
                  <span className="text-xs font-black text-slate-800 block leading-tight">মোট জমা</span>
                  <span className="text-[10px] text-slate-500 font-bold">নগদ/ব্যাংক</span>
                </div>
              </div>
              <span className="text-sm sm:text-base font-black text-emerald-600 tracking-tight">
                {formatTk(totalDeposit)}
              </span>
            </div>

            {/* বাকি অথবা জমা আছে (ব্যবহারকারীর নিয়ম: বিক্রির চেয়ে জমা বেশি হলে 'জমা আছে', না থাকলে বা কম হলে 'বাকি আছে') */}
            {totalSurplus > 0 ? (
              <div className="flex items-center justify-between p-2.5 px-3 rounded-2xl bg-emerald-50/90 border border-emerald-300">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-white text-emerald-700 flex items-center justify-center shadow-sm border border-emerald-300 shrink-0">
                    <Coins className="w-4 h-4 stroke-[2.8]" />
                  </div>
                  <div className="text-left">
                    <span className="text-xs font-black text-emerald-900 block leading-tight">জমা আছে</span>
                    <span className="text-[10px] text-emerald-700 font-bold">উদ্বৃত্ত জমা</span>
                  </div>
                </div>
                <span className="text-sm sm:text-base font-black text-emerald-600 tracking-tight">
                  +{formatTk(totalSurplus)}
                </span>
              </div>
            ) : (
              <div className="flex items-center justify-between p-2.5 px-3 rounded-2xl bg-amber-50/80 border border-amber-200">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-white text-amber-700 flex items-center justify-center shadow-sm border border-amber-200 shrink-0">
                    <CreditCard className="w-4 h-4 stroke-[2.8]" />
                  </div>
                  <div className="text-left">
                    <span className="text-xs font-black text-slate-800 block leading-tight">বাকি আছে</span>
                    <span className="text-[10px] text-slate-500 font-bold">পাওনা টাকা</span>
                  </div>
                </div>
                <span className="text-sm sm:text-base font-black text-amber-600 tracking-tight">
                  {formatTk(totalDue)}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Uniform Action Button: + নতুন হিসাব যোগ করুন */}
      <div className="px-4 mt-3.5">
        <button
          id="btn-add-shop-transaction"
          type="button"
          onClick={handleOpenAddModal}
          className="w-full py-3.5 sm:py-4 bg-[#4323d4] hover:bg-[#371cb8] text-white font-black text-sm sm:text-base rounded-2xl shadow-lg shadow-indigo-600/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer"
        >
          <Plus className="w-5 h-5" />
          <span>দোকানের নতুন হিসাব যোগ করুন</span>
        </button>
      </div>

      {/* Date Search Bar */}
      <div className="px-4 mt-4">
        <div className="bg-white rounded-2xl p-2 px-3 border border-slate-200/80 shadow-2xs flex items-center gap-2">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            value={searchDate}
            onChange={(e) => setSearchDate(e.target.value)}
            className="w-full text-xs sm:text-sm font-semibold text-slate-800 outline-none placeholder:text-slate-400"
            placeholder="তারিখ অনুযায়ী হিসাব খুঁজুন"
          />
          <span className="text-[11px] font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-xl shrink-0">
            {filteredTransactions.length} টি লেনদেন
          </span>
        </div>
      </div>

      {/* Transactions List Section */}
      <div className="px-4 mt-4">
        <div className="flex items-center justify-between mb-2.5">
          <h2 className="text-sm sm:text-base font-extrabold text-slate-900">
            দোকানের লেনদেন বিবরণী
          </h2>
          <span className="text-xs font-semibold text-slate-500">
            মোট রেকর্ড: {filteredTransactions.length}
          </span>
        </div>

        <div className="space-y-3">
          {filteredTransactions.length === 0 ? (
            <div className="p-8 text-center bg-white rounded-3xl border border-slate-200 text-slate-400 text-xs">
              এখনও কোনো লেনদেন যোগ করা হয়নি
            </div>
          ) : (
            filteredTransactions.map((trx) => {
              const itemBuy = Number(trx.buyPrice) || 0;
              const itemSell = Number(trx.sellPrice) || 0;
              const itemDeposit = Number(trx.depositAmount) || 0;
              const itemDue = Number(trx.dueAmount) || 0;
              const itemSurplus = itemDeposit > itemSell ? itemDeposit - itemSell : 0;
              const hasBuy = itemBuy > 0;
              const hasSell = itemSell > 0;
              const hasDeposit = itemDeposit > 0;
              const hasDue = itemDue > 0;
              const hasSurplus = itemSurplus > 0;
              const hasBothPrices = itemBuy > 0 && itemSell > 0;
              const itemProfit = trx.profit != null && trx.profit !== undefined && trx.profit !== 0
                ? Number(trx.profit)
                : (hasBothPrices ? itemSell - itemBuy : 0);
              const isPaid = hasSell && itemDue === 0 && itemDeposit > 0;

              return (
                <div
                  key={trx.id}
                  className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-2.5 relative hover:border-indigo-200 transition-all"
                >
                  {/* Card / Banner: বিক্রির ক্ষেত্রে মূল Card/Banner-এ শুধু অফারের বিক্রয় মূল্য ও লাভ দেখাবে */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-xs shrink-0">
                        <Store className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-sm font-black text-slate-900 block leading-tight">
                          {trx.itemName}
                        </span>
                        <div className="flex items-center gap-1.5 flex-wrap mt-0.5">
                          {trx.customerName && (
                            <span className="text-[10px] font-bold bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full inline-flex items-center gap-1">
                              <User className="w-2.5 h-2.5" />
                              <span>গ্রাহক: {trx.customerName}</span>
                            </span>
                          )}
                          {trx.category && (
                            <span className="text-[10px] font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">
                              {trx.category}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* বিক্রির ক্ষেত্রে Card/Banner-এ শুধু বিক্রয় মূল্য ও লাভ */}
                    {hasSell ? (
                      <div className="text-right shrink-0">
                        <div className="flex flex-col items-end">
                          <span className="text-[10px] text-slate-400 font-bold">বিক্রয় মূল্য</span>
                          <span className="text-sm font-black text-rose-600 tracking-tight leading-none">
                            {formatTk(trx.sellPrice)}
                          </span>
                          {itemProfit !== 0 && (
                            <span
                              className={`text-[10px] font-black px-1.5 py-0.5 rounded-md inline-flex items-center gap-0.5 mt-1 ${
                                itemProfit >= 0
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/80'
                                  : 'bg-rose-50 text-rose-700 border border-rose-200/80'
                              }`}
                            >
                              <TrendingUp className="w-2.5 h-2.5" />
                              <span>{itemProfit >= 0 ? `লাভ: +${formatTk(itemProfit)}` : `ক্ষতি: ${formatTk(itemProfit)}`}</span>
                            </span>
                          )}
                        </div>
                      </div>
                    ) : hasBothPrices ? (
                      <div className="shrink-0">
                        <span
                          className={`text-[11px] font-black px-2.5 py-1 rounded-xl flex items-center gap-1 ${
                            itemProfit >= 0
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/80'
                              : 'bg-rose-50 text-rose-700 border border-rose-200/80'
                          }`}
                        >
                          <TrendingUp className="w-3 h-3" />
                          <span>{itemProfit >= 0 ? `লাভ: +${formatTk(itemProfit)}` : `ক্ষতি: ${formatTk(itemProfit)}`}</span>
                        </span>
                      </div>
                    ) : null}
                  </div>

                  {/* Financial Breakdown Row: যে তথ্য ইনপুট দেওয়া হয়নি সেটি সম্পূর্ণ Hide থাকবে। বাকি থাকলে বাকি দেখাবে, জমা বেশি থাকলে জমা আছে দেখাবে */}
                  {(hasBuy || hasDeposit || hasDue || hasSurplus) && (
                    <div className="flex items-center gap-1.5 pt-2 border-t border-slate-100 text-center flex-wrap">
                      {hasBuy && (
                        <div className="flex-1 min-w-[70px] p-1.5 rounded-lg bg-slate-50 border border-slate-100/80">
                          <span className="text-[10px] text-slate-400 block font-medium">কেনা</span>
                          <span className="text-xs font-bold text-slate-700 truncate block">
                            {formatTk(trx.buyPrice)}
                          </span>
                        </div>
                      )}
                      {hasDeposit && (
                        <div className="flex-1 min-w-[70px] p-1.5 rounded-lg bg-emerald-50/50 border border-emerald-100/60">
                          <span className="text-[10px] text-emerald-600 block font-medium">জমা</span>
                          <span className="text-xs font-extrabold text-emerald-600 truncate block">
                            {formatTk(trx.depositAmount)}
                          </span>
                        </div>
                      )}
                      {hasSurplus && (
                        <div className="flex-1 min-w-[80px] p-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-950">
                          <span className="text-[10px] text-emerald-700 block font-black">জমা আছে</span>
                          <span className="text-xs font-black text-emerald-600 truncate block">
                            +{formatTk(itemSurplus)}
                          </span>
                        </div>
                      )}
                      {hasDue && (
                        <div className="flex-1 min-w-[80px] p-1.5 rounded-lg bg-amber-50/60 border border-amber-200/70 relative">
                          <span className="text-[10px] text-amber-700 block font-bold">বাকি আছে</span>
                          <span className="text-xs font-black text-amber-600 truncate block">
                            {formatTk(trx.dueAmount)}
                          </span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Bottom Row: Timestamp + Quick Deposit Button (if due) + Edit + Delete */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                    <span className="text-[11px] font-medium text-slate-400">
                      {formatShopTransactionDate(trx)} • {trx.time}
                    </span>

                    <div className="flex items-center gap-1.5">
                      {hasDue && (
                        <button
                          type="button"
                          onClick={() => handleOpenQuickDeposit(trx)}
                          className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 font-bold transition-colors cursor-pointer border border-emerald-200"
                          title="টাকা জমা নিন এবং বাকি কমান"
                        >
                          <Coins className="w-3.5 h-3.5 text-emerald-600" />
                          <span>+ জমা নিন</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => handleOpenEditModal(trx)}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 font-bold transition-colors cursor-pointer"
                      >
                        <Edit2 className="w-3.5 h-3.5 text-indigo-600" />
                        <span>এডিট</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onDeleteTransaction(trx.id)}
                        className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 font-bold transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                        <span>ডিলিট</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Quick Deposit Modal: "পরে টাকা দিলে জমায় যোগ হবে এবং বাকি অটোমেটিক কমে যাবে" */}
      {quickDepositTrx && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
          style={{
            paddingTop: 'max(16px, calc(env(safe-area-inset-top, 0px) + 12px))',
            paddingBottom: 'max(16px, calc(env(safe-area-inset-bottom, 0px) + 16px))',
          }}
        >
          <div className="bg-white rounded-3xl max-w-[360px] w-full p-5 shadow-2xl border border-slate-100 animate-fadeIn space-y-3 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <Coins className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">টাকা জমা নিন</h3>
                  <p className="text-[11px] text-slate-500">{quickDepositTrx.itemName}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setQuickDepositTrx(null)}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-between">
              <span className="text-xs font-bold text-amber-800">বর্তমান বাকি:</span>
              <span className="text-sm font-black text-amber-700">{formatTk(quickDepositTrx.dueAmount)}</span>
            </div>

            <form onSubmit={handleApplyQuickDeposit} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">জমা টাকার পরিমাণ (৳) *</label>
                <input
                  type="number"
                  required
                  autoFocus
                  value={quickDepositAmount}
                  onChange={(e) => setQuickDepositAmount(e.target.value)}
                  placeholder={`যেমন: ${quickDepositTrx.dueAmount}`}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-black text-emerald-600 text-base outline-none focus:border-emerald-600"
                />
              </div>

              {/* One-click full pay button */}
              <button
                type="button"
                onClick={() => setQuickDepositAmount(String(quickDepositTrx.dueAmount))}
                className="w-full py-1.5 bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold rounded-xl text-xs hover:bg-emerald-100 cursor-pointer"
              >
                পুরো বাকি {formatTk(quickDepositTrx.dueAmount)} একবারে পরিশোধ
              </button>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-md shadow-emerald-600/25 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>জমা সংরক্ষণ করুন ও বাকি কমান</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Add/Edit Transaction Modal */}
      {isModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
          style={{
            paddingTop: 'max(16px, calc(env(safe-area-inset-top, 0px) + 12px))',
            paddingBottom: 'max(16px, calc(env(safe-area-inset-bottom, 0px) + 16px))',
          }}
        >
          <div className="bg-white rounded-3xl max-w-[400px] w-full p-5 shadow-2xl border border-slate-100 animate-fadeIn space-y-3.5 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-black text-slate-900 text-base">
                {editingTrx ? 'দোকানের লেনদেন এডিট' : 'নতুন দোকানের লেনদেন যোগ'}
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
              {/* পণ্যের নাম / বিবরণ */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  পণ্যের নাম বা বিবরণ
                </label>
                <input
                  type="text"
                  required
                  value={itemName}
                  onChange={(e) => setItemName(e.target.value)}
                  placeholder="যেমন: চাল, ডাল, তেল বা রিচার্জ"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-indigo-600 focus:bg-white transition-all text-xs"
                />
                {/* কুইক ট্যাগ সিলেকশন চিপস */}
                <div className="flex items-center gap-1.5 flex-wrap mt-1.5">
                  {['পণ্য বিক্রি', 'মুদি মালামাল', 'চাল/ডাল', 'সয়াবিন তেল', 'রিচার্জ অফার'].map((tag) => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => setItemName(tag)}
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-lg border transition-all cursor-pointer ${
                        itemName === tag
                          ? 'bg-indigo-600 text-white border-indigo-700'
                          : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
                      }`}
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>

              {/* ৩টি অপশনাল ইনপুট: কেনা, বিক্রি ও জমা (+ - সহকারে, কোনো খালি ঘর নেই) */}
              <div className="space-y-3">
                {/* ১. কেনা (ক্রয় খরচ) - অপশনাল */}
                <div className="p-3 bg-indigo-50/50 border border-indigo-200/70 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="font-black text-indigo-950 flex items-center gap-1.5 text-xs">
                      <span>🛒 কেনা মূল্য (ক্রয় খরচ)</span>
                    </label>
                    <span className="text-[10px] font-bold text-indigo-600 bg-indigo-100/70 px-2 py-0.5 rounded-md">
                      ঐচ্ছিক (অপশনাল)
                    </span>
                  </div>

                  {/* + - Stepper Input Box */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleStepAmount(buyPrice, setBuyPrice, -10)}
                      className="w-10 h-10 rounded-xl bg-white border border-indigo-200 text-indigo-700 hover:bg-indigo-100/80 flex items-center justify-center font-black active:scale-95 transition-all cursor-pointer shadow-2xs shrink-0"
                      title="১০ টাকা কমান"
                    >
                      <Minus className="w-4 h-4 stroke-[3]" />
                    </button>

                    <div className="relative flex-1">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 font-black text-indigo-400 text-sm pointer-events-none">
                        ৳
                      </span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={buyPrice}
                        onFocus={(e) => e.target.select()}
                        onChange={(e) => handlePriceChange(setBuyPrice, e.target.value)}
                        onBlur={() => handlePriceBlur(buyPrice, setBuyPrice)}
                        placeholder="0"
                        className="w-full py-2 pl-7 pr-3 bg-white border border-indigo-200 rounded-xl font-black text-center text-indigo-950 text-base outline-none focus:border-indigo-600 focus:ring-2 focus:ring-indigo-600/20 transition-all"
                      />
                    </div>

                    <button
                      type="button"
                      onClick={() => handleStepAmount(buyPrice, setBuyPrice, 10)}
                      className="w-10 h-10 rounded-xl bg-indigo-600 border border-indigo-700 text-white hover:bg-indigo-700 flex items-center justify-center font-black active:scale-95 transition-all cursor-pointer shadow-xs shrink-0"
                      title="১০ টাকা বাড়ান"
                    >
                      <Plus className="w-4 h-4 stroke-[3]" />
                    </button>
                  </div>

                  {/* কুইক অ্যাডজাস্ট চিপস */}
                  <div className="flex items-center justify-between gap-1 pt-0.5">
                    <div className="flex items-center gap-1 flex-wrap">
                      <button
                        type="button"
                        onClick={() => handleStepAmount(buyPrice, setBuyPrice, -50)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-indigo-200 text-indigo-700 text-[10px] font-bold hover:bg-indigo-50 cursor-pointer"
                      >
                        -৫০
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStepAmount(buyPrice, setBuyPrice, 50)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-indigo-200 text-indigo-700 text-[10px] font-bold hover:bg-indigo-50 cursor-pointer"
                      >
                        +৫০
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStepAmount(buyPrice, setBuyPrice, 100)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-indigo-200 text-indigo-700 text-[10px] font-bold hover:bg-indigo-50 cursor-pointer"
                      >
                        +১০০
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStepAmount(buyPrice, setBuyPrice, 500)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-indigo-200 text-indigo-700 text-[10px] font-bold hover:bg-indigo-50 cursor-pointer"
                      >
                        +৫০০
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={() => setBuyPrice('0')}
                      className="text-[10px] font-bold text-slate-500 hover:text-slate-700 px-1.5 py-0.5 rounded cursor-pointer"
                    >
                      ০ (খালি)
                    </button>
                  </div>
                </div>

                {/* ২. বিক্রি (বিক্রয় মূল্য) - অপশনাল */}
                <div className="p-3 bg-rose-50/50 border border-rose-200/70 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="font-black text-rose-950 flex items-center gap-1.5 text-xs">
                      <span>🛍️ বিক্রি মূল্য (বিক্রয় মূল্য)</span>
                    </label>
                    <span className="text-[10px] font-bold text-rose-600 bg-rose-100/70 px-2 py-0.5 rounded-md">
                      ঐচ্ছিক (অপশনাল)
                    </span>
                  </div>

                  {/* + - Stepper Input Box */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleStepAmount(sellPrice, setSellPrice, -10)}
                      className="w-10 h-10 rounded-xl bg-white border border-rose-200 text-rose-700 hover:bg-rose-100/80 flex items-center justify-center font-black active:scale-95 transition-all cursor-pointer shadow-2xs shrink-0"
                      title="১০ টাকা কমান"
                    >
                      <Minus className="w-4 h-4 stroke-[3]" />
                    </button>

                    <div className="relative flex-1">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 font-black text-rose-400 text-sm pointer-events-none">
                        ৳
                      </span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={sellPrice}
                        onFocus={(e) => e.target.select()}
                        onChange={(e) => handlePriceChange(setSellPrice, e.target.value)}
                        onBlur={() => handlePriceBlur(sellPrice, setSellPrice)}
                        placeholder="0"
                        className="w-full py-2 pl-7 pr-3 bg-white border border-rose-200 rounded-xl font-black text-center text-rose-950 text-base outline-none focus:border-rose-600 focus:ring-2 focus:ring-rose-600/20 transition-all"
                      />
                    </div>

                    <button
                      type="button"
                      onClick={() => handleStepAmount(sellPrice, setSellPrice, 10)}
                      className="w-10 h-10 rounded-xl bg-rose-600 border border-rose-700 text-white hover:bg-rose-700 flex items-center justify-center font-black active:scale-95 transition-all cursor-pointer shadow-xs shrink-0"
                      title="১০ টাকা বাড়ান"
                    >
                      <Plus className="w-4 h-4 stroke-[3]" />
                    </button>
                  </div>

                  {/* কুইক অ্যাডজাস্ট চিপস */}
                  <div className="flex items-center justify-between gap-1 pt-0.5">
                    <div className="flex items-center gap-1 flex-wrap">
                      <button
                        type="button"
                        onClick={() => handleStepAmount(sellPrice, setSellPrice, -50)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-rose-200 text-rose-700 text-[10px] font-bold hover:bg-rose-50 cursor-pointer"
                      >
                        -৫০
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStepAmount(sellPrice, setSellPrice, 50)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-rose-200 text-rose-700 text-[10px] font-bold hover:bg-rose-50 cursor-pointer"
                      >
                        +৫০
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStepAmount(sellPrice, setSellPrice, 100)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-rose-200 text-rose-700 text-[10px] font-bold hover:bg-rose-50 cursor-pointer"
                      >
                        +১০০
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStepAmount(sellPrice, setSellPrice, 500)}
                        className="px-2 py-0.5 rounded-lg bg-white border border-rose-200 text-rose-700 text-[10px] font-bold hover:bg-rose-50 cursor-pointer"
                      >
                        +৫০০
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSellPrice('0')}
                      className="text-[10px] font-bold text-slate-500 hover:text-slate-700 px-1.5 py-0.5 rounded cursor-pointer"
                    >
                      ০ (খালি)
                    </button>
                  </div>
                </div>

                {/* ৩. জমা (কাস্টমার পরিশোধ) - অপশনাল */}
                <div className="p-3 bg-emerald-50/50 border border-emerald-200/70 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="font-black text-emerald-950 flex items-center gap-1.5 text-xs">
                      <span>💵 জমা টাকা (কাস্টমার পরিশোধ)</span>
                    </label>
                    {isSurplusDeposit ? (
                      <span className="text-[10px] font-black text-emerald-700 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-md flex items-center gap-1 animate-fadeIn">
                        <Coins className="w-2.5 h-2.5 text-emerald-600" />
                        <span>জমা আছে: +{formatTk(calculatedSurplus)}</span>
                      </span>
                    ) : isNoDeposit ? (
                      <span className="text-[10px] font-black text-amber-800 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-md flex items-center gap-1 animate-fadeIn">
                        <AlertCircle className="w-2.5 h-2.5 text-amber-600" />
                        <span>জমা নেই (বাকি: {formatTk(calculatedDue)})</span>
                      </span>
                    ) : calculatedDue > 0 ? (
                      <span className="text-[10px] font-black text-amber-800 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-md flex items-center gap-1 animate-fadeIn">
                        <AlertCircle className="w-2.5 h-2.5 text-amber-600" />
                        <span>বাকি আছে: {formatTk(calculatedDue)}</span>
                      </span>
                    ) : isFullyPaid ? (
                      <span className="text-[10px] font-black text-emerald-700 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-md flex items-center gap-1 animate-fadeIn">
                        <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600" />
                        <span>✓ সম্পূর্ণ পরিশোধ</span>
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold text-emerald-600 bg-emerald-100/70 px-2 py-0.5 rounded-md">
                        ঐচ্ছিক (অপশনাল)
                      </span>
                    )}
                  </div>

                  {/* + - Stepper Input Box */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleStepAmount(depositAmount, setDepositAmount, -10)}
                      className="w-10 h-10 rounded-xl bg-white border border-emerald-200 text-emerald-700 hover:bg-emerald-100/80 flex items-center justify-center font-black active:scale-95 transition-all cursor-pointer shadow-2xs shrink-0"
                      title="১০ টাকা কমান"
                    >
                      <Minus className="w-4 h-4 stroke-[3]" />
                    </button>

                    <div className="relative flex-1">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 font-black text-emerald-400 text-sm pointer-events-none">
                        ৳
                      </span>
                      <input
                        type="text"
                        inputMode="decimal"
                        value={depositAmount}
                        onFocus={(e) => e.target.select()}
                        onChange={(e) => handlePriceChange(setDepositAmount, e.target.value)}
                        onBlur={() => handlePriceBlur(depositAmount, setDepositAmount)}
                        placeholder="0"
                        className="w-full py-2 pl-7 pr-3 bg-white border border-emerald-200 rounded-xl font-black text-center text-emerald-950 text-base outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/20 transition-all"
                      />
                    </div>

                    <button
                      type="button"
                      onClick={() => handleStepAmount(depositAmount, setDepositAmount, 10)}
                      className="w-10 h-10 rounded-xl bg-emerald-600 border border-emerald-700 text-white hover:bg-emerald-700 flex items-center justify-center font-black active:scale-95 transition-all cursor-pointer shadow-xs shrink-0"
                      title="১০ টাকা বাড়ান"
                    >
                      <Plus className="w-4 h-4 stroke-[3]" />
                    </button>
                  </div>

                  {/* ওয়ান-ট্যাপ কুইক অ্যাকশন বোতাম */}
                  <div className="flex items-center justify-between gap-1 pt-0.5">
                    <div className="flex items-center gap-1 flex-wrap">
                      <button
                        type="button"
                        onClick={handleSetFullPaid}
                        className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-[10px] font-black hover:bg-emerald-700 cursor-pointer shadow-2xs"
                      >
                        ✓ পুরো পরিশোধ ({formatTk(numSell)})
                      </button>
                      <button
                        type="button"
                        onClick={handleSetFullDue}
                        className="px-2 py-1 rounded-lg bg-white border border-amber-300 text-amber-800 text-[10px] font-bold hover:bg-amber-50 cursor-pointer"
                      >
                        পুরো বাকি (০)
                      </button>
                      <button
                        type="button"
                        onClick={() => handleStepAmount(depositAmount, setDepositAmount, 50)}
                        className="px-2 py-1 rounded-lg bg-white border border-emerald-200 text-emerald-700 text-[10px] font-bold hover:bg-emerald-50 cursor-pointer"
                      >
                        +৫০
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={() => setDepositAmount('0')}
                      className="text-[10px] font-bold text-slate-500 hover:text-slate-700 px-1.5 py-0.5 rounded cursor-pointer"
                    >
                      ০ (খালি)
                    </button>
                  </div>

                  {/* ব্যবহারকারীর শর্ত অনুযায়ী স্ট্যাটাস বার্তা:
                      ১) যদি জমা না থাকে তাহলে বাকি দেখাবে
                      ২) জমার পরিমাণ যদি বেশি থাকে তাহলে জমা আছে দেখাবে */}
                  {isSurplusDeposit && (
                    <div className="p-2 rounded-xl bg-emerald-100/90 border border-emerald-300 text-emerald-950 flex items-center justify-between text-xs font-bold animate-fadeIn">
                      <span className="flex items-center gap-1.5">
                        <Coins className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                        <span>কাস্টমারের উদ্বৃত্ত জমা রয়েছে:</span>
                      </span>
                      <span className="text-[11px] font-black text-emerald-800 bg-white px-2 py-0.5 rounded-md border border-emerald-200 shadow-2xs">
                        জমা আছে: +{formatTk(calculatedSurplus)}
                      </span>
                    </div>
                  )}

                  {isNoDeposit && (
                    <div className="p-2 rounded-xl bg-amber-100/90 border border-amber-300 text-amber-950 flex items-center justify-between text-xs font-bold animate-fadeIn">
                      <span className="flex items-center gap-1.5">
                        <AlertCircle className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                        <span>টাকা জমা দেওয়া হয়নি (বাকি):</span>
                      </span>
                      <span className="text-[11px] font-black text-amber-800 bg-white px-2 py-0.5 rounded-md border border-amber-200 shadow-2xs">
                        বাকি আছে: {formatTk(calculatedDue)}
                      </span>
                    </div>
                  )}

                  {!isNoDeposit && calculatedDue > 0 && (
                    <div className="p-2 rounded-xl bg-amber-50 border border-amber-200 text-amber-950 flex items-center justify-between text-xs font-bold animate-fadeIn">
                      <span className="flex items-center gap-1.5">
                        <AlertCircle className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                        <span>আংশিক পরিশোধ, অবশিষ্ট বাকি:</span>
                      </span>
                      <span className="text-[11px] font-black text-amber-800 bg-white px-2 py-0.5 rounded-md border border-amber-200 shadow-2xs">
                        বাকি আছে: {formatTk(calculatedDue)}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* স্বয়ংক্রিয় হিসাব প্রিভিউ কার্ড: বাকি/অবশিষ্ট ও মোট লাভ */}
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center justify-between text-xs pb-1.5 border-b border-slate-200/80">
                  <span className="font-bold text-slate-600">হিসাবের তাৎক্ষণিক ফলাফল:</span>
                  <span className="text-[11px] font-bold text-slate-400">অটো ক্যালকুলেট</span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {/* বাকি অথবা জমা আছে ডাইনামিক রেজাল্ট কার্ড */}
                  {isSurplusDeposit ? (
                    <div className="p-2 rounded-xl border text-center bg-emerald-50 border-emerald-300 text-emerald-950 shadow-2xs">
                      <span className="text-[10px] font-black text-emerald-700 block opacity-90 flex items-center justify-center gap-1">
                        <Coins className="w-3 h-3 text-emerald-600" />
                        <span>জমা আছে (উদ্বৃত্ত)</span>
                      </span>
                      <span className="text-sm font-black block mt-0.5 text-emerald-700">
                        +{formatTk(calculatedSurplus)}
                      </span>
                      <span className="text-[9px] font-bold text-emerald-600 block mt-0.5">
                        কাস্টমারের জমা রয়েছে
                      </span>
                    </div>
                  ) : calculatedDue > 0 ? (
                    <div className="p-2 rounded-xl border text-center bg-amber-50 border-amber-300 text-amber-950 shadow-2xs">
                      <span className="text-[10px] font-black text-amber-800 block opacity-90 flex items-center justify-center gap-1">
                        <AlertCircle className="w-3 h-3 text-amber-600" />
                        <span>বাকি আছে</span>
                      </span>
                      <span className="text-sm font-black block mt-0.5 text-amber-700">
                        {formatTk(calculatedDue)}
                      </span>
                      <span className="text-[9px] font-bold text-amber-700 block mt-0.5">
                        {isNoDeposit ? 'কোনো জমা নেই (বাকি)' : 'অবশিষ্ট বাকি'}
                      </span>
                    </div>
                  ) : isFullyPaid ? (
                    <div className="p-2 rounded-xl border text-center bg-emerald-50 border-emerald-200 text-emerald-950 shadow-2xs">
                      <span className="text-[10px] font-black text-emerald-700 block opacity-90 flex items-center justify-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        <span>পরিশোধিত</span>
                      </span>
                      <span className="text-sm font-black block mt-0.5 text-emerald-700">
                        ✓ বাকি নেই
                      </span>
                      <span className="text-[9px] font-bold text-emerald-600 block mt-0.5">
                        সম্পূর্ণ পরিশোধ
                      </span>
                    </div>
                  ) : (
                    <div className="p-2 rounded-xl border text-center bg-white border-slate-200 text-slate-700">
                      <span className="text-[10px] font-bold block opacity-80">বাকি / জমা স্থিতি</span>
                      <span className="text-sm font-black block mt-0.5 text-slate-400">
                        ৳০
                      </span>
                      <span className="text-[9px] text-slate-400 block mt-0.5">
                        কোনো বাকি নেই
                      </span>
                    </div>
                  )}

                  {/* লাভ কার্ড */}
                  <div className={`p-2 rounded-xl border text-center ${
                    calculatedProfit > 0
                      ? 'bg-purple-50 border-purple-200 text-purple-900'
                      : numBuy > 0 && numSell > 0 && numBuy > numSell
                      ? 'bg-rose-50 border-rose-200 text-rose-900'
                      : 'bg-white border-slate-200 text-slate-700'
                  }`}>
                    <span className="text-[10px] font-bold block opacity-80">
                      {numBuy > 0 && numSell > 0 && numBuy > numSell ? 'লোকসান' : 'লাভ / প্রফিট'}
                    </span>
                    <span className="text-sm font-black block mt-0.5">
                      {numBuy > 0 && numSell > 0 && numBuy > numSell
                        ? formatTk(numBuy - numSell)
                        : formatTk(calculatedProfit)}
                    </span>
                  </div>
                </div>

                {/* কাস্টম লাভ ইনপুট অপশন (যদি ব্যবহারকারী নিজে থেকে লাভ নির্ধারণ করতে চান) */}
                <div className="pt-1 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500 font-medium">কাস্টম লাভ নির্ধারণ করতে চান?</span>
                  <input
                    type="text"
                    inputMode="decimal"
                    value={profitInput}
                    onChange={(e) => setProfitInput(e.target.value.replace(/[^0-9.-]/g, ''))}
                    placeholder={autoCalculatedProfit > 0 ? String(autoCalculatedProfit) : 'লাভ লিখুন'}
                    className="w-24 p-1 px-2 bg-white border border-slate-200 rounded-lg text-right font-bold text-purple-700 outline-none focus:border-purple-600 text-xs"
                  />
                </div>
              </div>

              {/* কাস্টমার নির্বাচন (দোকান ও কাস্টমার হিসাবের অটোমেটিক সংযোগ) */}
              {customers.length > 0 && (
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    কাস্টমার হিসাবের সাথে সংযুক্ত করুন (ঐচ্ছিক):
                  </label>
                  <select
                    value={selectedCustomerId}
                    onChange={(e) => setSelectedCustomerId(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-indigo-600 text-xs"
                  >
                    <option value="">সাধারণ দোকানের হিসাব (কোনো নির্দিষ্ট কাস্টমার নেই)</option>
                    {customers.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.phone})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3.5 bg-[#4323d4] hover:bg-[#381cb8] text-white font-black text-xs rounded-xl shadow-md shadow-indigo-600/25 flex items-center justify-center gap-1.5 transition-all mt-2 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{editingTrx ? 'পরিবর্তন সংরক্ষণ করুন' : 'হিসাব সংরক্ষণ করুন'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
