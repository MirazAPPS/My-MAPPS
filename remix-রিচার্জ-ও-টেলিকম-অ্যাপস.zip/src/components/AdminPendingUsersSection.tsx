import React, { useState } from 'react';
import {
  UserCheck,
  UserX,
  Clock,
  Smartphone,
  Mail,
  KeyRound,
  Store,
  ShieldAlert,
  Search,
  CheckCircle2,
  Copy,
  Check,
  PhoneCall,
  MessageCircle,
  Trash2,
  Sparkles,
  AlertTriangle,
  User,
  ShieldCheck,
  Briefcase,
} from 'lucide-react';
import { UserProfile } from '../types';

interface AdminPendingUsersSectionProps {
  pendingUsers: UserProfile[];
  onApproveUser: (phone: string, roleDecision?: 'user' | 'dealer') => void;
  onRejectUser: (phone: string) => void;
  onDeleteUser?: (phone: string) => void;
  onShowToast?: (msg: string) => void;
}

export const AdminPendingUsersSection: React.FC<AdminPendingUsersSectionProps> = ({
  pendingUsers,
  onApproveUser,
  onRejectUser,
  onDeleteUser,
  onShowToast,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedPhone, setCopiedPhone] = useState<string | null>(null);
  const [actionLoadingPhone, setActionLoadingPhone] = useState<string | null>(null);
  const [roleSelections, setRoleSelections] = useState<Record<string, 'user' | 'dealer'>>({});

  const handleCopy = (phone: string) => {
    navigator.clipboard.writeText(phone);
    setCopiedPhone(phone);
    if (onShowToast) onShowToast(`নম্বর কপি করা হয়েছে: ${phone}`);
    setTimeout(() => setCopiedPhone(null), 2000);
  };

  const handleApprove = (phone: string, name: string) => {
    const chosenRole = roleSelections[phone] || 'user';
    setActionLoadingPhone(phone);
    setTimeout(() => {
      onApproveUser(phone, chosenRole);
      setActionLoadingPhone(null);
      if (onShowToast) {
        onShowToast(
          `✅ ${name} এর অ্যাকাউন্ট ${chosenRole === 'dealer' ? 'ডিলার (অ্যাডমিন প্যানেল সহ)' : 'ইউজার'} হিসেবে অনুমোদিত হয়েছে!`
        );
      }
    }, 200);
  };

  const handleReject = (phone: string, name: string) => {
    if (!window.confirm(`আপনি কি নিশ্চিত যে ${name} (${phone}) এর রেজিস্ট্রেশন আবেদন বাতিল করতে চান?`)) {
      return;
    }
    setActionLoadingPhone(phone);
    setTimeout(() => {
      onRejectUser(phone);
      setActionLoadingPhone(null);
      if (onShowToast) onShowToast(`❌ ${name} এর আবেদন বাতিল করা হয়েছে।`);
    }, 200);
  };

  const filteredUsers = pendingUsers.filter((u) => {
    const q = searchQuery.toLowerCase();
    return (
      u.name.toLowerCase().includes(q) ||
      u.phone.includes(searchQuery) ||
      (u.email && u.email.toLowerCase().includes(q)) ||
      (u.shopName && u.shopName.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-4 animate-fadeIn">
      {/* Header Notification Card */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-rose-500/10 border border-amber-300/80 shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-amber-500/20 text-amber-700 flex items-center justify-center font-bold shadow-xs">
            <Clock className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-extrabold text-slate-900 text-sm">
                পেন্ডিং ইউজার রেজিস্ট্রেশন
              </h2>
              <span className="px-2 py-0.5 rounded-full bg-amber-500 text-white font-black text-[10px] shadow-xs animate-bounce">
                {pendingUsers.length} জন অপেক্ষমাণ
              </span>
            </div>
            <p className="text-[11px] text-slate-600 font-medium">
              সঠিক পিন ও তথ্য যাচাই করে অনুমোদন (Approve) বা বাতিল (Reject) করুন
            </p>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      {pendingUsers.length > 0 && (
        <div className="relative">
          <input
            type="text"
            id="pending-user-search-input"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="নাম, মোবাইল বা জিমেইল দিয়ে খুঁজুন..."
            className="w-full p-2.5 pl-9 pr-4 bg-white border border-slate-200 rounded-2xl text-xs font-semibold text-slate-900 placeholder:text-slate-400 outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 shadow-2xs"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
        </div>
      )}

      {/* Pending Users List */}
      {pendingUsers.length === 0 ? (
        <div className="p-8 text-center bg-white rounded-3xl border border-slate-200/80 shadow-xs space-y-3">
          <div className="w-14 h-14 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
            <CheckCircle2 className="w-7 h-7" />
          </div>
          <div>
            <h3 className="font-extrabold text-slate-900 text-sm">
              কোনো পেন্ডিং রেজিস্ট্রেশন নেই!
            </h3>
            <p className="text-xs text-slate-500 font-medium mt-1 leading-relaxed max-w-xs mx-auto">
              নতুন কোনো গ্রাহক সাইন আপ করলে তাৎক্ষণিকভাবে রিয়েল-টাইম নোটিফিকেশন সাউন্ড সহ এখানে যুক্ত হবে।
            </p>
          </div>
        </div>
      ) : filteredUsers.length === 0 ? (
        <div className="p-6 text-center bg-white rounded-2xl border border-slate-200 text-xs text-slate-500">
          অনুসন্ধানের সাথে কোনো পেন্ডিং ইউজার মেলেনি।
        </div>
      ) : (
        <div className="space-y-3">
          {filteredUsers.map((u) => {
            const isLoading = actionLoadingPhone === u.phone;
            const formattedWa = u.phone.replace(/^(\+880|880|0)/, '880');
            return (
              <div
                key={u.phone}
                id={`pending-user-card-${u.phone}`}
                className="p-4 bg-white rounded-2xl border border-amber-200/90 shadow-sm hover:shadow-md transition-all space-y-3 relative overflow-hidden"
              >
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-400 via-orange-500 to-rose-500" />

                {/* Top Info Bar */}
                <div className="flex items-start justify-between gap-2 pt-1">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-white flex items-center justify-center font-extrabold text-sm shadow-xs shrink-0">
                      {u.name.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h4 className="font-extrabold text-slate-900 text-sm">
                          {u.name}
                        </h4>
                        <span className="px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 text-[10px] font-extrabold border border-indigo-100">
                          {u.accountType || 'Retailer'}
                        </span>
                        <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-700 text-[10px] font-extrabold border border-amber-200 flex items-center gap-1">
                          <Clock className="w-2.5 h-2.5" />
                          পেন্ডিং
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                        {u.registeredAt ? new Date(u.registeredAt).toLocaleString('bn-BD') : 'আবেদনকৃত'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <a
                      href={`tel:${u.phone}`}
                      className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                      title="কল করুন"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                    </a>
                    <a
                      href={`https://wa.me/${formattedWa}`}
                      target="_blank"
                      rel="noreferrer"
                      className="p-1.5 rounded-lg bg-green-50 hover:bg-green-100 text-green-700 transition-colors"
                      title="WhatsApp এ মেসেজ"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>

                {/* Details Grid */}
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 grid grid-cols-2 gap-2 text-xs font-semibold text-slate-700">
                  <div className="flex items-center justify-between bg-white p-2 rounded-lg border border-slate-200/70">
                    <span className="text-slate-500 flex items-center gap-1">
                      <Smartphone className="w-3.5 h-3.5 text-slate-400" />
                      মোবাইল:
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopy(u.phone)}
                      className="font-mono font-bold text-slate-900 flex items-center gap-1 hover:text-indigo-600 cursor-pointer"
                      title="কপি করুন"
                    >
                      <span>{u.phone}</span>
                      {copiedPhone === u.phone ? (
                        <Check className="w-3 h-3 text-emerald-600" />
                      ) : (
                        <Copy className="w-3 h-3 text-slate-400" />
                      )}
                    </button>
                  </div>

                  <div className="flex items-center justify-between bg-white p-2 rounded-lg border border-slate-200/70">
                    <span className="text-slate-500 flex items-center gap-1">
                      <KeyRound className="w-3.5 h-3.5 text-amber-500" />
                      পাসওয়ার্ড পিন:
                    </span>
                    <span className="font-mono font-black text-amber-700 px-2 py-0.5 bg-amber-50 rounded border border-amber-200">
                      {u.pin || '---'}
                    </span>
                  </div>

                  {u.email && (
                    <div className="col-span-2 flex items-center justify-between bg-white p-2 rounded-lg border border-slate-200/70">
                      <span className="text-slate-500 flex items-center gap-1">
                        <Mail className="w-3.5 h-3.5 text-pink-500" />
                        জিমেইল:
                      </span>
                      <span className="font-mono font-medium text-slate-900 truncate max-w-[220px]">
                        {u.email}
                      </span>
                    </div>
                  )}

                  {u.shopName && (
                    <div className="col-span-2 flex items-center justify-between bg-white p-2 rounded-lg border border-slate-200/70">
                      <span className="text-slate-500 flex items-center gap-1">
                        <Store className="w-3.5 h-3.5 text-indigo-500" />
                        দোকান:
                      </span>
                      <span className="font-medium text-slate-900">
                        {u.shopName}
                      </span>
                    </div>
                  )}
                </div>

                {/* Role Decision Selector (ইউজার নাকি ডিলার) */}
                {(() => {
                  const selectedRole = roleSelections[u.phone] || 'user';
                  return (
                    <div className="p-3 bg-gradient-to-br from-indigo-50/90 to-sky-50/70 rounded-xl border border-indigo-200/80 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-indigo-950 flex items-center gap-1.5">
                          <Briefcase className="w-3.5 h-3.5 text-indigo-600" />
                          গ্রাহকের রোল নির্বাচন করুন:
                        </span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-black border ${
                            selectedRole === 'dealer'
                              ? 'bg-amber-100 text-amber-900 border-amber-300'
                              : 'bg-blue-100 text-blue-900 border-blue-300'
                          }`}
                        >
                          {selectedRole === 'dealer' ? '💼 ডিলার (অ্যাডমিন প্যানেল পাবে)' : '👤 ইউজার (সাধারণ গ্রাহক)'}
                        </span>
                      </div>

                      {/* 2 Selection Buttons */}
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          id={`select-role-user-${u.phone}`}
                          onClick={() => setRoleSelections((prev) => ({ ...prev, [u.phone]: 'user' }))}
                          className={`py-2 px-2.5 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
                            selectedRole === 'user'
                              ? 'bg-blue-600 text-white border-blue-600 shadow-sm ring-2 ring-blue-300 scale-[1.02]'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          <User className="w-3.5 h-3.5" />
                          <span>👤 সাধারণ ইউজার</span>
                          {selectedRole === 'user' && <Check className="w-3.5 h-3.5 text-white stroke-[3]" />}
                        </button>

                        <button
                          type="button"
                          id={`select-role-dealer-${u.phone}`}
                          onClick={() => setRoleSelections((prev) => ({ ...prev, [u.phone]: 'dealer' }))}
                          className={`py-2 px-2.5 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
                            selectedRole === 'dealer'
                              ? 'bg-amber-600 text-white border-amber-600 shadow-sm ring-2 ring-amber-300 scale-[1.02]'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>💼 ডিলার (Dealer)</span>
                          {selectedRole === 'dealer' && <Check className="w-3.5 h-3.5 text-white stroke-[3]" />}
                        </button>
                      </div>

                      <p className="text-[10px] text-slate-600 font-medium leading-relaxed">
                        {selectedRole === 'dealer'
                          ? '✅ ডিলার সিলেক্ট করে ওকে দিলে গ্রাহক এডমিন প্যানেল এক্সেস ও পরিচালনা করতে পারবে।'
                          : 'ℹ️ ইউজার সিলেক্ট করে ওকে দিলে গ্রাহক শুধু অ্যাপ ব্যবহার করতে পারবে, এডমিন প্যানেল এক্সেস পাবে না।'}
                      </p>
                    </div>
                  );
                })()}

                {/* Approve / Reject Action Buttons */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    id={`approve-user-btn-${u.phone}`}
                    disabled={isLoading}
                    onClick={() => handleApprove(u.phone, u.name)}
                    className="py-2.5 px-3 bg-gradient-to-r from-emerald-600 via-teal-600 to-green-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5 transition-all active:scale-98 cursor-pointer disabled:opacity-50"
                  >
                    <UserCheck className="w-4 h-4" />
                    <span>
                      {roleSelections[u.phone] === 'dealer'
                        ? 'ডিলার হিসেবে ওকে দিন'
                        : 'ইউজার হিসেবে ওকে দিন'}
                    </span>
                  </button>

                  <button
                    type="button"
                    id={`reject-user-btn-${u.phone}`}
                    disabled={isLoading}
                    onClick={() => handleReject(u.phone, u.name)}
                    className="py-2.5 px-3 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-700 hover:to-red-700 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition-all active:scale-98 cursor-pointer disabled:opacity-50"
                  >
                    <UserX className="w-4 h-4" />
                    <span>বাতিল (Reject)</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
