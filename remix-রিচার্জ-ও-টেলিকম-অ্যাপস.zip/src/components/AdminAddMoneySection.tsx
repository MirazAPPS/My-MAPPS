import React, { useState, useEffect } from 'react';
import {
  Wallet,
  CheckCircle2,
  XCircle,
  Clock,
  Phone,
  Copy,
  Check,
  Search,
  ArrowRight,
  ShieldCheck,
  Trash2,
  Sparkles,
  ExternalLink,
  MessageCircle,
  Settings2,
  Save,
  Building2,
  ToggleLeft,
  ToggleRight,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { AddMoneyRequest, SocialCommunityLinks, PaymentNumbersConfig } from '../types';
import { BKashLogo, NagadLogo, RocketLogo, UpayLogo } from './OperatorLogos';
import { openWhatsAppChat } from '../utils';

interface AdminAddMoneySectionProps {
  requests: AddMoneyRequest[];
  onApproveRequest: (req: AddMoneyRequest) => void;
  onRejectRequest: (requestId: string, userPhone?: string) => void;
  onDeleteRequest?: (requestId: string) => void;
  socialLinks?: SocialCommunityLinks;
  paymentNumbers?: PaymentNumbersConfig;
  onUpdatePaymentNumbers?: (numbers: PaymentNumbersConfig) => void;
  onShowToast: (msg: string) => void;
}

export const AdminAddMoneySection: React.FC<AdminAddMoneySectionProps> = ({
  requests = [],
  onApproveRequest,
  onRejectRequest,
  onDeleteRequest,
  socialLinks,
  paymentNumbers,
  onUpdatePaymentNumbers,
  onShowToast,
}) => {
  const [filterStatus, setFilterStatus] = useState<'pending' | 'approved' | 'all'>('pending');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isWalletsExpanded, setIsWalletsExpanded] = useState(true);

  // Editable payment numbers state with On/Off switches (No mock defaults)
  const [pNumbers, setPNumbers] = useState<PaymentNumbersConfig>({
    bKash: paymentNumbers?.bKash || '',
    bKashType: paymentNumbers?.bKashType || 'Send Money (Personal)',
    bKashEnabled: Boolean(paymentNumbers?.bKashEnabled),

    Nagad: paymentNumbers?.Nagad || '',
    NagadType: paymentNumbers?.NagadType || 'Send Money (Personal)',
    NagadEnabled: Boolean(paymentNumbers?.NagadEnabled),

    Rocket: paymentNumbers?.Rocket || '',
    RocketType: paymentNumbers?.RocketType || 'Send Money (Personal)',
    RocketEnabled: Boolean(paymentNumbers?.RocketEnabled),

    Upay: paymentNumbers?.Upay || '',
    UpayType: paymentNumbers?.UpayType || 'Send Money (Personal)',
    UpayEnabled: Boolean(paymentNumbers?.UpayEnabled),

    bankName: paymentNumbers?.bankName || '',
    bankAccountName: paymentNumbers?.bankAccountName || '',
    bankAccountNumber: paymentNumbers?.bankAccountNumber || '',
    bankBranchRouting: paymentNumbers?.bankBranchRouting || '',
    bankType: paymentNumbers?.bankType || 'Current / Savings',
    bankEnabled: Boolean(paymentNumbers?.bankEnabled),
  });

  // Sync state when paymentNumbers prop loads or changes from Firestore
  useEffect(() => {
    if (paymentNumbers) {
      setPNumbers({
        bKash: paymentNumbers.bKash || '',
        bKashType: paymentNumbers.bKashType || 'Send Money (Personal)',
        bKashEnabled: Boolean(paymentNumbers.bKashEnabled),

        Nagad: paymentNumbers.Nagad || '',
        NagadType: paymentNumbers.NagadType || 'Send Money (Personal)',
        NagadEnabled: Boolean(paymentNumbers.NagadEnabled),

        Rocket: paymentNumbers.Rocket || '',
        RocketType: paymentNumbers.RocketType || 'Send Money (Personal)',
        RocketEnabled: Boolean(paymentNumbers.RocketEnabled),

        Upay: paymentNumbers.Upay || '',
        UpayType: paymentNumbers.UpayType || 'Send Money (Personal)',
        UpayEnabled: Boolean(paymentNumbers.UpayEnabled),

        bankName: paymentNumbers.bankName || '',
        bankAccountName: paymentNumbers.bankAccountName || '',
        bankAccountNumber: paymentNumbers.bankAccountNumber || '',
        bankBranchRouting: paymentNumbers.bankBranchRouting || '',
        bankType: paymentNumbers.bankType || 'Current / Savings',
        bankEnabled: Boolean(paymentNumbers.bankEnabled),
      });
    }
  }, [paymentNumbers]);

  const [walletSaved, setWalletSaved] = useState(false);

  const handleToggleGateway = (
    key: 'bKashEnabled' | 'NagadEnabled' | 'RocketEnabled' | 'UpayEnabled' | 'bankEnabled',
    labelBn: string
  ) => {
    const nextVal = !pNumbers[key];
    const updated = {
      ...pNumbers,
      [key]: nextVal,
    };
    setPNumbers(updated);
    if (onUpdatePaymentNumbers) {
      onUpdatePaymentNumbers(updated);
    }
    setWalletSaved(true);
    setTimeout(() => setWalletSaved(false), 2000);

    if (nextVal) {
      const isBank = key === 'bankEnabled';
      const num = isBank
        ? (pNumbers.bankAccountNumber || '').trim()
        : (pNumbers[key.replace('Enabled', '') as keyof PaymentNumbersConfig] as string || '').trim();
      if (!num) {
        onShowToast(`⚠️ ${labelBn} অন হয়েছে। গ্রাহক প্যানেলে শো করাতে নম্বরটি লিখুন।`);
      } else {
        onShowToast(`✅ ${labelBn} চালু করা হয়েছে (গ্রাহক প্যানেলে দৃশ্যমান)`);
      }
    } else {
      onShowToast(`⭕ ${labelBn} বন্ধ করা হয়েছে (গ্রাহক প্যানেল থেকে লুকানো হয়েছে)`);
    }
  };

  const handleFieldChange = (key: keyof PaymentNumbersConfig, value: string) => {
    const updated = {
      ...pNumbers,
      [key]: value,
    };
    setPNumbers(updated);
    if (onUpdatePaymentNumbers) {
      onUpdatePaymentNumbers(updated);
    }
  };

  const handleInputBlur = () => {
    if (onUpdatePaymentNumbers) {
      onUpdatePaymentNumbers(pNumbers);
      setWalletSaved(true);
      setTimeout(() => setWalletSaved(false), 2000);
    }
  };

  const handleSaveNumbers = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (onUpdatePaymentNumbers) {
      onUpdatePaymentNumbers(pNumbers);
      setWalletSaved(true);
      onShowToast('✓ ওয়ালেট ও ব্যাংক অ্যাকাউন্ট সেটিংস সফলভাবে সংরক্ষিত হয়েছে!');
      setTimeout(() => setWalletSaved(false), 2500);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    onShowToast(`কপি হয়েছে: ${text}`);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const pendingCount = requests.filter((r) => r.status === 'pending').length;
  const approvedCount = requests.filter((r) => r.status === 'approved').length;

  const filteredRequests = requests.filter((req) => {
    if (filterStatus !== 'all' && req.status !== filterStatus) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchPhone = req.userPhone?.toLowerCase().includes(q) || req.senderNumber?.toLowerCase().includes(q);
      const matchName = req.userName?.toLowerCase().includes(q);
      const matchTrx = req.trxId?.toLowerCase().includes(q);
      const matchGateway = req.gateway?.toLowerCase().includes(q);
      if (!matchPhone && !matchName && !matchTrx && !matchGateway) return false;
    }
    return true;
  });

  const getGatewayLogo = (gw: string) => {
    switch (gw) {
      case 'bKash':
        return <BKashLogo className="w-5 h-5" />;
      case 'Nagad':
        return <NagadLogo className="w-5 h-5" />;
      case 'Rocket':
        return <RocketLogo className="w-5 h-5" />;
      case 'Upay':
        return <UpayLogo className="w-5 h-5" />;
      default:
        return <Building2 className="w-5 h-5 text-indigo-600" />;
    }
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      {/* 2.2: ওয়ালেট নাম্বার যোগ করুন [On/Off]: বিকাশ, নগদ, রকেট, উপায়, ব্যাংক অ্যাকাউন্ট */}
      <section className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-600 text-white flex items-center justify-center shadow-xs">
              <Settings2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-extrabold text-slate-900 text-sm leading-tight flex items-center gap-1.5">
                <span>ওয়ালেট নাম্বার যোগ ও নিয়ন্ত্রণ [On/Off]</span>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-black">
                  ৫টি গেটওয়ে
                </span>
              </h2>
              <p className="text-[10px] text-slate-500 font-medium">
                বিকাশ, নগদ, রকেট, উপায় ও ব্যাংক অ্যাকাউন্ট নম্বর যুক্ত ও চালু/বন্ধ করুন
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsWalletsExpanded(!isWalletsExpanded)}
            className="p-1.5 hover:bg-slate-100 rounded-xl text-slate-600 transition-colors cursor-pointer"
            title="টগল করুন"
          >
            {isWalletsExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>

        {isWalletsExpanded && (
          <form onSubmit={handleSaveNumbers} className="space-y-3 pt-1">
            {/* Guide banner */}
            <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-2xl p-3 text-xs text-emerald-900 flex items-start gap-2">
              <span className="text-base">💡</span>
              <p className="text-[11px] leading-relaxed">
                <strong>লাইভ অ্যাক্টিভেশন নিয়ম:</strong> যে মেথডে আপনি নম্বর লিখে <strong>[ON]</strong> করবেন, শুধুমাত্র সেটিই গ্রাহক প্যানেলে 'অ্যাড মানি' অপশনে শো করবে। নম্বর না দিলে বা সুইচ <strong>[OFF]</strong> রাখলে গ্রাহকের প্যানেলে তা সম্পূর্ণ লুকানো থাকবে। কোনো পরিবর্তন করার সাথে সাথেই তা তাৎক্ষণিক কার্যকর হবে।
              </p>
            </div>

            {/* 1. বিকাশ */}
            <div className={`p-3 rounded-2xl border transition-all ${pNumbers.bKashEnabled ? 'bg-pink-50/50 border-pink-200' : 'bg-slate-50 border-slate-200 opacity-75'}`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <BKashLogo className="w-5 h-5" />
                  <span className="text-xs font-black text-slate-900">১. বিকাশ (bKash)</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${pNumbers.bKashEnabled ? 'bg-pink-100 text-pink-800' : 'bg-slate-200 text-slate-600'}`}>
                    {pNumbers.bKashEnabled ? 'চালু আছে [ON]' : 'বন্ধ [OFF]'}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => handleToggleGateway('bKashEnabled', 'বিকাশ')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                    pNumbers.bKashEnabled ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {pNumbers.bKashEnabled ? <ToggleRight className="w-4 h-4" /> : <ToggleLeft className="w-4 h-4" />}
                  <span>{pNumbers.bKashEnabled ? 'ON' : 'OFF'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-slate-600 block mb-0.5">বিকাশ মোবাইল নম্বর</label>
                  <input
                    type="text"
                    value={pNumbers.bKash || ''}
                    onChange={(e) => handleFieldChange('bKash', e.target.value)}
                    onBlur={handleInputBlur}
                    placeholder="বিকাশ নম্বর লিখুন (যেমন: 017xxxxxxxx)"
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 outline-none focus:border-pink-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-600 block mb-0.5">অ্যাকাউন্ট টাইপ / নির্দেশিকা</label>
                  <input
                    type="text"
                    value={pNumbers.bKashType || ''}
                    onChange={(e) => handleFieldChange('bKashType', e.target.value)}
                    onBlur={handleInputBlur}
                    placeholder="যেমন: Send Money (Personal)"
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:border-pink-500"
                  />
                </div>
              </div>
            </div>

            {/* 2. নগদ */}
            <div className={`p-3 rounded-2xl border transition-all ${pNumbers.NagadEnabled ? 'bg-orange-50/50 border-orange-200' : 'bg-slate-50 border-slate-200 opacity-75'}`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <NagadLogo className="w-5 h-5" />
                  <span className="text-xs font-black text-slate-900">২. নগদ (Nagad)</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${pNumbers.NagadEnabled ? 'bg-orange-100 text-orange-800' : 'bg-slate-200 text-slate-600'}`}>
                    {pNumbers.NagadEnabled ? 'চালু আছে [ON]' : 'বন্ধ [OFF]'}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => handleToggleGateway('NagadEnabled', 'নগদ')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                    pNumbers.NagadEnabled ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {pNumbers.NagadEnabled ? <ToggleRight className="w-4 h-4" /> : <ToggleLeft className="w-4 h-4" />}
                  <span>{pNumbers.NagadEnabled ? 'ON' : 'OFF'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-slate-600 block mb-0.5">নগদ মোবাইল নম্বর</label>
                  <input
                    type="text"
                    value={pNumbers.Nagad || ''}
                    onChange={(e) => handleFieldChange('Nagad', e.target.value)}
                    onBlur={handleInputBlur}
                    placeholder="নগদ নম্বর লিখুন (যেমন: 018xxxxxxxx)"
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 outline-none focus:border-orange-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-600 block mb-0.5">অ্যাকাউন্ট টাইপ / নির্দেশিকা</label>
                  <input
                    type="text"
                    value={pNumbers.NagadType || ''}
                    onChange={(e) => handleFieldChange('NagadType', e.target.value)}
                    onBlur={handleInputBlur}
                    placeholder="যেমন: Send Money (Personal)"
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:border-orange-500"
                  />
                </div>
              </div>
            </div>

            {/* 3. রকেট */}
            <div className={`p-3 rounded-2xl border transition-all ${pNumbers.RocketEnabled ? 'bg-purple-50/50 border-purple-200' : 'bg-slate-50 border-slate-200 opacity-75'}`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <RocketLogo className="w-5 h-5" />
                  <span className="text-xs font-black text-slate-900">৩. রকেট (Rocket)</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${pNumbers.RocketEnabled ? 'bg-purple-100 text-purple-800' : 'bg-slate-200 text-slate-600'}`}>
                    {pNumbers.RocketEnabled ? 'চালু আছে [ON]' : 'বন্ধ [OFF]'}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => handleToggleGateway('RocketEnabled', 'রকেট')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                    pNumbers.RocketEnabled ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {pNumbers.RocketEnabled ? <ToggleRight className="w-4 h-4" /> : <ToggleLeft className="w-4 h-4" />}
                  <span>{pNumbers.RocketEnabled ? 'ON' : 'OFF'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-slate-600 block mb-0.5">রকেট ১২ ডিজিট নম্বর</label>
                  <input
                    type="text"
                    value={pNumbers.Rocket || ''}
                    onChange={(e) => handleFieldChange('Rocket', e.target.value)}
                    onBlur={handleInputBlur}
                    placeholder="রকেট নম্বর লিখুন (যেমন: 019xxxxxxxx)"
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-600 block mb-0.5">অ্যাকাউন্ট টাইপ / নির্দেশিকা</label>
                  <input
                    type="text"
                    value={pNumbers.RocketType || ''}
                    onChange={(e) => handleFieldChange('RocketType', e.target.value)}
                    onBlur={handleInputBlur}
                    placeholder="যেমন: Send Money (Personal)"
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:border-purple-500"
                  />
                </div>
              </div>
            </div>

            {/* 4. উপায় */}
            <div className={`p-3 rounded-2xl border transition-all ${pNumbers.UpayEnabled ? 'bg-blue-50/50 border-blue-200' : 'bg-slate-50 border-slate-200 opacity-75'}`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <UpayLogo className="w-5 h-5" />
                  <span className="text-xs font-black text-slate-900">৪. উপায় (Upay)</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${pNumbers.UpayEnabled ? 'bg-blue-100 text-blue-800' : 'bg-slate-200 text-slate-600'}`}>
                    {pNumbers.UpayEnabled ? 'চালু আছে [ON]' : 'বন্ধ [OFF]'}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => handleToggleGateway('UpayEnabled', 'উপায়')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                    pNumbers.UpayEnabled ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {pNumbers.UpayEnabled ? <ToggleRight className="w-4 h-4" /> : <ToggleLeft className="w-4 h-4" />}
                  <span>{pNumbers.UpayEnabled ? 'ON' : 'OFF'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-slate-600 block mb-0.5">উপায় মোবাইল নম্বর</label>
                  <input
                    type="text"
                    value={pNumbers.Upay || ''}
                    onChange={(e) => handleFieldChange('Upay', e.target.value)}
                    onBlur={handleInputBlur}
                    placeholder="উপায় নম্বর লিখুন (যেমন: 016xxxxxxxx)"
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-600 block mb-0.5">অ্যাকাউন্ট টাইপ / নির্দেশিকা</label>
                  <input
                    type="text"
                    value={pNumbers.UpayType || ''}
                    onChange={(e) => handleFieldChange('UpayType', e.target.value)}
                    onBlur={handleInputBlur}
                    placeholder="যেমন: Send Money (Personal)"
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </div>

            {/* 5. ব্যাংক অ্যাকাউন্ট */}
            <div className={`p-3 rounded-2xl border transition-all ${pNumbers.bankEnabled ? 'bg-emerald-50/50 border-emerald-200' : 'bg-slate-50 border-slate-200 opacity-75'}`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-xs">
                    <Building2 className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-xs font-black text-slate-900">৫. ব্যাংক অ্যাকাউন্ট (Bank Account)</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${pNumbers.bankEnabled ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'}`}>
                    {pNumbers.bankEnabled ? 'চালু আছে [ON]' : 'বন্ধ [OFF]'}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => handleToggleGateway('bankEnabled', 'ব্যাংক অ্যাকাউন্ট')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-extrabold transition-all cursor-pointer ${
                    pNumbers.bankEnabled ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {pNumbers.bankEnabled ? <ToggleRight className="w-4 h-4" /> : <ToggleLeft className="w-4 h-4" />}
                  <span>{pNumbers.bankEnabled ? 'ON' : 'OFF'}</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-slate-600 block mb-0.5">ব্যাংকের নাম</label>
                  <input
                    type="text"
                    value={pNumbers.bankName || ''}
                    onChange={(e) => handleFieldChange('bankName', e.target.value)}
                    onBlur={handleInputBlur}
                    placeholder="যেমন: Islami Bank Bangladesh Ltd"
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-900 outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-600 block mb-0.5">অ্যাকাউন্ট নাম (A/C Name)</label>
                  <input
                    type="text"
                    value={pNumbers.bankAccountName || ''}
                    onChange={(e) => handleFieldChange('bankAccountName', e.target.value)}
                    onBlur={handleInputBlur}
                    placeholder="যেমন: Telecom Service"
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-900 outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-600 block mb-0.5">হিসাব নম্বর (A/C Number)</label>
                  <input
                    type="text"
                    value={pNumbers.bankAccountNumber || ''}
                    onChange={(e) => handleFieldChange('bankAccountNumber', e.target.value)}
                    onBlur={handleInputBlur}
                    placeholder="যেমন: 2050xxxxxxxxxxxx"
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-600 block mb-0.5">শাখা ও রাউটিং নম্বর</label>
                  <input
                    type="text"
                    value={pNumbers.bankBranchRouting || ''}
                    onChange={(e) => handleFieldChange('bankBranchRouting', e.target.value)}
                    onBlur={handleInputBlur}
                    placeholder="যেমন: মিরপুর শাখা (রাউটিং: 125260)"
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            </div>

            <div className="pt-2 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100">
              <div className="flex items-center gap-1.5 text-[11px]">
                {walletSaved ? (
                  <span className="text-xs font-bold text-emerald-600 flex items-center gap-1 animate-fadeIn">
                    <Check className="w-4 h-4" />
                    <span>✓ সেটিংস স্বয়ংক্রিয়ভাবে সংরক্ষিত হয়েছে!</span>
                  </span>
                ) : (
                  <span className="text-slate-400 font-medium">
                    * সুইচ অন/অফ বা নম্বর লেখার সাথে সাথে স্বয়ংক্রিয়ভাবে আপডেট হয়
                  </span>
                )}
              </div>
              <button
                type="submit"
                id="save-wallet-numbers-btn"
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>সেটিংস সেভ করুন</span>
              </button>
            </div>
          </form>
        )}
      </section>

      {/* 2.1: ব্যালেন্স এড পেন্ডিং রিকোয়েস্ট (বাটন: সাকসেস / ক্যানসেল) */}
      <section className="bg-white rounded-3xl p-4 sm:p-5 border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
              <Wallet className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-extrabold text-slate-900 text-sm leading-tight">
                ব্যালেন্স এড রিকোয়েস্ট তালিকা
              </h2>
              <p className="text-[10px] text-slate-500 font-medium">
                গ্রাহকদের প্রেরিত টাকা যাচাই করে সাকসেস বা ক্যানসেল করুন
              </p>
            </div>
          </div>
          <span className="px-2.5 py-1 rounded-xl bg-emerald-100 text-emerald-800 font-black text-xs">
            পেন্ডিং: {pendingCount}
          </span>
        </div>

        {/* Filters */}
        <div className="flex gap-1.5 bg-slate-100 p-1 rounded-xl">
          <button
            type="button"
            id="filter-addmoney-pending"
            onClick={() => setFilterStatus('pending')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              filterStatus === 'pending'
                ? 'bg-white text-emerald-700 shadow-xs font-extrabold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            পেন্ডিং ({pendingCount})
          </button>
          <button
            type="button"
            id="filter-addmoney-approved"
            onClick={() => setFilterStatus('approved')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              filterStatus === 'approved'
                ? 'bg-white text-blue-700 shadow-xs font-extrabold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            সাকসেস ({approvedCount})
          </button>
          <button
            type="button"
            id="filter-addmoney-all"
            onClick={() => setFilterStatus('all')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              filterStatus === 'all'
                ? 'bg-white text-slate-900 shadow-xs font-extrabold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            সকল ({requests.length})
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <input
            type="text"
            id="search-addmoney-input"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="মোবাইল নম্বর, নাম, TrxID বা গেটওয়ে দিয়ে খুঁজুন..."
            className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 outline-none focus:border-emerald-600 focus:bg-white transition-all"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
        </div>
      </section>

      {/* Requests List */}
      <div className="space-y-3">
        {filteredRequests.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-slate-200 text-slate-500 space-y-2">
            <Wallet className="w-10 h-10 text-slate-300 mx-auto" />
            <p className="font-bold text-xs text-slate-700">কোনো ব্যালেন্স এড রিকোয়েস্ট পাওয়া যায়নি</p>
            <p className="text-[11px] text-slate-400">গ্রাহকরা অ্যাড মানি সাবমিট করলে এখানে রিয়েল-টাইমে দেখতে পাবেন।</p>
          </div>
        ) : (
          filteredRequests.map((req) => (
            <div
              key={req.id}
              id={`addmoney-card-${req.id}`}
              className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs hover:border-emerald-300 transition-all space-y-3"
            >
              {/* Header: User & Status */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getGatewayLogo(req.gateway)}
                  <div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-extrabold text-xs text-slate-900">{req.userName || 'গ্রাহক'}</span>
                      <span className="font-mono text-[11px] text-slate-500 font-bold">({req.userPhone})</span>
                    </div>
                    <span className="text-[10px] text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{req.timestamp || 'আজ, এইমাত্র'}</span>
                    </span>
                  </div>
                </div>

                <span
                  className={`px-2.5 py-0.5 rounded-full font-extrabold text-[10px] border ${
                    req.status === 'approved'
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      : req.status === 'rejected'
                      ? 'bg-rose-50 text-rose-700 border-rose-200'
                      : 'bg-amber-50 text-amber-800 border-amber-300 animate-pulse'
                  }`}
                >
                  {req.status === 'approved' ? '✓ সাকসেস (অনুমোদিত)' : req.status === 'rejected' ? '✕ ক্যানসেল (বাতিল)' : '⏳ পেন্ডিং'}
                </span>
              </div>

              {/* Transaction Details Box */}
              <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-[10px] text-slate-500 block font-medium">টাকার পরিমাণ</span>
                  <span className="font-black text-base text-emerald-700">৳{req.amount}</span>
                  {req.bonus > 0 && (
                    <span className="text-[10px] text-emerald-600 font-bold block">(+৳{req.bonus} বোনাস)</span>
                  )}
                </div>

                <div>
                  <span className="text-[10px] text-slate-500 block font-medium">ব্যালেন্স টাইপ</span>
                  <span className="font-bold text-slate-800 capitalize bg-white px-2 py-0.5 rounded-md border border-slate-200 inline-block mt-0.5">
                    {req.balanceType === 'drive' ? 'ড্রাইভ ব্যালেন্স' : req.balanceType === 'bank' ? 'ব্যাংক ব্যালেন্স' : 'মেইন ব্যালেন্স'}
                  </span>
                </div>

                {req.senderNumber && (
                  <div className="col-span-2 text-[11px] text-slate-600 font-medium">
                    <span>প্রেরকের নম্বর: </span>
                    <span className="font-mono font-bold text-slate-900">{req.senderNumber}</span>
                  </div>
                )}

                <div className="col-span-2 flex items-center justify-between border-t border-slate-200/60 pt-2">
                  <div className="flex items-center gap-1 font-mono text-[11px] font-bold text-slate-800">
                    <span className="text-slate-400">TrxID:</span>
                    <span className="tracking-wider bg-white px-1.5 py-0.5 rounded border border-slate-200">{req.trxId}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(req.trxId, req.id)}
                    className="flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md hover:bg-emerald-100 transition-colors cursor-pointer"
                  >
                    {copiedId === req.id ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedId === req.id ? 'কপি হয়েছে' : 'কপি'}</span>
                  </button>
                </div>
              </div>

              {/* 2.1 Action Buttons: সাকসেস / ক্যানসেল */}
              <div className="flex items-center gap-2 pt-1">
                {req.status === 'pending' ? (
                  <>
                    <button
                      type="button"
                      id={`btn-approve-addmoney-${req.id}`}
                      onClick={() => {
                        onApproveRequest(req);
                        onShowToast(`সাকসেস! গ্রাহকের অ্যাকাউন্টে ৳${req.totalCredit} ব্যালেন্স যুক্ত হয়েছে`);
                      }}
                      className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all active:scale-98 cursor-pointer"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>সাকসেস (অনুমোদন)</span>
                    </button>

                    <button
                      type="button"
                      id={`btn-cancel-addmoney-${req.id}`}
                      onClick={() => {
                        onRejectRequest(req.id, req.userPhone);
                        onShowToast('রিকোয়েস্টটি ক্যানসেল (বাতিল) করা হয়েছে');
                      }}
                      className="px-4 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-black transition-all active:scale-98 cursor-pointer"
                    >
                      <XCircle className="w-4 h-4 inline-block mr-1" />
                      <span>ক্যানসেল</span>
                    </button>
                  </>
                ) : (
                  <div className="flex-1 flex items-center justify-between text-xs text-slate-500">
                    <span className="font-bold">
                      {req.status === 'approved' ? '✓ লেনদেন সফল হয়েছে' : '✕ লেনদেন বাতিল করা হয়েছে'}
                    </span>
                    {onDeleteRequest && (
                      <button
                        type="button"
                        onClick={() => onDeleteRequest(req.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                        title="মুছে ফেলুন"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
