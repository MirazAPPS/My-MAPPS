import React, { useState } from 'react';
import {
  MessageCircle,
  Send,
  Youtube,
  Share2,
  Copy,
  Check,
  Sparkles,
  ExternalLink,
  Users,
  Megaphone,
  X,
  Flame,
  ArrowRight,
} from 'lucide-react';
import { DriveOffer, UserProfile } from '../types';

interface SocialMarketingHubProps {
  offers: DriveOffer[];
  user: UserProfile;
}

export const SocialMarketingHub: React.FC<SocialMarketingHubProps> = ({ offers, user }) => {
  const [isBroadcastModalOpen, setIsBroadcastModalOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  // Generate marketing broadcast text for WhatsApp/Telegram/Facebook
  const generateBroadcastText = () => {
    const shop = user.shopName || 'মেসার্স রনি স্টোর ও টেলিকম';
    const topOffers = offers.slice(0, 5);
    
    let text = `🔥 *${shop} - আজকের সেরা ড্রাইভ অফারসমূহ* 🔥\n`;
    text += `📅 তারিখ: ${new Date().toLocaleDateString('bn-BD')}\n`;
    text += `━━━━━━━━━━━━━━━━━━━━━\n\n`;

    topOffers.forEach((o, i) => {
      const opName = o.operatorName.toUpperCase();
      const minText = o.minutes > 0 ? `${o.minutes} মিনিট` : '';
      const gbText = o.internetGB > 0 ? `${o.internetGB} GB` : '';
      const combo = [minText, gbText].filter(Boolean).join(' + ');
      text += `${i + 1}️⃣ *${opName}*: ${combo} (${o.validityDays} দিন)\n`;
      text += `   🏷️ রেগুলার মূল্য: ৳${o.regularPriceTK || o.priceTK + 30}\n`;
      text += `   💰 *অফার মূল্য: মাত্র ৳${o.priceTK}* (ক্যাশব্যাক ৳${o.cashbackTK})\n\n`;
    });

    text += `━━━━━━━━━━━━━━━━━━━━━\n`;
    text += `⚡ *ইনস্ট্যান্ট রিচার্জ পেতে যোগাযোগ করুন:*\n`;
    text += `📞 মোবাইল: ${user.phone}\n`;
    text += `💬 হোয়াটসঅ্যাপ: https://wa.me/88${user.phone.replace(/[^0-9]/g, '')}\n`;
    text += `🏪 দোকান: ${shop}\n\n`;
    text += `📲 আমাদের রিচার্জ অ্যাপ ডাউনলোড লিংক:\nhttps://telecom-bd.app/download?ref=${user.phone}`;

    return text;
  };

  const handleCopyBroadcast = () => {
    const text = generateBroadcastText();
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleShareToWhatsApp = () => {
    const text = generateBroadcastText();
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleShareToTelegram = () => {
    const text = generateBroadcastText();
    window.open(`https://t.me/share/url?url=${encodeURIComponent('https://telecom-bd.app')}&text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="px-5 py-2">
      {/* Section Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#005ed9] to-[#0072CE] text-white flex items-center justify-center shadow-xs">
            <Megaphone className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base font-extrabold text-slate-900 tracking-tight leading-tight">
              অফার মার্কেটিং ও সোশ্যাল প্রচার
            </h2>
            <span className="text-[11px] text-slate-500 font-medium block">
              গ্রুপ ও চ্যানেলে যুক্ত হয়ে অফার সেল বাড়ান
            </span>
          </div>
        </div>

        {/* Quick Broadcast Button */}
        <button
          type="button"
          onClick={() => setIsBroadcastModalOpen(true)}
          className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-extrabold text-[11px] shadow-sm shadow-orange-500/20 active:scale-95 transition-all"
        >
          <Flame className="w-3.5 h-3.5" />
          <span>অফার প্রচার টুল</span>
        </button>
      </div>

      {/* 4 Social Marketing Channels Grid */}
      <div className="grid grid-cols-2 gap-2.5">
        {/* 1. WhatsApp Group */}
        <a
          href="https://chat.whatsapp.com/invite/telecomVIP"
          target="_blank"
          rel="noreferrer"
          className="bg-white rounded-2xl p-3 border border-emerald-100 hover:border-emerald-300 shadow-xs hover:shadow-md transition-all group flex flex-col justify-between relative overflow-hidden"
        >
          <div className="flex items-start justify-between">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition-transform">
              <MessageCircle className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-extrabold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
              VIP গ্রুপ
            </span>
          </div>

          <div className="mt-2.5">
            <h3 className="text-xs font-black text-slate-900 group-hover:text-emerald-700 transition-colors">
              হোয়াটসঅ্যাপ গ্রুপ
            </h3>
            <p className="text-[10px] text-slate-500 font-medium leading-tight mt-0.5">
              ড্রাইভ অফার ও ইনস্ট্যান্ট কাস্টমার সাপোর্ট
            </p>
          </div>

          <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] font-bold text-emerald-700">
            <span>জয়েন করুন</span>
            <ExternalLink className="w-3 h-3" />
          </div>
        </a>

        {/* 2. Telegram Channel */}
        <a
          href="https://t.me/telecom_app_bd"
          target="_blank"
          rel="noreferrer"
          className="bg-white rounded-2xl p-3 border border-sky-100 hover:border-sky-300 shadow-xs hover:shadow-md transition-all group flex flex-col justify-between relative overflow-hidden"
        >
          <div className="flex items-start justify-between">
            <div className="w-9 h-9 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Send className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-extrabold bg-sky-100 text-sky-800 px-2 py-0.5 rounded-full">
              চ্যানেল
            </span>
          </div>

          <div className="mt-2.5">
            <h3 className="text-xs font-black text-slate-900 group-hover:text-sky-700 transition-colors">
              টেলিগ্রাম চ্যানেল
            </h3>
            <p className="text-[10px] text-slate-500 font-medium leading-tight mt-0.5">
              মুহূর্তেই অফার নোটিশ ও ক্যাশব্যাক রেট
            </p>
          </div>

          <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] font-bold text-sky-700">
            <span>সাবস্ক্রাইব</span>
            <ExternalLink className="w-3 h-3" />
          </div>
        </a>

        {/* 3. Facebook Page & Group */}
        <a
          href="https://facebook.com/telecom.recharge.official"
          target="_blank"
          rel="noreferrer"
          className="bg-white rounded-2xl p-3 border border-indigo-100 hover:border-indigo-300 shadow-xs hover:shadow-md transition-all group flex flex-col justify-between relative overflow-hidden"
        >
          <div className="flex items-start justify-between">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Users className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-extrabold bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full">
              পেজ ও গ্রুপ
            </span>
          </div>

          <div className="mt-2.5">
            <h3 className="text-xs font-black text-slate-900 group-hover:text-indigo-700 transition-colors">
              ফেসবুক কমিউনিটি
            </h3>
            <p className="text-[10px] text-slate-500 font-medium leading-tight mt-0.5">
              অফার ব্যানার, লাইভ আপডেট ও পোস্ট
            </p>
          </div>

          <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] font-bold text-indigo-700">
            <span>ফলো করুন</span>
            <ExternalLink className="w-3 h-3" />
          </div>
        </a>

        {/* 4. YouTube Channel */}
        <a
          href="https://youtube.com/@telecom_tutorials"
          target="_blank"
          rel="noreferrer"
          className="bg-white rounded-2xl p-3 border border-rose-100 hover:border-rose-300 shadow-xs hover:shadow-md transition-all group flex flex-col justify-between relative overflow-hidden"
        >
          <div className="flex items-start justify-between">
            <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Youtube className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-extrabold bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full">
              ভিডিও
            </span>
          </div>

          <div className="mt-2.5">
            <h3 className="text-xs font-black text-slate-900 group-hover:text-rose-700 transition-colors">
              ইউটিউব চ্যানেল
            </h3>
            <p className="text-[10px] text-slate-500 font-medium leading-tight mt-0.5">
              অ্যাপ টিউটোরিয়াল, ড্রাইভ অফার ট্রিকস
            </p>
          </div>

          <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] font-bold text-rose-700">
            <span>ভিডিও দেখুন</span>
            <ExternalLink className="w-3 h-3" />
          </div>
        </a>
      </div>

      {/* Broadcast Modal */}
      {isBroadcastModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-[400px] w-full p-5 shadow-2xl border border-slate-100 animate-fadeIn space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center">
                  <Flame className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">
                    অফার প্রচার বার্তা জেনারেটর
                  </h3>
                  <span className="text-[10px] text-slate-500">
                    হোয়াটসঅ্যাপ, টেলিগ্রাম ও ফেসবুকে পোস্ট করুন
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsBroadcastModalOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Preview Box */}
            <div className="bg-slate-900 text-emerald-400 p-3.5 rounded-2xl font-mono text-[11px] whitespace-pre-wrap leading-relaxed shadow-inner max-h-[220px] overflow-y-auto border border-slate-800">
              {generateBroadcastText()}
            </div>

            {/* Quick Action Buttons */}
            <div className="space-y-2">
              <button
                type="button"
                onClick={handleCopyBroadcast}
                className="w-full py-3 bg-slate-900 hover:bg-black text-white font-extrabold text-xs rounded-xl flex items-center justify-center gap-2 transition-all shadow-md active:scale-98"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>টেক্সট কপি সম্পন্ন হয়েছে!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>সম্পূর্ণ অফার লিস্ট কপি করুন</span>
                  </>
                )}
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={handleShareToWhatsApp}
                  className="py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>WhatsApp গ্রুপে পাঠান</span>
                </button>

                <button
                  type="button"
                  onClick={handleShareToTelegram}
                  className="py-2.5 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                >
                  <Send className="w-4 h-4" />
                  <span>Telegram এ শেয়ার</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
