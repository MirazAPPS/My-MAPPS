import React, { useState } from 'react';
import { Search, X, Tag, ArrowRight, ArrowLeft } from 'lucide-react';
import { DriveOffer } from '../types';
import { OperatorLogo } from './OperatorLogos';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  offers: DriveOffer[];
  onSelectOffer: (offer: DriveOffer) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  offers,
  onSelectOffer,
}) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const results = offers.filter((o) => {
    const q = query.toLowerCase();
    return (
      o.operatorName.toLowerCase().includes(q) ||
      o.operator.toLowerCase().includes(q) ||
      `${o.minutes}`.includes(q) ||
      `${o.internetGB}`.includes(q) ||
      `${o.priceTK}`.includes(q) ||
      (o.division && o.division.toLowerCase().includes(q))
    );
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/65 backdrop-blur-xs flex items-start justify-center p-4 pt-12">
      <div className="bg-white rounded-3xl max-w-[420px] w-full overflow-hidden shadow-2xl border border-slate-100 animate-fadeIn">
        {/* Search Input Box with Back Button */}
        <div className="p-3.5 border-b border-slate-100 flex items-center gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 transition-colors shrink-0 cursor-pointer"
            title="পেছনে যান"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <Search className="w-4 h-4 text-indigo-600 shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="অফার, মিনিট, জিবি বা অপারেটর খুঁজুন..."
            className="w-full text-sm font-semibold text-slate-800 outline-none placeholder:text-slate-400"
          />
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 shrink-0 cursor-pointer"
            title="বন্ধ করুন"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="p-3 max-h-[60vh] overflow-y-auto space-y-2">
          {results.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-xs">
              কোনো অফার খুঁজে পাওয়া যায়নি
            </div>
          ) : (
            results.map((offer) => (
              <button
                key={offer.id}
                type="button"
                onClick={() => {
                  onSelectOffer(offer);
                  onClose();
                }}
                className="w-full p-3 rounded-2xl bg-slate-50 hover:bg-indigo-50/60 border border-slate-200/80 flex items-center justify-between text-left transition-all active:scale-98"
              >
                <div className="flex items-center gap-3">
                  <OperatorLogo operator={offer.operator} className="w-9 h-9" />
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">
                      {offer.operatorName} {offer.minutes}Min + {offer.internetGB}GB
                    </span>
                    <span className="text-[10px] text-slate-500">
                      {offer.validityDays} Days • Cashback ৳{offer.cashbackTK}
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  {offer.cashbackTK > 0 && (
                    <div className="text-[10px] font-bold text-slate-400 line-through">
                      ৳{offer.priceTK}
                    </div>
                  )}
                  <div className="text-sm font-black text-indigo-600">
                    ৳{offer.priceTK - offer.cashbackTK}
                  </div>
                </div>
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
