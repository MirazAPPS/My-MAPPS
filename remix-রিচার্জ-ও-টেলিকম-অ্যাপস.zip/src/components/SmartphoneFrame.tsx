import React from 'react';

interface SmartphoneFrameProps {
  children: React.ReactNode;
  isDarkMode?: boolean;
  appName?: string;
  isLoggedIn?: boolean;
  onToggleLoginView?: () => void;
  onOpenQrScanner?: () => void;
}

export const SmartphoneFrame: React.FC<SmartphoneFrameProps> = ({
  children,
  isDarkMode = false,
}) => {
  return (
    <div
      className={`w-full min-h-screen h-[100dvh] overflow-hidden ${
        isDarkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#f8fafc] text-slate-900'
      } md:flex md:items-center md:justify-center md:bg-slate-200/70 font-['Hind_Siliguri',sans-serif] selection:bg-blue-600 selection:text-white`}
    >
      {/* 
        Native Mobile & Android APK Viewport:
        - On mobile & Android APK / WebAPK: 100% full-width, full-height edge-to-edge (no frame, no bezel, no border)
        - On desktop: Centered realistic phone mock container
      */}
      <div
        className={`w-full h-full h-[100dvh] min-h-0 flex-1 ${
          isDarkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#f8fafc] text-slate-900'
        } relative flex flex-col overflow-hidden md:max-w-[430px] md:h-[92vh] md:max-h-[890px] md:rounded-[36px] md:shadow-2xl md:border-4 md:border-slate-800`}
      >
        {children}
      </div>
    </div>
  );
};
