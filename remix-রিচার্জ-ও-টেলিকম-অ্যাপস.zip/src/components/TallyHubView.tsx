import React, { useState, useMemo } from 'react';
import {
  Calendar,
  Tag,
  Receipt,
  Banknote,
  PlusCircle,
  Search,
  ChevronLeft,
  ChevronRight,
  CornerUpLeft,
  Share2,
  Store,
  User,
  List,
  Scale,
  MoreVertical,
  X,
  Check,
  Trash2,
  Edit2,
  Coins,
  ArrowLeft,
  Copy,
  Printer,
  CheckCircle2,
  Percent,
  Sparkles,
  MessageCircle,
  FileText,
  Layers,
  ArrowUpDown,
  Download,
  Loader2,
} from 'lucide-react';
import { CustomerAccount, ShopTransaction, UserProfile } from '../types';

export interface TallyHubViewProps {
  user?: UserProfile;
  shopTransactions: ShopTransaction[];
  customers?: CustomerAccount[];
  onOpenShopLedger?: () => void;
  onOpenCustomerLedger?: () => void;
  onAddTransaction?: (trx: ShopTransaction) => void;
  onUpdateTransaction?: (trx: ShopTransaction) => void;
  onDeleteTransaction?: (id: string) => void;
  onOpenProfileEdit?: () => void;
  onRefreshData?: () => void;
  onBack?: () => void;
}

// Convert English digits to Bengali digits
const toBengaliDigits = (num: number | string): string => {
  return String(num).replace(/\d/g, (d) => '০১২৩৪৫৬৭৮৯'[parseInt(d, 10)]);
};

// Convert Bengali digits to English string
const normalizeDigits = (val: unknown): string => {
  if (val == null) return '';
  const str = String(val).trim();
  const bn = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return str.replace(/[০-৯]/g, (d) => String(bn.indexOf(d)));
};

// Parse number safely from either Bengali or English input
const parseBengaliOrEnglishNumber = (val: unknown): number => {
  if (val == null || val === '') return 0;
  if (typeof val === 'number') return isNaN(val) ? 0 : val;
  const normalized = normalizeDigits(val);
  const match = normalized.match(/-?\d+(\.\d+)?/);
  return match ? parseFloat(match[0]) : 0;
};

// Format date as ১৬/৯/২০২৬
const formatBengaliDate = (dateStr: string): string => {
  if (!dateStr) return '';
  const normalized = normalizeDigits(dateStr);
  const parts = normalized.split(/[-/]/);
  if (parts.length === 3) {
    const d = parseInt(parts[0], 10);
    const m = parseInt(parts[1], 10);
    const y = parseInt(parts[2], 10);
    return `${toBengaliDigits(d)}/${toBengaliDigits(m)}/${toBengaliDigits(y)}`;
  }
  return toBengaliDigits(dateStr);
};

// Calculate Bengali day of week from date string
const getBengaliDayOfWeek = (dateStr: string, timestamp?: number): string => {
  const days = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];
  if (timestamp) {
    const dt = new Date(timestamp);
    if (!isNaN(dt.getTime())) return days[dt.getDay()];
  }
  if (dateStr) {
    const normalized = normalizeDigits(dateStr);
    const parts = normalized.split(/[-/]/);
    if (parts.length === 3) {
      const d = parseInt(parts[0], 10);
      const m = parseInt(parts[1], 10) - 1;
      const y = parseInt(parts[2], 10);
      const dt = new Date(y, m, d);
      if (!isNaN(dt.getTime())) return days[dt.getDay()];
    }
  }
  return 'বুধবার';
};

const getTodayDateFormatted = (): string => {
  const now = new Date();
  const day = now.getDate().toString();
  const month = (now.getMonth() + 1).toString();
  const year = now.getFullYear();
  return `${day}/${month}/${year}`;
};

export const TallyHubView: React.FC<TallyHubViewProps> = ({
  user,
  shopTransactions = [],
  customers = [],
  onOpenCustomerLedger,
  onAddTransaction,
  onUpdateTransaction,
  onDeleteTransaction,
  onOpenProfileEdit,
  onRefreshData,
  onBack,
}) => {
  // Category Filter: 'all' = সকল হিসাব, 'shop' = দোকান, 'personal' = ব্যক্তিগত
  const [activeCategory, setActiveCategory] = useState<'all' | 'shop' | 'personal'>('all');

  // Month navigation: 'all' = সকল মাসের মোট হিসাব, 'current' = চলতি মাস, or specific Month Year
  const [monthFilter, setMonthFilter] = useState<'all' | 'current'>('all');
  const [currentMonthIndex, setCurrentMonthIndex] = useState<number>(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState<number>(new Date().getFullYear());

  // Search state
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Three-dot menu state
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingTrx, setEditingTrx] = useState<ShopTransaction | null>(null);
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [shareSortOrder, setShareSortOrder] = useState<'asc' | 'desc'>('asc');
  const [shareActivePage, setShareActivePage] = useState<number | 'all'>(1);
  const [isDownloadingPdf, setIsDownloadingPdf] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [isCommissionModalOpen, setIsCommissionModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Modal Form State (দোকান ও ব্যক্তিগত হিসাব ইনপুট)
  const [formData, setFormData] = useState({
    itemName: '',
    quantity: '',
    category: 'দোকান' as 'দোকান' | 'ব্যক্তিগত',
    buyPrice: '',
    depositAmount: '',
    sellPrice: '',
    commissionTag: '',
    dueAmount: '',
    date: getTodayDateFormatted(),
    dayOfWeek: getBengaliDayOfWeek(getTodayDateFormatted()),
    note: '',
  });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Month labels in Bengali
  const bengaliMonths = [
    'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
    'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
  ];

  const currentMonthLabel = useMemo(() => {
    if (monthFilter === 'all') {
      return 'সকল মাসের মোট হিসাব';
    }
    return `${bengaliMonths[currentMonthIndex]} ${toBengaliDigits(currentYear)}`;
  }, [monthFilter, currentMonthIndex, currentYear]);

  const handlePrevMonth = () => {
    setMonthFilter('current');
    if (currentMonthIndex === 0) {
      setCurrentMonthIndex(11);
      setCurrentYear((y) => y - 1);
    } else {
      setCurrentMonthIndex((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    setMonthFilter('current');
    if (currentMonthIndex === 11) {
      setCurrentMonthIndex(0);
      setCurrentYear((y) => y + 1);
    } else {
      setCurrentMonthIndex((m) => m + 1);
    }
  };

  const handleResetCurrentMonth = () => {
    const now = new Date();
    setCurrentMonthIndex(now.getMonth());
    setCurrentYear(now.getFullYear());
    setMonthFilter('current');
  };

  // Filtered transactions with Bengali digit support
  const filteredTransactions = useMemo(() => {
    return shopTransactions.filter((trx) => {
      // Category filter
      if (activeCategory === 'shop' && trx.category !== 'দোকান') return false;
      if (activeCategory === 'personal' && trx.category !== 'ব্যক্তিগত') return false;

      // Month filter (handles both Bengali and English digits)
      if (monthFilter === 'current') {
        const norm = normalizeDigits(trx.date || '');
        const parts = norm.split(/[-/]/);
        if (parts.length === 3) {
          const m = parseInt(parts[1], 10) - 1;
          const y = parseInt(parts[2], 10);
          if (m !== currentMonthIndex || y !== currentYear) return false;
        }
      }

      // Search filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = (trx.itemName || '').toLowerCase().includes(q);
        const matchQty = (trx.quantity || '').toLowerCase().includes(q);
        const matchNote = (trx.note || '').toLowerCase().includes(q);
        const matchDate = (trx.date || '').toLowerCase().includes(q);
        const matchComm = (trx.commissionTag || '').toLowerCase().includes(q);
        const matchDay = (trx.dayOfWeek || '').toLowerCase().includes(q);
        if (!matchName && !matchQty && !matchNote && !matchDate && !matchComm && !matchDay) return false;
      }

      return true;
    });
  }, [shopTransactions, activeCategory, monthFilter, currentMonthIndex, currentYear, searchQuery]);

  // Calculations for Summary Cards (বাংলা ও ইংরেজি সংখ্যা সমর্থনসহ নিখুঁত যোগফল)
  const totalExpense = useMemo(() => {
    return filteredTransactions.reduce((acc, t) => acc + (parseBengaliOrEnglishNumber(t.buyPrice) || 0), 0);
  }, [filteredTransactions]);

  const totalDeposit = useMemo(() => {
    return filteredTransactions.reduce((acc, t) => acc + (parseBengaliOrEnglishNumber(t.depositAmount) || 0), 0);
  }, [filteredTransactions]);

  // মোট দোকান খরচ
  const totalShopExpense = useMemo(() => {
    return filteredTransactions.reduce((acc, t) => {
      if (t.category === 'ব্যক্তিগত') return acc;
      return acc + (parseBengaliOrEnglishNumber(t.buyPrice) || 0);
    }, 0);
  }, [filteredTransactions]);

  // মোট দোকান জমা
  const totalShopDeposit = useMemo(() => {
    return filteredTransactions.reduce((acc, t) => {
      if (t.category === 'ব্যক্তিগত') return acc;
      return acc + (parseBengaliOrEnglishNumber(t.depositAmount) || 0);
    }, 0);
  }, [filteredTransactions]);

  // মোট বিক্রি ও ব্যয় (দোকান পণ্যের বিক্রয় মূল্য + ব্যক্তিগত খরচ)
  const totalSell = useMemo(() => {
    return filteredTransactions.reduce((acc, t) => {
      const buy = parseBengaliOrEnglishNumber(t.buyPrice) || 0;
      const sell = parseBengaliOrEnglishNumber(t.sellPrice) || 0;
      if (t.category === 'ব্যক্তিগত') return acc + buy;
      return acc + (sell > 0 ? sell : buy);
    }, 0);
  }, [filteredTransactions]);

  // বাকি = মোট বাকি হিসাব (দোকানের কাস্টমার বাকি + ব্যক্তিগত বকেয়া)
  const totalDue = useMemo(() => {
    return filteredTransactions.reduce((acc, t) => {
      if (typeof t.dueAmount === 'number' && !isNaN(t.dueAmount)) {
        return acc + Math.max(0, t.dueAmount);
      }
      const buy = parseBengaliOrEnglishNumber(t.buyPrice) || 0;
      const sell = parseBengaliOrEnglishNumber(t.sellPrice) || 0;
      const target = t.category === 'ব্যক্তিগত' ? buy : (sell > 0 ? sell : buy);
      const dep = parseBengaliOrEnglishNumber(t.depositAmount) || 0;
      return acc + Math.max(0, target - dep);
    }, 0);
  }, [filteredTransactions]);

  // C (কমিশন / লাভ) হিসাব: বিক্রি − খরচ = লাভ / ক্যাশব্যাক (C)
  const { totalCommission, commissionTagsList, commissionDetails } = useMemo(() => {
    let total = 0;
    const tags: string[] = [];
    const details: { itemName: string; tag: string; amount: number; date: string }[] = [];

    filteredTransactions.forEach((t) => {
      if (t.category === 'ব্যক্তিগত') return;

      const s = parseBengaliOrEnglishNumber(t.sellPrice);
      const b = parseBengaliOrEnglishNumber(t.buyPrice);
      let commVal = 0;
      let tagStr = '';

      // বিক্রি ও খরচ থাকলে লাভ স্বয়ংক্রিয়ভাবে (বিক্রি − খরচ)
      if (s > 0 && b > 0 && s >= b) {
        commVal = s - b;
        tagStr = `C${commVal}`;
      } else if (t.commissionTag && t.commissionTag.trim()) {
        tagStr = t.commissionTag.trim();
        commVal = parseBengaliOrEnglishNumber(tagStr);
      } else if (t.note && /c\s*[-:]?\s*[\d০-৯]+/i.test(t.note)) {
        const match = t.note.match(/c\s*[-:]?\s*([\d০-৯]+)/i);
        if (match) {
          commVal = parseBengaliOrEnglishNumber(match[1]);
          tagStr = `C${commVal}`;
        }
      } else if (typeof t.profit === 'number' && t.profit > 0) {
        commVal = t.profit;
        tagStr = `C${commVal}`;
      }

      if (commVal > 0) {
        total += commVal;
        tags.push(tagStr || `C${commVal}`);
        details.push({
          itemName: t.itemName,
          tag: tagStr || `C${commVal}`,
          amount: commVal,
          date: t.date,
        });
      }
    });

    return { totalCommission: total, commissionTagsList: tags, commissionDetails: details };
  }, [filteredTransactions]);

  // =========================================================================
  // যোগ বিয়োগ ফলাফল স্বয়ংক্রিয় গাণিতিক সিস্টেম (Bidirectional Reactive Math Engine)
  // ১. লাভ = বিক্রি − খরচ (বিয়োগ)
  // ২. বিক্রি = খরচ + লাভ (যোগ)
  // ৩. বাকি = বিক্রি − জমা (বিয়োগ)
  // ৪. জমা = বিক্রি − বাকি (বিয়োগ)
  // =========================================================================

  // ১. খরচ (Buy Price) পরিবর্তন হলে
  const handleBuyPriceChange = (val: string) => {
    const buyNum = parseBengaliOrEnglishNumber(val);
    const isPersonal = formData.category === 'ব্যক্তিগত';

    if (isPersonal) {
      setFormData((prev) => {
        const depNum = parseBengaliOrEnglishNumber(prev.depositAmount);
        const due = Math.max(0, buyNum - depNum);
        return {
          ...prev,
          buyPrice: val,
          sellPrice: val,
          dueAmount: due > 0 ? String(due) : '0',
        };
      });
      return;
    }

    setFormData((prev) => {
      const sellNum = parseBengaliOrEnglishNumber(prev.sellPrice);
      const depNum = parseBengaliOrEnglishNumber(prev.depositAmount);
      const commMatch = prev.commissionTag.match(/[\d০-৯]+/);
      const commNum = commMatch ? parseBengaliOrEnglishNumber(commMatch[0]) : 0;

      // যদি বিক্রি আগে থেকেই দেওয়া থাকে: লাভ = বিক্রি − খরচ
      if (sellNum > 0 && buyNum > 0) {
        const profit = sellNum - buyNum;
        const due = Math.max(0, sellNum - depNum);
        return {
          ...prev,
          buyPrice: val,
          commissionTag: profit >= 0 ? `C${profit}` : '',
          dueAmount: String(due),
        };
      }

      // যদি লাভ/কমিশন আগে থেকে দেওয়া থাকে কিন্তু বিক্রি খালি: বিক্রি = খরচ + লাভ
      if (commNum > 0 && buyNum > 0 && !prev.sellPrice) {
        const autoSell = buyNum + commNum;
        const due = Math.max(0, autoSell - depNum);
        return {
          ...prev,
          buyPrice: val,
          sellPrice: String(autoSell),
          dueAmount: String(due),
        };
      }

      return {
        ...prev,
        buyPrice: val,
      };
    });
  };

  // ২. বিক্রি মূল্য (Sell Price) পরিবর্তন হলে:
  // লাভ = বিক্রি − খরচ এবং বাকি = বিক্রি − জমা
  const handleSellPriceChange = (val: string) => {
    const sellNum = parseBengaliOrEnglishNumber(val);
    const buyNum = parseBengaliOrEnglishNumber(formData.buyPrice);

    setFormData((prev) => {
      const depNum = parseBengaliOrEnglishNumber(prev.depositAmount);
      const profit = buyNum > 0 && sellNum >= buyNum ? sellNum - buyNum : 0;
      const commTag = profit > 0 ? `C${profit}` : (sellNum > 0 && buyNum > 0 && sellNum < buyNum ? '' : prev.commissionTag);
      const due = Math.max(0, sellNum - depNum);

      return {
        ...prev,
        sellPrice: val,
        commissionTag: commTag,
        dueAmount: String(due),
      };
    });
  };

  // ৩. লাভ / ক্যাশব্যাক (C) পরিবর্তন হলে:
  // বিক্রি = খরচ + লাভ এবং বাকি = বিক্রি − জমা
  const handleCommissionTagChange = (val: string) => {
    const commNum = parseBengaliOrEnglishNumber(val);
    const buyNum = parseBengaliOrEnglishNumber(formData.buyPrice);

    setFormData((prev) => {
      let updatedSell = prev.sellPrice;
      if (commNum > 0 && buyNum > 0) {
        updatedSell = String(buyNum + commNum);
      }
      const sellNum = parseBengaliOrEnglishNumber(updatedSell);
      const depNum = parseBengaliOrEnglishNumber(prev.depositAmount);
      const due = Math.max(0, sellNum - depNum);

      const formattedTag = val.toUpperCase().startsWith('C') ? val.toUpperCase() : (val ? `C${val}` : '');

      return {
        ...prev,
        commissionTag: formattedTag,
        sellPrice: updatedSell,
        dueAmount: String(due),
      };
    });
  };

  // ৪. জমা (Deposit Amount) পরিবর্তন হলে:
  // বাকি = বিক্রি − জমা
  const handleDepositAmountChange = (val: string) => {
    const depNum = parseBengaliOrEnglishNumber(val);
    const isPersonal = formData.category === 'ব্যক্তিগত';
    const buyNum = parseBengaliOrEnglishNumber(formData.buyPrice);
    const sellNum = parseBengaliOrEnglishNumber(formData.sellPrice);
    const totalTarget = isPersonal ? buyNum : (sellNum > 0 ? sellNum : buyNum);

    setFormData((prev) => {
      const due = Math.max(0, totalTarget - depNum);
      return {
        ...prev,
        depositAmount: val,
        dueAmount: String(due),
      };
    });
  };

  // ৫. বাকি (Due Amount) পরিবর্তন হলে:
  // জমা = বিক্রি − বাকি
  const handleDueAmountChange = (val: string) => {
    const dueNum = parseBengaliOrEnglishNumber(val);
    const isPersonal = formData.category === 'ব্যক্তিগত';
    const buyNum = parseBengaliOrEnglishNumber(formData.buyPrice);
    const sellNum = parseBengaliOrEnglishNumber(formData.sellPrice);
    const totalTarget = isPersonal ? buyNum : (sellNum > 0 ? sellNum : buyNum);

    setFormData((prev) => {
      const dep = Math.max(0, totalTarget - dueNum);
      return {
        ...prev,
        dueAmount: val,
        depositAmount: String(dep),
      };
    });
  };

  // কুইক ১-ক্লিক বাটন: সম্পূর্ণ নগদ আদায় (জমা = বিক্রি, বাকি = ০)
  const handleSetFullCashDeposit = () => {
    const isPersonal = formData.category === 'ব্যক্তিগত';
    const buyNum = parseBengaliOrEnglishNumber(formData.buyPrice);
    const sellNum = parseBengaliOrEnglishNumber(formData.sellPrice);
    const fullAmount = isPersonal ? buyNum : (sellNum > 0 ? sellNum : buyNum);
    setFormData((prev) => ({
      ...prev,
      depositAmount: fullAmount > 0 ? String(fullAmount) : '',
      dueAmount: '0',
    }));
  };

  // কুইক ১-ক্লিক বাটন: সম্পূর্ণ বাকি (জমা = ০, বাকি = বিক্রি)
  const handleSetFullDue = () => {
    const isPersonal = formData.category === 'ব্যক্তিগত';
    const buyNum = parseBengaliOrEnglishNumber(formData.buyPrice);
    const sellNum = parseBengaliOrEnglishNumber(formData.sellPrice);
    const fullAmount = isPersonal ? buyNum : (sellNum > 0 ? sellNum : buyNum);
    setFormData((prev) => ({
      ...prev,
      depositAmount: '0',
      dueAmount: fullAmount > 0 ? String(fullAmount) : '',
    }));
  };

  // বাকি ✓ টগল বাটন: বাকি থাকলে সম্পূর্ণ পরিশোধ করবে, আর পরিশোধ থাকলে বাকি রাখবে
  const handleToggleDueCheckbox = () => {
    const isPersonal = formData.category === 'ব্যক্তিগত';
    const buyNum = parseBengaliOrEnglishNumber(formData.buyPrice);
    const sellNum = parseBengaliOrEnglishNumber(formData.sellPrice);
    const target = isPersonal ? buyNum : (sellNum > 0 ? sellNum : buyNum);
    const currentlyDue = parseBengaliOrEnglishNumber(formData.dueAmount) > 0;

    if (currentlyDue) {
      // Switch to Paid
      setFormData((prev) => ({
        ...prev,
        depositAmount: target > 0 ? String(target) : '',
        dueAmount: '0',
      }));
    } else {
      // Switch to Due
      setFormData((prev) => ({
        ...prev,
        depositAmount: '0',
        dueAmount: target > 0 ? String(target) : '',
      }));
    }
  };

  // Handle Date input and auto-detect Bengali day
  const handleDateChangeForModal = (newDate: string) => {
    const detected = getBengaliDayOfWeek(newDate);
    setFormData((prev) => ({
      ...prev,
      date: newDate,
      dayOfWeek: detected,
    }));
  };

  // Open Add Modal with clean, fresh empty inputs
  const handleOpenAddModal = () => {
    const today = getTodayDateFormatted();
    const defaultCat = activeCategory === 'personal' ? 'ব্যক্তিগত' : 'দোকান';
    setFormData({
      itemName: '',
      quantity: '',
      category: defaultCat,
      buyPrice: '',
      depositAmount: '',
      sellPrice: '',
      commissionTag: '',
      dueAmount: '',
      date: today,
      dayOfWeek: getBengaliDayOfWeek(today),
      note: '',
    });
    setIsAddModalOpen(true);
  };

  // Open Edit Modal on row click
  const handleRowClick = (trx: ShopTransaction) => {
    setEditingTrx(trx);
    setFormData({
      itemName: trx.itemName || '',
      quantity: trx.quantity || '',
      category: trx.category === 'ব্যক্তিগত' ? 'ব্যক্তিগত' : 'দোকান',
      buyPrice: trx.buyPrice ? String(trx.buyPrice) : '',
      depositAmount: trx.depositAmount !== undefined && trx.depositAmount !== null ? String(trx.depositAmount) : '',
      sellPrice: trx.sellPrice ? String(trx.sellPrice) : '',
      commissionTag: trx.commissionTag || (trx.note && trx.note.startsWith('C') ? trx.note : ''),
      dueAmount: trx.dueAmount !== undefined && trx.dueAmount !== null ? String(trx.dueAmount) : '',
      date: trx.date || getTodayDateFormatted(),
      dayOfWeek: trx.dayOfWeek || getBengaliDayOfWeek(trx.date, trx.createdAtMs),
      note: trx.note || '',
    });
  };

  // Save new transaction from Modal
  const handleSaveNewTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.itemName.trim()) return;

    const buy = parseBengaliOrEnglishNumber(formData.buyPrice);
    const deposit = parseBengaliOrEnglishNumber(formData.depositAmount);
    const isPersonal = formData.category === 'ব্যক্তিগত';

    let commNumber = 0;
    let commTag = '';
    if (!isPersonal) {
      if (formData.commissionTag && formData.commissionTag.trim()) {
        const match = formData.commissionTag.match(/[\d০-৯]+/);
        if (match) {
          commNumber = parseBengaliOrEnglishNumber(match[0]);
          commTag = formData.commissionTag.toUpperCase().startsWith('C')
            ? formData.commissionTag.toUpperCase()
            : `C${commNumber}`;
        }
      }
    }

    let sell = isPersonal ? buy : (parseBengaliOrEnglishNumber(formData.sellPrice) || (commNumber > 0 ? buy + commNumber : buy));
    if (!isPersonal && commNumber === 0 && sell > buy) {
      commNumber = sell - buy;
      commTag = `C${commNumber}`;
    }

    const calculatedDue = formData.dueAmount !== ''
      ? parseBengaliOrEnglishNumber(formData.dueAmount)
      : Math.max(0, (isPersonal ? buy : sell) - deposit);
    const profit = isPersonal ? 0 : Math.max(0, sell - buy);

    const newTrx: ShopTransaction = {
      id: `SHOP-${Date.now()}`,
      itemName: formData.itemName.trim(),
      quantity: formData.quantity.trim() || undefined,
      category: formData.category,
      buyPrice: buy,
      depositAmount: deposit,
      sellPrice: sell,
      dueAmount: calculatedDue,
      profit: profit,
      date: formData.date.trim() || getTodayDateFormatted(),
      dayOfWeek: formData.dayOfWeek.trim() || getBengaliDayOfWeek(formData.date),
      commissionTag: commTag,
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      note: commTag || formData.note.trim(),
      createdAtMs: Date.now(),
    };

    if (onAddTransaction) {
      onAddTransaction(newTrx);
    }
    setIsAddModalOpen(false);
    showToast(`${formData.category === 'দোকান' ? 'দোকানের' : 'ব্যক্তিগত'} হিসাব সফলভাবে সংরক্ষণ করা হয়েছে`);
  };

  // Update existing transaction
  const handleUpdateTransactionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTrx) return;

    const buy = parseBengaliOrEnglishNumber(formData.buyPrice);
    const deposit = parseBengaliOrEnglishNumber(formData.depositAmount);
    const isPersonal = formData.category === 'ব্যক্তিগত';

    let commNumber = 0;
    let commTag = '';
    if (!isPersonal) {
      if (formData.commissionTag && formData.commissionTag.trim()) {
        const match = formData.commissionTag.match(/[\d০-৯]+/);
        if (match) {
          commNumber = parseBengaliOrEnglishNumber(match[0]);
          commTag = formData.commissionTag.toUpperCase().startsWith('C')
            ? formData.commissionTag.toUpperCase()
            : `C${commNumber}`;
        }
      }
    }

    let sell = isPersonal ? buy : (parseBengaliOrEnglishNumber(formData.sellPrice) || (commNumber > 0 ? buy + commNumber : buy));
    if (!isPersonal && commNumber === 0 && sell > buy) {
      commNumber = sell - buy;
      commTag = `C${commNumber}`;
    }

    const calculatedDue = formData.dueAmount !== ''
      ? parseBengaliOrEnglishNumber(formData.dueAmount)
      : Math.max(0, (isPersonal ? buy : sell) - deposit);
    const profit = isPersonal ? 0 : Math.max(0, sell - buy);

    const updatedTrx: ShopTransaction = {
      ...editingTrx,
      itemName: formData.itemName.trim(),
      quantity: formData.quantity.trim() || undefined,
      category: formData.category,
      buyPrice: buy,
      depositAmount: deposit,
      sellPrice: sell,
      dueAmount: calculatedDue,
      profit: profit,
      date: formData.date.trim() || editingTrx.date,
      dayOfWeek: formData.dayOfWeek.trim() || getBengaliDayOfWeek(formData.date),
      commissionTag: commTag,
      note: commTag || formData.note.trim(),
    };

    if (onUpdateTransaction) {
      onUpdateTransaction(updatedTrx);
    }
    setEditingTrx(null);
    showToast('হিসাব সফলভাবে আপডেট করা হয়েছে');
  };

  // Delete transaction
  const handleConfirmDelete = () => {
    if (!editingTrx) return;
    if (onDeleteTransaction) {
      onDeleteTransaction(editingTrx.id);
    }
    setIsDeleteConfirmOpen(false);
    setEditingTrx(null);
    showToast('হিসাব সফলভাবে মুছে ফেলা হয়েছে');
  };

  // Helper to parse date details for accurate 1st to 31st chronological sorting
  const parseTransactionDateDetails = (dateStr: string, createdAtMs?: number) => {
    if (createdAtMs && !isNaN(createdAtMs)) {
      const dt = new Date(createdAtMs);
      if (!isNaN(dt.getTime())) {
        return {
          day: dt.getDate(),
          month: dt.getMonth() + 1,
          year: dt.getFullYear(),
          timeMs: createdAtMs,
        };
      }
    }
    const normalized = normalizeDigits(dateStr || '');
    const parts = normalized.split(/[-/]/);
    if (parts.length === 3) {
      let d = parseInt(parts[0], 10);
      let m = parseInt(parts[1], 10);
      let y = parseInt(parts[2], 10);
      if (parts[0].length === 4) {
        y = parseInt(parts[0], 10);
        m = parseInt(parts[1], 10);
        d = parseInt(parts[2], 10);
      }
      const dt = new Date(y, m - 1, d);
      return {
        day: isNaN(d) ? 1 : d,
        month: isNaN(m) ? 1 : m,
        year: isNaN(y) ? new Date().getFullYear() : y,
        timeMs: !isNaN(dt.getTime()) ? dt.getTime() : 0,
      };
    }
    return { day: 1, month: 1, year: new Date().getFullYear(), timeMs: 0 };
  };

  // Transactions sorted by 1 to 31 (or 31 to 1) for the share view
  const shareTransactions = useMemo(() => {
    return [...filteredTransactions].sort((a, b) => {
      const pA = parseTransactionDateDetails(a.date, a.createdAtMs);
      const pB = parseTransactionDateDetails(b.date, b.createdAtMs);
      if (shareSortOrder === 'asc') {
        return pA.day !== pB.day ? pA.day - pB.day : pA.timeMs - pB.timeMs;
      } else {
        return pB.day !== pA.day ? pB.day - pA.day : pB.timeMs - pA.timeMs;
      }
    });
  }, [filteredTransactions, shareSortOrder]);

  // Multi-page distribution logic (Page 1 has summary cards + header so ~10 items; subsequent pages ~15 items)
  interface ReportPage {
    pageNumber: number;
    totalPages: number;
    items: ShopTransaction[];
    isFirstPage: boolean;
    isLastPage: boolean;
    startIndex: number;
  }

  const PAGE_1_LIMIT = 10;
  const SUBSEQUENT_PAGE_LIMIT = 15;

  const reportPages = useMemo((): ReportPage[] => {
    if (shareTransactions.length === 0) {
      return [
        {
          pageNumber: 1,
          totalPages: 1,
          items: [],
          isFirstPage: true,
          isLastPage: true,
          startIndex: 0,
        },
      ];
    }

    const pages: Omit<ReportPage, 'totalPages' | 'isLastPage'>[] = [];
    if (shareTransactions.length <= PAGE_1_LIMIT) {
      pages.push({
        pageNumber: 1,
        items: shareTransactions,
        isFirstPage: true,
        startIndex: 0,
      });
    } else {
      pages.push({
        pageNumber: 1,
        items: shareTransactions.slice(0, PAGE_1_LIMIT),
        isFirstPage: true,
        startIndex: 0,
      });
      let curIndex = PAGE_1_LIMIT;
      let pageNum = 2;
      while (curIndex < shareTransactions.length) {
        pages.push({
          pageNumber: pageNum,
          items: shareTransactions.slice(curIndex, curIndex + SUBSEQUENT_PAGE_LIMIT),
          isFirstPage: false,
          startIndex: curIndex,
        });
        curIndex += SUBSEQUENT_PAGE_LIMIT;
        pageNum++;
      }
    }

    const totalPages = pages.length;
    return pages.map((p, idx) => ({
      ...p,
      totalPages,
      isLastPage: idx === totalPages - 1,
    }));
  }, [shareTransactions]);

  // WhatsApp Share
  const handleWhatsAppShare = () => {
    const shopName = user?.shopName || 'মেসার্স রনি টেলিকম ও কনফেকশনারী';
    const ownerName = user?.name || 'মো: মিরাজ হোসেন';
    const phone = user?.phoneNumber || '';
    const dateRangeStr = monthFilter === 'all' ? 'সকল মাসের মোট হিসাব' : `১ তারিখ থেকে ৩১ তারিখ (${currentMonthLabel})`;
    const categoryStr = activeCategory === 'all' ? 'সব হিসাব' : activeCategory === 'shop' ? 'দোকান হিসাব' : 'ব্যক্তিগত হিসাব';

    const lines = [
      `📊 *টালি খাতা ডিজিটাল হিসাব রিপোর্ট*`,
      `🏪 *দোকান:* ${shopName}`,
      `👤 *স্বত্বাধিকারী:* ${ownerName} ${phone ? `(${toBengaliDigits(phone)})` : ''}`,
      `📅 *সময়কাল:* ${dateRangeStr}`,
      `🏷️ *হিসাব ধরণ:* ${categoryStr}`,
      `-----------------------------------------`,
      `🔴 *মোট খরচ:* ${toBengaliDigits(totalExpense)} ৳`,
      `🟢 *মোট জমা:* ${toBengaliDigits(totalDeposit)} ৳`,
      `🟠 *মোট বাকি:* ${toBengaliDigits(totalDue)} ৳`,
      `🟡 *মোট লাভ/কমিশন (C):* ${toBengaliDigits(totalCommission)} ৳`,
      `📝 *মোট লেনদেন:* ${toBengaliDigits(shareTransactions.length)} টি`,
      `📑 *মোট পৃষ্ঠা:* ${toBengaliDigits(reportPages.length)} টি`,
      `-----------------------------------------`,
      `📋 *১ তারিখ থেকে ৩১ তারিখের বিস্তারিত হিসাব:*`,
      ...shareTransactions.map((t, idx) => {
        const dayName = t.dayOfWeek || getBengaliDayOfWeek(t.date, t.createdAtMs);
        const buyNum = parseBengaliOrEnglishNumber(t.buyPrice);
        const depNum = parseBengaliOrEnglishNumber(t.depositAmount);
        const sellNum = parseBengaliOrEnglishNumber(t.sellPrice);
        const sellTotal = t.category === 'ব্যক্তিগত' ? buyNum : (sellNum > 0 ? sellNum : buyNum);
        const due = typeof t.dueAmount === 'number' && !isNaN(t.dueAmount)
          ? Math.max(0, t.dueAmount)
          : Math.max(0, (t.category === 'ব্যক্তিগত' ? buyNum : sellTotal) - depNum);
        const comm = t.commissionTag || (sellNum > buyNum ? `C${sellNum - buyNum}` : '-');

        return `${toBengaliDigits(idx + 1)}. [${formatBengaliDate(t.date)} ${dayName}] ${t.itemName}${t.quantity ? ` (${toBengaliDigits(t.quantity)})` : ''} | খরচ: ${toBengaliDigits(buyNum)}৳ | জমা: ${depNum > 0 ? toBengaliDigits(depNum) : '০'}৳ | বাকি: ${due > 0 ? toBengaliDigits(due) : '০'}৳ | ক্যাশ: ${comm}`;
      }),
      `-----------------------------------------`,
      `✅ ডিজিটাল টালি খাতা দ্বারা প্রস্তুতকৃত`,
    ];

    const fullMsg = lines.join('\n');
    const encoded = encodeURIComponent(fullMsg);
    window.open(`https://wa.me/?text=${encoded}`, '_blank');
  };

  // Copy share report
  const handleCopyReport = () => {
    const shopName = user?.shopName || 'মেসার্স রনি টেলিকম ও কনফেকশনারী';
    const ownerName = user?.name || 'মো: মিরাজ হোসেন';
    const dateRangeStr = monthFilter === 'all' ? 'সকল মাসের মোট হিসাব' : `১ তারিখ থেকে ৩১ তারিখ (${currentMonthLabel})`;
    const categoryStr = activeCategory === 'all' ? 'সব হিসাব' : activeCategory === 'shop' ? 'দোকান হিসাব' : 'ব্যক্তিগত হিসাব';

    const lines = [
      `📊 টালি খাতা হিসাব রিপোর্ট (${dateRangeStr})`,
      `দোকান: ${shopName}`,
      `স্বত্বাধিকারী: ${ownerName}`,
      `হিসাব ধরণ: ${categoryStr}`,
      `তারিখ: ${getTodayDateFormatted()}`,
      `-----------------------------------------`,
      `মোট খরচ: ${toBengaliDigits(totalExpense)} ৳`,
      `মোট জমা: ${toBengaliDigits(totalDeposit)} ৳`,
      `মোট বাকি: ${toBengaliDigits(totalDue)} ৳`,
      `মোট কমিশন (C লাভ): ${toBengaliDigits(totalCommission)} ৳`,
      `মোট এন্ট্রি: ${toBengaliDigits(shareTransactions.length)}টি (${toBengaliDigits(reportPages.length)} পৃষ্ঠার হিসাব)`,
      `-----------------------------------------`,
      `১ তারিখ থেকে ৩১ তারিখের বিস্তারিত হিসাব তালিকা:`,
      ...shareTransactions.map((t, idx) => {
        const dayName = t.dayOfWeek || getBengaliDayOfWeek(t.date, t.createdAtMs);
        const buyNum = parseBengaliOrEnglishNumber(t.buyPrice);
        const depNum = parseBengaliOrEnglishNumber(t.depositAmount);
        const sellNum = parseBengaliOrEnglishNumber(t.sellPrice);
        const sellTotal = t.category === 'ব্যক্তিগত' ? buyNum : (sellNum > 0 ? sellNum : buyNum);
        const due = typeof t.dueAmount === 'number' && !isNaN(t.dueAmount)
          ? Math.max(0, t.dueAmount)
          : Math.max(0, (t.category === 'ব্যক্তিগত' ? buyNum : sellTotal) - depNum);
        const comm = t.commissionTag || (sellNum > buyNum ? `C${sellNum - buyNum}` : '-');

        return `${toBengaliDigits(idx + 1)}. [${formatBengaliDate(t.date)} ${dayName}] ${t.itemName}${t.quantity ? ` (${toBengaliDigits(t.quantity)})` : ''} | খরচ: ${toBengaliDigits(buyNum)}৳ | জমা: ${toBengaliDigits(depNum)}৳ | বাকি: ${toBengaliDigits(due)}৳ | ক্যাশ: ${comm}`;
      }),
      `-----------------------------------------`,
      `স্মার্ট টালি খাতা • সুরক্ষিত ডিজিটাল হিসাব`,
    ];
    navigator.clipboard.writeText(lines.join('\n'));
    showToast('১-৩১ তারিখের সম্পূর্ণ রিপোর্ট ক্লিপবোর্ডে কপি করা হয়েছে');
  };

  // Native share dialog
  const handleNativeShare = async () => {
    const shopName = user?.shopName || 'মেসার্স রনি টেলিকম ও কনফেকশনারী';
    const dateRangeStr = monthFilter === 'all' ? 'সকল মাসের মোট হিসাব' : `১ তারিখ থেকে ৩১ তারিখ (${currentMonthLabel})`;
    const title = `টালি খাতা হিসাব রিপোর্ট (${dateRangeStr})`;
    const text = `📊 টালি খাতা হিসাব রিপোর্ট - ${shopName}\n📅 ${dateRangeStr}\nখরচ: ${toBengaliDigits(totalExpense)}৳ | জমা: ${toBengaliDigits(totalDeposit)}৳ | বাকি: ${toBengaliDigits(totalDue)}৳ | লাভ: ${toBengaliDigits(totalCommission)}৳\nমোট এন্ট্রি: ${toBengaliDigits(shareTransactions.length)}টি (${toBengaliDigits(reportPages.length)} পৃষ্ঠার রিপোর্ট)`;

    if (navigator.share) {
      try {
        await navigator.share({ title, text });
        showToast('রিপোর্ট শেয়ার করা হয়েছে');
      } catch {
        // user dismissed
      }
    } else {
      handleCopyReport();
    }
  };

  // Print dialog
  const handlePrintPdf = () => {
    // If inside an iframe, window.print() might be blocked or print the whole outer frame
    try {
      window.print();
    } catch {
      showToast('প্রিন্ট অপশন খোলা যায়নি, PDF ডাউনলোড বাটনটি ব্যবহার করুন');
    }
  };

  // Direct PDF Download (.pdf file generated and downloaded to device)
  const handleDownloadPdf = async () => {
    if (isDownloadingPdf) return;
    setIsDownloadingPdf(true);
    showToast('PDF ফাইল প্রস্তুত করা হচ্ছে, অনুগ্রহ করে অপেক্ষা করুন...');

    try {
      // Lazy load html2pdf.js dynamically
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const html2pdfModule: any = await import('html2pdf.js');
      const html2pdf = html2pdfModule.default || html2pdfModule;

      // Find the print container
      const printRoot = document.getElementById('tally-print-root');
      if (!printRoot) {
        throw new Error('Print container not found');
      }

      // Clone element to render off-screen with visible styles
      const clone = printRoot.cloneNode(true) as HTMLElement;
      clone.classList.remove('hidden');
      clone.classList.add('block');
      clone.style.position = 'fixed';
      clone.style.left = '-9999px';
      clone.style.top = '0';
      clone.style.width = '794px'; // Standard A4 pixel width at 96 DPI
      clone.style.background = '#ffffff';
      clone.style.zIndex = '-9999';
      document.body.appendChild(clone);

      // Sanitize any oklch/lab colors which html2canvas 1.4 cannot parse
      const sanitizeOklchInSubtree = (rootEl: HTMLElement) => {
        const all = [rootEl, ...Array.from(rootEl.querySelectorAll('*'))] as HTMLElement[];
        const colorProps = ['color', 'backgroundColor', 'borderColor', 'outlineColor', 'fill', 'stroke'] as const;
        all.forEach((el) => {
          try {
            const computed = window.getComputedStyle(el);
            colorProps.forEach((prop) => {
              const val = computed[prop];
              if (val && typeof val === 'string' && (val.includes('oklch') || val.includes('lab'))) {
                // Force a safe standard hex/rgb fallback
                if (prop === 'backgroundColor') el.style.backgroundColor = '#ffffff';
                else if (prop === 'color') el.style.color = '#0f172a';
                else if (prop === 'borderColor') el.style.borderColor = '#cbd5e1';
              }
            });
          } catch {
            // Ignore detached or cross-origin styles
          }
        });
      };
      sanitizeOklchInSubtree(clone);

      const shopName = (user?.shopName || 'টালি_খাতা_হিসাব').replace(/\s+/g, '_');
      const monthStr = monthFilter === 'all' ? 'সকল_মাস' : currentMonthLabel.replace(/\s+/g, '_');
      const fileName = `${shopName}_হিসাব_${monthStr}.pdf`;

      const opt = {
        margin: [10, 10, 10, 10] as [number, number, number, number],
        filename: fileName,
        image: { type: 'jpeg' as const, quality: 0.98 },
        html2canvas: {
          scale: 2,
          useCORS: true,
          logging: false,
          letterRendering: true,
          backgroundColor: '#ffffff',
          onclone: (clonedDoc: Document) => {
            const clonedEl = clonedDoc.getElementById('tally-print-root');
            if (clonedEl) {
              sanitizeOklchInSubtree(clonedEl as HTMLElement);
            }
          },
        },
        jsPDF: { unit: 'mm' as const, format: 'a4' as const, orientation: 'portrait' as const },
        pagebreak: { mode: ['css', 'legacy'] },
      };

      await html2pdf().set(opt).from(clone).save();

      // Clean up clone
      document.body.removeChild(clone);

      showToast('✅ PDF ফাইল সফলভাবে আপনার ডিভাইসে ডাউনলোড হয়েছে!');
    } catch (err) {
      console.error('PDF Generation failed:', err);
      // Fallback: trigger print dialog where user can choose "Save as PDF"
      showToast('সরাসরি PDF ডাউনলোডে সমস্যা হয়েছে, প্রিন্ট অপশন চালু করা হচ্ছে...');
      setTimeout(() => {
        window.print();
      }, 500);
    } finally {
      setIsDownloadingPdf(false);
    }
  };

  // Renders a single mobile page card (used in both interactive modal preview and hidden print root)
  const renderReportPageCard = (page: ReportPage, isPrintMode = false) => {
    const isFirst = page.isFirstPage;
    const isLast = page.isLastPage;
    const dateRangeDisplay = monthFilter === 'all'
      ? 'সকল মাসের মোট হিসাব'
      : `১ তারিখ থেকে ৩১ তারিখ (${currentMonthLabel})`;

    return (
      <div
        key={`page-${page.pageNumber}`}
        className={`bg-white rounded-2xl sm:rounded-3xl border border-slate-300 shadow-md overflow-hidden text-slate-900 ${
          isPrintMode ? 'tally-print-page border-0 shadow-none rounded-none' : ''
        }`}
      >
        {/* SHOP HEADER (Mobile screen design) */}
        <div className="bg-gradient-to-r from-[#091e36] via-[#0d2847] to-[#133863] text-white p-3 sm:p-4 border-b border-blue-900">
          <div className="flex items-center justify-between gap-2">
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <Store className="w-4 h-4 text-emerald-400 shrink-0" />
                <h3 className="font-black text-sm sm:text-base tracking-tight truncate text-white">
                  {user?.shopName || 'মেসার্স রনি টেলিকম ও কনফেকশনারী'}
                </h3>
                <span className="bg-emerald-500/30 text-emerald-300 text-[10px] font-black px-1.5 py-0.5 rounded-full border border-emerald-400/40">
                  ডিজিটাল টালি খাতা
                </span>
              </div>
              <p className="text-[11px] text-blue-200 mt-0.5 flex items-center gap-2">
                <span>স্বত্বাধিকারী: {user?.name || 'মো: মিরাজ হোসেন'}</span>
                {user?.phoneNumber && <span>• {toBengaliDigits(user.phoneNumber)}</span>}
              </p>
            </div>
            {/* Page number badge */}
            <div className="shrink-0 text-right">
              <span className="inline-block bg-white/20 text-white text-[11px] font-black px-2.5 py-1 rounded-full border border-white/30 backdrop-blur-xs">
                পৃষ্ঠা {toBengaliDigits(page.pageNumber)} / {toBengaliDigits(page.totalPages)}
              </span>
            </div>
          </div>

          {/* Date Range & Category Banner */}
          <div className="mt-2.5 pt-2 border-t border-blue-800/80 flex items-center justify-between text-[11px] text-blue-100 flex-wrap gap-1 font-bold">
            <div className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-blue-300 shrink-0" />
              <span>{dateRangeDisplay}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="bg-blue-950/60 px-2 py-0.5 rounded-md border border-blue-800 text-[10px] text-blue-200">
                {activeCategory === 'all' ? 'সব হিসাব' : activeCategory === 'shop' ? 'দোকান হিসাব' : 'ব্যক্তিগত হিসাব'}
              </span>
              <span className="bg-blue-950/60 px-2 py-0.5 rounded-md border border-blue-800 text-[10px] text-amber-300 font-black">
                {shareSortOrder === 'asc' ? '১ থেকে ৩১ তারিখ ক্রম' : '৩১ থেকে ১ তারিখ ক্রম'}
              </span>
            </div>
          </div>
        </div>

        {/* SUMMARY CARDS (Displayed on Page 1 or if single page) */}
        {isFirst ? (
          <div className="p-3 sm:p-4 bg-slate-50/90 border-b border-slate-200 space-y-2.5">
            {/* 3 Main Stat Cards */}
            <div className="grid grid-cols-3 gap-2 text-white font-bold">
              {/* খরচ */}
              <div className="bg-[#dc2626] rounded-xl p-2 sm:p-3 text-center shadow-xs flex flex-col items-center justify-center">
                <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center mb-1">
                  <Receipt className="w-3.5 h-3.5 text-white" />
                </div>
                <span className="text-[11px] sm:text-xs font-black opacity-95">খরচ</span>
                <span className="text-xs sm:text-base font-black tracking-tight mt-0.5">
                  {toBengaliDigits(totalExpense)} ৳
                </span>
              </div>

              {/* জমা */}
              <div className="bg-[#16a34a] rounded-xl p-2 sm:p-3 text-center shadow-xs flex flex-col items-center justify-center">
                <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center mb-1">
                  <Banknote className="w-3.5 h-3.5 text-white" />
                </div>
                <span className="text-[11px] sm:text-xs font-black opacity-95">জমা</span>
                <span className="text-xs sm:text-base font-black tracking-tight mt-0.5">
                  {toBengaliDigits(totalDeposit)} ৳
                </span>
              </div>

              {/* বাকি */}
              <div className="bg-[#ea580c] rounded-xl p-2 sm:p-3 text-center shadow-xs flex flex-col items-center justify-center">
                <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center mb-1">
                  <Scale className="w-3.5 h-3.5 text-white" />
                </div>
                <span className="text-[11px] sm:text-xs font-black opacity-95">বাকি</span>
                <span className="text-xs sm:text-base font-black tracking-tight mt-0.5">
                  {toBengaliDigits(totalDue)} ৳
                </span>
              </div>
            </div>

            {/* Commission / Profit Banner */}
            <div className="p-2 sm:p-2.5 rounded-xl bg-amber-500 text-slate-950 font-black flex items-center justify-between text-xs sm:text-sm shadow-xs border border-amber-600">
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-slate-950 shrink-0" />
                <span>সর্বমোট লাভ ও কমিশন (C)</span>
              </div>
              <span className="text-sm sm:text-base bg-white/90 px-2.5 py-0.5 rounded-lg border border-amber-600 shadow-2xs font-black">
                {toBengaliDigits(totalCommission)} ৳
              </span>
            </div>
          </div>
        ) : (
          /* Compact continuation banner for Page 2, 3... */
          <div className="bg-blue-50/80 px-3 py-2 border-b border-blue-200 flex items-center justify-between text-xs font-bold text-blue-950">
            <span className="flex items-center gap-1 font-black">
              <Layers className="w-3.5 h-3.5 text-blue-700" />
              চলমান হিসাব • পৃষ্ঠা {toBengaliDigits(page.pageNumber)} এর {toBengaliDigits(page.totalPages)}
            </span>
            <span className="text-[11px] text-blue-800">
              (হিসাব {toBengaliDigits(page.startIndex + 1)} থেকে {toBengaliDigits(page.startIndex + page.items.length)})
            </span>
          </div>
        )}

        {/* 6-COLUMN COLORED TABLE HEADER (Matching mobile screen) */}
        <div className="bg-slate-900 border-y border-slate-700 grid grid-cols-[19%_25%_15%_14%_14%_13%] text-center text-white font-black text-[11px] sm:text-xs tracking-tight shadow-xs">
          <div className="py-2 px-0.5 bg-[#1e40af] flex items-center justify-center gap-0.5 border-r border-blue-400/30">
            <Calendar className="w-3 h-3 text-blue-200 shrink-0 hidden sm:inline" />
            <span>তারিখ</span>
          </div>
          <div className="py-2 px-0.5 bg-[#6b21a8] flex items-center justify-center gap-0.5 border-r border-purple-400/30">
            <Tag className="w-3 h-3 text-purple-200 shrink-0 hidden sm:inline" />
            <span>বিবরণ</span>
          </div>
          <div className="py-2 px-0.5 bg-[#dc2626] flex items-center justify-center gap-0.5 border-r border-red-400/30">
            <Receipt className="w-3 h-3 text-red-200 shrink-0 hidden sm:inline" />
            <span>খরচ</span>
          </div>
          <div className="py-2 px-0.5 bg-[#16a34a] flex items-center justify-center gap-0.5 border-r border-green-400/30">
            <Banknote className="w-3 h-3 text-green-200 shrink-0 hidden sm:inline" />
            <span>জমা</span>
          </div>
          <div className="py-2 px-0.5 bg-[#ea580c] flex items-center justify-center gap-0.5 border-r border-orange-400/30">
            <Scale className="w-3 h-3 text-orange-200 shrink-0 hidden sm:inline" />
            <span>বাকি</span>
          </div>
          <div className="py-2 px-0.5 bg-[#0284c7] flex items-center justify-center gap-0.5">
            <Coins className="w-3 h-3 text-cyan-200 shrink-0 hidden sm:inline" />
            <span>ক্যাশ</span>
          </div>
        </div>

        {/* TABLE ROWS */}
        {page.items.length === 0 ? (
          <div className="py-10 text-center text-slate-400 text-xs font-bold">
            কোনো হিসাব এন্ট্রি পাওয়া যায়নি
          </div>
        ) : (
          <div className="divide-y divide-slate-200">
            {page.items.map((trx, index) => {
              const dayName = trx.dayOfWeek || getBengaliDayOfWeek(trx.date, trx.createdAtMs);
              const displayDateBengali = formatBengaliDate(trx.date || getTodayDateFormatted());
              const buyNum = parseBengaliOrEnglishNumber(trx.buyPrice);
              const depNum = parseBengaliOrEnglishNumber(trx.depositAmount);
              const isDepositEmpty = depNum === 0 && !trx.depositAmount;

              const isPersonal = trx.category === 'ব্যক্তিগত';
              const sellNum = parseBengaliOrEnglishNumber(trx.sellPrice);
              const sellTotal = isPersonal ? buyNum : (sellNum > 0 ? sellNum : buyNum);

              const calculatedDue = typeof trx.dueAmount === 'number' && !isNaN(trx.dueAmount)
                ? trx.dueAmount
                : Math.max(0, sellTotal - depNum);

              let commissionLabel = '-';
              if (trx.commissionTag) {
                commissionLabel = trx.commissionTag;
              } else if (sellNum > buyNum) {
                commissionLabel = `C${toBengaliDigits(sellNum - buyNum)}`;
              }

              return (
                <div
                  key={trx.id || `row-${index}`}
                  className={`grid grid-cols-[19%_25%_15%_14%_14%_13%] items-center divide-x divide-slate-200 py-2 sm:py-2.5 px-0 text-slate-800 text-center text-xs sm:text-sm font-black transition-colors ${
                    index % 2 === 0 ? 'bg-white' : 'bg-slate-50/70'
                  }`}
                >
                  {/* Col 1: তারিখ ও বার */}
                  <div className="px-0.5 text-center flex flex-col items-center justify-center leading-tight">
                    <span className="text-[11px] sm:text-xs font-black text-slate-900">
                      {displayDateBengali}
                    </span>
                    <span className="text-[9px] sm:text-[10px] font-bold text-blue-700 bg-blue-50 px-1 py-0.2 rounded-sm mt-0.5">
                      {dayName}
                    </span>
                  </div>

                  {/* Col 2: পণ্যের বিবরণ */}
                  <div className="px-1 text-center sm:text-left sm:px-2 flex flex-col justify-center leading-tight overflow-hidden">
                    <span className="text-[11px] sm:text-xs font-black text-slate-900 truncate">
                      {trx.itemName}
                    </span>
                    {trx.quantity && (
                      <span className="text-[9px] sm:text-[10px] font-bold text-purple-700 bg-purple-50 px-1 py-0.2 rounded-sm mt-0.5 self-center sm:self-start truncate max-w-full">
                        {toBengaliDigits(trx.quantity)}
                      </span>
                    )}
                  </div>

                  {/* Col 3: খরচ ও বিক্রি */}
                  <div className="px-0.5 text-center flex flex-col items-center justify-center leading-tight">
                    <span className="text-[11px] sm:text-xs font-black text-red-600">
                      {toBengaliDigits(buyNum)}৳
                    </span>
                    {sellNum > 0 && sellNum !== buyNum && (
                      <span className="text-[9px] sm:text-[10px] font-bold text-slate-500">
                        বি {toBengaliDigits(sellNum)}
                      </span>
                    )}
                  </div>

                  {/* Col 4: জমা */}
                  <div className="px-0.5 text-center flex items-center justify-center">
                    {isDepositEmpty ? (
                      <span className="text-slate-300 font-bold">-</span>
                    ) : (
                      <span className="text-[11px] sm:text-xs font-black text-emerald-600">
                        {toBengaliDigits(depNum)}৳
                      </span>
                    )}
                  </div>

                  {/* Col 5: বাকি */}
                  <div className="px-0.5 text-center flex items-center justify-center">
                    {calculatedDue <= 0 ? (
                      <span className="inline-flex items-center gap-0.5 px-1 py-0.2 rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-bold">
                        <Check className="w-2.5 h-2.5" />
                        <span>পরিশোধ</span>
                      </span>
                    ) : (
                      <span className="text-[11px] sm:text-xs font-black text-rose-600">
                        {toBengaliDigits(calculatedDue)}৳
                      </span>
                    )}
                  </div>

                  {/* Col 6: ক্যাশ / কমিশন */}
                  <div className="px-0.5 text-center flex items-center justify-center">
                    {commissionLabel !== '-' ? (
                      <span className="text-[10px] sm:text-xs font-black text-blue-700 bg-blue-50 px-1 py-0.5 rounded-md border border-blue-200">
                        {commissionLabel}
                      </span>
                    ) : (
                      <span className="text-slate-300 font-bold">-</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* PAGE FOOTER / GRAND TOTAL */}
        {!isLast ? (
          <div className="bg-slate-100 px-3 py-2 border-t border-slate-200 text-center text-xs font-bold text-slate-600 flex items-center justify-between">
            <span>পৃষ্ঠা {toBengaliDigits(page.pageNumber)} সমাপ্ত</span>
            <span className="text-blue-700 font-black">
              পরবর্তী হিসাব দেখতে পৃষ্ঠা {toBengaliDigits(page.pageNumber + 1)}-এ যান →
            </span>
          </div>
        ) : (
          <div>
            {/* Grand Total Row */}
            <div className="bg-slate-100/95 border-t-2 border-slate-300 grid grid-cols-[19%_25%_15%_14%_14%_13%] items-center divide-x divide-slate-300 py-2.5 px-0 text-slate-900 font-black text-center">
              <div className="col-span-2 px-1 text-center sm:text-left sm:px-2 flex flex-col justify-center">
                <span className="text-[11px] sm:text-xs font-black text-slate-900">
                  সর্বমোট ({toBengaliDigits(shareTransactions.length)}টি)
                </span>
              </div>
              <div className="px-0.5 text-center">
                <span className="text-xs sm:text-sm font-black text-red-600">
                  {toBengaliDigits(totalExpense)}৳
                </span>
              </div>
              <div className="px-0.5 text-center">
                <span className="text-xs sm:text-sm font-black text-emerald-600">
                  {toBengaliDigits(totalDeposit)}৳
                </span>
              </div>
              <div className="px-0.5 text-center">
                <span className="text-xs sm:text-sm font-black text-rose-600">
                  {toBengaliDigits(totalDue)}৳
                </span>
              </div>
              <div className="px-0.5 text-center">
                <span className="text-[10px] sm:text-xs font-black text-blue-700">
                  C{toBengaliDigits(totalCommission)}
                </span>
              </div>
            </div>

            {/* Signature and Verification */}
            <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-600 flex-wrap gap-2">
              <div>
                <span className="font-bold">স্বত্বাধিকারী স্বাক্ষর:</span> ___________________
              </div>
              <div className="text-[10px] text-slate-500">
                প্রস্তুতের তারিখ: {toBengaliDigits(new Date().toLocaleDateString('bn-BD'))}
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  const daysList = ['মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার', 'রবিবার', 'সোমবার'];

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 pb-20 select-none">
      {/* ========================================================================= */}
      {/* Toast Notification                                                        */}
      {/* ========================================================================= */}
      {toastMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white px-4 py-2 rounded-xl text-xs font-black shadow-lg flex items-center gap-2 border border-slate-700 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. TOP HEADER & PROFILE (Navy Blue #0d2847)                                */}
      {/* ========================================================================= */}
      <header
        className="bg-[#0d2847] text-white px-3 pb-3 shadow-md sticky top-0 z-30"
        style={{
          paddingTop: 'max(12px, calc(env(safe-area-inset-top, 0px) + 8px))',
        }}
      >
        {/* Top Bar: Centered Profile Avatar + Name + Back Button on Left + Menu on Right */}
        <div className="relative flex items-center justify-between min-h-[44px]">
          {/* Left: Back Button (if provided) or spacer */}
          <div className="flex items-center w-9 justify-start">
            {onBack ? (
              <button
                type="button"
                onClick={onBack}
                className="w-8 h-8 rounded-full bg-[#133863] hover:bg-[#1a4a82] flex items-center justify-center text-slate-200 transition-colors cursor-pointer"
                title="পেছনে যান"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            ) : null}
          </div>

          {/* Middle: Profile Avatar + Name (Centered) */}
          <div
            onClick={onOpenProfileEdit}
            title="প্রোফাইল দেখুন বা সম্পাদনা করুন"
            className="flex items-center gap-2.5 cursor-pointer hover:opacity-90 transition-opacity mx-auto"
          >
            {/* Circular Profile Avatar with Green Ring & Active Online Dot */}
            <div className="relative shrink-0">
              <div className="w-10 h-10 rounded-full border-2 border-emerald-500 bg-[#163a66] flex items-center justify-center text-white font-black text-sm shadow-inner overflow-hidden">
                {user?.profileImage ? (
                  <img
                    src={user.profileImage}
                    alt={user.name || 'User'}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <span className="tracking-tighter">টালি</span>
                )}
              </div>
              <span
                className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-[#0d2847]"
                title="সক্রিয়"
              />
            </div>

            {/* User Name Only (No 'প্রোফাইল' text) */}
            <div className="flex flex-col text-left">
              <h1 className="text-sm sm:text-base font-black text-white tracking-tight leading-tight">
                {user?.name || 'মো: মিরাজ হোসেন'}
              </h1>
            </div>
          </div>

          {/* Right: Three-Dot Menu Button (Coin badge removed) */}
          <div className="flex items-center justify-end w-9">
            <div className="relative">
              <button
                type="button"
                id="tally-three-dot-menu"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="w-8 h-8 rounded-full bg-[#133863] hover:bg-[#1a4a82] text-slate-200 flex items-center justify-center transition-colors cursor-pointer"
              >
                <MoreVertical className="w-4 h-4" />
              </button>

              {/* Dropdown Menu */}
              {isMenuOpen && (
                <div className="absolute right-0 mt-1.5 w-48 bg-white rounded-xl shadow-xl border border-slate-200 py-1 z-40 text-slate-800 text-xs font-bold animate-fadeIn">
                  <button
                    type="button"
                    onClick={() => {
                      setIsMenuOpen(false);
                      setIsShareModalOpen(true);
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-slate-100 flex items-center gap-2 text-slate-700 cursor-pointer"
                  >
                    <Share2 className="w-4 h-4" />
                    <span>রিপোর্ট শেয়ার ও প্রিন্ট</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsMenuOpen(false);
                      if (onRefreshData) onRefreshData();
                      showToast('ডাটা সফলভাবে রিফ্রেশ হয়েছে');
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-slate-100 flex items-center gap-2 text-slate-700 cursor-pointer"
                  >
                    <CornerUpLeft className="w-4 h-4" />
                    <span>ডাটা রিফ্রেশ করুন</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Second Row: Segmented Tabs (সব হিসাব | দোকান | ব্যক্তিগত) + Right Actions */}
        <div className="mt-3 flex items-center justify-between gap-2">
          {/* Segmented Filter Pills (Enlarged & Clearer) */}
          <div className="flex items-center gap-1.5 bg-[#091e36] p-1.5 rounded-xl border border-slate-700/80">
            <button
              type="button"
              id="tally-tab-all"
              onClick={() => setActiveCategory('all')}
              className={`px-3.5 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-black transition-all cursor-pointer ${
                activeCategory === 'all'
                  ? 'bg-white text-[#0d2847] shadow-md'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              সব হিসাব
            </button>

            <button
              type="button"
              id="tally-tab-shop"
              onClick={() => setActiveCategory('shop')}
              className={`px-3 sm:px-3.5 py-2 rounded-lg text-xs sm:text-sm font-black flex items-center gap-1.5 transition-all cursor-pointer ${
                activeCategory === 'shop'
                  ? 'bg-white text-[#0d2847] shadow-md'
                  : 'bg-[#133863] text-slate-300 hover:text-white border border-slate-700/80'
              }`}
            >
              <Store className="w-4 h-4 text-emerald-400 stroke-[2.5]" />
              <span>দোকান</span>
            </button>

            <button
              type="button"
              id="tally-tab-personal"
              onClick={() => setActiveCategory('personal')}
              className={`px-3 sm:px-3.5 py-2 rounded-lg text-xs sm:text-sm font-black flex items-center gap-1.5 transition-all cursor-pointer ${
                activeCategory === 'personal'
                  ? 'bg-white text-[#0d2847] shadow-md'
                  : 'bg-[#133863] text-slate-300 hover:text-white border border-slate-700/80'
              }`}
            >
              <User className="w-4 h-4 text-blue-400 stroke-[2.5]" />
              <span>ব্যক্তিগত</span>
            </button>
          </div>

          {/* Right Action Buttons: List & Share */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              id="tally-customer-list-btn"
              onClick={onOpenCustomerLedger}
              title="কাস্টমার খাতা তালিকা"
              className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-[#16a34a] hover:bg-[#15803d] text-white flex items-center justify-center shadow-xs transition-transform active:scale-95 cursor-pointer"
            >
              <List className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.5]" />
            </button>

            <button
              type="button"
              id="tally-share-btn"
              onClick={() => setIsShareModalOpen(true)}
              className="h-9 sm:h-10 px-3 sm:px-4 rounded-xl bg-[#16a34a] hover:bg-[#15803d] text-white font-black text-xs sm:text-sm flex items-center gap-1.5 shadow-xs transition-transform active:scale-95 cursor-pointer"
            >
              <Share2 className="w-4 h-4 stroke-[2.5]" />
              <span>শেয়ার</span>
            </button>
          </div>
        </div>
      </header>

      {/* ========================================================================= */}
      {/* 2. ড্যাশবোর্ড (খরচ, জমা, বাকি এবং মাঝে কমিশন বক্স)                         */}
      {/* ========================================================================= */}
      <section className="px-3 pt-2.5">
        {/* Row 1: ৩টি সমান বক্স - খরচ (Red) | জমা (Green) | বাকি (Orange) - লোগো বামে এবং লেখা বড় ও বোল্ড */}
        <div className="grid grid-cols-3 gap-2 sm:gap-2.5">
          {/* Box 1: খরচ (Red #dc2626) */}
          <div className="bg-[#dc2626] text-white rounded-xl py-2 px-2 sm:py-2.5 sm:px-3 shadow-md border-2 border-red-500/90 flex items-center justify-start gap-2 text-left transition-transform active:scale-98">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-white text-[#dc2626] flex items-center justify-center shadow-md shrink-0 border border-white">
              <Receipt className="w-4 h-4 sm:w-5 sm:h-5 stroke-[3]" />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-xs sm:text-sm font-black text-white leading-none tracking-wide">
                খরচ
              </span>
              <span className="text-sm sm:text-lg md:text-xl font-black text-white whitespace-nowrap tracking-tight leading-tight mt-0.5">
                {toBengaliDigits(totalExpense)}৳
              </span>
            </div>
          </div>

          {/* Box 2: জমা (Green #16a34a) */}
          <div className="bg-[#16a34a] text-white rounded-xl py-2 px-2 sm:py-2.5 sm:px-3 shadow-md border-2 border-emerald-500/90 flex items-center justify-start gap-2 text-left transition-transform active:scale-98">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-white text-[#16a34a] flex items-center justify-center shadow-md shrink-0 border border-white">
              <Banknote className="w-4 h-4 sm:w-5 sm:h-5 stroke-[3]" />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-xs sm:text-sm font-black text-white leading-none tracking-wide">
                জমা
              </span>
              <span className="text-sm sm:text-lg md:text-xl font-black text-white whitespace-nowrap tracking-tight leading-tight mt-0.5">
                {toBengaliDigits(totalDeposit)}৳
              </span>
            </div>
          </div>

          {/* Box 3: বাকি (Orange #ea580c) */}
          <div className="bg-[#ea580c] text-white rounded-xl py-2 px-2 sm:py-2.5 sm:px-3 shadow-md border-2 border-orange-500/90 flex items-center justify-start gap-2 text-left transition-transform active:scale-98">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-white text-[#ea580c] flex items-center justify-center shadow-md shrink-0 border border-white">
              <Scale className="w-4 h-4 sm:w-5 sm:h-5 stroke-[3]" />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-xs sm:text-sm font-black text-white leading-none tracking-wide">
                বাকি
              </span>
              <span className="text-sm sm:text-lg md:text-xl font-black text-white whitespace-nowrap tracking-tight leading-tight mt-0.5">
                {toBengaliDigits(totalDue)}৳
              </span>
            </div>
          </div>
        </div>

        {/* Row 2: মাঝের ঘরে নীল রঙের কমিশন / ক্যাশ বক্স (Blue #2563eb) - লোগো বামে, পরিমিত হাইট এবং বড় বোল্ড লেখা */}
        <div className="flex justify-center mt-2">
          <div
            onClick={() => setIsCommissionModalOpen(true)}
            title="ক্লিক করে সকল কমিশন ও ক্যাশব্যাকের তালিকা দেখুন"
            className="w-full sm:w-auto sm:min-w-[240px] max-w-xs bg-[#2563eb] hover:bg-[#1d4ed8] text-white rounded-xl py-2 px-4 shadow-md border-2 border-blue-400 flex items-center justify-center gap-2.5 cursor-pointer transition-transform active:scale-98"
          >
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-white text-[#2563eb] flex items-center justify-center shadow-md shrink-0 border border-white">
              <Coins className="w-4 h-4 sm:w-5 sm:h-5 stroke-[3]" />
            </div>
            <div className="flex items-baseline gap-1.5 whitespace-nowrap">
              <span className="text-sm sm:text-base font-black text-white tracking-wide">
                কমিশন:
              </span>
              <span className="text-base sm:text-xl md:text-2xl font-black text-white tracking-tight">
                {toBengaliDigits(totalCommission)}৳
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 3. ACTION BUTTONS: ফিল্টার | নতুন হিসাব যোগ করুন | খুঁজুন                */}
      {/* ========================================================================= */}
      <section className="px-3 pt-3">
        <div className="flex items-center gap-2">
          {/* Filter Button */}
          <button
            type="button"
            id="tally-open-filter-btn"
            onClick={() => setIsFilterModalOpen(true)}
            className="px-3.5 sm:px-4 py-2.5 rounded-xl bg-[#1d4ed8] hover:bg-[#1e40af] text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-xs transition-all active:scale-95 cursor-pointer shrink-0"
          >
            <Calendar className="w-4 h-4 stroke-[2.5]" />
            <span>ফিল্টার</span>
          </button>

          {/* Primary Add New Entry Button (Opens Modal with দোকান & ব্যক্তিগত) */}
          <button
            type="button"
            id="tally-add-entry-btn"
            onClick={handleOpenAddModal}
            className="flex-1 py-2.5 px-3 rounded-xl bg-[#16a34a] hover:bg-[#15803d] text-white font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-md transition-all active:scale-95 cursor-pointer"
          >
            <PlusCircle className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.5]" />
            <span>নতুন হিসাব যোগ করুন</span>
          </button>

          {/* Search Button */}
          <button
            type="button"
            id="tally-open-search-btn"
            onClick={() => setIsSearchOpen(!isSearchOpen)}
            className={`px-3.5 sm:px-4 py-2.5 rounded-xl text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-xs transition-all active:scale-95 cursor-pointer shrink-0 ${
              isSearchOpen ? 'bg-[#1e40af] ring-2 ring-blue-300' : 'bg-[#1d4ed8] hover:bg-[#1e40af]'
            }`}
          >
            <Search className="w-4 h-4 stroke-[2.5]" />
            <span>খুঁজুন</span>
          </button>
        </div>

        {/* Real-time Search Input Drawer */}
        {isSearchOpen && (
          <div className="mt-2.5 p-2 bg-white rounded-xl shadow-xs border border-blue-200 flex items-center gap-2 animate-fadeIn">
            <Search className="w-4 h-4 text-blue-600 shrink-0 ml-1" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="বিবরণ, পরিমাণ, কোড, বার বা তারিখ দিয়ে খুঁজুন..."
              className="flex-1 text-xs outline-hidden text-slate-800 font-medium"
              autoFocus
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="text-xs text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        )}
      </section>

      {/* ========================================================================= */}
      {/* 4. MONTH NAVIGATOR: < | [Calendar] সকল মাসের মোট হিসাব | > | ↩ চলতি মাস  */}
      {/* ========================================================================= */}
      <section className="px-3 pt-3">
        <div className="flex items-center gap-1.5">
          {/* Previous Month Button */}
          <button
            type="button"
            id="tally-prev-month-btn"
            onClick={handlePrevMonth}
            className="w-9 sm:w-10 h-9 sm:h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 hover:bg-slate-50 shadow-2xs cursor-pointer active:scale-95 transition-all shrink-0"
            title="আগের মাস"
          >
            <ChevronLeft className="w-5 h-5 stroke-[2.5]" />
          </button>

          {/* Center Month Pill Button */}
          <button
            type="button"
            id="tally-month-label-btn"
            onClick={() => {
              if (monthFilter === 'all') {
                handleResetCurrentMonth();
              } else {
                setMonthFilter('all');
              }
            }}
            className="flex-1 h-9 sm:h-10 px-2 sm:px-3 rounded-xl bg-white border border-slate-200 flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer hover:border-blue-400 transition-all overflow-hidden"
          >
            <Calendar className="w-4 h-4 text-blue-600 shrink-0" />
            <span className="font-black text-xs sm:text-sm text-slate-900 truncate">
              {currentMonthLabel}
            </span>
          </button>

          {/* Next Month Button */}
          <button
            type="button"
            id="tally-next-month-btn"
            onClick={handleNextMonth}
            className="w-9 sm:w-10 h-9 sm:h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-700 hover:bg-slate-50 shadow-2xs cursor-pointer active:scale-95 transition-all shrink-0"
            title="পরের মাস"
          >
            <ChevronRight className="w-5 h-5 stroke-[2.5]" />
          </button>

          {/* Current Month Reset Button */}
          <button
            type="button"
            id="tally-current-month-btn"
            onClick={handleResetCurrentMonth}
            className="h-9 sm:h-10 px-2.5 sm:px-3 rounded-xl bg-[#1d4ed8] hover:bg-[#1e40af] text-white font-black text-xs flex items-center justify-center gap-1 shadow-xs cursor-pointer active:scale-95 transition-all shrink-0"
            title="চলতি মাসে ফিরে যান"
          >
            <CornerUpLeft className="w-4 h-4 stroke-[2.5]" />
            <span className="hidden sm:inline">চলতি মাস</span>
            <span className="sm:hidden text-[11px]">চলতি</span>
          </button>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 5. INFO & COUNT BAR: 🔵 হিসাব এডিট বা ডিলিট করতে লাইনে চাপ দিন             */}
      {/* ========================================================================= */}
      <section className="px-3 pt-2.5 pb-1">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-[#1d4ed8] font-black">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600 inline-block shrink-0" />
            <span className="text-[11px] sm:text-xs">হিসাব এডিট বা ডিলিট করতে লাইনে চাপ দিন</span>
          </div>
          <div className="text-slate-900 font-black text-xs">
            মোট এন্ট্রি: <span className="text-blue-700">{toBengaliDigits(filteredTransactions.length)}</span>টি
          </div>
        </div>
      </section>

      {/* ========================================================================= */}
      {/* 6. THE 6-COLUMN LEDGER TABLE (ছবির হুবহু ৬টি কলাম)                         */}
      {/* Col 1: তারিখ | Col 2: বিবরণ | Col 3: খরচ/বিক্রি | Col 4: জমা | Col 5: বাকি | Col 6: ক্যাশ */}
      {/* ========================================================================= */}
      <main className="px-3 pt-1">
        <div className="rounded-xl overflow-hidden border-2 border-slate-300 bg-white shadow-sm">
          {/* Table Header: 6 Distinct High-Contrast Solid Colors */}
          <div className="grid grid-cols-[19%_25%_15%_14%_14%_13%] text-center text-white text-xs font-black divide-x divide-white/20">
            {/* Col 1: তারিখ (Deep Blue #1d4ed8) */}
            <div className="bg-[#1d4ed8] py-2.5 px-0.5 flex items-center justify-center gap-1">
              <div className="w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-white/20 flex items-center justify-center shrink-0">
                <Calendar className="w-3 h-3 sm:w-3.5 sm:h-3.5 stroke-[2.8] text-white" />
              </div>
              <span className="text-[11px] sm:text-xs font-black">তারিখ</span>
            </div>

            {/* Col 2: বিবরণ (Slate/Purple #334155) */}
            <div className="bg-[#334155] py-2.5 px-0.5 flex items-center justify-center gap-1">
              <div className="w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-white/20 flex items-center justify-center shrink-0">
                <Tag className="w-3 h-3 sm:w-3.5 sm:h-3.5 stroke-[2.8] text-white" />
              </div>
              <span className="text-[11px] sm:text-xs font-black">বিবরণ</span>
            </div>

            {/* Col 3: খরচ/বিক্রি (Red #dc2626) */}
            <div className="bg-[#dc2626] py-2.5 px-0.5 flex items-center justify-center gap-1">
              <div className="w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-white/20 flex items-center justify-center shrink-0">
                <Receipt className="w-3 h-3 sm:w-3.5 sm:h-3.5 stroke-[2.8] text-white" />
              </div>
              <span className="text-[11px] sm:text-xs font-black">খরচ/বিক্রি</span>
            </div>

            {/* Col 4: জমা (Green #16a34a) */}
            <div className="bg-[#16a34a] py-2.5 px-0.5 flex items-center justify-center gap-1">
              <div className="w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-white/20 flex items-center justify-center shrink-0">
                <Banknote className="w-3 h-3 sm:w-3.5 sm:h-3.5 stroke-[2.8] text-white" />
              </div>
              <span className="text-[11px] sm:text-xs font-black">জমা</span>
            </div>

            {/* Col 5: বাকি (Orange/Rose #ea580c) */}
            <div className="bg-[#ea580c] py-2.5 px-0.5 flex items-center justify-center gap-1">
              <div className="w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-white/20 flex items-center justify-center shrink-0">
                <Scale className="w-3 h-3 sm:w-3.5 sm:h-3.5 stroke-[2.8] text-white" />
              </div>
              <span className="text-[11px] sm:text-xs font-black">বাকি</span>
            </div>

            {/* Col 6: ক্যাশ (Cyan/Blue #0284c7) */}
            <div className="bg-[#0284c7] py-2.5 px-0.5 flex items-center justify-center gap-1">
              <div className="w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-white/20 flex items-center justify-center shrink-0">
                <Coins className="w-3 h-3 sm:w-3.5 sm:h-3.5 stroke-[2.8] text-white" />
              </div>
              <span className="text-[11px] sm:text-xs font-black">ক্যাশ</span>
            </div>
          </div>

          {/* Table Body / Rows */}
          {filteredTransactions.length === 0 ? (
            <div className="py-12 px-4 text-center text-slate-400">
              <Scale className="w-10 h-10 mx-auto text-slate-300 mb-2" />
              <p className="font-bold text-xs">কোনো হিসাব পাওয়া যায়নি</p>
              <p className="text-[11px] text-slate-400 mt-0.5">নতুন হিসাব যোগ করতে উপরের বাটনে চাপ দিন</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-200">
              {filteredTransactions.map((trx, index) => {
                const dayName = trx.dayOfWeek || getBengaliDayOfWeek(trx.date, trx.createdAtMs);
                const displayDateBengali = formatBengaliDate(trx.date || getTodayDateFormatted());
                const buyNum = parseBengaliOrEnglishNumber(trx.buyPrice);
                const depNum = parseBengaliOrEnglishNumber(trx.depositAmount);
                const isDepositEmpty = depNum === 0 && !trx.depositAmount;

                // Selling price calculation
                const isPersonal = trx.category === 'ব্যক্তিগত';
                const sellNum = parseBengaliOrEnglishNumber(trx.sellPrice);
                const sellTotal = isPersonal ? buyNum : (sellNum > 0 ? sellNum : buyNum);

                // Commission/Profit calculation: বিক্রি − খরচ = লাভ
                const dynamicProfit = !isPersonal && sellNum > 0 && buyNum > 0 && sellNum >= buyNum
                  ? sellNum - buyNum
                  : 0;
                const commTag = !isPersonal
                  ? (dynamicProfit > 0
                      ? `C${dynamicProfit}`
                      : (trx.commissionTag || (trx.note && trx.note.startsWith('C') ? trx.note : null)))
                  : null;

                // Due calculation (দোকানের কাস্টমার বাকি বা ব্যক্তিগত বকেয়া)
                const dueTotal = typeof trx.dueAmount === 'number' && !isNaN(trx.dueAmount)
                  ? Math.max(0, trx.dueAmount)
                  : Math.max(0, (isPersonal ? buyNum : sellTotal) - depNum);

                return (
                  <div
                    key={trx.id || index}
                    onClick={() => handleRowClick(trx)}
                    className="grid grid-cols-[19%_25%_15%_14%_14%_13%] items-center hover:bg-blue-50/50 active:bg-blue-100/60 cursor-pointer transition-colors divide-x divide-slate-200 py-2.5 px-0 text-slate-800 group"
                  >
                    {/* Col 1: তারিখ (১৬/৯/২০২৬ \n মঙ্গলবার) */}
                    <div className="flex flex-col items-center justify-center text-center px-1">
                      <span className="text-[11px] sm:text-xs font-black text-slate-900 tracking-tight leading-tight">
                        {displayDateBengali}
                      </span>
                      <span className="bg-blue-100 text-blue-900 text-[9px] sm:text-[10px] font-black px-1.5 py-0.5 rounded mt-0.5 leading-none">
                        {dayName}
                      </span>
                    </div>

                    {/* Col 2: বিবরণ (জিপি অফার \n 50+1500) */}
                    <div className="flex flex-col items-start justify-center px-1.5 sm:px-2 min-w-0">
                      <span className="font-black text-slate-900 text-[11px] sm:text-xs tracking-tight truncate w-full">
                        {trx.itemName}
                      </span>
                      {trx.quantity && (
                        <span className="bg-purple-100 text-purple-900 text-[9px] sm:text-[10px] font-black px-1.5 py-0.5 rounded mt-0.5 leading-none truncate max-w-full">
                          {trx.quantity}
                        </span>
                      )}
                    </div>

                    {/* Col 3: খরচ/বিক্রি (700 \n বিক্রি 750) */}
                    <div className="flex flex-col items-center justify-center text-center px-0.5">
                      <span className="text-xs sm:text-sm font-black text-red-600 tracking-tight">
                        {toBengaliDigits(buyNum)}
                      </span>
                      {sellTotal > 0 && sellTotal !== buyNum && (
                        <span className="text-[9px] sm:text-[10px] text-amber-900 font-bold leading-none mt-0.5">
                          বিক্রি {toBengaliDigits(sellTotal)}
                        </span>
                      )}
                    </div>

                    {/* Col 4: জমা (400, 700 বা -) */}
                    <div className="flex flex-col items-center justify-center text-center px-0.5">
                      <span className={`text-xs sm:text-sm font-black tracking-tight ${depNum > 0 ? 'text-emerald-600' : 'text-slate-400 font-bold'}`}>
                        {!isDepositEmpty && depNum > 0 ? toBengaliDigits(depNum) : '-'}
                      </span>
                    </div>

                    {/* Col 5: বাকি (750, 300 বা ✓) */}
                    <div className="flex flex-col items-center justify-center text-center px-0.5">
                      {dueTotal > 0 ? (
                        <span className="text-xs sm:text-sm font-black text-rose-600 tracking-tight">
                          {toBengaliDigits(dueTotal)}
                        </span>
                      ) : (
                        <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 font-black text-xs sm:text-sm px-1.5 py-0.5 rounded-full inline-flex items-center justify-center shadow-2xs">
                          ✓
                        </span>
                      )}
                    </div>

                    {/* Col 6: ক্যাশ (C50, C55, C60) */}
                    <div className="flex flex-col items-center justify-center text-center px-0.5">
                      {commTag ? (
                        <span className="bg-blue-100 text-blue-900 border border-blue-200 text-[10px] sm:text-xs font-black px-1.5 py-0.5 rounded-md shadow-2xs">
                          {commTag}
                        </span>
                      ) : (
                        <span className="text-slate-400 font-bold text-xs">-</span>
                      )}
                    </div>
                  </div>
                );
              })}

              {/* Table Footer / Summary Row (নিচের মোট হিসাব সারি) */}
              <div className="bg-slate-100/95 border-t-2 border-slate-300 grid grid-cols-[19%_25%_15%_14%_14%_13%] items-center divide-x divide-slate-300 py-3 px-0 text-slate-900 font-black text-center">
                {/* Col 1 & 2: মোট হিসাব */}
                <div className="col-span-2 px-1 text-center sm:text-left sm:px-2 flex flex-col justify-center">
                  <span className="text-[11px] sm:text-xs font-black text-slate-900">
                    মোট ({toBengaliDigits(filteredTransactions.length)})
                  </span>
                </div>

                {/* Col 3: মোট খরচ */}
                <div className="px-0.5 text-center">
                  <span className="text-xs sm:text-sm font-black text-red-600">
                    {toBengaliDigits(totalExpense)}৳
                  </span>
                </div>

                {/* Col 4: মোট জমা */}
                <div className="px-0.5 text-center">
                  <span className="text-xs sm:text-sm font-black text-emerald-600">
                    {toBengaliDigits(totalDeposit)}৳
                  </span>
                </div>

                {/* Col 5: মোট বাকি */}
                <div className="px-0.5 text-center">
                  <span className="text-xs sm:text-sm font-black text-rose-600">
                    {toBengaliDigits(totalDue)}৳
                  </span>
                </div>

                {/* Col 6: মোট ক্যাশ */}
                <div className="px-0.5 text-center">
                  <span className="text-[10px] sm:text-xs font-black text-blue-700">
                    C{toBengaliDigits(totalCommission)}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* ========================================================================= */}
      {/* 7. BOTTOM HELPER TIP BAR                                                  */}
      {/* ========================================================================= */}
      <footer className="px-3 mt-3 mb-6">
        <div className="p-2.5 rounded-xl bg-slate-200/70 border border-slate-300 text-center flex items-center justify-center gap-1.5 text-xs font-bold text-slate-700 shadow-2xs">
          <span>💡</span>
          <span className="font-black text-blue-950">ক্লিক করলে এডিট করা যাবে/ ডিলেট করা যাবে</span>
        </div>
      </footer>

      {/* ========================================================================= */}
      {/* MODAL 1: নতুন হিসাব যোগ করুন (দোকান ও ব্যক্তিগত সিলেক্টরসহ)              */}
      {/* ========================================================================= */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-black/65 backdrop-blur-xs flex items-end sm:items-center justify-center z-50 p-0 sm:p-4 animate-fadeIn">
          <div className="w-full sm:max-w-lg bg-white rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200 max-h-[92vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <PlusCircle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900 leading-tight">নতুন হিসাব যোগ করুন</h3>
                  <p className="text-[11px] text-slate-500 font-bold">দোকান বা ব্যক্তিগত হিসাব নির্বাচন করুন</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveNewTransaction} className="mt-4 space-y-3.5 text-xs font-bold">
              {/* Top Category Selection Tabs: দোকান vs ব্যক্তিগত */}
              <div>
                <label className="text-slate-600 block mb-1.5 font-black">হিসাবের ধরন বেছে নিন *</label>
                <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-2xl border border-slate-200">
                  <button
                    type="button"
                    onClick={() => {
                      setFormData((prev) => ({
                        ...prev,
                        category: 'দোকান',
                        itemName: prev.itemName === 'শাকসবজি' || prev.itemName === 'কাঁচাবাজার' ? 'জিপি অফার' : prev.itemName,
                        quantity: prev.quantity === '৫ কেজি' ? '50+1500' : prev.quantity,
                      }));
                    }}
                    className={`py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 font-black text-xs sm:text-sm transition-all cursor-pointer ${
                      formData.category === 'দোকান'
                        ? 'bg-emerald-600 text-white shadow-md'
                        : 'text-slate-700 hover:text-slate-900 hover:bg-white/60'
                    }`}
                  >
                    <Store className="w-4 h-4 text-emerald-200" />
                    <span>দোকান</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setFormData((prev) => ({
                        ...prev,
                        category: 'ব্যক্তিগত',
                        itemName: prev.itemName === 'জিপি অফার' ? 'শাকসবজি' : prev.itemName,
                        quantity: prev.quantity === '50+1500' ? '৫ কেজি' : prev.quantity,
                      }));
                    }}
                    className={`py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 font-black text-xs sm:text-sm transition-all cursor-pointer ${
                      formData.category === 'ব্যক্তিগত'
                        ? 'bg-blue-600 text-white shadow-md'
                        : 'text-slate-700 hover:text-slate-900 hover:bg-white/60'
                    }`}
                  >
                    <User className="w-4 h-4 text-blue-200" />
                    <span>ব্যক্তিগত</span>
                  </button>
                </div>
              </div>

              {/* ========================================================================= */}
              {/* TAB 1: দোকান সিলেক্ট হলে এই ইনপুট বক্সটি ওপেন হবে (ছবির ৩x৪ গ্রিড লেআউট)   */}
              {/* ========================================================================= */}
              {formData.category === 'দোকান' && (
                <div className="space-y-3 animate-fadeIn">
                  {/* হুবহু ব্যবহারকারীর ছবি অনুসারে লাল বর্ডারের ৩ কলাম ৪ সারির ইনপুট গ্রিড */}
                  <div className="border-2 border-red-500 rounded-2xl p-3 bg-white shadow-sm space-y-2.5">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                      {/* ROW 1 */}
                      {/* Row 1, Col 1: তারিখ: ১৭/৯/২০২৬ */}
                      <div className="bg-red-50/40 p-2 rounded-xl border border-red-200">
                        <label className="text-red-900 text-[11px] font-black block mb-0.5">তারিখ:</label>
                        <input
                          type="text"
                          required
                          value={formData.date}
                          onChange={(e) => handleDateChangeForModal(e.target.value)}
                          placeholder="১৭/৯/২০২৬"
                          className="w-full p-2 bg-white border border-red-300 rounded-lg text-xs font-black text-slate-900 outline-hidden focus:ring-2 focus:ring-red-400"
                        />
                      </div>

                      {/* Row 1, Col 2: বার : বৃহস্পতিবার */}
                      <div className="bg-red-50/40 p-2 rounded-xl border border-red-200">
                        <label className="text-red-900 text-[11px] font-black block mb-0.5">বার :</label>
                        <select
                          value={formData.dayOfWeek}
                          onChange={(e) => setFormData({ ...formData, dayOfWeek: e.target.value })}
                          className="w-full p-2 bg-white border border-red-300 rounded-lg text-xs font-black text-slate-900 outline-hidden focus:ring-2 focus:ring-red-400"
                        >
                          {daysList.map((d) => (
                            <option key={d} value={d}>
                              {d}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Row 1, Col 3: হিসাবের ধরণ (দোকান / ব্যক্তিগত) */}
                      <div className="bg-red-50/40 p-2 rounded-xl border border-red-200 flex flex-col justify-center">
                        <label className="text-red-900 text-[11px] font-black block mb-0.5">হিসাবের ধরণ:</label>
                        <div className="grid grid-cols-2 gap-1 w-full">
                          <button
                            type="button"
                            onClick={() => setFormData({ ...formData, category: 'দোকান' })}
                            className={`py-1 px-1.5 rounded-lg text-[11px] font-black transition-all cursor-pointer ${
                              formData.category === 'দোকান'
                                ? 'bg-[#16a34a] text-white shadow-2xs'
                                : 'bg-white text-slate-700 border border-slate-200'
                            }`}
                          >
                            দোকান
                          </button>
                          <button
                            type="button"
                            onClick={() => setFormData({ ...formData, category: 'ব্যক্তিগত' })}
                            className={`py-1 px-1.5 rounded-lg text-[11px] font-black transition-all cursor-pointer ${
                              formData.category === 'ব্যক্তিগত'
                                ? 'bg-[#1d4ed8] text-white shadow-2xs'
                                : 'bg-white text-slate-700 border border-slate-200'
                            }`}
                          >
                            ব্যক্তিগত
                          </button>
                        </div>
                      </div>

                      {/* ROW 2 */}
                      {/* Row 2, Col 1: কেনা: 500 */}
                      <div className="bg-red-50/60 p-2 rounded-xl border border-red-300">
                        <label className="text-red-900 text-[11px] font-black block mb-0.5">কেনা: (৳) *</label>
                        <input
                          type="text"
                          inputMode="numeric"
                          required
                          value={formData.buyPrice}
                          onChange={(e) => handleBuyPriceChange(e.target.value)}
                          placeholder="500"
                          className="w-full p-2 bg-white border border-red-300 text-red-700 rounded-lg text-xs sm:text-sm font-black outline-hidden focus:ring-2 focus:ring-red-400"
                        />
                      </div>

                      {/* Row 2, Col 2: বিক্রি: 550 */}
                      <div className="bg-amber-50/60 p-2 rounded-xl border border-amber-300">
                        <label className="text-amber-950 text-[11px] font-black block mb-0.5">বিক্রি: (৳)</label>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={formData.sellPrice}
                          onChange={(e) => handleSellPriceChange(e.target.value)}
                          placeholder="550"
                          className="w-full p-2 bg-white border border-amber-400 text-amber-950 rounded-lg text-xs sm:text-sm font-black outline-hidden focus:ring-2 focus:ring-amber-400"
                        />
                      </div>

                      {/* Row 2, Col 3: জমা: [ ] */}
                      <div className="bg-emerald-50/60 p-2 rounded-xl border border-emerald-300">
                        <label className="text-emerald-950 text-[11px] font-black block mb-0.5">জমা: (৳)</label>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={formData.depositAmount}
                          onChange={(e) => handleDepositAmountChange(e.target.value)}
                          placeholder="যেমন: 550 বা খালি"
                          className="w-full p-2 bg-white border border-emerald-300 text-emerald-700 rounded-lg text-xs sm:text-sm font-black outline-hidden focus:ring-2 focus:ring-emerald-400"
                        />
                      </div>

                      {/* ROW 3 */}
                      {/* Row 3, Col 1: লাভ (বিক্রি − কেনা) */}
                      <div className="bg-slate-50 p-2 rounded-xl border border-slate-200 flex flex-col justify-center text-center">
                        <span className="text-[10px] text-slate-500 font-bold block">লাভ (বিক্রি − কেনা)</span>
                        <span className="text-xs font-black text-amber-700 mt-0.5">
                          {(() => {
                            const b = parseBengaliOrEnglishNumber(formData.buyPrice);
                            const s = parseBengaliOrEnglishNumber(formData.sellPrice);
                            const profit = s > b ? s - b : 0;
                            return profit > 0 ? `${toBengaliDigits(profit)}৳ লাভ` : '০৳';
                          })()}
                        </span>
                      </div>

                      {/* Row 3, Col 2: ক্যাশ/C : 50 C */}
                      <div className="bg-blue-50/60 p-2 rounded-xl border border-blue-300">
                        <label className="text-blue-900 text-[11px] font-black block mb-0.5">ক্যাশ/C :</label>
                        <input
                          type="text"
                          value={formData.commissionTag}
                          onChange={(e) => handleCommissionTagChange(e.target.value)}
                          placeholder="50 C"
                          className="w-full p-2 bg-white border border-blue-300 text-blue-900 rounded-lg text-xs sm:text-sm font-black outline-hidden focus:ring-2 focus:ring-blue-400"
                        />
                      </div>

                      {/* Row 3, Col 3: বাকি: 550 */}
                      <div className="bg-rose-50/60 p-2 rounded-xl border border-rose-300">
                        <label className="text-rose-900 text-[11px] font-black block mb-0.5">বাকি: (৳)</label>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={formData.dueAmount}
                          onChange={(e) => handleDueAmountChange(e.target.value)}
                          placeholder="550"
                          className="w-full p-2 bg-white border border-rose-300 text-rose-800 rounded-lg text-xs sm:text-sm font-black outline-hidden focus:ring-2 focus:ring-rose-400"
                        />
                      </div>

                      {/* ROW 4 */}
                      {/* Row 4, Col 1: পণ্যের নাম: অফার */}
                      <div className="bg-purple-50/60 p-2 rounded-xl border border-purple-200">
                        <label className="text-purple-900 text-[11px] font-black block mb-0.5">পণ্যের নাম: *</label>
                        <input
                          type="text"
                          required
                          value={formData.itemName}
                          onChange={(e) => setFormData({ ...formData, itemName: e.target.value })}
                          placeholder="অফার"
                          className="w-full p-2 bg-white border border-purple-300 text-purple-950 rounded-lg text-xs font-black outline-hidden focus:ring-2 focus:ring-purple-400"
                        />
                      </div>

                      {/* Row 4, Col 2: বিবরণ: 999 */}
                      <div className="bg-purple-50/60 p-2 rounded-xl border border-purple-200">
                        <label className="text-purple-900 text-[11px] font-black block mb-0.5">বিবরণ:</label>
                        <input
                          type="text"
                          value={formData.quantity}
                          onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                          placeholder="999 বা 50+1500"
                          className="w-full p-2 bg-white border border-purple-300 text-purple-950 rounded-lg text-xs font-black outline-hidden focus:ring-2 focus:ring-purple-400"
                        />
                      </div>

                      {/* Row 4, Col 3: বাকি ✓ */}
                      <div className={`p-2 rounded-xl border flex flex-col justify-center ${parseBengaliOrEnglishNumber(formData.dueAmount) > 0 ? 'bg-rose-50/80 border-rose-300' : 'bg-emerald-50/80 border-emerald-300'}`}>
                        <label className="text-slate-800 text-[11px] font-black block mb-0.5">বাকি স্ট্যাটাস:</label>
                        <button
                          type="button"
                          onClick={handleToggleDueCheckbox}
                          className={`w-full py-1.5 px-2 rounded-lg text-xs font-black flex items-center justify-center gap-1 cursor-pointer transition-all shadow-2xs ${
                            parseBengaliOrEnglishNumber(formData.dueAmount) > 0
                              ? 'bg-[#dc2626] hover:bg-red-700 text-white'
                              : 'bg-[#16a34a] hover:bg-emerald-700 text-white'
                          }`}
                        >
                          {parseBengaliOrEnglishNumber(formData.dueAmount) > 0 ? (
                            <span>বাকি ✓</span>
                          ) : (
                            <span>✓ পরিশোধ</span>
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Quick chips below grid */}
                    <div className="pt-1 flex flex-wrap gap-1.5">
                      <button
                        type="button"
                        onClick={() => setFormData((p) => ({ ...p, itemName: 'জিপি অফার', quantity: '50+1500' }))}
                        className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-800 text-[10px] font-black hover:bg-blue-200 cursor-pointer"
                      >
                        +জিপি অফার
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormData((p) => ({ ...p, itemName: 'রবি অফার', quantity: '40+1000' }))}
                        className="px-2 py-0.5 rounded-md bg-red-100 text-red-800 text-[10px] font-black hover:bg-red-200 cursor-pointer"
                      >
                        +রবি অফার
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormData((p) => ({ ...p, itemName: 'বাংলালিংক অফার', quantity: '35+800' }))}
                        className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 text-[10px] font-black hover:bg-amber-200 cursor-pointer"
                      >
                        +বাংলালিংক
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormData((p) => ({ ...p, itemName: 'এয়ারটেল অফার', quantity: '50+1500' }))}
                        className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-800 text-[10px] font-black hover:bg-rose-200 cursor-pointer"
                      >
                        +এয়ারটেল
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormData((p) => ({ ...p, itemName: 'রিচার্জ', quantity: 'ফ্লেক্সিলোড' }))}
                        className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-black hover:bg-emerald-200 cursor-pointer"
                      >
                        +রিচার্জ
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* ========================================================================= */}
              {/* TAB 2: ব্যক্তিগত সিলেক্ট হলে এই ইনপুট বক্সটি ওপেন হবে                     */}
              {/* ========================================================================= */}
              {formData.category === 'ব্যক্তিগত' && (
                <div className="space-y-3 animate-fadeIn">
                  {/* Banner indicator */}
                  <div className="bg-blue-50 border border-blue-200 p-2 rounded-xl flex items-center justify-between text-blue-800">
                    <span className="font-black text-xs flex items-center gap-1.5">
                      <User className="w-4 h-4 text-blue-600" />
                      ব্যক্তিগত হিসাব ইনপুট বক্স
                    </span>
                    <span className="text-[10px] bg-blue-100 text-blue-900 font-bold px-2 py-0.5 rounded-full">
                      ব্যক্তিগত খরচ ও জমা
                    </span>
                  </div>

                  {/* তারিখ ও বার */}
                  <div className="bg-blue-50/70 p-2.5 rounded-xl border border-blue-200 space-y-1.5">
                    <label className="text-blue-900 font-black flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-blue-600" />
                      তারিখ ও বার
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        required
                        value={formData.date}
                        onChange={(e) => handleDateChangeForModal(e.target.value)}
                        placeholder="16/9/2026"
                        className="w-full p-2.5 bg-white border border-blue-300 rounded-lg outline-hidden text-xs font-black text-blue-950"
                      />
                      <select
                        value={formData.dayOfWeek}
                        onChange={(e) => setFormData({ ...formData, dayOfWeek: e.target.value })}
                        className="w-full p-2.5 bg-white border border-blue-300 rounded-lg outline-hidden text-xs font-black text-blue-950"
                      >
                        {daysList.map((d) => (
                          <option key={d} value={d}>
                            {d}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* খরচের বিবরণ ও পরিমাণ */}
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 space-y-1.5">
                    <label className="text-slate-800 font-black flex items-center gap-1">
                      <Tag className="w-3.5 h-3.5 text-slate-600" />
                      খরচ বা জমার বিবরণ
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        required
                        value={formData.itemName}
                        onChange={(e) => setFormData({ ...formData, itemName: e.target.value })}
                        placeholder="যেমন: শাকসবজি, বাজার"
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-lg outline-hidden text-xs font-black text-slate-900"
                      />
                      <input
                        type="text"
                        value={formData.quantity}
                        onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                        placeholder="যেমন: ৫ কেজি"
                        className="w-full p-2.5 bg-white border border-slate-300 rounded-lg outline-hidden text-xs font-bold text-slate-900"
                      />
                    </div>
                    {/* Fast Chips */}
                    <div className="pt-1 flex flex-wrap gap-1.5">
                      <button
                        type="button"
                        onClick={() => setFormData((p) => ({ ...p, itemName: 'শাকসবজি', quantity: '৫ কেজি' }))}
                        className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-black hover:bg-emerald-200"
                      >
                        +শাকসবজি
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormData((p) => ({ ...p, itemName: 'কাঁচাবাজার', quantity: '৫ কেজি' }))}
                        className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-black hover:bg-emerald-200"
                      >
                        +কাঁচাবাজার
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormData((p) => ({ ...p, itemName: 'হাতখরচ', quantity: '১' }))}
                        className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-800 text-[10px] font-black hover:bg-blue-200"
                      >
                        +হাতখরচ
                      </button>
                      <button
                        type="button"
                        onClick={() => setFormData((p) => ({ ...p, itemName: 'চাল ও ডাল', quantity: '১০ কেজি' }))}
                        className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 text-[10px] font-black hover:bg-amber-200"
                      >
                        +চাল ও ডাল
                      </button>
                    </div>
                  </div>

                  {/* ব্যক্তিগত খরচ, জমা ও বাকি (খরচ = জমা + বাকি) */}
                  <div className="bg-slate-50/90 p-2.5 rounded-xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-slate-800 font-black text-xs flex items-center gap-1">
                        <Banknote className="w-3.5 h-3.5 text-emerald-700" />
                        ব্যক্তিগত খরচ, জমা ও বাকি
                      </label>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={handleSetFullCashDeposit}
                          className="px-2 py-0.5 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-black cursor-pointer shadow-2xs transition-colors"
                        >
                          ✓ সম্পূর্ণ পরিশোধ
                        </button>
                        <button
                          type="button"
                          onClick={handleSetFullDue}
                          className="px-2 py-0.5 rounded-md bg-orange-600 hover:bg-orange-700 text-white text-[10px] font-black cursor-pointer shadow-2xs transition-colors"
                        >
                          বাকি রাখা
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      {/* খরচ */}
                      <div className="bg-red-50/70 p-2 rounded-xl border border-red-200">
                        <label className="text-red-700 block mb-0.5 font-black text-[11px] flex items-center gap-1">
                          <Receipt className="w-3 h-3" />
                          খরচ / ব্যয় (৳) *
                        </label>
                        <input
                          type="text"
                          inputMode="numeric"
                          required
                          value={formData.buyPrice}
                          onChange={(e) => handleBuyPriceChange(e.target.value)}
                          placeholder="যেমন: ৫০০"
                          className="w-full p-2 bg-white border border-red-300 text-red-700 rounded-lg outline-hidden text-xs sm:text-sm font-black focus:ring-2 focus:ring-red-400"
                        />
                      </div>

                      {/* জমা */}
                      <div className="bg-emerald-50/70 p-2 rounded-xl border border-emerald-200">
                        <label className="text-emerald-700 block mb-0.5 font-black text-[11px] flex items-center gap-1">
                          <Banknote className="w-3 h-3" />
                          জমা / পরিশোধ (৳)
                        </label>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={formData.depositAmount}
                          onChange={(e) => handleDepositAmountChange(e.target.value)}
                          placeholder="যেমন: ৪০০"
                          className="w-full p-2 bg-white border border-emerald-300 text-emerald-700 rounded-lg outline-hidden text-xs sm:text-sm font-black focus:ring-2 focus:ring-emerald-400"
                        />
                      </div>

                      {/* বাকি */}
                      <div className="bg-orange-50/70 p-2 rounded-xl border border-orange-200">
                        <label className="text-orange-700 block mb-0.5 font-black text-[11px] flex items-center gap-1">
                          <Coins className="w-3 h-3" />
                          বাকি (৳)
                        </label>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={formData.dueAmount}
                          onChange={(e) => handleDueAmountChange(e.target.value)}
                          placeholder="যেমন: ১০০"
                          className="w-full p-2 bg-white border border-orange-300 text-orange-800 rounded-lg outline-hidden text-xs sm:text-sm font-black focus:ring-2 focus:ring-orange-400"
                        />
                      </div>
                    </div>

                    <div className="bg-white/80 p-1.5 rounded-lg border border-slate-200 text-[10px] font-bold text-slate-700 flex items-center justify-between">
                      <span>💡 সমীকরণ: <strong>খরচ ({toBengaliDigits(parseBengaliOrEnglishNumber(formData.buyPrice))}৳) = জমা ({toBengaliDigits(parseBengaliOrEnglishNumber(formData.depositAmount))}৳) + বাকি ({toBengaliDigits(parseBengaliOrEnglishNumber(formData.dueAmount))}৳)</strong></span>
                    </div>
                  </div>
                </div>
              )}

              {/* 4-Card Live Calculation Preview (Directly matches the Top 4 Total Boxes) */}
              {(() => {
                const pBuy = parseBengaliOrEnglishNumber(formData.buyPrice);
                const pDeposit = parseBengaliOrEnglishNumber(formData.depositAmount);
                const isPers = formData.category === 'ব্যক্তিগত';
                let pSell = isPers ? pBuy : (parseBengaliOrEnglishNumber(formData.sellPrice) || pBuy);
                let pComm = 0;
                if (!isPers) {
                  const match = formData.commissionTag.match(/[\d০-৯]+/);
                  if (match) {
                    pComm = parseBengaliOrEnglishNumber(match[0]);
                  } else if (pSell > pBuy) {
                    pComm = pSell - pBuy;
                  }
                }
                const pDue = formData.dueAmount !== ''
                  ? parseBengaliOrEnglishNumber(formData.dueAmount)
                  : Math.max(0, pSell - pDeposit);

                return (
                  <div className="p-2.5 sm:p-3 bg-slate-900 text-white rounded-xl border border-slate-700 shadow-md space-y-2">
                    <div className="flex items-center justify-between text-xs font-black border-b border-slate-800 pb-1.5 text-slate-300">
                      <span className="flex items-center gap-1.5 text-amber-300">
                        <Scale className="w-4 h-4" />
                        হিসাব প্রিভিউ (উপরের ৪টি ঘরের সাথে সরাসরি মিলবে):
                      </span>
                      {!isPers && pSell > 0 && (
                        <span className="text-emerald-400 font-mono text-[11px] bg-emerald-950/80 px-2 py-0.5 rounded-md border border-emerald-700/50">
                          বিক্রি: {toBengaliDigits(pSell)}৳
                        </span>
                      )}
                    </div>
                    <div className="grid grid-cols-4 gap-1.5 sm:gap-2 text-center font-black pt-0.5">
                      <div className="bg-[#dc2626] rounded-lg py-1.5 px-1 shadow-xs border border-red-400/40">
                        <span className="text-[10px] text-red-100 block">খরচ</span>
                        <span className="text-white text-xs sm:text-sm">{toBengaliDigits(pBuy)}৳</span>
                      </div>
                      <div className="bg-[#16a34a] rounded-lg py-1.5 px-1 shadow-xs border border-emerald-400/40">
                        <span className="text-[10px] text-emerald-100 block">জমা</span>
                        <span className="text-white text-xs sm:text-sm">{toBengaliDigits(pDeposit)}৳</span>
                      </div>
                      <div className="bg-[#ea580c] rounded-lg py-1.5 px-1 shadow-xs border border-amber-400/40">
                        <span className="text-[10px] text-amber-100 block">বাকি</span>
                        <span className="text-white text-xs sm:text-sm">{toBengaliDigits(pDue)}৳</span>
                      </div>
                      <div className="bg-[#7c3aed] rounded-lg py-1.5 px-1 shadow-xs border border-purple-400/40">
                        <span className="text-[10px] text-purple-100 block">কমিশন</span>
                        <span className="text-white text-xs sm:text-sm">{toBengaliDigits(pComm)}৳</span>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  className={`w-full py-3 rounded-xl text-white font-black text-sm shadow-md transition-transform active:scale-98 flex items-center justify-center gap-1.5 cursor-pointer ${
                    formData.category === 'দোকান' ? 'bg-[#16a34a] hover:bg-[#15803d]' : 'bg-[#1d4ed8] hover:bg-[#1e40af]'
                  }`}
                >
                  <Check className="w-4 h-4 stroke-[2.5]" />
                  <span>
                    {formData.category === 'দোকান' ? 'দোকানের হিসাব সংরক্ষণ করুন' : 'ব্যক্তিগত হিসাব সংরক্ষণ করুন'}
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: হিসাব এডিট ও ডিলিট (Edit/Delete Row Modal)                       */}
      {/* ========================================================================= */}
      {editingTrx && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center z-50 p-0 sm:p-4 animate-fadeIn">
          <div className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
                  <Edit2 className="w-4 h-4" />
                </div>
                <h3 className="text-base font-black text-slate-900">হিসাব এডিট বা ডিলিট</h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingTrx(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleUpdateTransactionSubmit} className="mt-4 space-y-3.5 text-xs font-bold">
              {/* Category selector */}
              <div>
                <label className="text-slate-600 block mb-1">ক্যাটাগরি</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, category: 'দোকান' })}
                    className={`py-2 rounded-xl flex items-center justify-center gap-1.5 text-xs font-black border transition-all cursor-pointer ${
                      formData.category === 'দোকান'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    <Store className="w-3.5 h-3.5" />
                    <span>দোকান</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, category: 'ব্যক্তিগত' })}
                    className={`py-2 rounded-xl flex items-center justify-center gap-1.5 text-xs font-black border transition-all cursor-pointer ${
                      formData.category === 'ব্যক্তিগত'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    <User className="w-3.5 h-3.5" />
                    <span>ব্যক্তিগত</span>
                  </button>
                </div>
              </div>

              {formData.category === 'দোকান' ? (
                <div className="space-y-3 animate-fadeIn">
                  {/* হুবহু ব্যবহারকারীর ছবি অনুসারে লাল বর্ডারের ৩ কলাম ৪ সারির ইনপুট গ্রিড */}
                  <div className="border-2 border-red-500 rounded-2xl p-3 bg-white shadow-sm space-y-2.5">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                      {/* ROW 1 */}
                      {/* Row 1, Col 1: তারিখ */}
                      <div className="bg-red-50/40 p-2 rounded-xl border border-red-200">
                        <label className="text-red-900 text-[11px] font-black block mb-0.5">তারিখ:</label>
                        <input
                          type="text"
                          required
                          value={formData.date}
                          onChange={(e) => handleDateChangeForModal(e.target.value)}
                          placeholder="১৭/৯/২০২৬"
                          className="w-full p-2 bg-white border border-red-300 rounded-lg text-xs font-black text-slate-900 outline-hidden focus:ring-2 focus:ring-red-400"
                        />
                      </div>

                      {/* Row 1, Col 2: বার */}
                      <div className="bg-red-50/40 p-2 rounded-xl border border-red-200">
                        <label className="text-red-900 text-[11px] font-black block mb-0.5">বার :</label>
                        <select
                          value={formData.dayOfWeek}
                          onChange={(e) => setFormData({ ...formData, dayOfWeek: e.target.value })}
                          className="w-full p-2 bg-white border border-red-300 rounded-lg text-xs font-black text-slate-900 outline-hidden focus:ring-2 focus:ring-red-400"
                        >
                          {daysList.map((d) => (
                            <option key={d} value={d}>
                              {d}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Row 1, Col 3: হিসাবের ধরণ */}
                      <div className="bg-red-50/40 p-2 rounded-xl border border-red-200 flex flex-col justify-center">
                        <label className="text-red-900 text-[11px] font-black block mb-0.5">হিসাবের ধরণ:</label>
                        <div className="grid grid-cols-2 gap-1 w-full">
                          <button
                            type="button"
                            onClick={() => setFormData({ ...formData, category: 'দোকান' })}
                            className={`py-1 px-1.5 rounded-lg text-[11px] font-black transition-all cursor-pointer ${
                              formData.category === 'দোকান'
                                ? 'bg-[#16a34a] text-white shadow-2xs'
                                : 'bg-white text-slate-700 border border-slate-200'
                            }`}
                          >
                            দোকান
                          </button>
                          <button
                            type="button"
                            onClick={() => setFormData({ ...formData, category: 'ব্যক্তিগত' })}
                            className={`py-1 px-1.5 rounded-lg text-[11px] font-black transition-all cursor-pointer ${
                              formData.category === 'ব্যক্তিগত'
                                ? 'bg-[#1d4ed8] text-white shadow-2xs'
                                : 'bg-white text-slate-700 border border-slate-200'
                            }`}
                          >
                            ব্যক্তিগত
                          </button>
                        </div>
                      </div>

                      {/* ROW 2 */}
                      {/* Row 2, Col 1: কেনা */}
                      <div className="bg-red-50/60 p-2 rounded-xl border border-red-300">
                        <label className="text-red-900 text-[11px] font-black block mb-0.5">কেনা: (৳) *</label>
                        <input
                          type="text"
                          inputMode="numeric"
                          required
                          value={formData.buyPrice}
                          onChange={(e) => handleBuyPriceChange(e.target.value)}
                          placeholder="500"
                          className="w-full p-2 bg-white border border-red-300 text-red-700 rounded-lg text-xs sm:text-sm font-black outline-hidden focus:ring-2 focus:ring-red-400"
                        />
                      </div>

                      {/* Row 2, Col 2: বিক্রি */}
                      <div className="bg-amber-50/60 p-2 rounded-xl border border-amber-300">
                        <label className="text-amber-950 text-[11px] font-black block mb-0.5">বিক্রি: (৳)</label>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={formData.sellPrice}
                          onChange={(e) => handleSellPriceChange(e.target.value)}
                          placeholder="550"
                          className="w-full p-2 bg-white border border-amber-400 text-amber-950 rounded-lg text-xs sm:text-sm font-black outline-hidden focus:ring-2 focus:ring-amber-400"
                        />
                      </div>

                      {/* Row 2, Col 3: জমা */}
                      <div className="bg-emerald-50/60 p-2 rounded-xl border border-emerald-300">
                        <label className="text-emerald-950 text-[11px] font-black block mb-0.5">জমা: (৳)</label>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={formData.depositAmount}
                          onChange={(e) => handleDepositAmountChange(e.target.value)}
                          placeholder="যেমন: 550 বা খালি"
                          className="w-full p-2 bg-white border border-emerald-300 text-emerald-700 rounded-lg text-xs sm:text-sm font-black outline-hidden focus:ring-2 focus:ring-emerald-400"
                        />
                      </div>

                      {/* ROW 3 */}
                      {/* Row 3, Col 1: লাভ */}
                      <div className="bg-slate-50 p-2 rounded-xl border border-slate-200 flex flex-col justify-center text-center">
                        <span className="text-[10px] text-slate-500 font-bold block">লাভ (বিক্রি − কেনা)</span>
                        <span className="text-xs font-black text-amber-700 mt-0.5">
                          {(() => {
                            const b = parseBengaliOrEnglishNumber(formData.buyPrice);
                            const s = parseBengaliOrEnglishNumber(formData.sellPrice);
                            const profit = s > b ? s - b : 0;
                            return profit > 0 ? `${toBengaliDigits(profit)}৳ লাভ` : '০৳';
                          })()}
                        </span>
                      </div>

                      {/* Row 3, Col 2: ক্যাশ/C */}
                      <div className="bg-blue-50/60 p-2 rounded-xl border border-blue-300">
                        <label className="text-blue-900 text-[11px] font-black block mb-0.5">ক্যাশ/C :</label>
                        <input
                          type="text"
                          value={formData.commissionTag}
                          onChange={(e) => handleCommissionTagChange(e.target.value)}
                          placeholder="50 C"
                          className="w-full p-2 bg-white border border-blue-300 text-blue-900 rounded-lg text-xs sm:text-sm font-black outline-hidden focus:ring-2 focus:ring-blue-400"
                        />
                      </div>

                      {/* Row 3, Col 3: বাকি */}
                      <div className="bg-rose-50/60 p-2 rounded-xl border border-rose-300">
                        <label className="text-rose-900 text-[11px] font-black block mb-0.5">বাকি: (৳)</label>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={formData.dueAmount}
                          onChange={(e) => handleDueAmountChange(e.target.value)}
                          placeholder="550"
                          className="w-full p-2 bg-white border border-rose-300 text-rose-800 rounded-lg text-xs sm:text-sm font-black outline-hidden focus:ring-2 focus:ring-rose-400"
                        />
                      </div>

                      {/* ROW 4 */}
                      {/* Row 4, Col 1: পণ্যের নাম */}
                      <div className="bg-purple-50/60 p-2 rounded-xl border border-purple-200">
                        <label className="text-purple-900 text-[11px] font-black block mb-0.5">পণ্যের নাম: *</label>
                        <input
                          type="text"
                          required
                          value={formData.itemName}
                          onChange={(e) => setFormData({ ...formData, itemName: e.target.value })}
                          placeholder="অফার"
                          className="w-full p-2 bg-white border border-purple-300 text-purple-950 rounded-lg text-xs font-black outline-hidden focus:ring-2 focus:ring-purple-400"
                        />
                      </div>

                      {/* Row 4, Col 2: বিবরণ */}
                      <div className="bg-purple-50/60 p-2 rounded-xl border border-purple-200">
                        <label className="text-purple-900 text-[11px] font-black block mb-0.5">বিবরণ:</label>
                        <input
                          type="text"
                          value={formData.quantity}
                          onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                          placeholder="999 বা 50+1500"
                          className="w-full p-2 bg-white border border-purple-300 text-purple-950 rounded-lg text-xs font-black outline-hidden focus:ring-2 focus:ring-purple-400"
                        />
                      </div>

                      {/* Row 4, Col 3: বাকি ✓ */}
                      <div className={`p-2 rounded-xl border flex flex-col justify-center ${parseBengaliOrEnglishNumber(formData.dueAmount) > 0 ? 'bg-rose-50/80 border-rose-300' : 'bg-emerald-50/80 border-emerald-300'}`}>
                        <label className="text-slate-800 text-[11px] font-black block mb-0.5">বাকি স্ট্যাটাস:</label>
                        <button
                          type="button"
                          onClick={handleToggleDueCheckbox}
                          className={`w-full py-1.5 px-2 rounded-lg text-xs font-black flex items-center justify-center gap-1 cursor-pointer transition-all shadow-2xs ${
                            parseBengaliOrEnglishNumber(formData.dueAmount) > 0
                              ? 'bg-[#dc2626] hover:bg-red-700 text-white'
                              : 'bg-[#16a34a] hover:bg-emerald-700 text-white'
                          }`}
                        >
                          {parseBengaliOrEnglishNumber(formData.dueAmount) > 0 ? (
                            <span>বাকি ✓</span>
                          ) : (
                            <span>✓ পরিশোধ</span>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <>
                  {/* 1. তারিখ ও বার */}
                  <div className="bg-blue-50/60 p-2.5 rounded-xl border border-blue-200 space-y-2">
                    <label className="text-blue-900 font-black flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-blue-600" />
                      তারিখ ও বার
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        required
                        value={formData.date}
                        onChange={(e) => handleDateChangeForModal(e.target.value)}
                        className="w-full p-2 bg-white border border-blue-300 rounded-lg outline-hidden text-xs font-black text-blue-950"
                      />
                      <select
                        value={formData.dayOfWeek}
                        onChange={(e) => setFormData({ ...formData, dayOfWeek: e.target.value })}
                        className="w-full p-2 bg-white border border-blue-300 rounded-lg outline-hidden text-xs font-black text-blue-950"
                      >
                        {daysList.map((d) => (
                          <option key={d} value={d}>
                            {d}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* 2. বিবরণ ও প্যাক */}
                  <div className="bg-purple-50/60 p-2.5 rounded-xl border border-purple-200 space-y-2">
                    <label className="text-purple-900 font-black flex items-center gap-1">
                      <Tag className="w-3.5 h-3.5 text-purple-600" />
                      বিবরণ ও প্যাক/পরিমাণ
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        required
                        value={formData.itemName}
                        onChange={(e) => setFormData({ ...formData, itemName: e.target.value })}
                        className="w-full p-2 bg-white border border-purple-300 rounded-lg outline-hidden text-xs font-black text-purple-950"
                      />
                      <input
                        type="text"
                        value={formData.quantity}
                        onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                        className="w-full p-2 bg-white border border-purple-300 rounded-lg outline-hidden text-xs font-bold text-purple-950"
                      />
                    </div>
                  </div>

                  {/* ব্যক্তিগত খরচ, জমা ও বাকি (খরচ = জমা + বাকি) */}
                  <div className="bg-slate-50/90 p-2.5 rounded-xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-slate-800 font-black text-xs flex items-center gap-1">
                        <Banknote className="w-3.5 h-3.5 text-emerald-700" />
                        ব্যক্তিগত খরচ, জমা ও বাকি
                      </label>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={handleSetFullCashDeposit}
                          className="px-2 py-0.5 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-black cursor-pointer shadow-2xs transition-colors"
                        >
                          ✓ সম্পূর্ণ পরিশোধ
                        </button>
                        <button
                          type="button"
                          onClick={handleSetFullDue}
                          className="px-2 py-0.5 rounded-md bg-orange-600 hover:bg-orange-700 text-white text-[10px] font-black cursor-pointer shadow-2xs transition-colors"
                        >
                          বাকি রাখা
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      {/* খরচ */}
                      <div className="bg-red-50/70 p-2 rounded-xl border border-red-200">
                        <label className="text-red-700 block mb-0.5 font-black text-[11px] flex items-center gap-1">
                          <Receipt className="w-3 h-3" />
                          খরচ / ব্যয় (৳) *
                        </label>
                        <input
                          type="text"
                          inputMode="numeric"
                          required
                          value={formData.buyPrice}
                          onChange={(e) => handleBuyPriceChange(e.target.value)}
                          placeholder="যেমন: ৫০০"
                          className="w-full p-2 bg-white border border-red-300 text-red-700 rounded-lg outline-hidden text-xs sm:text-sm font-black focus:ring-2 focus:ring-red-400"
                        />
                      </div>

                      {/* জমা */}
                      <div className="bg-emerald-50/70 p-2 rounded-xl border border-emerald-200">
                        <label className="text-emerald-700 block mb-0.5 font-black text-[11px] flex items-center gap-1">
                          <Banknote className="w-3 h-3" />
                          জমা / পরিশোধ (৳)
                        </label>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={formData.depositAmount}
                          onChange={(e) => handleDepositAmountChange(e.target.value)}
                          placeholder="যেমন: ৪০০"
                          className="w-full p-2 bg-white border border-emerald-300 text-emerald-700 rounded-lg outline-hidden text-xs sm:text-sm font-black focus:ring-2 focus:ring-emerald-400"
                        />
                      </div>

                      {/* বাকি */}
                      <div className="bg-orange-50/70 p-2 rounded-xl border border-orange-200">
                        <label className="text-orange-700 block mb-0.5 font-black text-[11px] flex items-center gap-1">
                          <Coins className="w-3 h-3" />
                          বাকি (৳)
                        </label>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={formData.dueAmount}
                          onChange={(e) => handleDueAmountChange(e.target.value)}
                          placeholder="যেমন: ১০০"
                          className="w-full p-2 bg-white border border-orange-300 text-orange-800 rounded-lg outline-hidden text-xs sm:text-sm font-black focus:ring-2 focus:ring-orange-400"
                        />
                      </div>
                    </div>

                    <div className="bg-white/80 p-1.5 rounded-lg border border-slate-200 text-[10px] font-bold text-slate-700 flex items-center justify-between">
                      <span>💡 সমীকরণ: <strong>খরচ ({toBengaliDigits(parseBengaliOrEnglishNumber(formData.buyPrice))}৳) = জমা ({toBengaliDigits(parseBengaliOrEnglishNumber(formData.depositAmount))}৳) + বাকি ({toBengaliDigits(parseBengaliOrEnglishNumber(formData.dueAmount))}৳)</strong></span>
                    </div>
                  </div>
                </>
              )}

              {/* 4-Card Live Calculation Preview in Edit Modal */}
              {(() => {
                const pBuy = parseBengaliOrEnglishNumber(formData.buyPrice);
                const pDeposit = parseBengaliOrEnglishNumber(formData.depositAmount);
                const isPers = formData.category === 'ব্যক্তিগত';
                const pSell = isPers ? pBuy : (parseBengaliOrEnglishNumber(formData.sellPrice) || pBuy);
                let pComm = 0;
                if (!isPers) {
                  const match = formData.commissionTag.match(/[\d০-৯]+/);
                  if (match) {
                    pComm = parseBengaliOrEnglishNumber(match[0]);
                  } else if (pSell > pBuy) {
                    pComm = pSell - pBuy;
                  }
                }
                const pDue = formData.dueAmount !== ''
                  ? parseBengaliOrEnglishNumber(formData.dueAmount)
                  : Math.max(0, pSell - pDeposit);

                return (
                  <div className="p-2.5 bg-slate-900 text-white rounded-xl border border-slate-700 shadow-md space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] font-black border-b border-slate-800 pb-1 text-slate-300">
                      <span className="flex items-center gap-1 text-amber-300">
                        <Scale className="w-3.5 h-3.5" />
                        হিসাব প্রিভিউ:
                      </span>
                      {!isPers && pSell > 0 && (
                        <span className="text-emerald-400 font-mono text-[10px] bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-700/50">
                          বিক্রি: {toBengaliDigits(pSell)}৳
                        </span>
                      )}
                    </div>
                    <div className="grid grid-cols-4 gap-1.5 text-center font-black pt-0.5">
                      <div className="bg-[#dc2626] rounded-lg py-1 px-0.5 border border-red-400/40">
                        <span className="text-[9px] text-red-100 block">খরচ</span>
                        <span className="text-white text-xs">{toBengaliDigits(pBuy)}৳</span>
                      </div>
                      <div className="bg-[#16a34a] rounded-lg py-1 px-0.5 border border-emerald-400/40">
                        <span className="text-[9px] text-emerald-100 block">জমা</span>
                        <span className="text-white text-xs">{toBengaliDigits(pDeposit)}৳</span>
                      </div>
                      <div className="bg-[#ea580c] rounded-lg py-1 px-0.5 border border-amber-400/40">
                        <span className="text-[9px] text-amber-100 block">বাকি</span>
                        <span className="text-white text-xs">{toBengaliDigits(pDue)}৳</span>
                      </div>
                      <div className="bg-[#7c3aed] rounded-lg py-1 px-0.5 border border-purple-400/40">
                        <span className="text-[9px] text-purple-100 block">কমিশন</span>
                        <span className="text-white text-xs">{toBengaliDigits(pComm)}৳</span>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Actions: Delete & Update */}
              <div className="pt-2 grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setIsDeleteConfirmOpen(true)}
                  className="py-2.5 rounded-xl bg-red-100 hover:bg-red-200 text-red-700 font-black text-xs flex items-center justify-center gap-1 cursor-pointer transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>ডিলিট করুন</span>
                </button>
                <button
                  type="submit"
                  className="py-2.5 rounded-xl bg-[#1d4ed8] hover:bg-[#1e40af] text-white font-black text-xs flex items-center justify-center gap-1 shadow-md cursor-pointer transition-colors"
                >
                  <Check className="w-4 h-4 stroke-[2.5]" />
                  <span>আপডেট করুন</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: ডিলিট নিশ্চিতকরণ ডায়ালগ                                        */}
      {/* ========================================================================= */}
      {isDeleteConfirmOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center z-60 p-4 animate-fadeIn">
          <div className="w-full max-w-xs bg-white rounded-2xl p-5 shadow-2xl border border-red-200 text-center">
            <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto mb-3">
              <Trash2 className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-black text-slate-900">হিসাব মুছে ফেলতে চান?</h4>
            <p className="text-xs text-slate-600 mt-1 mb-4">
              "{editingTrx?.itemName}" এন্ট্রিটি স্থায়ীভাবে মুছে ফেলা হবে।
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setIsDeleteConfirmOpen(false)}
                className="py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black shadow-xs cursor-pointer"
              >
                হ্যাঁ, মুছুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: ফিল্টার ডায়ালগ                                                   */}
      {/* ========================================================================= */}
      {isFilterModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center z-50 p-0 sm:p-4 animate-fadeIn">
          <div className="w-full sm:max-w-sm bg-white rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-blue-600" />
                <span>তারিখ ও হিসাব ফিল্টার</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsFilterModalOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs font-bold">
              <div>
                <span className="text-slate-600 block mb-1.5">সময়কাল নির্বাচন করুন</span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setMonthFilter('all');
                      setIsFilterModalOpen(false);
                      showToast('সকল মাসের মোট হিসাব দেখানো হচ্ছে');
                    }}
                    className={`py-2 rounded-xl border text-center transition-all cursor-pointer ${
                      monthFilter === 'all'
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    সকল মাস
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      handleResetCurrentMonth();
                      setIsFilterModalOpen(false);
                      showToast('চলতি মাসের হিসাব দেখানো হচ্ছে');
                    }}
                    className={`py-2 rounded-xl border text-center transition-all cursor-pointer ${
                      monthFilter === 'current'
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    চলতি মাস
                  </button>
                </div>
              </div>

              <div>
                <span className="text-slate-600 block mb-1.5">হিসাবের ধরন</span>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setActiveCategory('all');
                      setIsFilterModalOpen(false);
                    }}
                    className={`py-1.5 rounded-lg border text-center cursor-pointer ${
                      activeCategory === 'all'
                        ? 'bg-slate-900 text-white border-slate-900'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    সকল
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveCategory('shop');
                      setIsFilterModalOpen(false);
                    }}
                    className={`py-1.5 rounded-lg border text-center cursor-pointer ${
                      activeCategory === 'shop'
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    দোকান
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveCategory('personal');
                      setIsFilterModalOpen(false);
                    }}
                    className={`py-1.5 rounded-lg border text-center cursor-pointer ${
                      activeCategory === 'personal'
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    ব্যক্তিগত
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: শেয়ার ও প্রিন্ট রিপোর্ট (মোবাইল স্ক্রিন ভিউ ও মাল্টি-পেজ সিস্টেম)  */}
      {/* ========================================================================= */}
      {isShareModalOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-end sm:items-center justify-center z-50 p-0 sm:p-4 animate-fadeIn">
          <div className="w-full sm:max-w-2xl bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 max-h-[92vh] flex flex-col overflow-hidden">
            {/* Modal Header */}
            <div className="p-3.5 sm:p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50 shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700">
                  <Share2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-black text-slate-900 leading-tight">
                    টালি খাতা হিসাব শেয়ার ও প্রিন্ট
                  </h3>
                  <p className="text-[11px] text-slate-500 font-bold">
                    ১ তারিখ থেকে ৩১ তারিখের সম্পূর্ণ মোবাইল ভিউ রিপোর্ট
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsShareModalOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-200/80 hover:bg-slate-300 flex items-center justify-center text-slate-700 cursor-pointer transition-colors"
                title="বন্ধ করুন"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Controls Bar: Sort order & Pages */}
            <div className="px-3.5 py-2.5 bg-slate-100/90 border-b border-slate-200 flex items-center justify-between flex-wrap gap-2 shrink-0">
              {/* Left: 1 to 31 date sort toggle */}
              <button
                type="button"
                onClick={() => setShareSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-white border border-slate-300 hover:border-blue-400 text-slate-800 text-xs font-black shadow-2xs transition-colors cursor-pointer"
                title="তারিখের ক্রম পরিবর্তন করুন"
              >
                <ArrowUpDown className="w-3.5 h-3.5 text-blue-600" />
                <span>{shareSortOrder === 'asc' ? '১ থেকে ৩১ তারিখ ক্রম' : '৩১ থেকে ১ তারিখ ক্রম'}</span>
              </button>

              {/* Right: Summary badge */}
              <div className="text-[11px] font-black text-slate-600 flex items-center gap-1.5">
                <span className="bg-white px-2 py-1 rounded-lg border border-slate-200">
                  মোট {toBengaliDigits(shareTransactions.length)}টি হিসাব
                </span>
                <span className="bg-blue-100 text-blue-900 px-2 py-1 rounded-lg border border-blue-200">
                  {toBengaliDigits(reportPages.length)}টি পেজে বিভক্ত
                </span>
              </div>
            </div>

            {/* Page Navigation Tabs (When multiple pages exist) */}
            <div className="px-3.5 py-2 bg-slate-50 border-b border-slate-200 flex items-center gap-1.5 overflow-x-auto no-scrollbar shrink-0">
              <span className="text-xs font-black text-slate-500 shrink-0 mr-1 flex items-center gap-1">
                <Layers className="w-3.5 h-3.5 text-slate-500" />
                পেজ:
              </span>
              {reportPages.map((pg) => (
                <button
                  key={`tab-page-${pg.pageNumber}`}
                  type="button"
                  onClick={() => setShareActivePage(pg.pageNumber)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer shrink-0 flex items-center gap-1 ${
                    shareActivePage === pg.pageNumber
                      ? 'bg-[#0d2847] text-white shadow-xs'
                      : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <span>পৃষ্ঠা {toBengaliDigits(pg.pageNumber)}</span>
                </button>
              ))}
              {reportPages.length > 1 && (
                <button
                  type="button"
                  onClick={() => setShareActivePage('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer shrink-0 flex items-center gap-1 ${
                    shareActivePage === 'all'
                      ? 'bg-[#0d2847] text-white shadow-xs'
                      : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <span>সব পৃষ্ঠা একসাথে ({toBengaliDigits(reportPages.length)})</span>
                </button>
              )}
            </div>

            {/* Mobile View Preview Container */}
            <div className="flex-1 overflow-y-auto p-3 sm:p-4 bg-slate-200/70 space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-2.5 text-center text-xs font-bold text-blue-900 flex items-center justify-center gap-2">
                <span className="text-base">💡</span>
                <span>
                  <strong>সরাসরি ফাইল ডাউনলোড করতে:</strong> নিচের লাল <strong>"PDF ডাউনলোড"</strong> বাটনে চাপ দিন। আপনার ডিভাইসে সরাসরি <strong>.pdf</strong> ফাইল সেভ হবে।
                </span>
              </div>

              {shareActivePage === 'all' ? (
                // Render all pages stacked
                reportPages.map((page) => (
                  <div key={`all-preview-page-${page.pageNumber}`} className="space-y-1">
                    {renderReportPageCard(page, false)}
                    {page.pageNumber < reportPages.length && (
                      <div className="text-center py-2 flex items-center justify-center gap-2 text-slate-500 text-xs font-bold">
                        <div className="h-px bg-slate-300 flex-1" />
                        <span>পরবর্তী পৃষ্ঠা ({toBengaliDigits(page.pageNumber + 1)}) নিচে ↓</span>
                        <div className="h-px bg-slate-300 flex-1" />
                      </div>
                    )}
                  </div>
                ))
              ) : (
                // Render single selected page
                (() => {
                  const targetPage = reportPages.find(p => p.pageNumber === shareActivePage) || reportPages[0];
                  return (
                    <div>
                      {renderReportPageCard(targetPage, false)}
                      {reportPages.length > 1 && (
                        <div className="mt-3 flex items-center justify-between text-xs font-black text-slate-700">
                          <button
                            type="button"
                            disabled={targetPage.pageNumber === 1}
                            onClick={() => setShareActivePage(prev => typeof prev === 'number' && prev > 1 ? prev - 1 : 1)}
                            className="px-3 py-1.5 rounded-xl bg-white border border-slate-300 shadow-2xs hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer flex items-center gap-1"
                          >
                            <ChevronLeft className="w-3.5 h-3.5" />
                            <span>পূর্ববর্তী পৃষ্ঠা</span>
                          </button>
                          <span>
                            পৃষ্ঠা {toBengaliDigits(targetPage.pageNumber)} এর {toBengaliDigits(targetPage.totalPages)}
                          </span>
                          <button
                            type="button"
                            disabled={targetPage.pageNumber === reportPages.length}
                            onClick={() => setShareActivePage(prev => typeof prev === 'number' && prev < reportPages.length ? prev + 1 : reportPages.length)}
                            className="px-3 py-1.5 rounded-xl bg-white border border-slate-300 shadow-2xs hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer flex items-center gap-1"
                          >
                            <span>পরবর্তী পৃষ্ঠা</span>
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })()
              )}
            </div>

            {/* Modal Actions Footer */}
            <div className="p-3 sm:p-4 bg-white border-t border-slate-200 grid grid-cols-2 sm:grid-cols-5 gap-2 shrink-0">
              {/* Action 1: Direct PDF Download */}
              <button
                type="button"
                disabled={isDownloadingPdf}
                onClick={handleDownloadPdf}
                className="py-2.5 px-2 rounded-xl bg-red-600 hover:bg-red-700 disabled:bg-red-400 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                title="সরাসরি PDF ফাইল হিসেবে আপনার ফোনে/কম্পিউটারে ডাউনলোড করুন"
              >
                {isDownloadingPdf ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin shrink-0" />
                    <span>প্রস্তুত হচ্ছে...</span>
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 shrink-0" />
                    <span>PDF ডাউনলোড</span>
                  </>
                )}
              </button>

              {/* Action 2: WhatsApp Share */}
              <button
                type="button"
                onClick={handleWhatsAppShare}
                className="py-2.5 px-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                title="হোয়াটসঅ্যাপে সম্পূর্ণ ১-৩১ তারিখের রিপোর্ট পাঠান"
              >
                <MessageCircle className="w-4 h-4 shrink-0" />
                <span>হোয়াটসঅ্যাপ</span>
              </button>

              {/* Action 3: Print / Browser PDF Save */}
              <button
                type="button"
                onClick={handlePrintPdf}
                className="py-2.5 px-2 rounded-xl bg-[#0d2847] hover:bg-[#133863] text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                title="ব্রাউজারের প্রিন্ট ডায়ালগ দিয়ে প্রিন্ট বা সেভ করুন"
              >
                <Printer className="w-4 h-4 shrink-0" />
                <span>প্রিন্ট করুন</span>
              </button>

              {/* Action 4: Copy Text */}
              <button
                type="button"
                onClick={handleCopyReport}
                className="py-2.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                title="রিপোর্ট টেক্সট ক্লিপবোর্ডে কপি করুন"
              >
                <Copy className="w-4 h-4 shrink-0" />
                <span>কপি করুন</span>
              </button>

              {/* Action 5: Native Share */}
              <button
                type="button"
                onClick={handleNativeShare}
                className="py-2.5 px-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer col-span-2 sm:col-span-1"
                title="ডিভাইসের মাধ্যমে সরাসরি শেয়ার করুন"
              >
                <Share2 className="w-4 h-4 shrink-0" />
                <span>শেয়ার</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 6: C (কমিশন / লাভ) এর বিস্তারিত তালিকা মোডাল                         */}
      {/* ========================================================================= */}
      {isCommissionModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center z-50 p-0 sm:p-4 animate-fadeIn">
          <div className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 shrink-0">
              <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>কমিশন ও মোট লাভের হিসাব (C)</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsCommissionModalOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 cursor-pointer hover:bg-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Summary Top Banner in Modal */}
            <div className="mt-3 bg-linear-to-r from-amber-500 to-amber-600 text-white p-3.5 rounded-2xl shadow-sm shrink-0 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold text-amber-100 block">সর্বমোট লাভ (C কমিশন)</span>
                <span className="text-xl font-black tracking-tight">
                  = {toBengaliDigits(totalCommission)} ৳
                </span>
              </div>
              <div className="bg-white/20 backdrop-blur-xs px-3 py-1.5 rounded-xl text-center">
                <span className="text-[10px] font-bold block text-amber-100">মোট আইটেম</span>
                <span className="text-xs font-black">{toBengaliDigits(commissionDetails.length)}টি</span>
              </div>
            </div>

            {/* Formula tags string */}
            {commissionTagsList.length > 0 && (
              <div className="mt-2.5 p-2 bg-amber-50 border border-amber-200 rounded-xl text-center shrink-0">
                <span className="text-[10px] text-amber-800 font-bold block mb-0.5">সবগুলো C একসাথে যোগফল:</span>
                <span className="text-xs font-mono font-black text-amber-950 break-words">
                  {commissionTagsList.join(' + ')} = {totalCommission} ৳
                </span>
              </div>
            )}

            {/* Itemized list of commissions */}
            <div className="mt-3 flex-1 overflow-y-auto space-y-2 pr-1 divide-y divide-slate-100">
              {commissionDetails.length === 0 ? (
                <div className="py-8 text-center text-slate-400 text-xs">
                  কোনো C কমিশন বা লাভ এন্ট্রি পাওয়া যায়নি
                </div>
              ) : (
                commissionDetails.map((item, idx) => (
                  <div key={idx} className="pt-2 flex items-center justify-between text-xs">
                    <div>
                      <p className="font-bold text-slate-800">{item.itemName}</p>
                      <p className="text-[10px] text-slate-500">{item.date}</p>
                    </div>
                    <div className="text-right">
                      <span className="px-2 py-0.5 bg-amber-100 text-amber-900 font-mono font-black rounded-md text-[11px]">
                        {item.tag}
                      </span>
                      <p className="text-[11px] font-black text-emerald-700 mt-0.5">
                        = {toBengaliDigits(item.amount)} ৳
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Close Button */}
            <div className="mt-4 pt-3 border-t border-slate-100 shrink-0">
              <button
                type="button"
                onClick={() => setIsCommissionModalOpen(false)}
                className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-black text-xs shadow-xs cursor-pointer"
              >
                ঠিক আছে বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* PRINT-ONLY MULTI-PAGE CONTAINER (Only rendered during window.print())     */}
      {/* ========================================================================= */}
      <div id="tally-print-root" className="hidden print:block space-y-6">
        {reportPages.map((page) => renderReportPageCard(page, true))}
      </div>
    </div>
  );
};

export default TallyHubView;
