import React from 'react';
import {
  TallyKhataLogo,
  DriveOfferSimsLogo,
  AddMoneyServiceLogo,
  MobileRechargeServiceLogo,
} from './ServiceLogos';

export type ServiceKey =
  | 'add_money'
  | 'recharge'
  | 'drive'
  | 'tally';

interface ServicesGridProps {
  onSelectService: (serviceKey: ServiceKey) => void;
  language?: 'bn' | 'en';
}

export const ServicesGrid: React.FC<ServicesGridProps> = ({
  onSelectService,
  language = 'bn',
}) => {
  const isBangla = language !== 'en';

  const services = [
    {
      id: 'service-add-money',
      key: 'add_money' as const,
      name: isBangla ? 'অ্যাড মানি' : 'Add Money',
      LogoComponent: AddMoneyServiceLogo,
    },
    {
      id: 'service-recharge',
      key: 'recharge' as const,
      name: isBangla ? 'মোবাইল রিচার্জ' : 'Recharge',
      LogoComponent: MobileRechargeServiceLogo,
    },
    {
      id: 'service-drive',
      key: 'drive' as const,
      name: isBangla ? 'ড্রাইভ অফার' : 'Drive Offers',
      LogoComponent: DriveOfferSimsLogo,
    },
    {
      id: 'service-tally',
      key: 'tally' as const,
      name: isBangla ? 'টালি খাতা' : 'Tally Khata',
      LogoComponent: TallyKhataLogo,
    },
  ];

  return (
    <div className="px-4 py-3">
      {/* Title */}
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-black text-slate-950 tracking-tight">
          {isBangla ? 'সার্ভিস সমূহ' : 'Our Services'}
        </h2>
        <span className="text-xs font-black text-orange-800 bg-orange-100 px-2.5 py-1 rounded-full border border-orange-300 shadow-2xs">
          {isBangla ? 'টেলিকম ও হিসাব সেবা' : 'Telecom & Ledger'}
        </span>
      </div>

      {/* Grid container - 4 columns on mobile with crisp contrast and bold labels */}
      <div className="grid grid-cols-4 gap-2">
        {services.map((item) => {
          const Logo = item.LogoComponent;
          return (
            <button
              key={item.key}
              id={item.id}
              type="button"
              onClick={() => onSelectService(item.key)}
              className="flex flex-col items-center justify-start text-center p-2 rounded-2xl bg-white border-2 border-slate-200/90 shadow-sm hover:shadow-md hover:border-indigo-400 active:scale-95 transition-all group cursor-pointer"
            >
              {/* Logo Container with crisp boundary */}
              <div
                className="w-13 h-13 sm:w-14 sm:h-14 rounded-2xl bg-slate-50/80 flex items-center justify-center p-1.5 shadow-xs border-2 border-slate-200 mb-1.5 transform group-hover:scale-105 transition-transform"
              >
                <Logo className="w-10 h-10 object-contain drop-shadow-xs" />
              </div>

              {/* Single Title: Shows clean readable title with no cut-off */}
              <span className="text-[11px] sm:text-xs font-black text-slate-900 leading-tight block w-full text-center px-0.5 min-h-[28px] flex items-center justify-center">
                {item.name}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};


