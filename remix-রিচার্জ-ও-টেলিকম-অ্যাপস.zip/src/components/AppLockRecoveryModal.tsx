import React, { useState } from 'react';
import {
  KeyRound,
  ShieldCheck,
  Check,
  X,
  Eye,
  EyeOff,
  Sparkles,
  Phone,
  Mail,
  Lock,
  Smartphone,
  AlertCircle,
} from 'lucide-react';
import { UserProfile } from '../types';

interface AppLockRecoveryModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onUpdateUser?: (updated: UserProfile) => void;
  onShowToast?: (msg: string) => void;
}

export const AppLockRecoveryModal: React.FC<AppLockRecoveryModalProps> = ({
  isOpen,
  onClose,
  user,
  onUpdateUser,
  onShowToast,
}) => {
  const [showCurrentPin, setShowCurrentPin] = useState(false);
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [showNewPin, setShowNewPin] = useState(false);
  const [recoveryEmailInput, setRecoveryEmailInput] = useState(user.email || '');
  const [isSuccessMessage, setIsSuccessMessage] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const currentPin = user.pin || '1234';

  const handleQuickResetDefault = () => {
    setNewPin('1234');
    setConfirmPin('1234');
    setErrorMessage('');
  };

  const handleSavePin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!newPin) {
      setErrorMessage('অনুগ্রহ করে নতুন ৪ সংখ্যার পিন প্রদান করুন!');
      return;
    }

    if (newPin.length < 4) {
      setErrorMessage('পিন কমপক্ষে ৪ সংখ্যার হতে হবে!');
      return;
    }

    if (newPin !== confirmPin) {
      setErrorMessage('নতুন পিন এবং নিশ্চিতকরণ পিন মিলছে না!');
      return;
    }

    const updatedUser: UserProfile = {
      ...user,
      pin: newPin,
      email: recoveryEmailInput.trim() || user.email,
    };

    if (onUpdateUser) {
      onUpdateUser(updatedUser);
    }

    setIsSuccessMessage(true);
    if (onShowToast) {
      onShowToast(`অ্যাপ লক পিন সফলভাবে আপডেট হয়েছে! নতুন পিন: ${newPin}`);
    }

    setTimeout(() => {
      setIsSuccessMessage(false);
      onClose();
    }, 1500);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn overflow-y-auto"
    >
      <div className="bg-white rounded-3xl w-full max-w-sm p-5 border border-amber-200 shadow-2xl space-y-4 my-auto relative">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center shadow-md shadow-amber-500/20">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900 leading-tight">
                অ্যাপ লক ও পিন রিকভারি
              </h3>
              <p className="text-[10px] text-slate-500 font-medium">
                হোম পেজ সিকিউরিটি ও পিন রিসেট সিস্টেম
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* User Account Verification Info */}
        <div className="p-3 bg-amber-50/70 rounded-2xl border border-amber-200/80 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-600 font-bold flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-amber-600" />
              রেজিস্টার্ড মোবাইল:
            </span>
            <span className="font-mono font-black text-slate-900 bg-white px-2 py-0.5 rounded-md border border-amber-200">
              {user.phone}
            </span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-600 font-bold flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-amber-600" />
              জিমেইল আইডি:
            </span>
            <span className="font-mono text-[11px] text-slate-800 bg-white px-2 py-0.5 rounded-md border border-amber-200 truncate max-w-[170px]">
              {user.email || 'সেট করা নেই'}
            </span>
          </div>

          {/* Current PIN Display */}
          <div className="pt-1.5 border-t border-amber-200/60 flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-slate-700 block">বর্তমান অ্যাপ লক পিন:</span>
              <span className="text-[10px] text-slate-500">লগইন বা লক খুলতে ব্যবহৃত</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="font-mono text-base font-black text-amber-900 bg-white px-2.5 py-0.5 rounded-lg border border-amber-300 tracking-wider">
                {showCurrentPin ? currentPin : '••••'}
              </span>
              <button
                type="button"
                onClick={() => setShowCurrentPin(!showCurrentPin)}
                className="p-1 rounded-md text-amber-700 hover:bg-amber-100 cursor-pointer"
                title={showCurrentPin ? 'পিন লুকান' : 'পিন দেখুন'}
              >
                {showCurrentPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Success Message Banner */}
        {isSuccessMessage && (
          <div className="p-2.5 bg-emerald-50 border border-emerald-300 rounded-xl text-xs font-bold text-emerald-800 flex items-center gap-2 animate-fadeIn">
            <Check className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>পিন সফলভাবে পরিবর্তন হয়েছে!</span>
          </div>
        )}

        {/* Error Message */}
        {errorMessage && (
          <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-xs font-bold text-rose-700 flex items-center gap-2 animate-fadeIn">
            <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* PIN Reset Form */}
        <form onSubmit={handleSavePin} className="space-y-3 text-xs">
          <div className="flex items-center justify-between">
            <label className="text-[11px] font-extrabold text-slate-800">
              নতুন পিন কোড সেট করুন:
            </label>
            <button
              type="button"
              onClick={handleQuickResetDefault}
              className="text-[10px] font-black text-indigo-700 hover:text-indigo-900 bg-indigo-50 hover:bg-indigo-100 px-2 py-0.5 rounded-md border border-indigo-200 cursor-pointer flex items-center gap-1"
            >
              <Sparkles className="w-3 h-3 text-indigo-500" />
              <span>১২৩৪ ডিফল্ট পিন</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <span className="text-[10px] text-slate-500 font-bold block mb-1">নতুন ৪-সংখ্যার পিন:</span>
              <div className="relative">
                <input
                  type={showNewPin ? 'text' : 'password'}
                  maxLength={6}
                  value={newPin}
                  onChange={(e) => setNewPin(e.target.value.replace(/[^0-9]/g, ''))}
                  placeholder="যেমন: 1234"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-center font-mono font-black text-sm text-slate-900 tracking-widest outline-none focus:border-amber-500 focus:bg-white"
                />
              </div>
            </div>

            <div>
              <span className="text-[10px] text-slate-500 font-bold block mb-1">পিন নিশ্চিত করুন:</span>
              <div className="relative">
                <input
                  type={showNewPin ? 'text' : 'password'}
                  maxLength={6}
                  value={confirmPin}
                  onChange={(e) => setConfirmPin(e.target.value.replace(/[^0-9]/g, ''))}
                  placeholder="পুনরায় লিখুন"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-center font-mono font-black text-sm text-slate-900 tracking-widest outline-none focus:border-amber-500 focus:bg-white"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end">
            <button
              type="button"
              onClick={() => setShowNewPin(!showNewPin)}
              className="text-[10px] font-semibold text-slate-500 hover:text-slate-700 flex items-center gap-1 cursor-pointer"
            >
              {showNewPin ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
              <span>{showNewPin ? 'পিন লুকান' : 'পিন দেখুন'}</span>
            </button>
          </div>

          {/* Optional Update Recovery Email */}
          <div>
            <label className="text-[10px] font-bold text-slate-600 block mb-1">
              রিকভারি জিমেইল আইডি (পিন ভুলে গেলে কাজে লাগবে):
            </label>
            <input
              type="email"
              value={recoveryEmailInput}
              onChange={(e) => setRecoveryEmailInput(e.target.value)}
              placeholder="user@gmail.com"
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs text-slate-900 outline-none focus:border-amber-500 focus:bg-white"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer transition-colors"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white text-xs font-black rounded-xl shadow-md flex items-center justify-center gap-1.5 cursor-pointer transition-all active:scale-98"
            >
              <Check className="w-4 h-4" />
              <span>পিন সেভ করুন</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
