import React, { useState, useEffect, useRef } from 'react';
import {
  Share2,
  Headphones,
  Save,
  CheckCircle2,
  PhoneCall,
  MessageCircle,
  Send,
  Youtube,
  Users,
  Smartphone,
  Globe,
  Bell,
  Sparkles,
  HelpCircle,
  MessageSquare,
} from 'lucide-react';
import { SocialCommunityLinks } from '../types';
import { cleanBDPhoneForDial } from '../utils';

interface AdminSocialSupportSectionProps {
  socialLinks: SocialCommunityLinks;
  onUpdateSocialLinks: (newLinks: SocialCommunityLinks) => void;
  currentNotice?: string;
  onUpdateNotice?: (notice: string) => void;
  onShowToast?: (msg: string) => void;
}

export const AdminSocialSupportSection: React.FC<AdminSocialSupportSectionProps> = ({
  socialLinks,
  onUpdateSocialLinks,
  currentNotice = '',
  onUpdateNotice,
  onShowToast,
}) => {
  // 1. Notice Title & Switch State
  const [noticeTitle, setNoticeTitle] = useState(
    socialLinks.noticeTitle || 'জরুরি নোটিশ'
  );
  const [noticeTitleEnabled, setNoticeTitleEnabled] = useState(
    socialLinks.noticeTitleEnabled !== false
  );
  const [marqueeNotice, setMarqueeNotice] = useState(currentNotice);

  // 2. Social Channels & Switches State
  const [waGroup, setWaGroup] = useState(socialLinks.whatsappGroup || '');
  const [waGroupEnabled, setWaGroupEnabled] = useState(
    socialLinks.whatsappGroupEnabled !== false
  );

  const [tgChannel, setTgChannel] = useState(socialLinks.telegramChannel || '');
  const [tgChannelEnabled, setTgChannelEnabled] = useState(
    socialLinks.telegramChannelEnabled !== false
  );

  const [ytChannel, setYtChannel] = useState(socialLinks.youtubeChannel || '');
  const [ytChannelEnabled, setYtChannelEnabled] = useState(
    socialLinks.youtubeChannelEnabled !== false
  );

  const [fbPage, setFbPage] = useState(socialLinks.facebookPage || '');
  const [fbPageEnabled, setFbPageEnabled] = useState(
    socialLinks.facebookPageEnabled !== false
  );

  // 3. Help Support Channels & Switches State
  const [supportPhone, setSupportPhone] = useState(
    socialLinks.supportPhone || ''
  );
  const [supportPhoneEnabled, setSupportPhoneEnabled] = useState(
    socialLinks.supportPhoneEnabled !== false
  );

  const [digitalChatUrl, setDigitalChatUrl] = useState(
    socialLinks.digitalChatUrl || ''
  );
  const [digitalChatEnabled, setDigitalChatEnabled] = useState(
    socialLinks.digitalChatEnabled !== false
  );

  const [waSupport, setWaSupport] = useState(
    socialLinks.whatsappSupportNumber || ''
  );
  const [waSupportEnabled, setWaSupportEnabled] = useState(
    socialLinks.whatsappSupportEnabled !== false
  );

  const [messengerId, setMessengerId] = useState(
    socialLinks.messengerId || ''
  );
  const [messengerEnabled, setMessengerEnabled] = useState(
    socialLinks.messengerEnabled !== false
  );

  const [imoNumber, setImoNumber] = useState(
    socialLinks.imoNumber || ''
  );
  const [imoEnabled, setImoEnabled] = useState(
    socialLinks.imoEnabled !== false
  );

  // Admin Contact Number & General Details
  const [adminContactNumber, setAdminContactNumber] = useState(
    socialLinks.adminContactNumber || ''
  );
  const [supportHours, setSupportHours] = useState(
    socialLinks.supportHours || 'সকাল ১০টা - রাত ১০টা (জরুরি সেবা ২৪/৭)'
  );
  const [emergencyNotice, setEmergencyNotice] = useState(
    socialLinks.emergencyNotice || ''
  );
  const [telegramSupport, setTelegramSupport] = useState(
    socialLinks.telegramSupport || ''
  );
  const [appDownloadUrl, setAppDownloadUrl] = useState(
    socialLinks.appDownloadUrl || ''
  );

  const [savedSuccess, setSavedSuccess] = useState(false);
  const isDirtyRef = useRef(false);

  // Sync inputs dynamically only when user isn't actively modifying
  useEffect(() => {
    if (!isDirtyRef.current) {
      if (currentNotice !== undefined) setMarqueeNotice(currentNotice);
      if (socialLinks.appDownloadUrl !== undefined) setAppDownloadUrl(socialLinks.appDownloadUrl || '');
      if (socialLinks.noticeTitle) setNoticeTitle(socialLinks.noticeTitle);
      setNoticeTitleEnabled(socialLinks.noticeTitleEnabled !== false);
      if (socialLinks.whatsappGroup !== undefined) setWaGroup(socialLinks.whatsappGroup || '');
      setWaGroupEnabled(socialLinks.whatsappGroupEnabled !== false);
      if (socialLinks.telegramChannel !== undefined) setTgChannel(socialLinks.telegramChannel || '');
      setTgChannelEnabled(socialLinks.telegramChannelEnabled !== false);
      if (socialLinks.youtubeChannel !== undefined) setYtChannel(socialLinks.youtubeChannel || '');
      setYtChannelEnabled(socialLinks.youtubeChannelEnabled !== false);
      if (socialLinks.facebookPage !== undefined) setFbPage(socialLinks.facebookPage || '');
      setFbPageEnabled(socialLinks.facebookPageEnabled !== false);
      if (socialLinks.supportPhone !== undefined) setSupportPhone(socialLinks.supportPhone || '');
      setSupportPhoneEnabled(socialLinks.supportPhoneEnabled !== false);
      if (socialLinks.digitalChatUrl !== undefined) setDigitalChatUrl(socialLinks.digitalChatUrl || '');
      setDigitalChatEnabled(socialLinks.digitalChatEnabled !== false);
      if (socialLinks.whatsappSupportNumber !== undefined) setWaSupport(socialLinks.whatsappSupportNumber || '');
      setWaSupportEnabled(socialLinks.whatsappSupportEnabled !== false);
      if (socialLinks.messengerId !== undefined) setMessengerId(socialLinks.messengerId || '');
      setMessengerEnabled(socialLinks.messengerEnabled !== false);
      if (socialLinks.imoNumber !== undefined) setImoNumber(socialLinks.imoNumber || '');
      setImoEnabled(socialLinks.imoEnabled !== false);
      if (socialLinks.adminContactNumber !== undefined) setAdminContactNumber(socialLinks.adminContactNumber || '');
      if (socialLinks.supportHours) setSupportHours(socialLinks.supportHours);
      if (socialLinks.emergencyNotice !== undefined) setEmergencyNotice(socialLinks.emergencyNotice || '');
      if (socialLinks.telegramSupport !== undefined) setTelegramSupport(socialLinks.telegramSupport || '');
    }
  }, [socialLinks, currentNotice]);

  const handlePhoneInputChange = (
    raw: string,
    setter: (val: string) => void
  ) => {
    isDirtyRef.current = true;
    let digits = raw.replace(/[^0-9]/g, '');
    if (digits.startsWith('880')) digits = digits.substring(3);
    else if (digits.startsWith('88')) digits = digits.substring(2);
    digits = digits.replace(/^0+/, '');
    const clean10 = digits.slice(0, 10);
    setter(clean10 ? `0${clean10}` : '');
  };

  const getPayload = (overrides?: Partial<SocialCommunityLinks>): SocialCommunityLinks => ({
    ...socialLinks,
    adminContactNumber: cleanBDPhoneForDial(overrides?.adminContactNumber !== undefined ? overrides.adminContactNumber : adminContactNumber),
    noticeTitle: (overrides?.noticeTitle !== undefined ? overrides.noticeTitle : noticeTitle).trim(),
    noticeTitleEnabled: overrides?.noticeTitleEnabled !== undefined ? overrides.noticeTitleEnabled : noticeTitleEnabled,
    whatsappGroup: (overrides?.whatsappGroup !== undefined ? overrides.whatsappGroup : waGroup).trim(),
    whatsappGroupEnabled: overrides?.whatsappGroupEnabled !== undefined ? overrides.whatsappGroupEnabled : waGroupEnabled,
    telegramChannel: (overrides?.telegramChannel !== undefined ? overrides.telegramChannel : tgChannel).trim(),
    telegramChannelEnabled: overrides?.telegramChannelEnabled !== undefined ? overrides.telegramChannelEnabled : tgChannelEnabled,
    youtubeChannel: (overrides?.youtubeChannel !== undefined ? overrides.youtubeChannel : ytChannel).trim(),
    youtubeChannelEnabled: overrides?.youtubeChannelEnabled !== undefined ? overrides.youtubeChannelEnabled : ytChannelEnabled,
    facebookPage: (overrides?.facebookPage !== undefined ? overrides.facebookPage : fbPage).trim(),
    facebookPageEnabled: overrides?.facebookPageEnabled !== undefined ? overrides.facebookPageEnabled : fbPageEnabled,
    supportPhone: cleanBDPhoneForDial(overrides?.supportPhone !== undefined ? overrides.supportPhone : supportPhone),
    supportPhoneEnabled: overrides?.supportPhoneEnabled !== undefined ? overrides.supportPhoneEnabled : supportPhoneEnabled,
    digitalChatUrl: (overrides?.digitalChatUrl !== undefined ? overrides.digitalChatUrl : digitalChatUrl).trim(),
    digitalChatEnabled: overrides?.digitalChatEnabled !== undefined ? overrides.digitalChatEnabled : digitalChatEnabled,
    whatsappSupportNumber: cleanBDPhoneForDial(overrides?.whatsappSupportNumber !== undefined ? overrides.whatsappSupportNumber : waSupport),
    whatsappSupportEnabled: overrides?.whatsappSupportEnabled !== undefined ? overrides.whatsappSupportEnabled : waSupportEnabled,
    messengerId: (overrides?.messengerId !== undefined ? overrides.messengerId : messengerId).trim(),
    messengerEnabled: overrides?.messengerEnabled !== undefined ? overrides.messengerEnabled : messengerEnabled,
    imoNumber: cleanBDPhoneForDial(overrides?.imoNumber !== undefined ? overrides.imoNumber : imoNumber),
    imoEnabled: overrides?.imoEnabled !== undefined ? overrides.imoEnabled : imoEnabled,
    supportHours: (overrides?.supportHours !== undefined ? overrides.supportHours : supportHours).trim(),
    emergencyNotice: (overrides?.emergencyNotice !== undefined ? overrides.emergencyNotice : emergencyNotice).trim(),
    telegramSupport: (overrides?.telegramSupport !== undefined ? overrides.telegramSupport : telegramSupport).trim(),
    appDownloadUrl: (overrides?.appDownloadUrl !== undefined ? overrides.appDownloadUrl : appDownloadUrl).trim(),
  });

  // Direct Toggle: updates state AND immediately persists so user panel updates in real time!
  const handleToggle = (key: keyof SocialCommunityLinks, newValue: boolean, labelBn: string) => {
    isDirtyRef.current = false;
    if (key === 'noticeTitleEnabled') setNoticeTitleEnabled(newValue);
    if (key === 'whatsappGroupEnabled') setWaGroupEnabled(newValue);
    if (key === 'telegramChannelEnabled') setTgChannelEnabled(newValue);
    if (key === 'youtubeChannelEnabled') setYtChannelEnabled(newValue);
    if (key === 'facebookPageEnabled') setFbPageEnabled(newValue);
    if (key === 'supportPhoneEnabled') setSupportPhoneEnabled(newValue);
    if (key === 'whatsappSupportEnabled') setWaSupportEnabled(newValue);
    if (key === 'digitalChatEnabled') setDigitalChatEnabled(newValue);
    if (key === 'messengerEnabled') setMessengerEnabled(newValue);
    if (key === 'imoEnabled') setImoEnabled(newValue);

    const payload = getPayload({ [key]: newValue });
    onUpdateSocialLinks(payload);

    if (onShowToast) {
      onShowToast(
        newValue
          ? `✅ ${labelBn} অন করা হয়েছে (গ্রাহক দেখতে পাবেন)`
          : `⭕ ${labelBn} অফ করা হয়েছে (গ্রাহকের প্যানেলে দেখা যাবে না)`
      );
    }
  };

  // Auto-save on blur when editing text/URL inputs
  const handleInputBlur = () => {
    isDirtyRef.current = false;
    const payload = getPayload();
    onUpdateSocialLinks(payload);
    if (onUpdateNotice && marqueeNotice.trim() !== currentNotice) {
      onUpdateNotice(marqueeNotice.trim());
    }
  };

  const handleSaveAll = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    isDirtyRef.current = false;
    const payload = getPayload();
    onUpdateSocialLinks(payload);

    if (onUpdateNotice && marqueeNotice.trim() !== currentNotice) {
      onUpdateNotice(marqueeNotice.trim());
    }

    setSavedSuccess(true);
    if (onShowToast) onShowToast('✅ সকল সেটিংস তাৎক্ষণিক সংরক্ষিত হয়েছে!');
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      {/* Top Banner Card */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-sky-500 to-indigo-600 text-white flex items-center justify-center shrink-0 shadow-xs">
            <Share2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-black text-slate-900 text-sm leading-tight">
              সোশ্যাল মিডিয়া ও হেল্প সাপোর্ট কন্ট্রোল
            </h2>
            <p className="text-[10px] text-emerald-600 font-bold flex items-center gap-1 mt-0.5">
              <Sparkles className="w-3 h-3 text-emerald-500" />
              <span>অন/অফ বাটনে ক্লিক করলেই সরাসরি কাজ করবে</span>
            </p>
          </div>
        </div>

        <button
          type="button"
          id="save-social-support-top-btn"
          onClick={() => handleSaveAll()}
          className="px-3.5 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer shrink-0"
        >
          <Save className="w-3.5 h-3.5" />
          <span>সেভ করুন</span>
        </button>
      </div>

      {savedSuccess && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-2 text-emerald-800 text-xs font-bold animate-fadeIn shadow-2xs">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>সকল সোশ্যাল মিডিয়া চ্যানেল ও হেল্প সাপোর্ট সেটিংস সফলভাবে সংরক্ষিত হয়েছে!</span>
        </div>
      )}

      {/* ========================================================= */}
      {/* SECTION 1: নোটিশ টাইটেল ও স্ক্রলিং নোটিশ (On/Off Switch)  */}
      {/* ========================================================= */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3.5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-black text-slate-900 leading-tight">
                ১. নোটিশ টাইটেল ও ব্যানার সেটিংস
              </h3>
              <p className="text-[10px] text-slate-500 font-medium">
                হোমস্ক্রিনের উপরের জরুরি নোটিশ বার ও টাইটেল প্রদর্শন
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          {/* Notice Title + Switch */}
          <div className="p-3 rounded-2xl bg-amber-50/60 border border-amber-200/80 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-amber-950 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>নোটিশ টাইটেল (Notice Title)</span>
              </label>
              <div className="flex items-center gap-2">
                <span
                  className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                    noticeTitleEnabled
                      ? 'bg-amber-200 text-amber-900'
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  {noticeTitleEnabled ? 'অন (ON)' : 'অফ (OFF)'}
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    id="toggle-notice-title-switch"
                    checked={noticeTitleEnabled}
                    onChange={(e) =>
                      handleToggle('noticeTitleEnabled', e.target.checked, 'নোটিশ টাইটেল')
                    }
                    className="sr-only peer"
                  />
                  <div className="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-amber-600"></div>
                </label>
              </div>
            </div>
            <input
              type="text"
              value={noticeTitle}
              onChange={(e) => {
                isDirtyRef.current = true;
                setNoticeTitle(e.target.value);
              }}
              onBlur={handleInputBlur}
              placeholder="জরুরি নোটিশ / আজকের বিশেষ ঘোষণা"
              className="w-full p-2.5 bg-white border border-amber-200 rounded-xl font-bold text-xs text-slate-900 outline-none focus:border-amber-500"
            />
          </div>

          {/* Marquee Notice Text */}
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-1.5">
            <label className="text-xs font-extrabold text-slate-800 flex items-center gap-1.5">
              <Bell className="w-3.5 h-3.5 text-slate-600" />
              <span>স্ক্রোলিং নোটিশ টেক্সট (Marquee Message)</span>
            </label>
            <textarea
              rows={2}
              value={marqueeNotice}
              onChange={(e) => {
                isDirtyRef.current = true;
                setMarqueeNotice(e.target.value);
              }}
              onBlur={handleInputBlur}
              placeholder="গ্রাহকদের উদ্দেশে জরুরি বার্তা লিখুন..."
              className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-900 outline-none focus:border-amber-500 resize-none"
            />
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* SECTION 1.5: ইউজার অ্যাপ ডাউনলোড ও রেফারেল শেয়ার লিংক সেটিংস */}
      {/* ========================================================= */}
      <div className="bg-white rounded-3xl p-5 border-2 border-indigo-200/80 shadow-xs space-y-3.5">
        <div className="flex items-center justify-between pb-3 border-b border-indigo-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-black text-slate-900 leading-tight">
                অ্যাপস ডাউনলোড ও রেফারেল লিংক সেটিংস
              </h3>
              <p className="text-[10px] text-slate-500 font-bold">
                ইউজাররা অ্যাপের সাইডবার থেকে "শেয়ার করুন" চাপলে এই লিংক যাবে
              </p>
            </div>
          </div>
          <span className={`text-[10px] font-black px-2.5 py-1 rounded-full border ${
            appDownloadUrl.trim()
              ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
              : 'bg-indigo-50 text-indigo-800 border-indigo-200'
          }`}>
            {appDownloadUrl.trim() ? '✓ ম্যানুয়াল মোড সক্রিয়' : '⚡ অটোমেটিক মোড সক্রিয়'}
          </span>
        </div>

        <div className="space-y-3">
          <div className="p-3.5 rounded-2xl bg-indigo-50/50 border border-indigo-200 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-indigo-950 flex items-center gap-1.5">
                <Smartphone className="w-3.5 h-3.5 text-indigo-600" />
                <span>কাস্টম অ্যাপ লিংক / APK ডাউনলোড লিংক (URL)</span>
              </label>
            </div>
            <input
              type="url"
              value={appDownloadUrl}
              onChange={(e) => {
                isDirtyRef.current = true;
                setAppDownloadUrl(e.target.value);
              }}
              onBlur={handleInputBlur}
              placeholder="ফাঁকা রাখলে অটোমেটিক লাইভ লিংক নেবে, অথবা আপনার ড্রাইভ/প্লেস্টোর লিংক দিন"
              className="w-full p-3 bg-white border-2 border-indigo-300 rounded-xl text-xs font-mono font-bold text-slate-900 outline-none focus:border-indigo-600 placeholder:text-slate-400 shadow-2xs"
            />
          </div>

          <div className="bg-slate-50 rounded-2xl p-3 border border-slate-200 text-[11px] space-y-1.5 text-slate-700">
            <div className="flex items-start gap-1.5">
              <span className="text-emerald-700 font-black shrink-0">১. অটোমেটিক নিয়ম:</span>
              <span>আপনি যদি এই ঘরটি ফাঁকা রাখেন, তাহলে আপনাকে কোনো লিংক বসাতে হবে না—সিস্টেম স্বয়ংক্রিয়ভাবে বর্তমান লাইভ অ্যাপের ওয়েব লিংকটি ব্যবহার করবে।</span>
            </div>
            <div className="flex items-start gap-1.5">
              <span className="text-indigo-700 font-black shrink-0">২. ম্যানুয়াল নিয়ম:</span>
              <span>যদি আপনি আপনার অ্যাপের গুগল ড্রাইভ APK ডাউনলোড লিংক বা প্লে-স্টোর লিংক এখানে বসিয়ে সেভ করেন, তখন ইউজারদের শেয়ার বাটনে আপনার দেয়া কাস্টম লিংকটিই যাবে।</span>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* SECTION 2: সোশ্যাল মিডিয়া চ্যানেল ও On/Off সুইচ          */}
      {/* ========================================================= */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-black text-slate-900 leading-tight">
                ২. সোশ্যাল মিডিয়া চ্যানেল ও On/Off সুইচ
              </h3>
              <p className="text-[10px] text-slate-500 font-medium">
                হোমস্ক্রিনের নিচের বারে দৃশ্যমান সোশ্যাল কমিউনিটি লিংক
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-3.5">
          {/* 1. WhatsApp Group Link + Switch */}
          <div className="p-3 rounded-2xl bg-emerald-50/50 border border-emerald-200/80 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <MessageCircle className="w-4 h-4 text-emerald-600" />
                <label className="text-xs font-black text-emerald-950">
                  হোয়াটসঅ্যাপ গ্রুপ (WhatsApp Group Link)
                </label>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                    waGroupEnabled
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  {waGroupEnabled ? 'অন (ON)' : 'অফ (OFF)'}
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    id="toggle-whatsapp-group-switch"
                    checked={waGroupEnabled}
                    onChange={(e) =>
                      handleToggle('whatsappGroupEnabled', e.target.checked, 'হোয়াটসঅ্যাপ গ্রুপ')
                    }
                    className="sr-only peer"
                  />
                  <div className="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>
            </div>
            <input
              type="url"
              value={waGroup}
              onChange={(e) => {
                isDirtyRef.current = true;
                setWaGroup(e.target.value);
              }}
              onBlur={handleInputBlur}
              placeholder="https://chat.whatsapp.com/invite/..."
              className="w-full p-2 bg-white border border-emerald-200 rounded-xl font-mono text-xs text-slate-800 outline-none focus:border-emerald-600"
            />
          </div>

          {/* 2. Telegram Channel Link + Switch */}
          <div className="p-3 rounded-2xl bg-sky-50/50 border border-sky-200/80 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Send className="w-4 h-4 text-sky-600" />
                <label className="text-xs font-black text-sky-950">
                  টেলিগ্রাম চ্যানেল (Telegram Channel Link)
                </label>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                    tgChannelEnabled
                      ? 'bg-sky-100 text-sky-800'
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  {tgChannelEnabled ? 'অন (ON)' : 'অফ (OFF)'}
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    id="toggle-telegram-channel-switch"
                    checked={tgChannelEnabled}
                    onChange={(e) =>
                      handleToggle('telegramChannelEnabled', e.target.checked, 'টেলিগ্রাম চ্যানেল')
                    }
                    className="sr-only peer"
                  />
                  <div className="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-sky-600"></div>
                </label>
              </div>
            </div>
            <input
              type="url"
              value={tgChannel}
              onChange={(e) => {
                isDirtyRef.current = true;
                setTgChannel(e.target.value);
              }}
              onBlur={handleInputBlur}
              placeholder="https://t.me/your_channel"
              className="w-full p-2 bg-white border border-sky-200 rounded-xl font-mono text-xs text-slate-800 outline-none focus:border-sky-600"
            />
          </div>

          {/* 3. YouTube Channel Link + Switch */}
          <div className="p-3 rounded-2xl bg-rose-50/50 border border-rose-200/80 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Youtube className="w-4 h-4 text-rose-600" />
                <label className="text-xs font-black text-rose-950">
                  ইউটিউব চ্যানেল (YouTube Channel Link)
                </label>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                    ytChannelEnabled
                      ? 'bg-rose-100 text-rose-800'
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  {ytChannelEnabled ? 'অন (ON)' : 'অফ (OFF)'}
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    id="toggle-youtube-channel-switch"
                    checked={ytChannelEnabled}
                    onChange={(e) =>
                      handleToggle('youtubeChannelEnabled', e.target.checked, 'ইউটিউব চ্যানেল')
                    }
                    className="sr-only peer"
                  />
                  <div className="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-rose-600"></div>
                </label>
              </div>
            </div>
            <input
              type="url"
              value={ytChannel}
              onChange={(e) => {
                isDirtyRef.current = true;
                setYtChannel(e.target.value);
              }}
              onBlur={handleInputBlur}
              placeholder="https://youtube.com/@channel"
              className="w-full p-2 bg-white border border-rose-200 rounded-xl font-mono text-xs text-slate-800 outline-none focus:border-rose-600"
            />
          </div>

          {/* 4. Facebook Page Link + Switch */}
          <div className="p-3 rounded-2xl bg-indigo-50/50 border border-indigo-200/80 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-indigo-600" />
                <label className="text-xs font-black text-indigo-950">
                  ফেসবুক পেজ (Facebook Page Link)
                </label>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                    fbPageEnabled
                      ? 'bg-indigo-100 text-indigo-800'
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  {fbPageEnabled ? 'অন (ON)' : 'অফ (OFF)'}
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    id="toggle-facebook-page-switch"
                    checked={fbPageEnabled}
                    onChange={(e) =>
                      handleToggle('facebookPageEnabled', e.target.checked, 'ফেসবুক পেজ')
                    }
                    className="sr-only peer"
                  />
                  <div className="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>
            </div>
            <input
              type="url"
              value={fbPage}
              onChange={(e) => {
                isDirtyRef.current = true;
                setFbPage(e.target.value);
              }}
              onBlur={handleInputBlur}
              placeholder="https://facebook.com/your_page"
              className="w-full p-2 bg-white border border-indigo-200 rounded-xl font-mono text-xs text-slate-800 outline-none focus:border-indigo-600"
            />
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* SECTION 3: হেল্প সাপোর্ট সেটিংস ও On/Off সুইচ             */}
      {/* ========================================================= */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
              <Headphones className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-black text-slate-900 leading-tight">
                ৩. হেল্প সাপোর্ট সেটিংস ও On/Off সুইচ
              </h3>
              <p className="text-[10px] text-slate-500 font-medium">
                সময়সূচি: {supportHours}
              </p>
            </div>
          </div>
        </div>

        {/* 1. Admin Contact Number */}
        <div className="p-3.5 bg-indigo-50/70 border border-indigo-200 rounded-2xl space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="text-[11px] font-black text-indigo-950 flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-indigo-600" />
              <span>এডমিন কন্টাক্ট নম্বর (Admin Contact Number) *</span>
            </label>
            <span className="text-[9px] font-bold text-indigo-700 bg-white px-2 py-0.5 rounded-full border border-indigo-200">
              রসিদ ও SMS প্রেরক
            </span>
          </div>
          <p className="text-[10px] text-indigo-900/80 font-medium">
            গ্রাহকদের WhatsApp ও SMS রসিদে "যোগাযোগ: [এডমিন নম্বর]" হিসেবে দৃশ্যমান হবে।
          </p>
          <div className="flex items-center rounded-xl bg-white border border-indigo-300 focus-within:border-indigo-600 overflow-hidden shadow-2xs">
            <div className="flex items-center gap-1 px-2.5 py-2 bg-indigo-100/70 border-r border-indigo-200 text-indigo-900 text-xs font-black select-none shrink-0">
              <span>🇧🇩 +880</span>
            </div>
            <input
              type="tel"
              required
              id="admin-contact-phone-input"
              maxLength={10}
              value={adminContactNumber ? adminContactNumber.replace(/^(\+880|880|0+)/, '') : ''}
              onChange={(e) => handlePhoneInputChange(e.target.value, setAdminContactNumber)}
              onBlur={handleInputBlur}
              placeholder="17XXXXXXXX"
              className="w-full px-2.5 py-2 bg-transparent font-black text-xs text-slate-900 outline-none"
            />
          </div>
        </div>

        {/* 5 Channels with individual On/Off switches */}
        <div className="space-y-3">
          {/* A. Phone Support */}
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <PhoneCall className="w-3.5 h-3.5 text-emerald-600" />
                <label className="text-xs font-extrabold text-slate-800">
                  জরুরি ফোন কল সাপোর্ট (Phone Hotline)
                </label>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                    supportPhoneEnabled
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  {supportPhoneEnabled ? 'অন (ON)' : 'অফ (OFF)'}
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    id="toggle-phone-support-switch"
                    checked={supportPhoneEnabled}
                    onChange={(e) =>
                      handleToggle('supportPhoneEnabled', e.target.checked, 'ফোন কল সাপোর্ট')
                    }
                    className="sr-only peer"
                  />
                  <div className="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>
            </div>
            <div className="flex items-center rounded-xl bg-white border border-slate-300 focus-within:border-emerald-600 overflow-hidden">
              <div className="px-2.5 py-1.5 bg-slate-100 border-r border-slate-200 text-slate-700 text-xs font-bold shrink-0">
                🇧🇩 +880
              </div>
              <input
                type="tel"
                maxLength={10}
                value={supportPhone ? supportPhone.replace(/^(\+880|880|0+)/, '') : ''}
                onChange={(e) => handlePhoneInputChange(e.target.value, setSupportPhone)}
                onBlur={handleInputBlur}
                placeholder="17XXXXXXXX"
                className="w-full px-2.5 py-1.5 bg-transparent text-xs font-bold text-slate-900 outline-none"
              />
            </div>
          </div>

          {/* B. WhatsApp Support */}
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                <label className="text-xs font-extrabold text-slate-800">
                  হোয়াটসঅ্যাপ সাপোর্ট (WhatsApp Support)
                </label>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                    waSupportEnabled
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  {waSupportEnabled ? 'অন (ON)' : 'অফ (OFF)'}
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    id="toggle-whatsapp-support-switch"
                    checked={waSupportEnabled}
                    onChange={(e) =>
                      handleToggle('whatsappSupportEnabled', e.target.checked, 'হোয়াটসঅ্যাপ সাপোর্ট')
                    }
                    className="sr-only peer"
                  />
                  <div className="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-emerald-600"></div>
                </label>
              </div>
            </div>
            <div className="flex items-center rounded-xl bg-white border border-slate-300 focus-within:border-emerald-600 overflow-hidden">
              <div className="px-2.5 py-1.5 bg-slate-100 border-r border-slate-200 text-slate-700 text-xs font-bold shrink-0">
                🇧🇩 +880
              </div>
              <input
                type="tel"
                maxLength={10}
                value={waSupport ? waSupport.replace(/^(\+880|880|0+)/, '') : ''}
                onChange={(e) => handlePhoneInputChange(e.target.value, setWaSupport)}
                onBlur={handleInputBlur}
                placeholder="17XXXXXXXX"
                className="w-full px-2.5 py-1.5 bg-transparent text-xs font-bold text-slate-900 outline-none"
              />
            </div>
          </div>

          {/* C. Digital Chat */}
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-indigo-600" />
                <label className="text-xs font-extrabold text-slate-800">
                  ডিজিটাল চ্যাট (Digital Live Chat Link)
                </label>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                    digitalChatEnabled
                      ? 'bg-indigo-100 text-indigo-800'
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  {digitalChatEnabled ? 'অন (ON)' : 'অফ (OFF)'}
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    id="toggle-digital-chat-switch"
                    checked={digitalChatEnabled}
                    onChange={(e) =>
                      handleToggle('digitalChatEnabled', e.target.checked, 'ডিজিটাল চ্যাট')
                    }
                    className="sr-only peer"
                  />
                  <div className="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>
            </div>
            <input
              type="url"
              value={digitalChatUrl}
              onChange={(e) => {
                isDirtyRef.current = true;
                setDigitalChatUrl(e.target.value);
              }}
              onBlur={handleInputBlur}
              placeholder="https://tawk.to/chat/... বা ওয়েব চ্যাট লিংক"
              className="w-full p-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-800 outline-none focus:border-indigo-600"
            />
          </div>

          {/* D. Messenger */}
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Share2 className="w-3.5 h-3.5 text-blue-600" />
                <label className="text-xs font-extrabold text-slate-800">
                  মেসেঞ্জার (Facebook Messenger ID / Link)
                </label>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                    messengerEnabled
                      ? 'bg-blue-100 text-blue-800'
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  {messengerEnabled ? 'অন (ON)' : 'অফ (OFF)'}
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    id="toggle-messenger-switch"
                    checked={messengerEnabled}
                    onChange={(e) =>
                      handleToggle('messengerEnabled', e.target.checked, 'ফেসবুক মেসেঞ্জার')
                    }
                    className="sr-only peer"
                  />
                  <div className="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>
            <input
              type="text"
              value={messengerId}
              onChange={(e) => {
                isDirtyRef.current = true;
                setMessengerId(e.target.value);
              }}
              onBlur={handleInputBlur}
              placeholder="https://m.me/your_id বা পেজ ইউজারনেম"
              className="w-full p-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-800 outline-none focus:border-blue-600"
            />
          </div>

          {/* E. Imo Support */}
          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Smartphone className="w-3.5 h-3.5 text-sky-600" />
                <label className="text-xs font-extrabold text-slate-800">
                  ইমো নম্বর (Imo Support Number)
                </label>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                    imoEnabled
                      ? 'bg-sky-100 text-sky-800'
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  {imoEnabled ? 'অন (ON)' : 'অফ (OFF)'}
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    id="toggle-imo-switch"
                    checked={imoEnabled}
                    onChange={(e) =>
                      handleToggle('imoEnabled', e.target.checked, 'ইমো সাপোর্ট')
                    }
                    className="sr-only peer"
                  />
                  <div className="w-8 h-4.5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-sky-600"></div>
                </label>
              </div>
            </div>
            <div className="flex items-center rounded-xl bg-white border border-slate-300 focus-within:border-sky-600 overflow-hidden">
              <div className="px-2.5 py-1.5 bg-slate-100 border-r border-slate-200 text-slate-700 text-xs font-bold shrink-0">
                🇧🇩 +880
              </div>
              <input
                type="tel"
                value={imoNumber.replace(/^(\+880|880|0)/, '')}
                onChange={(e) => {
                  isDirtyRef.current = true;
                  const val = e.target.value.replace(/[^0-9]/g, '');
                  setImoNumber(val ? `0${val}` : '');
                }}
                onBlur={handleInputBlur}
                placeholder="17XXXXXXXX"
                className="w-full px-2.5 py-1.5 bg-transparent text-xs font-bold text-slate-900 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Timings & Emergency Notice */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
            <label className="text-[11px] font-bold text-slate-700 flex items-center gap-1">
              <span>সাপোর্ট সময়সূচি (Support Hours)</span>
            </label>
            <input
              type="text"
              value={supportHours}
              onChange={(e) => {
                isDirtyRef.current = true;
                setSupportHours(e.target.value);
              }}
              onBlur={handleInputBlur}
              placeholder="সকাল ১০টা - রাত ১০টা"
              className="w-full p-2 bg-white border border-slate-200 rounded-xl font-bold text-xs text-slate-900 outline-none focus:border-indigo-600"
            />
          </div>

          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
            <label className="text-[11px] font-bold text-slate-700 flex items-center gap-1">
              <span>টেলিগ্রাম সাপোর্ট বটের লিংক</span>
            </label>
            <input
              type="url"
              value={telegramSupport}
              onChange={(e) => {
                isDirtyRef.current = true;
                setTelegramSupport(e.target.value);
              }}
              onBlur={handleInputBlur}
              placeholder="https://t.me/admin_support_bot"
              className="w-full p-2 bg-white border border-slate-200 rounded-xl font-mono text-xs text-slate-900 outline-none focus:border-indigo-600"
            />
          </div>
        </div>

        {/* Emergency Notice */}
        <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-2xl space-y-1.5">
          <label className="text-xs font-black text-amber-950 flex items-center gap-1.5">
            <Bell className="w-3.5 h-3.5 text-amber-600" />
            <span>জরুরি হেল্পলাইন সতর্কবার্তা (Emergency Notice)</span>
          </label>
          <input
            type="text"
            value={emergencyNotice}
            onChange={(e) => {
              isDirtyRef.current = true;
              setEmergencyNotice(e.target.value);
            }}
            onBlur={handleInputBlur}
            placeholder="যেকোনো রিচার্জ বা ব্যালেন্স সংক্রান্ত জরুরি প্রয়োজনে সরাসরি কল করুন..."
            className="w-full p-2.5 bg-white border border-amber-200 rounded-xl font-medium text-xs text-slate-900 outline-none focus:border-amber-600"
          />
        </div>
      </div>
    </div>
  );
};
