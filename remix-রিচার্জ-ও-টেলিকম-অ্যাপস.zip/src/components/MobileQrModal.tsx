import React, { useState, useEffect } from 'react';
import {
  QrCode,
  Copy,
  Check,
  ExternalLink,
  X,
  Smartphone,
  Sparkles,
  Share2,
} from 'lucide-react';

interface MobileQrModalProps {
  isOpen: boolean;
  onClose: () => void;
  appName?: string;
}

export const MobileQrModal: React.FC<MobileQrModalProps> = ({
  isOpen,
  onClose,
  appName = 'M APPS',
}) => {
  const [copied, setCopied] = useState(false);
  const [currentUrl, setCurrentUrl] = useState('');

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setCurrentUrl(window.location.href);
    }
  }, []);

  if (!isOpen) return null;

  const handleCopyLink = () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(currentUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleShare = () => {
    if (typeof navigator !== 'undefined' && navigator.share) {
      navigator
        .share({
          title: appName,
          text: `${appName} - ডিজিটাল টেলিকম রিচার্জ ও ড্রাইভ অফার অ্যাপ`,
          url: currentUrl,
        })
        .catch(() => {});
    } else {
      handleCopyLink();
    }
  };

  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&margin=10&data=${encodeURIComponent(
    currentUrl || 'https://ais-pre-zllaqzcthprk7px5g7rrfo-495811225278.asia-east1.run.app'
  )}`;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 font-['Hind_Siliguri',sans-serif] animate-fadeIn"
    >
      <div className="bg-white rounded-3xl p-5 max-w-sm w-full shadow-2xl border border-slate-100 space-y-3.5 text-center animate-scaleUp">
        {/* Header */}
        <div className="flex items-center justify-between pb-2.5 border-b border-slate-100">
          <div className="flex items-center gap-2 text-left">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
              <QrCode className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900">মোবাইল স্ক্যানার ও কিউআর</h3>
              <p className="text-[10px] text-slate-500 font-medium">স্মার্টফোনে সরাসরি ওপেন করতে স্ক্যান করুন</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* QR Code Container */}
        <div className="bg-gradient-to-b from-slate-50 to-emerald-50/40 p-3.5 rounded-2xl border border-emerald-100 flex flex-col items-center justify-center">
          <div className="p-2 bg-white rounded-2xl shadow-md border border-slate-200">
            <img
              src={qrImageUrl}
              alt="App QR Code"
              className="w-44 h-44 rounded-xl object-contain"
              loading="eager"
            />
          </div>
          <p className="text-xs font-black text-slate-800 mt-2.5 flex items-center gap-1 justify-center">
            <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
            ক্যামেরা বা কিউআর স্ক্যানার দিয়ে স্ক্যান করুন
          </p>
          <p className="text-[11px] text-slate-500 mt-0.5 max-w-xs leading-relaxed">
            মোবাইলে ব্রাউজারে খোলার পর <span className="font-bold text-slate-700">"Add to Home screen"</span> দিলে সাধারণ অ্যান্ড্রয়েড অ্যাপের মতো কাজ করবে।
          </p>
        </div>

        {/* URL and Copy Link Actions */}
        <div className="space-y-2">
          <div className="flex items-center gap-1.5 p-1.5 bg-slate-50 rounded-xl border border-slate-200 text-left">
            <input
              type="text"
              readOnly
              value={currentUrl}
              className="w-full bg-transparent text-[10px] text-slate-600 font-mono px-2 outline-none select-all"
            />
            <button
              type="button"
              onClick={handleCopyLink}
              className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shrink-0 flex items-center gap-1 transition-all cursor-pointer shadow-xs"
            >
              {copied ? (
                <>
                  <Check className="w-3 h-3 text-white" />
                  <span>কপি হয়েছে</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span>কপি লিংক</span>
                </>
              )}
            </button>
          </div>

          <div className="flex items-center gap-2 pt-0.5">
            <button
              type="button"
              onClick={handleShare}
              className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>শেয়ার করুন</span>
            </button>
            <a
              href={currentUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-md"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>নতুন উইন্ডোতে</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
