import React, { useState } from 'react';
import {
  X,
  Sparkles,
  Bot,
  Send,
  Plus,
  Copy,
  Check,
  Zap,
  Tag,
  MessageCircle,
  Smartphone,
  CheckCircle2,
  RefreshCw,
  Sliders,
  HelpCircle,
  Award,
} from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { DriveOffer, OperatorType, UserProfile } from '../types';
import { OperatorLogo } from './OperatorLogos';

interface TelecomAiModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  offers: DriveOffer[];
  onAddOffer?: (newOffer: DriveOffer) => void;
  isAdmin?: boolean;
}

interface AiChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  generatedOffers?: Partial<DriveOffer>[];
  timestamp: string;
}

export const TelecomAiModal: React.FC<TelecomAiModalProps> = ({
  isOpen,
  onClose,
  user,
  offers,
  onAddOffer,
  isAdmin = false,
}) => {
  const [activeTab, setActiveTab] = useState<'generator' | 'chat'>('generator');
  const [selectedOperator, setSelectedOperator] = useState<OperatorType | 'all'>('all');
  const [promptInput, setPromptInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [addedOfferIds, setAddedOfferIds] = useState<Record<string, boolean>>({});

  // Generated offers list state
  const [generatedOffers, setGeneratedOffers] = useState<DriveOffer[]>([
    {
      id: 'ai-gp-1',
      operator: 'gp',
      operatorName: 'Grameenphone',
      packageName: 'কম্বো স্পেশাল',
      minutes: 750,
      internetGB: 35,
      validityDays: 30,
      priceTK: 498,
      regularPriceTK: 649,
      cashbackTK: 151,
      division: 'অল বিডি (All BD)',
      title: 'জিপি ৩৫ জিবি + ৭৫০ মিনিট মেগা অফার',
      whatsappNumber: user.phone,
    },
    {
      id: 'ai-robi-1',
      operator: 'robi',
      operatorName: 'Robi',
      packageName: 'ধামাকা বান্ডেল',
      minutes: 800,
      internetGB: 45,
      validityDays: 30,
      priceTK: 539,
      regularPriceTK: 699,
      cashbackTK: 160,
      division: 'অল বিডি (All BD)',
      title: 'রবি ৪৫ জিবি + ৮০০ মিনিট ক্যাশব্যাক অফার',
      whatsappNumber: user.phone,
    },
    {
      id: 'ai-bl-1',
      operator: 'banglalink',
      operatorName: 'Banglalink',
      packageName: 'ইন্টারনেট প্লাস',
      minutes: 0,
      internetGB: 50,
      validityDays: 30,
      priceTK: 399,
      regularPriceTK: 499,
      cashbackTK: 100,
      division: 'অল বিডি (All BD)',
      title: 'বাংলালিংক ৫০ জিবি সুপার ডাটা প্যাক',
      whatsappNumber: user.phone,
    },
    {
      id: 'ai-airtel-1',
      operator: 'airtel',
      operatorName: 'Airtel',
      packageName: 'স্টুডেন্ট স্পেশাল',
      minutes: 600,
      internetGB: 30,
      validityDays: 30,
      priceTK: 388,
      regularPriceTK: 498,
      cashbackTK: 110,
      division: 'অল বিডি (All BD)',
      title: 'এয়ারটেল ৩০ জিবি + ৬০০ মিনিট স্টুডেন্ট বান্ডেল',
      whatsappNumber: user.phone,
    },
  ]);

  // AI Chat History
  const [chatMessages, setChatMessages] = useState<AiChatMessage[]>([
    {
      id: 'msg-welcome',
      sender: 'ai',
      text: `আসসালামু আলাইকুম ${user.name}! আমি আপনার স্মার্ট টেলিকম AI অ্যাসিস্ট্যান্ট।\n\nঅপারেটর অফার লিস্ট জেনারেট করা, ক্যাশব্যাক হিসাব, ড্রাইভ অফার তৈরি, সিম হেল্পলাইন কোড বা রিচার্জ বিষয়ক যেকোনো সহায়তায় আমি আপনাকে সহায়তা করতে প্রস্তুত।`,
      timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [chatInput, setChatInput] = useState('');

  if (!isOpen) return null;

  // Fallback offline telecom intelligence generator
  const generateOfflineOffers = (query: string, op: OperatorType | 'all'): DriveOffer[] => {
    const timestamp = Date.now();
    const ops: OperatorType[] = op === 'all' ? ['gp', 'robi', 'banglalink', 'airtel', 'teletalk'] : [op];

    const pool = [
      { gb: 50, min: 800, days: 30, price: 549, reg: 749, cash: 200, pkg: 'সুপার ধামাকা কম্বো' },
      { gb: 40, min: 600, days: 30, price: 460, reg: 599, cash: 139, pkg: 'মেগা বান্ডেল প্যাক' },
      { gb: 60, min: 0, days: 30, price: 420, reg: 550, cash: 130, pkg: 'ডাটা স্পেশাল প্যাক' },
      { gb: 0, min: 1000, days: 30, price: 480, reg: 650, cash: 170, pkg: 'মিনিট ধামাকা অফার' },
      { gb: 25, min: 450, days: 30, price: 340, reg: 450, cash: 110, pkg: 'বাজেট ফ্রেন্ডলি প্যাক' },
      { gb: 30, min: 500, days: 30, price: 375, reg: 490, cash: 115, pkg: 'ফ্যামিলি কম্বো প্যাক' },
      { gb: 100, min: 1200, days: 30, price: 890, reg: 1199, cash: 309, pkg: 'ভিআইপি মেগা বান্ডেল' },
    ];

    const results: DriveOffer[] = [];
    ops.forEach((currentOp, i) => {
      const template = pool[(i + timestamp) % pool.length];
      const opNameMap: Record<OperatorType, string> = {
        gp: 'Grameenphone',
        robi: 'Robi',
        banglalink: 'Banglalink',
        airtel: 'Airtel',
        teletalk: 'Teletalk',
        skitto: 'Skitto',
      };

      results.push({
        id: `ai-gen-${currentOp}-${timestamp}-${i}`,
        operator: currentOp,
        operatorName: opNameMap[currentOp] || currentOp,
        packageName: template.pkg,
        minutes: template.min,
        internetGB: template.gb,
        validityDays: template.days,
        priceTK: template.price,
        regularPriceTK: template.reg,
        cashbackTK: template.cash,
        division: 'অল বিডি (All BD)',
        title: `${opNameMap[currentOp]} ${template.gb > 0 ? template.gb + 'GB' : ''} ${
          template.min > 0 ? '+ ' + template.min + ' Min' : ''
        } ${template.pkg}`,
        whatsappNumber: user.phone,
      });
    });

    return results;
  };

  // Generate Offers Handler (Gemini or Smart Telecom Engine)
  const handleGenerateOffers = async (customPrompt?: string) => {
    const promptToUse = customPrompt || promptInput || 'সকল অপারেটরের ৩০ দিনের সেরা ড্রাইভ অফারসমূহ';
    setIsGenerating(true);

    try {
      // Try to call Gemini API if key is available in environment
      // @ts-ignore
      const apiKey = typeof process !== 'undefined' && process.env ? process.env.GEMINI_API_KEY : '';
      
      let newGeneratedList: DriveOffer[] = [];

      if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
        const ai = new GoogleGenAI({ apiKey });
        const systemPrompt = `You are an expert telecom drive offer generator in Bangladesh. Generate 4 realistic telecom drive offers for Bangladesh operators (${selectedOperator === 'all' ? 'GP, Robi, Banglalink, Airtel' : selectedOperator}) in JSON format matching this TypeScript interface:
Array<{ operator: "gp"|"robi"|"banglalink"|"airtel"|"teletalk", operatorName: string, packageName: string, minutes: number, internetGB: number, validityDays: number, priceTK: number, regularPriceTK: number, cashbackTK: number, division: string, title: string }>
Return ONLY raw JSON array.`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.7-flash',
          contents: [{ role: 'user', parts: [{ text: `${systemPrompt}\nUser Request: ${promptToUse}` }] }],
        });

        const text = response.text || '';
        const jsonMatch = text.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0]);
          newGeneratedList = parsed.map((item: any, idx: number) => ({
            id: `ai-gemini-${Date.now()}-${idx}`,
            operator: item.operator || 'gp',
            operatorName: item.operatorName || 'Grameenphone',
            packageName: item.packageName || 'কম্বো প্যাক',
            minutes: Number(item.minutes) || 0,
            internetGB: Number(item.internetGB) || 0,
            validityDays: Number(item.validityDays) || 30,
            priceTK: Number(item.priceTK) || 350,
            regularPriceTK: Number(item.regularPriceTK) || Number(item.priceTK) + 100,
            cashbackTK: Number(item.cashbackTK) || 100,
            division: item.division || 'অল বিডি (All BD)',
            title: item.title || `${item.operatorName} ${item.internetGB}GB + ${item.minutes}Min`,
            whatsappNumber: user.phone,
          }));
        }
      }

      if (newGeneratedList.length === 0) {
        // Fallback to our rich built-in telecom intelligence engine
        newGeneratedList = generateOfflineOffers(promptToUse, selectedOperator);
      }

      setGeneratedOffers(newGeneratedList);
      setAddedOfferIds({});
    } catch (err) {
      console.warn('Using intelligent fallback engine for offers:', err);
      const fallbackList = generateOfflineOffers(promptToUse, selectedOperator);
      setGeneratedOffers(fallbackList);
    } finally {
      setIsGenerating(false);
    }
  };

  // Add a single generated offer to the live app/admin offers
  const handleAddGeneratedOfferToApp = (off: DriveOffer) => {
    if (onAddOffer) {
      const uniqueOffer: DriveOffer = {
        ...off,
        id: `off-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      };
      onAddOffer(uniqueOffer);
      setAddedOfferIds((prev) => ({ ...prev, [off.id]: true }));
    }
  };

  // Add all generated offers in bulk
  const handleAddAllOffersToApp = () => {
    if (onAddOffer) {
      generatedOffers.forEach((off, idx) => {
        const uniqueOffer: DriveOffer = {
          ...off,
          id: `off-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 7)}`,
        };
        onAddOffer(uniqueOffer);
      });
      const allAdded: Record<string, boolean> = {};
      generatedOffers.forEach((o) => (allAdded[o.id] = true));
      setAddedOfferIds(allAdded);
    }
  };

  // Copy offer as social media text
  const handleCopyOfferText = (off: DriveOffer) => {
    const text = `🔥 ${off.operatorName} ধামাকা অফার! 🔥\n📦 ${off.internetGB}GB + ${off.minutes} Min (${off.validityDays} দিন)\n🏷️ রেগুলার মূল্য: ৳${off.regularPriceTK || off.priceTK + 40}\n💰 অফার মূল্য: মাত্র ৳${off.priceTK} (ক্যাশব্যাক ৳${off.cashbackTK})\n⚡ এখনই রিচার্জ পেতে ইনবক্স করুন বা কল দিন: ${user.phone}`;
    navigator.clipboard.writeText(text);
    setCopiedId(off.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Send Chat message
  const handleSendChatMessage = async () => {
    if (!chatInput.trim()) return;

    const userMsg: AiChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: chatInput,
      timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev, userMsg]);
    const query = chatInput;
    setChatInput('');

    // AI Response generation
    setTimeout(() => {
      let reply = '';
      const lower = query.toLowerCase();

      if (lower.includes('gp') || lower.includes('গ্রামীন') || lower.includes('grameenphone')) {
        reply = `📱 **গ্রামীনফোন (GP) সেরা ইনফরমেশন:**\n- ব্যালেন্স চেক: *566#\n- মিনিট চেক: *121*1*2#\n- ইন্টারনেট চেক: *121*1*4#\n- আজকের সেরা অফার: ৫০ জিবি + ৮০০ মিনিট (৳৫৪৯, ক্যাশব্যাক ৳১৫০)।`;
      } else if (lower.includes('robi') || lower.includes('রবি')) {
        reply = `📱 **রবি (Robi) সেরা ইনফরমেশন:**\n- মেইন ব্যালেন্স চেক: *222#\n- ডাটা ও মিনিট চেক: *3#\n- আজকের ধামাকা: ৪৫ জিবি + ৮০০ মিনিট (৳৫৩৯, ক্যাশব্যাক ৳১৬০)।`;
      } else if (lower.includes('banglalink') || lower.includes('বাংলালিংক')) {
        reply = `📱 **বাংলালিংক (Banglalink) সেরা ইনফরমেশন:**\n- ব্যালেন্স চেক: *124#\n- ডাটা চেক: *5000*500#\n- স্পেশাল অফার: *888#\n- অফার: ৫০ জিবি ইন্টারনেট মাত্র ৳৩৯৯ তে ক্যাশব্যাক সহ।`;
      } else if (lower.includes('ক্যাশব্যাক') || lower.includes('লাভ') || lower.includes('হিসাব')) {
        reply = `💰 **ড্রাইভ অফার লাভ ও ক্যাশব্যাক গাইড:**\nড্রাইভ অফার বিক্রি করে প্রতি সিমে গড়ে ৳৮০ থেকে ৳২০০ পর্যন্ত ক্যাশব্যাক লাভ করা যায়। টালি খাতায় বাকি ও জমা সঠিকভাবে এন্ট্রি রাখলে ব্যবসার হিসাব ১০০% নিখুঁত থাকে।`;
      } else if (lower.includes('ফেইল') || lower.includes('ব্যালেন্স') || lower.includes('সমস্যা')) {
        reply = `⚠️ **রিচার্জ সংক্রান্ত তাৎক্ষণিক সমাধান:**\n১. ব্যালেন্স পর্যাপ্ত আছে কিনা চেক করুন।\n২. গ্রাহকের অপারেটর ও নম্বর সঠিক কিনা যাচাই করুন।\n৩. কোনো সমস্যা হলে সরাসরি অ্যাডমিন বা WhatsApp সাপোর্টে TrxID সহ টিকিট সাবমিট করুন।`;
      } else {
        reply = `ধন্যবাদ আপনার প্রশ্নের জন্য! "${query}" বিষয়ে সমাধান পেতে আপনি ড্রাইভ অফার তালিকা থেকে পছন্দসই অফার সিলেক্ট করতে পারেন অথবা অ্যাডমিন প্যানেলে অফার জেনারেটর ব্যবহার করতে পারেন।`;
      }

      setChatMessages((prev) => [
        ...prev,
        {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: reply,
          timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="w-full max-w-[430px] bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Header Bar */}
        <div className="bg-gradient-to-r from-purple-700 via-indigo-700 to-pink-600 p-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 shadow-inner">
              <Sparkles className="w-5 h-5 text-amber-300 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-extrabold text-sm leading-tight">
                  টেলিকম AI অ্যাসিস্ট্যান্ট
                </h3>
                <span className="text-[9px] bg-amber-400 text-purple-950 px-1.5 py-0.2 rounded-full font-black">
                  PRO AI
                </span>
              </div>
              <p className="text-[10px] text-white/80 font-medium">
                অফার জেনারেটর ও ২৪/৭ টেলিকম সাপোর্ট
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-all cursor-pointer border border-white/25"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-3 pt-2 gap-1">
          <button
            type="button"
            onClick={() => setActiveTab('generator')}
            className={`flex-1 py-2 text-xs font-bold text-center border-b-2 transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'generator'
                ? 'border-purple-600 text-purple-700 bg-white rounded-t-xl'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>অফার জেনারেটর</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('chat')}
            className={`flex-1 py-2 text-xs font-bold text-center border-b-2 transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'chat'
                ? 'border-purple-600 text-purple-700 bg-white rounded-t-xl'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Bot className="w-3.5 h-3.5" />
            <span>AI চ্যাট সাপোর্ট</span>
          </button>
        </div>

        {/* Tab 1: Offer Generator */}
        {activeTab === 'generator' && (
          <div className="p-4 overflow-y-auto space-y-4 flex-1">
            {/* Quick Operator Selection */}
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1.5">
                অপারেটর সিলেক্ট করুন:
              </label>
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {[
                  { id: 'all', label: 'সকল অপারেটর' },
                  { id: 'gp', label: 'GP' },
                  { id: 'robi', label: 'Robi' },
                  { id: 'banglalink', label: 'BL' },
                  { id: 'airtel', label: 'Airtel' },
                  { id: 'teletalk', label: 'Teletalk' },
                ].map((op) => (
                  <button
                    key={op.id}
                    type="button"
                    onClick={() => setSelectedOperator(op.id as any)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-extrabold transition-all shrink-0 cursor-pointer ${
                      selectedOperator === op.id
                        ? 'bg-purple-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {op.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Prompt presets */}
            <div className="space-y-1.5">
              <label className="block text-[11px] font-bold text-slate-600">
                রেডিমেড প্রম্পট সিলেক্ট করুন:
              </label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'আজকের সেরা ৫টি ড্রাইভ অফার বানাও',
                  'GP ৩০ দিনের কম্বো প্যাক ক্যাশব্যাক সহ',
                  'বাংলালিংক ৫০ জিবি ইন্টারনেট ডাটা প্যাক',
                  'রবি ৮০০ মিনিট + ৪৫ জিবি বান্ডেল',
                  'স্টুডেন্ট স্পেশাল ৪০০ টাকার কম্বো',
                ].map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setPromptInput(preset);
                      handleGenerateOffers(preset);
                    }}
                    className="px-2.5 py-1 bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200/80 rounded-lg text-[10.5px] font-bold transition-colors cursor-pointer text-left"
                  >
                    ✨ {preset}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Prompt Input */}
            <div className="space-y-2">
              <div className="relative">
                <input
                  type="text"
                  value={promptInput}
                  onChange={(e) => setPromptInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleGenerateOffers()}
                  placeholder="যেমন: ৪০০ টাকার মধ্যে রবি ও জিপি মিনিট অফার..."
                  className="w-full pl-3 pr-24 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-500 font-medium"
                />
                <button
                  type="button"
                  onClick={() => handleGenerateOffers()}
                  disabled={isGenerating}
                  className="absolute right-1.5 top-1.5 bottom-1.5 px-3 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white rounded-lg text-xs font-extrabold flex items-center gap-1 shadow-xs transition-all cursor-pointer"
                >
                  {isGenerating ? (
                    <RefreshCw className="w-3 h-3 animate-spin" />
                  ) : (
                    <Sparkles className="w-3 h-3 text-amber-300" />
                  )}
                  <span>{isGenerating ? 'তৈরি হচ্ছে...' : 'জেনারেট'}</span>
                </button>
              </div>
            </div>

            {/* Generated Offers Header & Bulk Add Action */}
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Tag className="w-4 h-4 text-purple-600" />
                <span className="text-xs font-extrabold text-slate-900">
                  AI প্রস্তুতকৃত অফারসমূহ ({generatedOffers.length})
                </span>
              </div>

              {onAddOffer && (
                <button
                  type="button"
                  onClick={handleAddAllOffersToApp}
                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[11px] rounded-lg shadow-2xs transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                >
                  <Plus className="w-3 h-3" />
                  <span>সবগুলো অ্যাপে যোগ করুন</span>
                </button>
              )}
            </div>

            {/* Generated Offers List */}
            <div className="space-y-2.5">
              {generatedOffers.map((off) => {
                const isAdded = !!addedOfferIds[off.id];
                return (
                  <div
                    key={off.id}
                    className="p-3 bg-slate-50 hover:bg-white rounded-2xl border border-slate-200 hover:border-purple-300 shadow-2xs transition-all space-y-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <OperatorLogo operator={off.operator} size="sm" />
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h4 className="font-extrabold text-xs text-slate-900">
                              {off.internetGB > 0 ? `${off.internetGB}GB` : ''}{' '}
                              {off.minutes > 0 ? `+ ${off.minutes} Min` : ''}
                            </h4>
                            <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded-md bg-purple-50 text-purple-700 border border-purple-200">
                              {off.packageName}
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-500 block">
                            {off.validityDays} Days • {off.division}
                          </span>
                        </div>
                      </div>

                      {/* Pricing Tag */}
                      <div className="text-right shrink-0">
                        <div className="text-xs font-black text-slate-900">
                          ৳{off.priceTK}
                        </div>
                        <div className="text-[9.5px] text-emerald-600 font-extrabold">
                          ক্যাশব্যাক ৳{off.cashbackTK}
                        </div>
                      </div>
                    </div>

                    {/* Action Bar for each generated card */}
                    <div className="flex items-center justify-between pt-1.5 border-t border-slate-200/70 gap-2">
                      <button
                        type="button"
                        onClick={() => handleCopyOfferText(off)}
                        className="px-2 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-[10.5px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                      >
                        {copiedId === off.id ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-600" />
                            <span className="text-emerald-600">কপি হয়েছে</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>পোস্ট কপি</span>
                          </>
                        )}
                      </button>

                      {onAddOffer && (
                        <button
                          type="button"
                          onClick={() => handleAddGeneratedOfferToApp(off)}
                          disabled={isAdded}
                          className={`px-2.5 py-1 text-[10.5px] font-extrabold rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                            isAdded
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-300 cursor-default'
                              : 'bg-purple-600 hover:bg-purple-700 text-white shadow-2xs active:scale-95'
                          }`}
                        >
                          {isAdded ? (
                            <>
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              <span>অ্যাডমিনে যোগ হয়েছে</span>
                            </>
                          ) : (
                            <>
                              <Plus className="w-3 h-3" />
                              <span>অফার যোগ করুন</span>
                            </>
                          )}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 2: AI Chat Support */}
        {activeTab === 'chat' && (
          <div className="flex flex-col flex-1 overflow-hidden">
            <div className="p-4 overflow-y-auto space-y-3 flex-1 bg-slate-50/50">
              {chatMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex items-start gap-2 ${
                    msg.sender === 'user' ? 'flex-row-reverse' : 'flex-row'
                  }`}
                >
                  <div
                    className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 ${
                      msg.sender === 'user'
                        ? 'bg-indigo-600 text-white'
                        : 'bg-purple-600 text-white shadow-xs'
                    }`}
                  >
                    {msg.sender === 'user' ? 'ইউ' : <Bot className="w-4 h-4" />}
                  </div>

                  <div
                    className={`p-3 rounded-2xl text-xs max-w-[80%] whitespace-pre-line leading-relaxed ${
                      msg.sender === 'user'
                        ? 'bg-indigo-600 text-white rounded-tr-xs'
                        : 'bg-white text-slate-800 border border-slate-200 rounded-tl-xs shadow-2xs'
                    }`}
                  >
                    {msg.text}
                    <div
                      className={`text-[9px] mt-1 ${
                        msg.sender === 'user' ? 'text-indigo-200 text-right' : 'text-slate-400'
                      }`}
                    >
                      {msg.timestamp}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Chat Input Bar */}
            <div className="p-3 bg-white border-t border-slate-200">
              <div className="relative">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendChatMessage()}
                  placeholder="টেলিকম বা অফার নিয়ে প্রশ্ন লিখুন..."
                  className="w-full pl-3 pr-10 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-500 font-medium"
                />
                <button
                  type="button"
                  onClick={handleSendChatMessage}
                  disabled={!chatInput.trim()}
                  className="absolute right-1.5 top-1.5 bottom-1.5 px-2.5 bg-purple-600 hover:bg-purple-700 disabled:opacity-40 text-white rounded-lg transition-all cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          <span className="text-[10px] text-slate-500 font-medium">
            💡 অফার তৈরি বা কাস্টমার সাপোর্টে চ্যাটজিপিটি বা জেমিনাই এর বিকল্প
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl transition-colors cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
