import React from 'react';
import {
  MessageCircle,
  Send,
  Youtube,
  Users,
} from 'lucide-react';
import { SocialCommunityLinks, DriveOffer, UserProfile } from '../types';

interface SocialCommunityBarProps {
  socialLinks: SocialCommunityLinks;
  offers?: DriveOffer[];
  user?: UserProfile;
}

export const SocialCommunityBar: React.FC<SocialCommunityBarProps> = ({
  socialLinks,
}) => {
  const allChannels = [
    {
      id: 'chan-wa',
      name: 'WhatsApp',
      sub: 'গ্রুপ',
      icon: MessageCircle,
      url: socialLinks.whatsappGroup,
      enabled: socialLinks.whatsappGroupEnabled !== false,
      badgeColor: 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border-emerald-200/70',
      iconColor: 'text-emerald-600',
    },
    {
      id: 'chan-tg',
      name: 'Telegram',
      sub: 'চ্যানেল',
      icon: Send,
      url: socialLinks.telegramChannel,
      enabled: socialLinks.telegramChannelEnabled !== false,
      badgeColor: 'bg-sky-50 text-sky-700 hover:bg-sky-100 border-sky-200/70',
      iconColor: 'text-sky-600',
    },
    {
      id: 'chan-yt',
      name: 'YouTube',
      sub: 'চ্যানেল',
      icon: Youtube,
      url: socialLinks.youtubeChannel,
      enabled: socialLinks.youtubeChannelEnabled !== false,
      badgeColor: 'bg-rose-50 text-rose-700 hover:bg-rose-100 border-rose-200/70',
      iconColor: 'text-rose-600',
    },
    {
      id: 'chan-fb',
      name: 'Facebook',
      sub: 'পেজ',
      icon: Users,
      url: socialLinks.facebookPage,
      enabled: socialLinks.facebookPageEnabled !== false,
      badgeColor: 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border-indigo-200/70',
      iconColor: 'text-indigo-600',
    },
  ];

  const channels = allChannels.filter(
    (c) => c.enabled && Boolean(c.url && c.url.trim() !== '' && c.url !== '#')
  );

  if (channels.length === 0) return null;

  return (
    <div className="bg-white/95 rounded-2xl px-3 py-2.5 border border-slate-200 shadow-xs mb-3">
      <div className="text-[11px] font-black text-slate-500 mb-1.5 px-0.5 text-center">
        অফিসিয়াল সোশ্যাল গ্রুপ ও চ্যানেল
      </div>
      <div className="flex items-center justify-between gap-1.5 sm:gap-2">
        {channels.map((chan) => {
          const Icon = chan.icon;
          return (
            <a
              key={chan.id}
              id={chan.id}
              href={chan.url || '#'}
              target={chan.url ? '_blank' : '_self'}
              rel="noreferrer"
              className={`flex-1 min-w-0 flex flex-col items-center justify-center py-1.5 px-1 rounded-xl border ${chan.badgeColor} active:scale-95 transition-all group shadow-xs`}
            >
              <div className="flex items-center gap-1 max-w-full">
                <Icon className={`w-3.5 h-3.5 shrink-0 ${chan.iconColor} group-hover:scale-110 transition-transform stroke-[2.5]`} />
                <span className="text-[11px] font-black tracking-tight text-slate-900 truncate">
                  {chan.name}
                </span>
              </div>
              <span className="text-[9px] sm:text-[10px] text-slate-600 font-bold leading-none mt-0.5 truncate max-w-full">
                {chan.sub}
              </span>
            </a>
          );
        })}
      </div>
    </div>
  );
};
