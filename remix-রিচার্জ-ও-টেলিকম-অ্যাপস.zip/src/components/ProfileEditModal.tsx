import React, { useState, useRef, useEffect } from 'react';
import { X, Camera, Upload, Trash2, Check, User, Sparkles } from 'lucide-react';
import { UserProfile } from '../types';

interface ProfileEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onUpdateUser: (updatedUser: UserProfile) => void;
}

// Helper to compress and optimize uploaded profile images for fast Firestore storage
const compressAndResizeImage = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new window.Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 360;
        let width = img.width;
        let height = img.height;
        if (width > height) {
          if (width > maxDim) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          }
        } else {
          if (height > maxDim) {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        resolve(dataUrl);
      };
      img.onerror = () => resolve(e.target?.result as string);
      img.src = e.target?.result as string;
    };
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });
};

export const ProfileEditModal: React.FC<ProfileEditModalProps> = ({
  isOpen,
  onClose,
  user,
  onUpdateUser,
}) => {
  const [editName, setEditName] = useState(user.name);
  const [editProfileImage, setEditProfileImage] = useState(user.profileImage || '');
  const [imageUploading, setImageUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setEditName(user.name);
      setEditProfileImage(user.profileImage || '');
    }
  }, [isOpen, user]);

  if (!isOpen) return null;

  const handleImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setImageUploading(true);
      const compressed = await compressAndResizeImage(file);
      setEditProfileImage(compressed);
    } catch (err) {
      console.error('Image compression error:', err);
    } finally {
      setImageUploading(false);
    }
  };

  const handleRemoveImage = () => {
    setEditProfileImage('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editName.trim()) return;
    onUpdateUser({
      ...user,
      name: editName.trim(),
      profileImage: editProfileImage,
      avatarUrl: editProfileImage,
    });
    onClose();
  };

  return (
    <div
      id="profile-edit-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="profile-edit-modal-card"
        className="bg-white rounded-3xl max-w-[380px] w-full p-5 shadow-2xl border border-slate-100 space-y-4 relative"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#005ed9] to-[#0072CE] text-white flex items-center justify-center shadow-xs">
              <User className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-slate-900 text-base leading-tight">
                নাম ও ছবি পরিবর্তন
              </h3>
              <p className="text-[11px] text-slate-500 font-medium">
                প্রোফাইল থেকে সরাসরি আপডেট করুন
              </p>
            </div>
          </div>
          <button
            id="close-profile-modal-btn"
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 transition-colors cursor-pointer"
            title="বন্ধ করুন"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Profile Photo Upload & Preview */}
          <div className="flex flex-col items-center justify-center p-4 bg-gradient-to-b from-sky-50/70 via-blue-50/40 to-slate-50 rounded-2xl border border-sky-100/70">
            <div className="relative group">
              <div
                onClick={() => fileInputRef.current?.click()}
                className="w-24 h-24 rounded-full overflow-hidden border-3 border-white shadow-lg bg-gradient-to-tr from-[#005ed9] via-[#0072CE] to-sky-400 flex items-center justify-center text-white text-3xl font-black cursor-pointer hover:opacity-95 transition-all relative"
                title="ছবি পরিবর্তন করতে ক্লিক করুন"
              >
                {editProfileImage ? (
                  <img
                    src={editProfileImage}
                    alt="Profile Preview"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span>{editName ? editName.charAt(0).toUpperCase() : 'U'}</span>
                )}
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <Camera className="w-6 h-6 text-white drop-shadow-md" />
                </div>
              </div>

              {/* Camera Action Badge */}
              <button
                id="profile-camera-badge-btn"
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-0 right-0 w-8 h-8 bg-gradient-to-r from-[#005ed9] to-[#0072CE] hover:from-[#004fa8] hover:to-[#005ed9] text-white rounded-full shadow-md flex items-center justify-center transition-transform active:scale-95 cursor-pointer border-2 border-white"
                title="ছবি নির্বাচন করুন"
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>

            {/* Hidden File Input */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageFileChange}
              className="hidden"
            />

            {/* Upload / Remove Buttons */}
            <div className="flex items-center gap-2 mt-3.5">
              <button
                id="profile-upload-image-btn"
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={imageUploading}
                className="px-3.5 py-1.5 bg-white hover:bg-purple-50 text-purple-700 font-extrabold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer border border-purple-200 shadow-2xs active:scale-95"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>
                  {imageUploading
                    ? 'আপলোড হচ্ছে...'
                    : editProfileImage
                    ? 'নতুন ছবি নির্বাচন'
                    : 'ছবি আপলোড করুন'}
                </span>
              </button>

              {editProfileImage && (
                <button
                  id="profile-remove-image-btn"
                  type="button"
                  onClick={handleRemoveImage}
                  className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 font-bold text-xs rounded-xl flex items-center gap-1 transition-colors cursor-pointer border border-rose-200 active:scale-95"
                  title="ছবি মুছে ফেলুন"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>মুছুন</span>
                </button>
              )}
            </div>
            <p className="text-[11px] text-slate-500 mt-2 font-medium text-center">
              গ্যালারি বা ক্যামেরা থেকে ছবি যুক্ত করুন
            </p>
          </div>

          {/* User Name Input */}
          <div>
            <label className="font-extrabold text-slate-800 text-xs block mb-1.5 text-center">
              আপনার নাম (Name)
            </label>
            <input
              id="profile-edit-name-input"
              type="text"
              required
              value={editName}
              onChange={(e) => setEditName(e.target.value)}
              placeholder="আপনার পূর্ণ নাম লিখুন"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 text-sm outline-none focus:border-[#0072CE] focus:bg-white transition-all shadow-inner text-center"
            />
          </div>

          {/* Save Button */}
          <button
            id="profile-edit-save-btn"
            type="submit"
            disabled={!editName.trim() || imageUploading}
            className="w-full max-w-[300px] mx-auto py-3 bg-gradient-to-r from-[#005ed9] to-[#0072CE] hover:from-[#004fa8] hover:to-[#005ed9] disabled:opacity-50 text-white font-semibold text-[16px] rounded-xl shadow-md shadow-sky-600/25 flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-98"
          >
            <Check className="w-4 h-4 stroke-[2.5]" />
            <span>পরিবর্তন সংরক্ষণ করুন</span>
          </button>
        </form>
      </div>
    </div>
  );
};
