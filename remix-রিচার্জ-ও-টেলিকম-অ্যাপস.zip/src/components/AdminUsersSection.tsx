import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Store,
  ShieldCheck,
  TrendingUp,
  Smartphone,
  KeyRound,
  Search,
  Check,
  Copy,
  PhoneCall,
  MessageCircle,
  Trash2,
  Folder,
  FolderOpen,
  ChevronRight,
  ShieldAlert,
  ShieldX,
  Wallet,
  Plus,
  Minus,
  CheckCircle2,
  AlertCircle,
  MapPin,
  Building,
  Mail,
  X,
  Lock,
  Unlock,
  RefreshCw,
  Pencil,
  User,
  Briefcase,
  Sliders,
  History,
  CheckSquare,
  Square,
  Calendar,
  AlertTriangle,
  Crown,
  Clock,
} from 'lucide-react';
import { UserProfile, DealerPermissions, SUPER_ADMIN_EMAIL } from '../types';
import {
  approveUserAsDealerInFirestore,
  updateDealerPermissionsInFirestore,
  suspendDealerInFirestore,
  reactivateDealerInFirestore,
  removeDealerRoleInFirestore,
  logActivityAuditToFirestore,
} from '../lib/firebase';

interface AdminUsersSectionProps {
  users: UserProfile[];
  currentUser?: UserProfile;
  currentAdminPhone?: string;
  onAddUser?: (newUser: UserProfile) => void;
  onUpdateUser?: (updated: UserProfile) => void;
  onDeleteUser?: (phone: string) => void;
  onToggleBlockUser?: (phone: string, isBlocked: boolean, reason?: string) => void;
  onAdjustBalance?: (
    phone: string,
    balanceType: 'main' | 'drive' | 'bank',
    amount: number,
    mode: 'add' | 'deduct' | 'set',
    note?: string
  ) => void;
  onShowToast?: (msg: string) => void;
  onOpenAuditLogs?: () => void;
}

export const AdminUsersSection: React.FC<AdminUsersSectionProps> = ({
  users,
  currentUser,
  currentAdminPhone,
  onAddUser,
  onUpdateUser,
  onDeleteUser,
  onToggleBlockUser,
  onAdjustBalance,
  onShowToast,
  onOpenAuditLogs,
}) => {
  // Folder & Search State
  const [selectedFolder, setSelectedFolder] = useState<
    'all' | 'Retailer' | 'Dealer' | 'Reseller' | 'Personal' | 'admin' | 'blocked' | null
  >(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedPhone, setCopiedPhone] = useState<string | null>(null);
  const [deletingPhone, setDeletingPhone] = useState<string | null>(null);

  // New User Form State
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newUserName, setNewUserName] = useState('');
  const [newUserPhone, setNewUserPhone] = useState('');
  const [newUserPin, setNewUserPin] = useState('1234');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserShop, setNewUserShop] = useState('');
  const [newUserDivision, setNewUserDivision] = useState('ঢাকা');
  const [newUserAddress, setNewUserAddress] = useState('');
  const [newUserAccountType, setNewUserAccountType] = useState<UserProfile['accountType']>('Retailer');
  const [newUserRole, setNewUserRole] = useState<'user' | 'admin'>('user');
  const [newUserMainBal, setNewUserMainBal] = useState('');
  const [newUserDriveBal, setNewUserDriveBal] = useState('');
  const [newUserBankBal, setNewUserBankBal] = useState('');
  const [userCreateError, setUserCreateError] = useState('');
  const [userCreateSuccess, setUserCreateSuccess] = useState(false);

  // Balance Adjustment Modal State
  const [balanceModalUser, setBalanceModalUser] = useState<UserProfile | null>(null);
  const [balanceType, setBalanceType] = useState<'main' | 'drive' | 'bank'>('main');
  const [balanceMode, setBalanceMode] = useState<'add' | 'deduct' | 'set'>('add');
  const [balanceAmount, setBalanceAmount] = useState<string>('');
  const [balanceNote, setBalanceNote] = useState<string>('');
  const [balanceCommissionRate, setBalanceCommissionRate] = useState<number>(0);
  const [customCommissionTk, setCustomCommissionTk] = useState<string>('');
  const [balanceAdjusting, setBalanceAdjusting] = useState<boolean>(false);

  // Block Modal State
  const [blockModalUser, setBlockModalUser] = useState<UserProfile | null>(null);
  const [blockReason, setBlockReason] = useState('নিয়ম লঙ্ঘন / সন্দেহজনক লেনদেন');

  // Customer PIN Recovery Modal State
  const [pinModalUser, setPinModalUser] = useState<UserProfile | null>(null);
  const [newPinValue, setNewPinValue] = useState('1234');

  // Edit Customer Modal State
  const [editModalUser, setEditModalUser] = useState<UserProfile | null>(null);
  const [editFormName, setEditFormName] = useState('');
  const [editFormPhone, setEditFormPhone] = useState('');
  const [editFormEmail, setEditFormEmail] = useState('');
  const [editFormPin, setEditFormPin] = useState('');
  const [editFormShop, setEditFormShop] = useState('');
  const [editFormDivision, setEditFormDivision] = useState('ঢাকা');
  const [editFormAddress, setEditFormAddress] = useState('');
  const [editFormAccountType, setEditFormAccountType] = useState<UserProfile['accountType']>('Retailer');
  const [editFormRole, setEditFormRole] = useState<'user' | 'admin'>('user');

  // Dealer Permissions & Suspension Modal State
  const [dealerPermModalUser, setDealerPermModalUser] = useState<UserProfile | null>(null);
  const [permManageOffers, setPermManageOffers] = useState(true);
  const [permManageOrders, setPermManageOrders] = useState(true);
  const [permManageAddMoney, setPermManageAddMoney] = useState(true);
  const [permManageRecharge, setPermManageRecharge] = useState(true);
  const [permManageTickets, setPermManageTickets] = useState(true);
  const [permViewUsers, setPermViewUsers] = useState(false);
  const [permExpiresDuration, setPermExpiresDuration] = useState<'never' | '1h' | '24h' | '3d' | '7d' | '30d'>('never');

  const [dealerSuspendModalUser, setDealerSuspendModalUser] = useState<UserProfile | null>(null);
  const [dealerSuspendReason, setDealerSuspendReason] = useState('সুপার এডমিন কর্তৃক সাময়িকভাবে স্থগিত');
  const [isDealerActionLoading, setIsDealerActionLoading] = useState(false);

  const divisions = [
    'ঢাকা',
    'চট্টগ্রাম',
    'রাজশাহী',
    'খুলনা',
    'বরিশাল',
    'সিলেট',
    'রংপুর',
    'ময়মনসিংহ',
  ];

  // Helper to check if a user is Super Admin
  const isSuperAdminUser = (u: UserProfile) =>
    u.isSuperAdmin === true ||
    u.appRole === 'super_admin' ||
    (u.email && u.email.toLowerCase().trim() === SUPER_ADMIN_EMAIL.toLowerCase()) ||
    u.phone === '01869875883' ||
    u.phone === '01918458908';

  // Helper to check if a user is a Dealer
  const isUserDealer = (u: UserProfile) =>
    !isSuperAdminUser(u) &&
    (u.accountType === 'Dealer' || u.appRole === 'dealer' || u.role === 'admin');

  // User Folders Definition
  const userFolders = [
    {
      id: 'all' as const,
      name: 'সকল গ্রাহক ফোল্ডার',
      desc: 'সিস্টেমের সকল নিবন্ধিত অ্যাকাউন্ট ও ব্যালেন্স',
      icon: Users,
      badgeColor: 'bg-indigo-100 text-indigo-800 border-indigo-200',
      folderBg: 'bg-indigo-50/70 hover:bg-indigo-50 border-indigo-200/80',
      iconBg: 'bg-indigo-600 text-white',
      usersList: users,
      count: users.length,
      totalBalance: users.reduce(
        (sum, u) => sum + (u.mainBalance || 0) + (u.driveBalance || 0) + (u.bankBalance || 0),
        0
      ),
    },
    {
      id: 'Retailer' as const,
      name: 'রিটেইলার ফোল্ডার',
      desc: 'দোকানদার ও রিটেইল সিম রিচার্জার অ্যাকাউন্ট',
      icon: Store,
      badgeColor: 'bg-purple-100 text-purple-800 border-purple-200',
      folderBg: 'bg-purple-50/70 hover:bg-purple-50 border-purple-200/80',
      iconBg: 'bg-purple-600 text-white',
      usersList: users.filter((u) => u.accountType === 'Retailer' && !isUserDealer(u)),
      count: users.filter((u) => u.accountType === 'Retailer' && !isUserDealer(u)).length,
      totalBalance: users
        .filter((u) => u.accountType === 'Retailer' && !isUserDealer(u))
        .reduce((sum, u) => sum + (u.mainBalance || 0) + (u.driveBalance || 0) + (u.bankBalance || 0), 0),
    },
    {
      id: 'Dealer' as const,
      name: 'ডিলার ফোল্ডার',
      desc: 'জেলা ও উপজেলা ডিলার ও ডিস্ট্রিবিউটর অ্যাকাউন্ট',
      icon: ShieldCheck,
      badgeColor: 'bg-amber-100 text-amber-800 border-amber-200',
      folderBg: 'bg-amber-50/70 hover:bg-amber-50 border-amber-200/80',
      iconBg: 'bg-amber-600 text-white',
      usersList: users.filter((u) => isUserDealer(u)),
      count: users.filter((u) => isUserDealer(u)).length,
      totalBalance: users
        .filter((u) => isUserDealer(u))
        .reduce((sum, u) => sum + (u.mainBalance || 0) + (u.driveBalance || 0) + (u.bankBalance || 0), 0),
    },
    {
      id: 'Reseller' as const,
      name: 'রিসেলার ফোল্ডার',
      desc: 'সাব-অ্যাডমিন ও রিটেল রিসেলার অ্যাকাউন্ট',
      icon: TrendingUp,
      badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      folderBg: 'bg-emerald-50/70 hover:bg-emerald-50 border-emerald-200/80',
      iconBg: 'bg-emerald-600 text-white',
      usersList: users.filter((u) => u.accountType === 'Reseller'),
      count: users.filter((u) => u.accountType === 'Reseller').length,
      totalBalance: users
        .filter((u) => u.accountType === 'Reseller')
        .reduce((sum, u) => sum + (u.mainBalance || 0) + (u.driveBalance || 0) + (u.bankBalance || 0), 0),
    },
    {
      id: 'Personal' as const,
      name: 'পার্সোনাল গ্রাহক ফোল্ডার',
      desc: 'ব্যক্তিগত গ্রাহক ও সাধারণ ইউজার অ্যাকাউন্ট',
      icon: Smartphone,
      badgeColor: 'bg-sky-100 text-sky-800 border-sky-200',
      folderBg: 'bg-sky-50/70 hover:bg-sky-50 border-sky-200/80',
      iconBg: 'bg-sky-600 text-white',
      usersList: users.filter(
        (u) => u.accountType === 'Personal' || (!u.accountType && u.role !== 'admin')
      ),
      count: users.filter(
        (u) => u.accountType === 'Personal' || (!u.accountType && u.role !== 'admin')
      ).length,
      totalBalance: users
        .filter((u) => u.accountType === 'Personal' || (!u.accountType && u.role !== 'admin'))
        .reduce((sum, u) => sum + (u.mainBalance || 0) + (u.driveBalance || 0) + (u.bankBalance || 0), 0),
    },
    {
      id: 'blocked' as const,
      name: 'ব্লকড ইউজার ফোল্ডার',
      desc: 'স্থগিত ও নিষিদ্ধ গ্রাহকদের তালিকা',
      icon: ShieldX,
      badgeColor: 'bg-rose-100 text-rose-800 border-rose-200',
      folderBg: 'bg-rose-50/70 hover:bg-rose-50 border-rose-200/80',
      iconBg: 'bg-rose-600 text-white',
      usersList: users.filter((u) => u.isBlocked),
      count: users.filter((u) => u.isBlocked).length,
      totalBalance: users
        .filter((u) => u.isBlocked)
        .reduce((sum, u) => sum + (u.mainBalance || 0) + (u.driveBalance || 0) + (u.bankBalance || 0), 0),
    },
    {
      id: 'admin' as const,
      name: 'অ্যাডমিন ও কন্ট্রোলার ফোল্ডার',
      desc: 'সুপার অ্যাডমিন ও কন্ট্রোল প্যানেল স্টাফ',
      icon: KeyRound,
      badgeColor: 'bg-rose-100 text-rose-800 border-rose-200',
      folderBg: 'bg-rose-50/70 hover:bg-rose-50 border-rose-200/80',
      iconBg: 'bg-rose-600 text-white',
      usersList: users.filter((u) => u.role === 'admin'),
      count: users.filter((u) => u.role === 'admin').length,
      totalBalance: users
        .filter((u) => u.role === 'admin')
        .reduce((sum, u) => sum + (u.mainBalance || 0) + (u.driveBalance || 0) + (u.bankBalance || 0), 0),
    },
  ];

  // Active User Folder Details & Filtered List
  const activeFolderObj = userFolders.find((f) => f.id === selectedFolder);
  const baseUsersList = activeFolderObj ? activeFolderObj.usersList : users;

  const currentFolderUsers = baseUsersList.filter((u, idx) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      (u.name && u.name.toLowerCase().includes(q)) ||
      (u.phone && u.phone.includes(q)) ||
      (u.shopName && u.shopName.toLowerCase().includes(q)) ||
      (u.currentAddress && u.currentAddress.toLowerCase().includes(q)) ||
      (u.division && u.division.toLowerCase().includes(q)) ||
      String(idx + 1).includes(q)
    );
  });

  const handleCopyCredentials = (u: UserProfile) => {
    const total = (u.mainBalance || 0) + (u.driveBalance || 0) + (u.bankBalance || 0);
    const info = `👤 নাম: ${u.name}\n📱 মোবাইল: ${u.phone}\n🔑 পিন: ${u.pin}\n🏪 দোকান: ${
      u.shopName || 'টেলিকম শপ'
    }\n💰 ব্যালেন্স: ৳${total} (মেইন: ৳${u.mainBalance || 0}, ড্রাইভ: ৳${u.driveBalance || 0}, ব্যাংক: ৳${
      u.bankBalance || 0
    })\n📍 বিভাগ: ${u.division || 'প্রযোজ্য নয়'}, ঠিকানা: ${u.currentAddress || 'প্রযোজ্য নয়'}`;
    navigator.clipboard.writeText(info);
    setCopiedPhone(u.phone);
    if (onShowToast) onShowToast(`ইউজার তথ্য কপি করা হয়েছে!`);
    setTimeout(() => setCopiedPhone(null), 2000);
  };

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    setUserCreateError('');
    if (!newUserName.trim() || !newUserPhone.trim()) {
      setUserCreateError('গ্রাহকের নাম ও মোবাইল নম্বর পূরণ করুন');
      return;
    }

    const formattedPhone = newUserPhone.replace(/[^0-9]/g, '');
    if (formattedPhone.length < 11) {
      setUserCreateError('১১ ডিজিটের সঠিক মোবাইল নাম্বার প্রদান করুন');
      return;
    }

    const phoneExists = users.some((u) => u.phone.replace(/[^0-9]/g, '') === formattedPhone);
    if (phoneExists) {
      setUserCreateError(`মোবাইল নম্বর (${newUserPhone}) ইতিমধ্যে নিবন্ধিত রয়েছে! ১ নম্বরে ১ অ্যাকাউন্ট।`);
      return;
    }

    const pinClean = newUserPin.trim();
    if (!pinClean || pinClean.length < 4) {
      setUserCreateError('গ্রাহকের জন্য ৪ সংখ্যার গোপন পিন কোড প্রদান করুন (যেমন: 1234)');
      return;
    }

    const createdUser: UserProfile = {
      name: newUserName.trim(),
      email: newUserEmail.trim() || undefined,
      phone: formattedPhone,
      pin: pinClean,
      shopName: newUserShop.trim() || 'টেলিকম শপ',
      division: newUserDivision,
      currentAddress: newUserAddress.trim() || undefined,
      mainBalance: parseFloat(newUserMainBal) || 0,
      driveBalance: parseFloat(newUserDriveBal) || 0,
      bankBalance: parseFloat(newUserBankBal) || 0,
      accountType: newUserAccountType,
      role: newUserRole,
      status: 'approved',
      isBlocked: false,
      serialNumber: users.length + 1,
      registeredAt: new Date().toISOString(),
    };

    if (onAddUser) {
      onAddUser(createdUser);
    }
    setUserCreateSuccess(true);
    if (onShowToast) onShowToast(`✅ ${createdUser.name} এর নতুন অ্যাকাউন্ট তৈরি সম্পন্ন হয়েছে!`);

    // Reset Form
    setNewUserName('');
    setNewUserPhone('');
    setNewUserPin('1234');
    setNewUserEmail('');
    setNewUserShop('');
    setNewUserAddress('');
    setNewUserMainBal('');
    setNewUserDriveBal('');
    setNewUserBankBal('');
    setTimeout(() => {
      setUserCreateSuccess(false);
      setShowCreateForm(false);
    }, 2000);
  };

  // Submit Balance Adjustment
  const handleBalanceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!balanceModalUser) return;
    const baseAmt = parseFloat(balanceAmount);
    if (isNaN(baseAmt) || baseAmt <= 0) {
      if (onShowToast) onShowToast('সঠিক টাকার পরিমাণ লিখুন');
      return;
    }

    // Calculate commission if in Add mode
    let commissionAmt = 0;
    if (balanceMode === 'add') {
      if (customCommissionTk) {
        commissionAmt = Math.max(0, parseFloat(customCommissionTk) || 0);
      } else if (balanceCommissionRate > 0) {
        commissionAmt = Math.round((baseAmt * balanceCommissionRate) / 100);
      }
    }

    const totalToCredit = balanceMode === 'add' ? baseAmt + commissionAmt : baseAmt;

    let finalNote = balanceNote.trim();
    if (balanceMode === 'add' && commissionAmt > 0) {
      const commDetail = `মূল: ৳${baseAmt} + কমিশন: ৳${commissionAmt}`;
      finalNote = finalNote ? `${finalNote} (${commDetail})` : commDetail;
    }

    setBalanceAdjusting(true);
    if (onAdjustBalance) {
      onAdjustBalance(
        balanceModalUser.phone,
        balanceType,
        totalToCredit,
        balanceMode,
        finalNote || undefined
      );
    }

    const typeBn = balanceType === 'drive' ? 'ড্রাইভ' : balanceType === 'bank' ? 'ব্যাংক' : 'কারেন্ট';
    const modeBn = balanceMode === 'add' ? 'যোগ' : balanceMode === 'deduct' ? 'কর্তন' : 'সেট';

    if (onShowToast) {
      if (balanceMode === 'add' && commissionAmt > 0) {
        onShowToast(`✅ ${balanceModalUser.name}-এর ${typeBn} ব্যালেন্সে মূল ৳${baseAmt} + কমিশন ৳${commissionAmt} সহ মোট ৳${totalToCredit} যোগ করা হয়েছে!`);
      } else {
        onShowToast(`✅ ${balanceModalUser.name}-এর ${typeBn} ব্যালেন্স ৳${totalToCredit} ${modeBn} করা হয়েছে!`);
      }
    }

    setBalanceAdjusting(false);
    setBalanceModalUser(null);
    setBalanceAmount('');
    setBalanceNote('');
    setBalanceCommissionRate(0);
    setCustomCommissionTk('');
  };

  // Submit Block / Unblock
  const handleToggleBlock = (u: UserProfile) => {
    if (u.isBlocked) {
      // Unblock directly
      if (onToggleBlockUser) {
        onToggleBlockUser(u.phone, false);
      }
      if (onShowToast) onShowToast(`✅ ${u.name}-এর অ্যাকাউন্ট সফলভাবে আনব্লক করা হয়েছে!`);
    } else {
      // Open modal to specify reason
      setBlockModalUser(u);
    }
  };

  const handleConfirmBlock = () => {
    if (!blockModalUser) return;
    if (onToggleBlockUser) {
      onToggleBlockUser(blockModalUser.phone, true, blockReason);
    }
    if (onShowToast) onShowToast(`🚫 ${blockModalUser.name}-এর অ্যাকাউন্ট ব্লক করা হয়েছে!`);
    setBlockModalUser(null);
  };

  // Quick Role Switching (ইউজার বনাম ডিলার)
  const handleSwitchRole = (u: UserProfile, newRole: 'user' | 'dealer') => {
    if (newRole === 'dealer') {
      handleOpenDealerPermissions(u);
      return;
    }
    handleRemoveDealer(u);
  };

  // Open Dealer Permissions Modal
  const handleOpenDealerPermissions = (u: UserProfile) => {
    setDealerPermModalUser(u);
    const existing = u.dealerPermissions || {};
    setPermManageOffers(existing.manageOffers !== false);
    setPermManageOrders(existing.manageOrders !== false);
    setPermManageAddMoney(existing.manageAddMoney !== false);
    setPermManageRecharge(existing.manageRecharge !== false);
    setPermManageTickets(existing.manageTickets !== false);
    setPermViewUsers(Boolean(existing.viewUsers));
    setPermExpiresDuration('never');
  };

  // Save Dealer Permissions (Super Admin only)
  const handleSaveDealerPermissions = async () => {
    if (!dealerPermModalUser) return;
    setIsDealerActionLoading(true);

    let expiresAt: string | undefined = undefined;
    const now = Date.now();
    if (permExpiresDuration === '1h') {
      expiresAt = new Date(now + 3600 * 1000).toISOString();
    } else if (permExpiresDuration === '24h') {
      expiresAt = new Date(now + 24 * 3600 * 1000).toISOString();
    } else if (permExpiresDuration === '3d') {
      expiresAt = new Date(now + 3 * 24 * 3600 * 1000).toISOString();
    } else if (permExpiresDuration === '7d') {
      expiresAt = new Date(now + 7 * 24 * 3600 * 1000).toISOString();
    } else if (permExpiresDuration === '30d') {
      expiresAt = new Date(now + 30 * 24 * 3600 * 1000).toISOString();
    }

    const safePermissions: DealerPermissions = {
      manageOffers: permManageOffers,
      manageOrders: permManageOrders,
      manageAddMoney: permManageAddMoney,
      manageRecharge: permManageRecharge,
      manageTickets: permManageTickets,
      viewUsers: permViewUsers,
      expiresAt,
      grantedAt: new Date().toISOString(),
      grantedBy: currentUser?.email || SUPER_ADMIN_EMAIL,
    };

    try {
      const actorInfo = {
        email: currentUser?.email || SUPER_ADMIN_EMAIL,
        name: currentUser?.name || 'Super Admin',
        phone: currentUser?.phone || currentAdminPhone,
      };

      if (!isUserDealer(dealerPermModalUser)) {
        await approveUserAsDealerInFirestore(dealerPermModalUser.phone, safePermissions, actorInfo);
      } else {
        await updateDealerPermissionsInFirestore(dealerPermModalUser.phone, safePermissions, actorInfo);
      }

      const updatedUser: UserProfile = {
        ...dealerPermModalUser,
        role: 'admin',
        appRole: 'dealer',
        accountType: 'Dealer',
        dealerStatus: 'active',
        dealerPermissions: safePermissions,
      };

      if (onUpdateUser) onUpdateUser(updatedUser);
      if (onShowToast) {
        onShowToast(`✓ ${dealerPermModalUser.name}-এর ডিলার পারমিশন সফলভাবে সংরক্ষিত হয়েছে!`);
      }
      setDealerPermModalUser(null);
    } catch (err) {
      console.error('Error saving dealer permissions:', err);
      if (onShowToast) onShowToast('⚠️ পারমিশন সংরক্ষণে সমস্যা হয়েছে, আবার চেষ্টা করুন।');
    } finally {
      setIsDealerActionLoading(false);
    }
  };

  // Suspend Dealer
  const handleOpenSuspendDealer = (u: UserProfile) => {
    setDealerSuspendModalUser(u);
    setDealerSuspendReason('সুপার এডমিন কর্তৃক সাময়িকভাবে স্থগিত');
  };

  const handleConfirmSuspendDealer = async () => {
    if (!dealerSuspendModalUser) return;
    setIsDealerActionLoading(true);
    try {
      const actorInfo = {
        email: currentUser?.email || SUPER_ADMIN_EMAIL,
        name: currentUser?.name || 'Super Admin',
        phone: currentUser?.phone || currentAdminPhone,
      };
      await suspendDealerInFirestore(dealerSuspendModalUser.phone, dealerSuspendReason, actorInfo);
      const updatedUser: UserProfile = {
        ...dealerSuspendModalUser,
        dealerStatus: 'suspended',
        dealerSuspendedReason: dealerSuspendReason,
        dealerSuspendedAt: new Date().toISOString(),
      };
      if (onUpdateUser) onUpdateUser(updatedUser);
      if (onShowToast) {
        onShowToast(`⚠️ ${dealerSuspendModalUser.name}-এর ডিলার সুবিধা সাময়িক স্থগিত করা হয়েছে।`);
      }
      setDealerSuspendModalUser(null);
    } catch (err) {
      console.error('Error suspending dealer:', err);
      if (onShowToast) onShowToast('⚠️ ডিলার স্থগিত করতে সমস্যা হয়েছে।');
    } finally {
      setIsDealerActionLoading(false);
    }
  };

  // Reactivate Dealer
  const handleReactivateDealer = async (u: UserProfile) => {
    setIsDealerActionLoading(true);
    try {
      const actorInfo = {
        email: currentUser?.email || SUPER_ADMIN_EMAIL,
        name: currentUser?.name || 'Super Admin',
        phone: currentUser?.phone || currentAdminPhone,
      };
      await reactivateDealerInFirestore(u.phone, actorInfo);
      const updatedUser: UserProfile = {
        ...u,
        dealerStatus: 'active',
        dealerSuspendedReason: '',
        dealerSuspendedAt: '',
      };
      if (onUpdateUser) onUpdateUser(updatedUser);
      if (onShowToast) {
        onShowToast(`✓ ${u.name}-এর ডিলার অ্যাকাউন্ট পুনরায় সক্রিয় করা হয়েছে!`);
      }
    } catch (err) {
      console.error('Error reactivating dealer:', err);
      if (onShowToast) onShowToast('⚠️ ডিলার সক্রিয় করতে সমস্যা হয়েছে।');
    } finally {
      setIsDealerActionLoading(false);
    }
  };

  // Remove Dealer Role
  const handleRemoveDealer = async (u: UserProfile) => {
    if (!window.confirm(`আপনি কি নিশ্চিত যে ${u.name}-এর ডিলার রোল বাতিল করে সাধারণ ইউজার করতে চান?`)) {
      return;
    }
    setIsDealerActionLoading(true);
    try {
      const actorInfo = {
        email: currentUser?.email || SUPER_ADMIN_EMAIL,
        name: currentUser?.name || 'Super Admin',
        phone: currentUser?.phone || currentAdminPhone,
      };
      await removeDealerRoleInFirestore(u.phone, actorInfo);
      const updatedUser: UserProfile = {
        ...u,
        role: 'user',
        appRole: 'user',
        accountType: 'Retailer',
        dealerStatus: 'pending',
        dealerPermissions: {},
      };
      if (onUpdateUser) onUpdateUser(updatedUser);
      if (onShowToast) {
        onShowToast(`✓ ${u.name}-এর ডিলার রোল বাতিল করে সাধারণ ইউজার করা হয়েছে।`);
      }
    } catch (err) {
      console.error('Error removing dealer role:', err);
      if (onShowToast) onShowToast('⚠️ ডিলার রোল বাতিল করতে সমস্যা হয়েছে।');
    } finally {
      setIsDealerActionLoading(false);
    }
  };

  // PIN Recovery Handler
  const handleOpenPinRecovery = (u: UserProfile) => {
    setPinModalUser(u);
    setNewPinValue('1234');
  };

  const handleSaveRecoveredPin = () => {
    if (!pinModalUser) return;
    const cleanPin = newPinValue.trim();
    if (!cleanPin || cleanPin.length < 4) {
      if (onShowToast) onShowToast('⚠️ ৪ সংখ্যার পিন প্রদান করুন (যেমন: 1234)');
      return;
    }
    const updatedUser: UserProfile = {
      ...pinModalUser,
      pin: cleanPin,
    };
    if (onUpdateUser) {
      onUpdateUser(updatedUser);
    }
    if (onShowToast) {
      onShowToast(`🔑 ${pinModalUser.name}-এর পিন সফলভাবে আপডেট করা হয়েছে: ${cleanPin}`);
    }
    setPinModalUser(null);
  };

  // Edit User Handler
  const handleOpenEdit = (u: UserProfile) => {
    setEditModalUser(u);
    setEditFormName(u.name || '');
    setEditFormPhone(u.phone || '');
    setEditFormEmail(u.email || '');
    setEditFormPin(u.pin || '1234');
    setEditFormShop(u.shopName || '');
    setEditFormDivision(u.division || 'ঢাকা');
    setEditFormAddress(u.currentAddress || '');
    setEditFormAccountType(u.accountType || 'Retailer');
    setEditFormRole(u.role || 'user');
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editModalUser) return;
    if (!editFormName.trim()) {
      if (onShowToast) onShowToast('গ্রাহকের নাম আবশ্যক');
      return;
    }
    const updatedUser: UserProfile = {
      ...editModalUser,
      name: editFormName.trim(),
      email: editFormEmail.trim() || undefined,
      pin: editFormPin.trim() || editModalUser.pin || '1234',
      shopName: editFormShop.trim() || 'টেলিকম শপ',
      division: editFormDivision,
      currentAddress: editFormAddress.trim() || undefined,
      accountType: editFormAccountType,
      role: editFormRole,
    };
    if (onUpdateUser) {
      onUpdateUser(updatedUser);
    }
    if (onShowToast) {
      onShowToast(`✅ ${updatedUser.name}-এর তথ্য সফলভাবে সংরক্ষণ করা হয়েছে!`);
    }
    setEditModalUser(null);
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      {/* Top Header Card: Title + Add User Toggle */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-black text-slate-900 text-sm leading-tight">
              সকল গ্রাহক ও ইউজার কন্ট্রোল
            </h2>
            <p className="text-[10px] text-slate-500 font-medium">
              ব্যালেন্স সরাসরি যোগ, ব্লক/আনব্লক ও বিস্তারিত প্রোফাইল ব্যবস্থাপনা
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {onOpenAuditLogs && (
            <button
              type="button"
              id="open-audit-logs-section-btn"
              onClick={onOpenAuditLogs}
              className="px-3 py-2 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-extrabold text-xs rounded-xl shadow-2xs flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
              title="অ্যাক্টিভিটি ও ডিলার অডিট লগ দেখুন"
            >
              <History className="w-3.5 h-3.5 text-amber-700" />
              <span className="hidden sm:inline">অডিট লগ</span>
            </button>
          )}

          <button
            type="button"
            id="toggle-create-user-form-btn"
            onClick={() => setShowCreateForm(!showCreateForm)}
            className="px-3 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer shrink-0"
          >
            {showCreateForm ? (
              <>
                <X className="w-3.5 h-3.5" />
                <span>বন্ধ করুন</span>
              </>
            ) : (
              <>
                <UserPlus className="w-3.5 h-3.5" />
                <span>নতুন ইউজার</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 1. Create User Accordion Form */}
      {showCreateForm && (
        <section className="bg-white rounded-3xl p-5 border border-indigo-200 shadow-sm space-y-4 animate-fadeIn">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <UserPlus className="w-4 h-4 text-indigo-600" />
              <h3 className="font-extrabold text-slate-900 text-xs">
                নতুন ইউজার অ্যাকাউন্ট নিবন্ধন ফর্ম
              </h3>
            </div>
            <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full">
              তাৎক্ষণিক লাইভ
            </span>
          </div>

          <form onSubmit={handleCreateUser} className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  গ্রাহকের পূর্ণ নাম *
                </label>
                <input
                  type="text"
                  required
                  value={newUserName}
                  onChange={(e) => setNewUserName(e.target.value)}
                  placeholder="যেমন: মোঃ সুমন ইসলাম"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 outline-none focus:border-indigo-600 focus:bg-white"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  মোবাইল নম্বর (লগইন আইডি) *
                </label>
                <div className="flex items-center rounded-xl bg-slate-50 border border-slate-200 focus-within:border-indigo-600 focus-within:bg-white overflow-hidden">
                  <div className="px-2.5 py-2 bg-slate-100 border-r border-slate-200 text-slate-700 text-xs font-bold shrink-0">
                    🇧🇩 +880
                  </div>
                  <input
                    type="tel"
                    required
                    value={newUserPhone.replace(/^(\+880|880|0)/, '')}
                    onChange={(e) => {
                      const val = e.target.value.replace(/[^0-9]/g, '');
                      setNewUserPhone(val ? `0${val}` : '');
                    }}
                    placeholder="17XXXXXXXX"
                    className="w-full px-2.5 py-2 bg-transparent text-xs font-bold text-slate-900 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  ৪ সংখ্যার গোপন পিন (PIN) *
                </label>
                <input
                  type="text"
                  maxLength={4}
                  required
                  value={newUserPin}
                  onChange={(e) => setNewUserPin(e.target.value.replace(/[^0-9]/g, ''))}
                  placeholder="1234"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-black text-indigo-600 outline-none focus:border-indigo-600 focus:bg-white text-center tracking-widest"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  দোকান / ব্যবসার নাম
                </label>
                <input
                  type="text"
                  value={newUserShop}
                  onChange={(e) => setNewUserShop(e.target.value)}
                  placeholder="যেমন: সুমন টেলিকম"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 outline-none focus:border-indigo-600 focus:bg-white"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  বিভাগ নির্বাচন
                </label>
                <select
                  value={newUserDivision}
                  onChange={(e) => setNewUserDivision(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 outline-none focus:border-indigo-600 cursor-pointer"
                >
                  {divisions.map((div) => (
                    <option key={div} value={div}>
                      {div} বিভাগ
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  বর্তমান ঠিকানা (থানা/জেলা)
                </label>
                <input
                  type="text"
                  value={newUserAddress}
                  onChange={(e) => setNewUserAddress(e.target.value)}
                  placeholder="যেমন: মিরপুর-১০, ঢাকা"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 outline-none focus:border-indigo-600 focus:bg-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  অ্যাকাউন্ট টাইপ
                </label>
                <select
                  value={newUserAccountType}
                  onChange={(e) => setNewUserAccountType(e.target.value as any)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 outline-none focus:border-indigo-600 cursor-pointer"
                >
                  <option value="Retailer">Retailer (রিটেইলার)</option>
                  <option value="Dealer">Dealer (ডিলার)</option>
                  <option value="Reseller">Reseller (রিসেলার)</option>
                  <option value="Personal">Personal (ব্যক্তিগত)</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  ভূমিকা / রোল
                </label>
                <select
                  value={newUserRole}
                  onChange={(e) => setNewUserRole(e.target.value as any)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 outline-none focus:border-indigo-600 cursor-pointer"
                >
                  <option value="user">সাধারণ গ্রাহক (User)</option>
                  <option value="admin">অ্যাডমিন (Admin)</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  ইমেইল ঠিকানা (ঐচ্ছিক)
                </label>
                <input
                  type="email"
                  value={newUserEmail}
                  onChange={(e) => setNewUserEmail(e.target.value)}
                  placeholder="user@gmail.com"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-900 outline-none focus:border-indigo-600 focus:bg-white"
                />
              </div>
            </div>

            {/* Initial Balances */}
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200">
              <span className="text-[11px] font-extrabold text-slate-800 block mb-2">
                💰 প্রারম্ভিক ব্যালেন্স জমা (ঐচ্ছিক)
              </span>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[10px] font-bold text-emerald-800 block mb-0.5">
                    মেইন ব্যালেন্স (৳)
                  </label>
                  <input
                    type="number"
                    value={newUserMainBal}
                    onChange={(e) => setNewUserMainBal(e.target.value)}
                    placeholder="0"
                    className="w-full p-2 bg-white border border-emerald-200 rounded-xl text-xs font-bold text-emerald-950 outline-none focus:border-emerald-600"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-purple-800 block mb-0.5">
                    ড্রাইভ ব্যালেন্স (৳)
                  </label>
                  <input
                    type="number"
                    value={newUserDriveBal}
                    onChange={(e) => setNewUserDriveBal(e.target.value)}
                    placeholder="0"
                    className="w-full p-2 bg-white border border-purple-200 rounded-xl text-xs font-bold text-purple-950 outline-none focus:border-purple-600"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-blue-800 block mb-0.5">
                    ব্যাংক ব্যালেন্স (৳)
                  </label>
                  <input
                    type="number"
                    value={newUserBankBal}
                    onChange={(e) => setNewUserBankBal(e.target.value)}
                    placeholder="0"
                    className="w-full p-2 bg-white border border-blue-200 rounded-xl text-xs font-bold text-blue-950 outline-none focus:border-blue-600"
                  />
                </div>
              </div>
            </div>

            {userCreateError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2 text-rose-800 text-xs font-bold">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span>{userCreateError}</span>
              </div>
            )}

            {userCreateSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-emerald-800 text-xs font-bold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>ইউজার অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে!</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-extrabold text-xs rounded-xl shadow-md flex items-center justify-center gap-2 transition-all active:scale-98 cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>নিবন্ধন নিশ্চিত করুন</span>
            </button>
          </form>
        </section>
      )}

      {/* 2. Folder Navigation Cards (Outside folder) */}
      {!selectedFolder ? (
        <section className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-1.5">
              <Folder className="w-4 h-4 text-indigo-600" />
              <h3 className="text-xs font-extrabold text-slate-900">
                গ্রাহক ফোল্ডার সমূহ (ক্লিক করে ভেতরে দেখুন)
              </h3>
            </div>
            <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
              মোট ক্যাটাগরি: {userFolders.length} টি
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {userFolders.map((fld) => {
              const FldIcon = fld.icon;
              return (
                <div
                  key={fld.id}
                  id={`user-folder-${fld.id}`}
                  onClick={() => {
                    setSelectedFolder(fld.id);
                    setSearchQuery('');
                  }}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer hover:shadow-md hover:scale-[1.01] active:scale-98 ${fld.folderBg} flex flex-col justify-between gap-3 group`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-10 h-10 rounded-xl ${fld.iconBg} flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform`}
                      >
                        <FldIcon className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-extrabold text-slate-900 text-xs leading-tight group-hover:text-indigo-700 transition-colors">
                          {fld.name}
                        </h4>
                        <p className="text-[10px] text-slate-500 font-medium line-clamp-1 mt-0.5">
                          {fld.desc}
                        </p>
                      </div>
                    </div>
                    <span
                      className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${fld.badgeColor} shrink-0`}
                    >
                      {fld.count} জন
                    </span>
                  </div>

                  <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px]">
                    <span className="font-bold text-slate-600">
                      ব্যালেন্স: ৳{fld.totalBalance.toLocaleString('bn-BD')}
                    </span>
                    <span className="font-extrabold text-indigo-700 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                      <span>ফোল্ডার খুলুন</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      ) : (
        /* 3. Folder Inside: Detailed User List with Block/Unblock & Balance Adjust */
        <section className="bg-white rounded-3xl p-5 border border-indigo-200 shadow-xs space-y-4 animate-fadeIn">
          {/* Header Bar */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 gap-2 flex-wrap">
            <div className="flex items-center gap-2">
              <button
                type="button"
                id="back-to-all-user-folders-btn"
                onClick={() => {
                  setSelectedFolder(null);
                  setSearchQuery('');
                }}
                className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-extrabold flex items-center gap-1 transition-all active:scale-95 cursor-pointer"
              >
                <FolderOpen className="w-3.5 h-3.5 text-indigo-600" />
                <span>সকল ফোল্ডার</span>
              </button>
              <h3 className="text-xs font-black text-slate-900">{activeFolderObj?.name}</h3>
            </div>

            <span
              className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full border ${activeFolderObj?.badgeColor}`}
            >
              মোট: {currentFolderUsers.length} জন
            </span>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              id="admin-search-user-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="নাম, মোবাইল নম্বর, দোকান, বিভাগ বা ঠিকানা দিয়ে খুঁজুন..."
              className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 outline-none focus:border-indigo-600 focus:bg-white transition-all placeholder:text-slate-400"
            />
          </div>

          {/* User Cards List */}
          <div className="space-y-3 max-h-[600px] overflow-y-auto pr-0.5">
            {currentFolderUsers.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-slate-400 text-xs space-y-1">
                <Users className="w-8 h-8 mx-auto text-slate-300 mb-1" />
                <p className="font-bold">কোনো ইউজার পাওয়া যায়নি।</p>
                <p className="text-[10px]">সার্চ কোয়েরি বা ফিল্টার পরিবর্তন করে দেখুন।</p>
              </div>
            ) : (
              currentFolderUsers.map((u, idx) => {
                const totalBal = (u.mainBalance || 0) + (u.driveBalance || 0) + (u.bankBalance || 0);
                const isCurrentAdmin = u.phone === currentAdminPhone;
                const isBlocked = Boolean(u.isBlocked);

                return (
                  <div
                    key={u.phone + idx}
                    className={`p-4 rounded-2xl border transition-all space-y-3 ${
                      isBlocked
                        ? 'bg-rose-50/70 border-rose-200 shadow-2xs'
                        : 'bg-slate-50/80 hover:bg-slate-50 border-slate-200/90 shadow-xs'
                    }`}
                  >
                    {/* Top Row: Serial, Name, Status Badge, Role */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-2.5">
                        {/* Serial & Avatar */}
                        <div className="relative">
                          <div
                            className={`w-11 h-11 rounded-2xl text-white font-black flex items-center justify-center text-sm shadow-xs shrink-0 overflow-hidden ${
                              isBlocked
                                ? 'bg-rose-600'
                                : u.role === 'admin'
                                ? 'bg-amber-600'
                                : 'bg-gradient-to-tr from-indigo-600 to-purple-600'
                            }`}
                          >
                            {u.profileImage ? (
                              <img src={u.profileImage} alt={u.name} className="w-full h-full object-cover" />
                            ) : (
                              u.name ? u.name.charAt(0).toUpperCase() : 'U'
                            )}
                          </div>
                          <span className="absolute -bottom-1 -right-1 px-1.5 py-0.2 bg-slate-900 text-white rounded-md text-[9px] font-mono font-bold">
                            #{u.serialNumber || idx + 1}
                          </span>
                        </div>

                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h4 className="font-black text-slate-900 text-xs">{u.name}</h4>
                            <span
                              className={`text-[9px] font-extrabold px-2 py-0.5 rounded-md border ${
                                u.role === 'admin'
                                  ? 'bg-amber-100 text-amber-800 border-amber-200'
                                  : 'bg-indigo-100 text-indigo-700 border-indigo-200'
                              }`}
                            >
                              {u.accountType || 'Retailer'} {u.role === 'admin' ? '• Admin' : ''}
                            </span>

                            {/* Status Pill */}
                            {isBlocked ? (
                              <span className="text-[9px] font-black px-2 py-0.5 rounded-md bg-rose-100 text-rose-700 border border-rose-300 flex items-center gap-1 animate-pulse">
                                <Lock className="w-2.5 h-2.5" />
                                <span>ব্লক করা</span>
                              </span>
                            ) : (
                              <span className="text-[9px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                                <CheckCircle2 className="w-2.5 h-2.5" />
                                <span>সক্রিয়</span>
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-2 text-[11px] text-slate-600 font-mono mt-1">
                            <span>📱 {u.phone}</span>
                            <span>•</span>
                            <span className="font-bold text-indigo-700 bg-indigo-50 px-1.5 py-0.2 rounded border border-indigo-100">
                              🔑 পিন: {u.pin}
                            </span>
                          </div>

                          {/* Address & Shop details */}
                          <div className="flex items-center gap-3 text-[10px] text-slate-500 font-medium mt-1 flex-wrap">
                            {u.shopName && (
                              <span className="flex items-center gap-1">
                                <Store className="w-3 h-3 text-slate-400" />
                                <span>{u.shopName}</span>
                              </span>
                            )}
                            {u.division && (
                              <span className="flex items-center gap-1 text-slate-600">
                                <Building className="w-3 h-3 text-indigo-500" />
                                <span>{u.division} বিভাগ</span>
                              </span>
                            )}
                            {u.currentAddress && (
                              <span className="flex items-center gap-1 text-slate-600">
                                <MapPin className="w-3 h-3 text-rose-400" />
                                <span>{u.currentAddress}</span>
                              </span>
                            )}
                            {u.email && (
                              <span className="flex items-center gap-1 text-pink-700">
                                <Mail className="w-3 h-3 text-pink-400" />
                                <span>{u.email}</span>
                              </span>
                            )}
                          </div>

                          {isBlocked && u.blockReason && (
                            <p className="text-[10px] text-rose-600 font-medium bg-rose-100/70 px-2 py-0.5 rounded-md mt-1">
                              ⚠️ কারণ: {u.blockReason}
                            </p>
                          )}

                          {/* Quick Role Switcher Buttons: User vs Dealer */}
                          {!isCurrentAdmin && (
                            <div className="mt-2 space-y-1.5">
                              {isUserDealer(u) ? (
                                <div className="p-2 rounded-xl bg-amber-50/70 border border-amber-200/80 space-y-2">
                                  {/* Dealer Header & Status */}
                                  <div className="flex items-center justify-between gap-1.5 flex-wrap">
                                    <div className="flex items-center gap-1.5">
                                      <span className="px-2 py-0.5 rounded-lg bg-amber-600 text-white text-[10px] font-black flex items-center gap-1 shadow-2xs">
                                        <Crown className="w-3 h-3" />
                                        <span>ডিলার</span>
                                      </span>
                                      {u.dealerStatus === 'suspended' ? (
                                        <span className="px-2 py-0.5 rounded-lg bg-rose-100 text-rose-800 text-[10px] font-black border border-rose-200">
                                          ⚠️ স্থগিত
                                        </span>
                                      ) : (
                                        <span className="px-2 py-0.5 rounded-lg bg-emerald-100 text-emerald-800 text-[10px] font-black border border-emerald-200">
                                          ✓ সক্রিয়
                                        </span>
                                      )}
                                      {u.dealerPermissions?.expiresAt && (
                                        <span className="px-2 py-0.5 rounded-lg bg-indigo-50 text-indigo-700 text-[9px] font-bold border border-indigo-200">
                                          ⏳ মেয়াদ: {new Date(u.dealerPermissions.expiresAt).toLocaleDateString('bn-BD')}
                                        </span>
                                      )}
                                    </div>

                                    {/* Action Buttons for Dealer */}
                                    <div className="flex items-center gap-1">
                                      <button
                                        type="button"
                                        id={`configure-dealer-perms-${u.phone}`}
                                        onClick={() => handleOpenDealerPermissions(u)}
                                        className="px-2 py-1 bg-white hover:bg-amber-100 text-amber-900 text-[10px] font-black rounded-lg border border-amber-300 flex items-center gap-1 transition-all active:scale-95 cursor-pointer shadow-2xs"
                                        title="ডিলার পারমিশন কনফিগার করুন"
                                      >
                                        <Sliders className="w-3 h-3 text-amber-600" />
                                        <span>পারমিশন</span>
                                      </button>

                                      {u.dealerStatus === 'suspended' ? (
                                        <button
                                          type="button"
                                          id={`reactivate-dealer-${u.phone}`}
                                          onClick={() => handleReactivateDealer(u)}
                                          disabled={isDealerActionLoading}
                                          className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-black rounded-lg transition-all active:scale-95 cursor-pointer shadow-2xs flex items-center gap-1"
                                          title="ডিলার পুনরায় সক্রিয় করুন"
                                        >
                                          <Check className="w-3 h-3" />
                                          <span>সক্রিয়</span>
                                        </button>
                                      ) : (
                                        <button
                                          type="button"
                                          id={`suspend-dealer-${u.phone}`}
                                          onClick={() => handleOpenSuspendDealer(u)}
                                          disabled={isDealerActionLoading}
                                          className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 text-[10px] font-black rounded-lg border border-rose-200 transition-all active:scale-95 cursor-pointer flex items-center gap-1"
                                          title="ডিলার সাময়িক স্থগিত করুন"
                                        >
                                          <AlertTriangle className="w-3 h-3 text-rose-500" />
                                          <span>স্থগিত</span>
                                        </button>
                                      )}

                                      <button
                                        type="button"
                                        id={`remove-dealer-role-${u.phone}`}
                                        onClick={() => handleRemoveDealer(u)}
                                        disabled={isDealerActionLoading}
                                        className="px-1.5 py-1 bg-white hover:bg-slate-100 text-slate-500 hover:text-rose-600 text-[10px] font-bold rounded-lg border border-slate-200 transition-all active:scale-95 cursor-pointer"
                                        title="ডিলার রোল বাতিল করে সাধারণ ইউজার বানান"
                                      >
                                        <X className="w-3 h-3" />
                                      </button>
                                    </div>
                                  </div>

                                  {/* Permissions Tags */}
                                  <div className="flex items-center gap-1 flex-wrap text-[9px] font-bold">
                                    <span className="text-slate-500">অনুমতি:</span>
                                    <span
                                      className={`px-1.5 py-0.5 rounded ${
                                        u.dealerPermissions?.manageOffers !== false
                                          ? 'bg-purple-100 text-purple-800'
                                          : 'bg-slate-100 text-slate-400 line-through'
                                      }`}
                                    >
                                      অফার
                                    </span>
                                    <span
                                      className={`px-1.5 py-0.5 rounded ${
                                        u.dealerPermissions?.manageOrders !== false
                                          ? 'bg-indigo-100 text-indigo-800'
                                          : 'bg-slate-100 text-slate-400 line-through'
                                      }`}
                                    >
                                      অর্ডার
                                    </span>
                                    <span
                                      className={`px-1.5 py-0.5 rounded ${
                                        u.dealerPermissions?.manageAddMoney !== false
                                          ? 'bg-emerald-100 text-emerald-800'
                                          : 'bg-slate-100 text-slate-400 line-through'
                                      }`}
                                    >
                                      অ্যাড মানি
                                    </span>
                                    <span
                                      className={`px-1.5 py-0.5 rounded ${
                                        u.dealerPermissions?.manageRecharge !== false
                                          ? 'bg-blue-100 text-blue-800'
                                          : 'bg-slate-100 text-slate-400 line-through'
                                      }`}
                                    >
                                      রিচার্জ
                                    </span>
                                    <span
                                      className={`px-1.5 py-0.5 rounded ${
                                        u.dealerPermissions?.manageTickets !== false
                                          ? 'bg-amber-100 text-amber-800'
                                          : 'bg-slate-100 text-slate-400 line-through'
                                      }`}
                                    >
                                      সাপোর্ট
                                    </span>
                                    <span
                                      className={`px-1.5 py-0.5 rounded ${
                                        u.dealerPermissions?.viewUsers
                                          ? 'bg-teal-100 text-teal-800 font-black'
                                          : 'bg-slate-100 text-slate-400 line-through'
                                      }`}
                                    >
                                      ইউজার ভিউ
                                    </span>
                                  </div>
                                </div>
                              ) : (
                                <div className="flex items-center gap-1.5 bg-slate-100/80 p-1 rounded-xl border border-slate-200 w-fit">
                                  <span className="text-[10px] font-black text-slate-700 pl-1">রোল:</span>
                                  <button
                                    type="button"
                                    id={`switch-user-role-${u.phone}`}
                                    onClick={() => handleSwitchRole(u, 'user')}
                                    className="px-2 py-0.5 rounded-lg text-[10px] font-black transition-all cursor-pointer flex items-center gap-1 bg-blue-600 text-white shadow-xs"
                                  >
                                    <User className="w-2.5 h-2.5" />
                                    <span>👤 সাধারণ ইউজার</span>
                                  </button>
                                  <button
                                    type="button"
                                    id={`switch-dealer-role-${u.phone}`}
                                    onClick={() => handleOpenDealerPermissions(u)}
                                    className="px-2 py-0.5 rounded-lg text-[10px] font-black transition-all cursor-pointer flex items-center gap-1 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200"
                                  >
                                    <Briefcase className="w-2.5 h-2.5 text-amber-600" />
                                    <span>💼 ডিলার বানান</span>
                                  </button>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Total balance display */}
                      <div className="text-right shrink-0">
                        <span className="text-[9px] text-slate-500 block font-medium">মোট ব্যালেন্স</span>
                        <span className="font-mono font-black text-slate-900 text-sm">
                          ৳{totalBal.toLocaleString('bn-BD')}
                        </span>
                      </div>
                    </div>

                    {/* Middle Row: 3 Individual Balances Display */}
                    <div className="grid grid-cols-3 gap-1.5 p-2 bg-white rounded-xl border border-slate-200/80 text-center">
                      <div className="p-1 rounded-lg bg-emerald-50/50">
                        <span className="text-[9px] font-bold text-emerald-800 block">কারেন্ট ব্যালেন্স</span>
                        <span className="text-xs font-mono font-black text-emerald-950">
                          ৳{u.mainBalance || 0}
                        </span>
                      </div>
                      <div className="p-1 rounded-lg bg-purple-50/50">
                        <span className="text-[9px] font-bold text-purple-800 block">ড্রাইভ ব্যালেন্স</span>
                        <span className="text-xs font-mono font-black text-purple-950">
                          ৳{u.driveBalance || 0}
                        </span>
                      </div>
                      <div className="p-1 rounded-lg bg-blue-50/50">
                        <span className="text-[9px] font-bold text-blue-800 block">ব্যাংক ব্যালেন্স</span>
                        <span className="text-xs font-mono font-black text-blue-950">
                          ৳{u.bankBalance || 0}
                        </span>
                      </div>
                    </div>

                    {/* Bottom Row: Actions Bar */}
                    <div className="pt-2 border-t border-slate-200/70 flex items-center justify-between gap-1.5 flex-wrap">
                      {/* Left: Direct Balance, PIN Recovery, Edit, Block */}
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {/* Direct Balance Add Button */}
                        <button
                          type="button"
                          id={`adjust-balance-btn-${u.phone}`}
                          onClick={() => {
                            setBalanceModalUser(u);
                            setBalanceType('main');
                            setBalanceMode('add');
                            setBalanceAmount('');
                            setBalanceNote('');
                          }}
                          className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-[10px] font-extrabold rounded-lg shadow-2xs flex items-center gap-1 transition-all cursor-pointer"
                        >
                          <Wallet className="w-3 h-3" />
                          <span>ব্যালেন্স</span>
                        </button>

                        {/* Customer PIN Recovery Button */}
                        <button
                          type="button"
                          id={`pin-recovery-btn-${u.phone}`}
                          onClick={() => handleOpenPinRecovery(u)}
                          className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 active:scale-95 text-amber-800 text-[10px] font-extrabold rounded-lg border border-amber-200 shadow-2xs flex items-center gap-1 transition-all cursor-pointer"
                          title="গ্রাহকের পিন রিকভারি বা পরিবর্তন করুন"
                        >
                          <KeyRound className="w-3 h-3 text-amber-600" />
                          <span>পিন রিকভারি</span>
                        </button>

                        {/* Customer Edit Button */}
                        <button
                          type="button"
                          id={`edit-customer-btn-${u.phone}`}
                          onClick={() => handleOpenEdit(u)}
                          className="px-2.5 py-1 bg-sky-50 hover:bg-sky-100 active:scale-95 text-sky-800 text-[10px] font-extrabold rounded-lg border border-sky-200 shadow-2xs flex items-center gap-1 transition-all cursor-pointer"
                          title="গ্রাহকের তথ্য এডিট করুন"
                        >
                          <Pencil className="w-3 h-3 text-sky-600" />
                          <span>এডিট</span>
                        </button>

                        {/* Block / Unblock Toggle Button */}
                        {!isCurrentAdmin && (
                          <button
                            type="button"
                            id={`block-toggle-btn-${u.phone}`}
                            onClick={() => handleToggleBlock(u)}
                            className={`px-2 py-1 text-[10px] font-extrabold rounded-lg border transition-all active:scale-95 cursor-pointer flex items-center gap-1 ${
                              isBlocked
                                ? 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border-emerald-300'
                                : 'bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200'
                            }`}
                          >
                            {isBlocked ? (
                              <>
                                <Unlock className="w-3 h-3 text-emerald-600" />
                                <span>আনব্লক</span>
                              </>
                            ) : (
                              <>
                                <Lock className="w-3 h-3 text-rose-600" />
                                <span>ব্লক</span>
                              </>
                            )}
                          </button>
                        )}
                      </div>

                      {/* Right: Quick Communications & Delete */}
                      <div className="flex items-center gap-1">
                        {/* Copy Info */}
                        <button
                          type="button"
                          onClick={() => handleCopyCredentials(u)}
                          className="px-2 py-1 bg-white hover:bg-slate-100 text-slate-700 text-[10px] font-bold rounded-lg border border-slate-200 flex items-center gap-1 transition-colors cursor-pointer"
                          title="লগইন তথ্য কপি করুন"
                        >
                          {copiedPhone === u.phone ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-600" />
                              <span className="text-emerald-600">কপি হয়েছে</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3 text-slate-500" />
                              <span>কপি</span>
                            </>
                          )}
                        </button>

                        {/* Direct Call */}
                        <a
                          href={`tel:${u.phone}`}
                          className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg transition-colors"
                          title="সরাসরি কল দিন"
                        >
                          <PhoneCall className="w-3.5 h-3.5" />
                        </a>

                        {/* WhatsApp Message */}
                        <a
                          href={`https://wa.me/88${u.phone.replace(/[^0-9]/g, '')}`}
                          target="_blank"
                          rel="noreferrer"
                          className="p-1.5 bg-green-50 hover:bg-green-100 text-green-700 rounded-lg transition-colors"
                          title="WhatsApp-এ বার্তা পাঠান"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                        </a>

                        {/* Delete User */}
                        {onDeleteUser && !isCurrentAdmin && (
                          <div>
                            {deletingPhone === u.phone ? (
                              <div className="flex items-center gap-1 bg-rose-50 p-1 rounded-lg border border-rose-200">
                                <span className="text-[9px] font-bold text-rose-700">মুছবেন?</span>
                                <button
                                  type="button"
                                  onClick={() => {
                                    onDeleteUser(u.phone);
                                    setDeletingPhone(null);
                                    if (onShowToast) onShowToast(`${u.name} অ্যাকাউন্টটি মুছে ফেলা হয়েছে`);
                                  }}
                                  className="px-1.5 py-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded text-[9px] font-black cursor-pointer"
                                >
                                  হ্যাঁ
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setDeletingPhone(null)}
                                  className="px-1.5 py-0.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded text-[9px] font-bold cursor-pointer"
                                >
                                  না
                                </button>
                              </div>
                            ) : (
                              <button
                                type="button"
                                onClick={() => setDeletingPhone(u.phone)}
                                className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg transition-colors cursor-pointer"
                                title="ইউজার ডিলিট করুন"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>
      )}

      {/* ========================================================= */}
      {/* MODAL 1: DIRECT BALANCE ADJUSTMENT (মেইন, ড্রাইভ, ব্যাংক) */}
      {/* ========================================================= */}
      {balanceModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 border border-slate-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <Wallet className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-black text-slate-900">
                    ব্যালেন্স সরাসরি যোগ / সমন্বয়
                  </h3>
                  <p className="text-[10px] text-slate-500 font-medium">
                    {balanceModalUser.name} ({balanceModalUser.phone})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setBalanceModalUser(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleBalanceSubmit} className="space-y-3.5">
              {/* 1. Select Balance Type */}
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  ব্যালেন্স টাইপ নির্বাচন করুন
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setBalanceType('main')}
                    className={`py-2 px-1 text-center rounded-xl font-extrabold text-xs border transition-all cursor-pointer ${
                      balanceType === 'main'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : 'bg-emerald-50 text-emerald-900 border-emerald-200'
                    }`}
                  >
                    মেইন (৳{balanceModalUser.mainBalance || 0})
                  </button>

                  <button
                    type="button"
                    onClick={() => setBalanceType('drive')}
                    className={`py-2 px-1 text-center rounded-xl font-extrabold text-xs border transition-all cursor-pointer ${
                      balanceType === 'drive'
                        ? 'bg-purple-600 text-white border-purple-600 shadow-xs'
                        : 'bg-purple-50 text-purple-900 border-purple-200'
                    }`}
                  >
                    ড্রাইভ (৳{balanceModalUser.driveBalance || 0})
                  </button>

                  <button
                    type="button"
                    onClick={() => setBalanceType('bank')}
                    className={`py-2 px-1 text-center rounded-xl font-extrabold text-xs border transition-all cursor-pointer ${
                      balanceType === 'bank'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-blue-50 text-blue-900 border-blue-200'
                    }`}
                  >
                    ব্যাংক (৳{balanceModalUser.bankBalance || 0})
                  </button>
                </div>
              </div>

              {/* 2. Select Mode: Add, Deduct, Set */}
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  অ্যাকশন মোড
                </label>
                <div className="grid grid-cols-3 gap-1.5 bg-slate-100 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setBalanceMode('add')}
                    className={`py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1 ${
                      balanceMode === 'add'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <Plus className="w-3 h-3" />
                    <span>যোগ (+Add)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setBalanceMode('deduct')}
                    className={`py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1 ${
                      balanceMode === 'deduct'
                        ? 'bg-rose-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <Minus className="w-3 h-3" />
                    <span>কেটে নিন</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setBalanceMode('set')}
                    className={`py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1 ${
                      balanceMode === 'set'
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>সেট করুন</span>
                  </button>
                </div>
              </div>

              {/* 3. Amount Input & Quick Chips */}
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  টাকার পরিমাণ (৳) *
                </label>
                <input
                  type="number"
                  required
                  value={balanceAmount}
                  onChange={(e) => setBalanceAmount(e.target.value)}
                  placeholder="যেমন: ৫০০"
                  className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl text-lg font-mono font-black text-slate-900 outline-none focus:border-indigo-600 focus:bg-white text-center"
                />

                <div className="flex items-center gap-1.5 pt-2 flex-wrap">
                  {[50, 100, 200, 500, 1000, 2000].map((chip) => (
                    <button
                      key={chip}
                      type="button"
                      onClick={() => setBalanceAmount(String(chip))}
                      className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 text-[10px] font-extrabold rounded-lg transition-colors cursor-pointer"
                    >
                      +{chip}৳
                    </button>
                  ))}
                </div>
              </div>

              {/* 4. Note (Optional) */}
              <div>
                <label className="text-[10px] font-bold text-slate-600 block mb-1">
                  এডমিন নোট / কারণ (ঐচ্ছিক)
                </label>
                <input
                  type="text"
                  value={balanceNote}
                  onChange={(e) => setBalanceNote(e.target.value)}
                  placeholder="যেমন: স্পেশাল বোনাস বা ব্যাংক রিকভারি"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 outline-none focus:border-indigo-600"
                />
              </div>

              {/* Live Preview calculation */}
              {balanceAmount && (
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs flex items-center justify-between font-bold">
                  <span className="text-slate-600">আপডেটেড ব্যালেন্স:</span>
                  <span className="font-mono font-black text-indigo-700">
                    ৳
                    {(() => {
                      const cur =
                        balanceType === 'drive'
                          ? balanceModalUser.driveBalance || 0
                          : balanceType === 'bank'
                          ? balanceModalUser.bankBalance || 0
                          : balanceModalUser.mainBalance || 0;
                      const inputAmt = parseFloat(balanceAmount) || 0;
                      if (balanceMode === 'add') return cur + inputAmt;
                      if (balanceMode === 'deduct') return Math.max(0, cur - inputAmt);
                      return inputAmt;
                    })()}
                  </span>
                </div>
              )}

              {/* Buttons */}
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setBalanceModalUser(null)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={balanceAdjusting}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black rounded-xl shadow-md flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Check className="w-4 h-4" />
                  <span>নিশ্চিত করুন</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL 2: BLOCK USER REASON SPECIFICATION                  */}
      {/* ========================================================= */}
      {blockModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 border border-rose-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
                  <ShieldAlert className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-black text-rose-900">
                    ইউজার অ্যাকাউন্ট ব্লক নিশ্চিতকরণ
                  </h3>
                  <p className="text-[10px] text-slate-500 font-medium">
                    {blockModalUser.name} ({blockModalUser.phone})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setBlockModalUser(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-600 font-medium">
                ব্লক করার পর গ্রাহক আর অ্যাপে লগইন করতে পারবেন না এবং তার সকল সার্ভিস স্থগিত থাকবে।
              </p>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  ব্লক করার কারণ নির্বাচন বা লিখুন:
                </label>
                <select
                  value={blockReason}
                  onChange={(e) => setBlockReason(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 outline-none mb-1.5 cursor-pointer"
                >
                  <option value="নিয়ম লঙ্ঘন / সন্দেহজনক লেনদেন">নিয়ম লঙ্ঘন / সন্দেহজনক লেনদেন</option>
                  <option value="ভুয়া ট্রানজেকশন আইডি প্রদান">ভুয়া ট্রানজেকশন আইডি প্রদান</option>
                  <option value="অস্বাভাবিক রিচার্জ অ্যাক্টিভিটি">অস্বাভাবিক রিচার্জ অ্যাক্টিভিটি</option>
                  <option value="বকেয়া ব্যালেন্স পরিশোধ করেনি">বকেয়া ব্যালেন্স পরিশোধ করেনি</option>
                  <option value="অন্যান্য কারণ">অন্যান্য কারণ</option>
                </select>

                <input
                  type="text"
                  value={blockReason}
                  onChange={(e) => setBlockReason(e.target.value)}
                  placeholder="কাস্টম কারণ লিখুন..."
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 outline-none focus:border-rose-600"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setBlockModalUser(null)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="button"
                  onClick={handleConfirmBlock}
                  className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-xl shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>অ্যাকাউন্ট ব্লক করুন</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL 3: CUSTOMER PIN RECOVERY & RESET MODAL              */}
      {/* ========================================================= */}
      {pinModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-3xl w-full max-w-sm p-5 border border-amber-200 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-black text-slate-900">
                    গ্রাহক পিন রিকভারি ও পরিবর্তন
                  </h3>
                  <p className="text-[10px] text-slate-500 font-medium">
                    {pinModalUser.name} • {pinModalUser.phone}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPinModalUser(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              {/* Current Details Card */}
              <div className="p-3 bg-amber-50/60 rounded-2xl border border-amber-200/70 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-slate-600 font-bold">বর্তমান পিন কোড:</span>
                  <span className="font-mono text-base font-black text-amber-900 bg-white px-3 py-0.5 rounded-lg border border-amber-300">
                    {pinModalUser.pin || 'সেট করা নেই'}
                  </span>
                </div>
                {pinModalUser.email && (
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-500">জিমেইল আইডি:</span>
                    <span className="font-mono text-slate-800">{pinModalUser.email}</span>
                  </div>
                )}
              </div>

              {/* New PIN Input */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-extrabold text-slate-800">
                    নতুন ৪-সংখ্যার পিন দিন:
                  </label>
                  <button
                    type="button"
                    onClick={() => setNewPinValue('1234')}
                    className="text-[10px] font-black text-indigo-600 hover:text-indigo-800 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-200 cursor-pointer"
                  >
                    ১২৩৪ ডিফল্ট পিন দিন
                  </button>
                </div>
                <input
                  type="text"
                  maxLength={6}
                  value={newPinValue}
                  onChange={(e) => setNewPinValue(e.target.value.replace(/[^0-9]/g, ''))}
                  placeholder="যেমন: 1234"
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-center text-lg font-mono font-black text-slate-900 tracking-widest outline-none focus:border-amber-500 focus:bg-white"
                />
                <p className="text-[10px] text-slate-500">
                  পিন পরিবর্তনের পর গ্রাহক নতুন এই পিন দিয়ে তাৎক্ষণিকভাবে অ্যাপে লগইন করতে পারবেন।
                </p>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPinModalUser(null)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="button"
                  onClick={handleSaveRecoveredPin}
                  className="flex-1 py-2.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white text-xs font-black rounded-xl shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>পিন সেভ করুন</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL 4: EDIT CUSTOMER INFORMATION MODAL                  */}
      {/* ========================================================= */}
      {editModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn overflow-y-auto">
          <div className="bg-white rounded-3xl w-full max-w-md p-5 border border-sky-200 shadow-2xl space-y-4 my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center">
                  <Pencil className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-black text-slate-900">
                    গ্রাহক তথ্য এডিট ও সংশোধন
                  </h3>
                  <p className="text-[10px] text-slate-500 font-medium">
                    মোবাইল: {editModalUser.phone}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditModalUser(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">
                    গ্রাহকের নাম:
                  </label>
                  <input
                    type="text"
                    required
                    value={editFormName}
                    onChange={(e) => setEditFormName(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-sky-500 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">
                    গোপন পিন (PIN):
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={editFormPin}
                    onChange={(e) => setEditFormPin(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono font-bold text-slate-900 outline-none focus:border-sky-500 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  জিমেইল আইডি (Gmail ID):
                </label>
                <input
                  type="email"
                  value={editFormEmail}
                  onChange={(e) => setEditFormEmail(e.target.value)}
                  placeholder="user@gmail.com"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-slate-900 outline-none focus:border-sky-500 focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">
                    দোকান / ব্যবসার নাম:
                  </label>
                  <input
                    type="text"
                    value={editFormShop}
                    onChange={(e) => setEditFormShop(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 outline-none focus:border-sky-500 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-700 block mb-1">
                    বিভাগ:
                  </label>
                  <select
                    value={editFormDivision}
                    onChange={(e) => setEditFormDivision(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-sky-500 cursor-pointer"
                  >
                    {divisions.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">
                  ঠিকানা:
                </label>
                <input
                  type="text"
                  value={editFormAddress}
                  onChange={(e) => setEditFormAddress(e.target.value)}
                  placeholder="যেমন: মিরপুর ১০, ঢাকা"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 outline-none focus:border-sky-500 focus:bg-white"
                />
              </div>

              {/* Role & Account Type Decision */}
              <div className="p-3 bg-sky-50/70 rounded-2xl border border-sky-200/80 space-y-2">
                <label className="text-[11px] font-black text-sky-950 block">
                  রোল ও অ্যাডমিন প্যানেল এক্সেস নির্ধারণ:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setEditFormRole('user');
                      setEditFormAccountType('Retailer');
                    }}
                    className={`py-2 px-2.5 rounded-xl font-black text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
                      editFormRole === 'user'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    <User className="w-3.5 h-3.5" />
                    <span>👤 সাধারণ ইউজার</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setEditFormRole('admin');
                      setEditFormAccountType('Dealer');
                    }}
                    className={`py-2 px-2.5 rounded-xl font-black text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
                      editFormRole === 'admin'
                        ? 'bg-amber-600 text-white border-amber-600 shadow-sm'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    <Briefcase className="w-3.5 h-3.5" />
                    <span>💼 ডিলার (অ্যাডমিন)</span>
                  </button>
                </div>
                <p className="text-[10px] text-slate-600">
                  {editFormRole === 'admin'
                    ? '⚠️ ডিলার হিসেবে অ্যাডমিন প্যানেল ও অফার/অর্ডার পরিচালনা করতে পারবে।'
                    : 'ℹ️ সাধারণ ইউজার হিসেবে শুধু রিচার্জ ও ড্রাইভ প্যাকের অফার কিনতে পারবে।'}
                </p>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditModalUser(null)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-sky-600 hover:bg-sky-700 text-white text-xs font-black rounded-xl shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>তথ্য সংরক্ষণ করুন</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 5. Dealer Permissions Configuration Modal */}
      {dealerPermModalUser && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-white rounded-3xl p-5 w-full max-w-md shadow-2xl border border-slate-200 space-y-4 my-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
                  <Crown className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900 leading-tight">
                    ডিলার পারমিশন কনফিগারেশন
                  </h3>
                  <p className="text-[10px] text-slate-500 font-medium">
                    {dealerPermModalUser.name} ({dealerPermModalUser.phone})
                  </p>
                </div>
              </div>
              <button
                type="button"
                id="close-dealer-perm-modal-btn"
                onClick={() => setDealerPermModalUser(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Info notice */}
            <div className="p-3 bg-amber-50/80 border border-amber-200/80 rounded-2xl text-[11px] text-amber-900 leading-relaxed">
              💡 <strong>ডিলার ক্ষমতা:</strong> এই ডিলার আপনার অ্যাডমিন প্যানেলে শুধুমাত্র নিচে অনুমোদিত মডিউলগুলো পরিচালনা করতে পারবেন। মেয়াদ শেষ হলে পারমিশন স্বয়ংক্রিয়ভাবে অকার্যকর হবে।
            </div>

            {/* Granular Permissions Checklist */}
            <div className="space-y-2">
              <label className="text-xs font-black text-slate-700 block">
                অনুমোদিত মডিউল ও ক্ষমতা নির্বাচন করুন:
              </label>

              {/* Offer Management */}
              <label className="flex items-start gap-2.5 p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer transition-all">
                <input
                  type="checkbox"
                  id="perm-manage-offers"
                  checked={permManageOffers}
                  onChange={(e) => setPermManageOffers(e.target.checked)}
                  className="mt-0.5 rounded text-amber-600 focus:ring-amber-500 cursor-pointer"
                />
                <div className="text-xs">
                  <div className="font-black text-slate-800 flex items-center gap-1">
                    <span>ড্রাইভ অফার পরিচালনা</span>
                    <span className="text-[9px] bg-purple-100 text-purple-800 px-1.5 py-0.2 rounded font-bold">অফার</span>
                  </div>
                  <div className="text-[10px] text-slate-500">নতুন অফার তৈরি, এডিট এবং ডিলিট করার এক্সেস</div>
                </div>
              </label>

              {/* Order Management */}
              <label className="flex items-start gap-2.5 p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer transition-all">
                <input
                  type="checkbox"
                  id="perm-manage-orders"
                  checked={permManageOrders}
                  onChange={(e) => setPermManageOrders(e.target.checked)}
                  className="mt-0.5 rounded text-amber-600 focus:ring-amber-500 cursor-pointer"
                />
                <div className="text-xs">
                  <div className="font-black text-slate-800 flex items-center gap-1">
                    <span>ড্রাইভ অর্ডার নিয়ন্ত্রণ</span>
                    <span className="text-[9px] bg-indigo-100 text-indigo-800 px-1.5 py-0.2 rounded font-bold">অর্ডার</span>
                  </div>
                  <div className="text-[10px] text-slate-500">প্যাক অর্ডার অনুমোদন (Success) বা রিফান্ড (Cancel) করার এক্সেস</div>
                </div>
              </label>

              {/* Add Money Management */}
              <label className="flex items-start gap-2.5 p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer transition-all">
                <input
                  type="checkbox"
                  id="perm-manage-addmoney"
                  checked={permManageAddMoney}
                  onChange={(e) => setPermManageAddMoney(e.target.checked)}
                  className="mt-0.5 rounded text-amber-600 focus:ring-amber-500 cursor-pointer"
                />
                <div className="text-xs">
                  <div className="font-black text-slate-800 flex items-center gap-1">
                    <span>অ্যাড মানি অনুরোধ অনুমোদন</span>
                    <span className="text-[9px] bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded font-bold">অ্যাড মানি</span>
                  </div>
                  <div className="text-[10px] text-slate-500">গ্রাহকের ব্যালেন্স রিচার্জ ও ট্রানজেকশন আইডি ভেরিফাই</div>
                </div>
              </label>

              {/* Recharge Management */}
              <label className="flex items-start gap-2.5 p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer transition-all">
                <input
                  type="checkbox"
                  id="perm-manage-recharge"
                  checked={permManageRecharge}
                  onChange={(e) => setPermManageRecharge(e.target.checked)}
                  className="mt-0.5 rounded text-amber-600 focus:ring-amber-500 cursor-pointer"
                />
                <div className="text-xs">
                  <div className="font-black text-slate-800 flex items-center gap-1">
                    <span>মোবাইল রিচার্জ নিয়ন্ত্রণ</span>
                    <span className="text-[9px] bg-blue-100 text-blue-800 px-1.5 py-0.2 rounded font-bold">রিচার্জ</span>
                  </div>
                  <div className="text-[10px] text-slate-500">ফ্লেক্সিলোড / প্রিপেইড / পোস্টপেইড রিচার্জ অনুমোদন</div>
                </div>
              </label>

              {/* Support Tickets Management */}
              <label className="flex items-start gap-2.5 p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer transition-all">
                <input
                  type="checkbox"
                  id="perm-manage-tickets"
                  checked={permManageTickets}
                  onChange={(e) => setPermManageTickets(e.target.checked)}
                  className="mt-0.5 rounded text-amber-600 focus:ring-amber-500 cursor-pointer"
                />
                <div className="text-xs">
                  <div className="font-black text-slate-800 flex items-center gap-1">
                    <span>সাপোর্ট ও হেল্পলাইন টিকেট</span>
                    <span className="text-[9px] bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded font-bold">টিকেট</span>
                  </div>
                  <div className="text-[10px] text-slate-500">কাস্টমার কমপ্লেইন দেখা, উত্তর ও সমাধান করা</div>
                </div>
              </label>

              {/* View Users (Optional) */}
              <label className="flex items-start gap-2.5 p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer transition-all">
                <input
                  type="checkbox"
                  id="perm-view-users"
                  checked={permViewUsers}
                  onChange={(e) => setPermViewUsers(e.target.checked)}
                  className="mt-0.5 rounded text-teal-600 focus:ring-teal-500 cursor-pointer"
                />
                <div className="text-xs">
                  <div className="font-black text-slate-800 flex items-center gap-1">
                    <span>গ্রাহক তালিকা পরিদর্শন (Read Only)</span>
                    <span className="text-[9px] bg-teal-100 text-teal-800 px-1.5 py-0.2 rounded font-bold">ইউজার ভিউ</span>
                  </div>
                  <div className="text-[10px] text-slate-500">গ্রাহকদের নাম ও ফোন নাম্বার দেখার সুযোগ (এডিট বা ব্যালেন্স পরিবর্তন বন্ধ থাকবে)</div>
                </div>
              </label>
            </div>

            {/* Expiration Timer Selector */}
            <div className="space-y-1 pt-1">
              <label className="text-xs font-black text-slate-700 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-indigo-600" />
                <span>অনুমতির মেয়াদ (Temporary Access Timer):</span>
              </label>
              <select
                id="perm-expiration-select"
                value={permExpiresDuration}
                onChange={(e) => setPermExpiresDuration(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-amber-500 cursor-pointer"
              >
                <option value="never">স্থায়ী / মেয়াদহীন (Permanent Dealer)</option>
                <option value="1h">১ ঘণ্টা (জরুরি হেল্প / টেস্ট সাপোর্ট)</option>
                <option value="24h">২৪ ঘণ্টা (১ দিন)</option>
                <option value="3d">৩ দিন</option>
                <option value="7d">৭ দিন (১ সপ্তাহ)</option>
                <option value="30d">৩০ দিন (১ মাস)</option>
              </select>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                id="cancel-dealer-perm-btn"
                onClick={() => setDealerPermModalUser(null)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="button"
                id="save-dealer-perm-btn"
                onClick={handleSaveDealerPermissions}
                disabled={isDealerActionLoading}
                className="flex-1 py-2.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-black rounded-xl shadow-md flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isDealerActionLoading ? (
                  <span>সংরক্ষণ হচ্ছে...</span>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    <span>পারমিশন সংরক্ষণ করুন</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. Dealer Suspension Modal */}
      {dealerSuspendModalUser && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-white rounded-3xl p-5 w-full max-w-sm shadow-2xl border border-slate-200 space-y-4 my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-800 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900 leading-tight">
                    ডিলার সাময়িক স্থগিত করুন
                  </h3>
                  <p className="text-[10px] text-slate-500 font-medium">
                    {dealerSuspendModalUser.name} ({dealerSuspendModalUser.phone})
                  </p>
                </div>
              </div>
              <button
                type="button"
                id="close-suspend-modal-btn"
                onClick={() => setDealerSuspendModalUser(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              স্থগিত করা হলে এই ডিলারের অ্যাডমিন প্যানেল এক্সেস বন্ধ থাকবে, কিন্তু ব্যবহারকারী হিসেবে অ্যাপ ব্যবহার করতে পারবেন।
            </p>

            <div className="space-y-1">
              <label className="text-xs font-black text-slate-700 block">
                স্থগিতের কারণ (ঐচ্ছিক):
              </label>
              <input
                type="text"
                id="dealer-suspend-reason-input"
                value={dealerSuspendReason}
                onChange={(e) => setDealerSuspendReason(e.target.value)}
                placeholder="যেমন: নিয়ম লঙ্ঘন বা সাময়িক তদন্ত"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-rose-500"
              />
            </div>

            <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                id="cancel-suspend-btn"
                onClick={() => setDealerSuspendModalUser(null)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="button"
                id="confirm-suspend-dealer-btn"
                onClick={handleConfirmSuspendDealer}
                disabled={isDealerActionLoading}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-xl shadow-md flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isDealerActionLoading ? (
                  <span>স্থগিত হচ্ছে...</span>
                ) : (
                  <>
                    <AlertTriangle className="w-4 h-4" />
                    <span>স্থগিত নিশ্চিত করুন</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
