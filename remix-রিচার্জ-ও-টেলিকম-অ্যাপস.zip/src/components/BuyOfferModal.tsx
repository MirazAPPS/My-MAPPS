import React, { useState } from 'react';
import { X, CheckCircle2, Phone, MessageCircle, ArrowRight, ShieldCheck, Sparkles } from 'lucide-react';
import { DriveOffer, UserProfile, DriveOrder, SocialCommunityLinks } from '../types';
import { OperatorLogo } from './OperatorLogos';
import { getWhatsAppDriveOrderUrl, openWhatsAppChat, getOperatorBrandTheme } from '../utils';
import confetti from 'canvas-confetti';

interface BuyOfferModalProps {
  offer: DriveOffer | null;
  onClose: () => void;
  user: UserProfile;
  socialLinks?: SocialCommunityLinks;
  onConfirmOrder: (order: DriveOrder) => void;
}

export const BuyOfferModal: React.FC<BuyOfferModalProps> = ({
  offer,
  onClose,
  user,
  socialLinks,
  onConfirmOrder,
}) => {
  // Mobile number input starts blank by default
  const [customerPhone, setCustomerPhone] = useState('');
  const [error, setError] = useState('');
  const [submittedOrder, setSubmittedOrder] = useState<DriveOrder | null>(null);

  if (!offer) return null;

  const netCost = offer.priceTK - offer.cashbackTK;
  const brand = getOperatorBrandTheme(offer.operator);
  const opShort = offer.operator === 'gp' ? 'GP' : (offer.operatorName || offer.operator.toUpperCase());
  const specList: string[] = [];
  if (offer.internetGB && offer.internetGB > 0) specList.push(`${offer.internetGB} GB`);
  if (offer.minutes && offer.minutes > 0) specList.push(`${offer.minutes} Min`);
  if (offer.sms && offer.sms > 0) specList.push(`${offer.sms} SMS`);
  const specText = specList.length > 0 ? specList.join(' + ') : (offer.packageName || 'ড্রাইভ অফার');
  const offerTitle = `${opShort} ${specText}`;

  const handleConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const cleanPhone = customerPhone.replace(/[^0-9]/g, '');
    if (!cleanPhone || cleanPhone.length !== 11 || !cleanPhone.startsWith('01')) {
      setError('অনুগ্রহ করে সঠিক ১১ ডিজিটের মোবাইল নম্বর প্রদান করুন (যেমন: 017XXXXXXXX)');
      return;
    }

    const now = new Date();
    const timeFormatted = now.toLocaleTimeString('bn-BD', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });

    const newOrder: DriveOrder = {
      id: `DRV-${Date.now().toString().slice(-6)}`,
      offerId: offer.id,
      operator: offer.operator,
      operatorName: offer.operatorName,
      packageName: offer.packageName,
      date: offer.date || `${now.getDate()}/${now.getMonth() + 1}/${now.getFullYear()}`,
      title: `${offer.internetGB && offer.internetGB > 0 ? `${offer.internetGB}GB ` : ''}${offer.minutes && offer.minutes > 0 ? `+ ${offer.minutes} মিনিট` : ''}`.trim() || offer.packageName || 'ড্রাইভ অফার',
      customerPhone: cleanPhone,
      requesterPhone: user.phone,
      requesterName: user.name || user.shopName,
      minutes: offer.minutes,
      internetGB: offer.internetGB,
      sms: offer.sms,
      validityDays: offer.validityDays,
      regularPriceTK: offer.regularPriceTK,
      amount: offer.priceTK,
      cashback: offer.cashbackTK,
      netCost: netCost,
      status: 'pending',
      createdAt: now.toISOString(),
      timestamp: `আজ, ${timeFormatted}`,
      details: `${offerTitle} (${offer.validityDays} দিন)`,
    };

    // 1. Dual Messaging Trigger (a): WhatsApp message
    const waUrl = getWhatsAppDriveOrderUrl(cleanPhone, offer, socialLinks);
    openWhatsAppChat(waUrl);

    // 2. Dual Messaging Trigger (b): Push active order notification to Admin Panel
    onConfirmOrder(newOrder);

    try {
      confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    } catch {}

    setSubmittedOrder(newOrder);
  };

  const handleClose = () => {
    setCustomerPhone('');
    setError('');
    setSubmittedOrder(null);
    onClose();
  };

  const handleWhatsAppDirect = () => {
    if (!submittedOrder) return;
    const waUrl = getWhatsAppDriveOrderUrl(submittedOrder.customerPhone, offer, socialLinks);
    openWhatsAppChat(waUrl);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl max-w-[420px] w-full overflow-hidden shadow-2xl border border-slate-100 animate-fadeIn">
        {/* Header - Adapts dynamically to offer operator brand */}
        <div className={`bg-gradient-to-r ${brand.headerGradient} px-4 py-3.5 text-white flex items-center justify-between shadow-xs`}>
          <div className="flex items-center gap-2.5">
            <OperatorLogo operator={offer.operator} className="w-8 h-8 shrink-0 shadow-xs" />
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-bold text-base leading-tight">{offer.operatorName} ড্রাইভ</h3>
                {offer.packageName && (
                  <span className="text-[10px] font-black px-2 py-0.5 bg-white/20 rounded-md">
                    {offer.packageName}
                  </span>
                )}
              </div>
              <span className="text-[11px] text-white/90">ক্যাশব্যাক অ্যাডমিন অনুমোদনের পর জমা হবে</span>
            </div>
          </div>
          <button
            type="button"
            onClick={handleClose}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors cursor-pointer"
            title="বন্ধ করুন"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {!submittedOrder ? (
          <div className="p-5 space-y-4 max-h-[85vh] overflow-y-auto">
            {/* 1. Offer Details Summary Card (Title, Validity, Net Cost, Cashback) */}
            <div className={`${brand.lightBg} border rounded-2xl p-4 space-y-3`}>
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="text-lg font-black text-slate-900 leading-snug">
                    {offer.minutes > 0 && `${offer.minutes} Min + `}{offer.internetGB > 0 ? `${offer.internetGB} GB` : ''}
                    {!offer.internetGB && !offer.minutes && (offer.packageName || 'ড্রাইভ অফার')}
                  </h4>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-800">
                      মেয়াদ: {offer.validityDays} দিন
                    </span>
                    {offer.packageName && (
                      <span className="text-[10px] font-bold text-slate-600 bg-white px-2 py-0.5 rounded-md border border-slate-200">
                        {offer.packageName}
                      </span>
                    )}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div className="text-lg font-black text-slate-900">৳{offer.priceTK}</div>
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full inline-block mt-0.5">
                    ক্যাশব্যাক ৳{offer.cashbackTK}
                  </span>
                </div>
              </div>

              {/* Net Cost Highlight */}
              <div className="pt-2.5 border-t border-slate-200/80 flex items-center justify-between text-xs font-semibold text-slate-700">
                <span className="text-slate-600">প্রকৃত খরচ (Net Cost):</span>
                <span className="font-extrabold text-slate-900 text-base">৳{netCost}</span>
              </div>
            </div>

            {/* 2. Single Input Field & Confirm Button */}
            <form onSubmit={handleConfirm} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-800 block mb-1.5 text-center">
                  যে নম্বরে অফার নিবেন (Mobile Number)
                </label>
                <div className="relative flex items-center justify-center">
                  <div className="absolute left-3.5 text-slate-500 pointer-events-none">
                    <Phone className="w-4 h-4" />
                  </div>
                  <input
                    id="buy-offer-phone-input"
                    type="tel"
                    maxLength={11}
                    value={customerPhone}
                    onChange={(e) => {
                      setCustomerPhone(e.target.value);
                      if (error) setError('');
                    }}
                    placeholder="01XXXXXXXXX"
                    autoFocus
                    className="w-full px-10 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-base font-bold text-slate-900 outline-none focus:border-[#0072CE] focus:bg-white focus:ring-2 focus:ring-sky-100 transition-all placeholder:text-slate-400 font-mono text-center"
                  />
                </div>
              </div>

              {error && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-600 rounded-xl text-xs font-bold text-center animate-fadeIn">
                  {error}
                </div>
              )}

              {/* 3. Action Button: কনফার্ম করুন */}
              <button
                id="buy-offer-confirm-btn"
                type="submit"
                className={`w-full max-w-[300px] mx-auto py-3 bg-gradient-to-r ${brand.btnGradient} text-white font-semibold text-[16px] rounded-2xl shadow-md flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer`}
              >
                <span>কনফার্ম করুন</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        ) : (
          /* Order Submitted Success Confirmation */
          <div className="p-6 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center shadow-xs">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <h3 className="text-xl font-black text-slate-900">অর্ডার পাঠানো হয়েছে!</h3>
              <p className="text-xs text-slate-500 mt-1">
                অর্ডারটি অ্যাডমিন প্যানেলে জমা হয়েছে এবং WhatsApp এ মেসেজ পাঠানো হয়েছে।
              </p>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-left space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">যে নম্বরে অফার:</span>
                <span className="font-bold text-slate-900 font-mono text-sm">{submittedOrder.customerPhone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">অফারের নাম:</span>
                <span className="font-bold text-slate-800">{submittedOrder.details}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">অফার মূল্য:</span>
                <span className="font-bold text-slate-800">৳{submittedOrder.amount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">ক্যাশব্যাক:</span>
                <span className="font-extrabold text-emerald-600">৳{submittedOrder.cashback}</span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-1.5">
                <span className="text-slate-500">প্রকৃত খরচ:</span>
                <span className="font-extrabold text-indigo-700">৳{submittedOrder.netCost}</span>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleWhatsAppDirect}
                className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp মেসেজ দেখুন</span>
              </button>
              <button
                type="button"
                onClick={handleClose}
                className="flex-1 py-3 bg-slate-900 hover:bg-slate-800 active:scale-95 text-white font-bold text-xs rounded-xl transition-all cursor-pointer"
              >
                ঠিক আছে
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
