import React, { useState } from 'react';
import {
  MoreVertical,
  Eye,
  EyeOff,
  ChevronRight,
  Globe,
  RefreshCw,
  QrCode,
  Moon,
  Sun,
  Volume2,
  VolumeX,
  Bell,
  BellOff,
  Palette,
  Check,
  Settings,
  X,
  Smartphone,
  Sparkles,
  KeyRound,
  ShieldCheck,
} from 'lucide-react';
import { UserProfile, AppSettings } from '../types';
import { speakText } from '../utils';
import { AppLogoModal } from './AppLogoModal';
import { AppLockRecoveryModal } from './AppLockRecoveryModal';

interface HeaderProps {
  user: UserProfile;
  settings: AppSettings;
  onUpdateSettings?: (settings: AppSettings) => void;
  onUpdateUser?: (updated: UserProfile) => void;
  onOpenSearch?: () => void;
  onOpenDrawer: () => void;
  onOpenAddMoney?: () => void;
  onOpenProfileEdit?: () => void;
  onRefreshData?: () => void;
  onOpenQrScanner?: () => void;
  onOpenAndroidApk?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  settings,
  onUpdateSettings,
  onUpdateUser,
  onOpenSearch,
  onOpenDrawer,
  onOpenAddMoney,
  onOpenProfileEdit,
  onRefreshData,
  onOpenQrScanner,
  onOpenAndroidApk,
}) => {
  const [showBalance, setShowBalance] = useState(false);
  const [balanceType, setBalanceType] = useState<'main' | 'drive' | 'bank'>('main');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isThreeDotOpen, setIsThreeDotOpen] = useState(false);
  const [isLogoModalOpen, setIsLogoModalOpen] = useState(false);
  const [isAppLockModalOpen, setIsAppLockModalOpen] = useState(false);

  const isDarkMode = settings.darkMode ?? (settings.theme === 'dark');
  const isBangla = settings.language !== 'en';

  // Synchronize status bar color dynamically with browser/WebAPK and native Android interface
  React.useEffect(() => {
    let themeColor = '#1d4ed8';
    if (isDarkMode) {
      themeColor = '#0f172a';
    } else {
      switch (settings.theme) {
        case 'purple':
          themeColor = '#4f46e5';
          break;
        case 'green':
          themeColor = '#047857';
          break;
        case 'orange':
          themeColor = '#ea580c';
          break;
        case 'red':
          themeColor = '#dc2626';
          break;
        case 'dark':
          themeColor = '#0f172a';
          break;
        case 'blue':
        default:
          themeColor = '#1d4ed8';
          break;
      }
    }
    // Update HTML meta theme-color tag
    const metaTag = document.querySelector('meta[name="theme-color"]');
    if (metaTag) {
      metaTag.setAttribute('content', themeColor);
    }
    // Update Android native status bar if running inside Android APK
    const win = window as any;
    if (win.AndroidNative && typeof win.AndroidNative.setStatusBarColor === 'function') {
      try {
        win.AndroidNative.setStatusBarColor(themeColor, false);
      } catch (e) {
        // Safe fallback
      }
    }
  }, [settings.theme, isDarkMode]);

  const getThemeGradient = () => {
    if (isDarkMode) {
      return 'bg-gradient-to-r from-[#0f172a] via-[#1e293b] to-[#334155] shadow-slate-950/40 border-b border-slate-700/50';
    }
    switch (settings.theme) {
      case 'purple':
        return 'bg-gradient-to-r from-[#6366f1] via-[#7c3aed] to-[#4f46e5] shadow-indigo-600/20';
      case 'green':
        return 'bg-gradient-to-r from-[#047857] via-[#059669] to-[#0d9488] shadow-emerald-600/20';
      case 'orange':
        return 'bg-gradient-to-r from-[#c2410c] via-[#ea580c] to-[#f97316] shadow-orange-500/20';
      case 'red':
        return 'bg-gradient-to-r from-[#b91c1c] via-[#dc2626] to-[#e11d48] shadow-rose-600/20';
      case 'dark':
        return 'bg-gradient-to-r from-[#1e293b] via-[#0f172a] to-[#334155] shadow-slate-950/40';
      case 'blue':
      default:
        return 'bg-gradient-to-r from-[#1d4ed8] via-[#2563eb] to-[#3b82f6] shadow-blue-600/20';
    }
  };

  const formatTk = (amount: number) => {
    if (!isBangla) {
      return amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    return amount.toLocaleString('bn-BD', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const getActiveBalance = () => {
    return {
      title: isBangla ? 'কারেন্ট ব্যালেন্স' : 'Current Balance',
      amount: user.mainBalance ?? 0,
    };
  };

  const currentBal = getActiveBalance();

  return (
    <header
      className={`w-full ${getThemeGradient()} pb-3.5 px-4 sm:px-5 rounded-b-2xl text-white shadow-md select-none transition-colors duration-200`}
      style={{
        paddingTop: 'max(10px, calc(env(safe-area-inset-top, 0px) + 8px))',
      }}
    >
      {/* Top row: Avatar + Name & Three Dot Menu Button */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {/* Avatar circle & Profile Quick Edit */}
          <button
            id="header-profile-avatar"
            type="button"
            onClick={onOpenProfileEdit || onOpenDrawer}
            title={isBangla ? 'নাম ও ছবি পরিবর্তন করতে ক্লিক করুন' : 'Click to change name and photo'}
            className="w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-white text-[#3090F8] flex items-center justify-center font-black text-lg shadow-sm border-2 border-white/60 overflow-hidden relative cursor-pointer group"
          >
            {user.profileImage ? (
              <img
                src={user.profileImage}
                alt={user.name}
                className="w-full h-full object-cover rounded-full"
              />
            ) : (
              user.name ? user.name.charAt(0).toUpperCase() : 'M'
            )}
            {/* Small camera badge to visually hint that tapping edits profile picture */}
            <div className="absolute inset-0 bg-black/35 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <span className="text-white text-[10px]">📷</span>
            </div>
          </button>

          <button
            id="header-profile-name-btn"
            type="button"
            onClick={onOpenProfileEdit || onOpenDrawer}
            title={isBangla ? 'নাম ও ছবি পরিবর্তন করতে ক্লিক করুন' : 'Click to change name and photo'}
            className="text-left cursor-pointer group/name"
          >
            <span className="text-white/80 text-[11px] font-bold block leading-tight">
              {isBangla ? 'স্বাগতম' : 'Welcome'}
            </span>
            <div className="flex items-center gap-1.5">
              <span className="text-white font-black text-base sm:text-lg tracking-tight block group-hover/name:underline decoration-white/70">
                {user.name || 'Md Miraz GP'}
              </span>
            </div>
          </button>
        </div>

        {/* Action icons: Three-dot menu button */}
        <div className="flex items-center gap-2">
          {/* Three Dot Menu Button - Opens Fast Settings & Actions Menu */}
          <div className="relative">
            <button
              id="header-three-dots-btn"
              type="button"
              onClick={() => setIsThreeDotOpen(!isThreeDotOpen)}
              aria-label={isBangla ? 'মেনু ও সেটিংস' : 'Menu & Settings'}
              title={isBangla ? 'মেনু ও সেটিংস' : 'Menu & Settings'}
              className={`w-9 h-9 rounded-full ${
                isThreeDotOpen ? 'bg-white text-blue-600 shadow-md scale-105' : 'bg-white/20 hover:bg-white/30 text-white'
              } backdrop-blur-md flex items-center justify-center active:scale-95 transition-all shadow-xs cursor-pointer border border-white/30`}
            >
              <MoreVertical className="w-4 h-4" />
            </button>

            {/* Three Dot Interactive Settings Popover Menu */}
            {isThreeDotOpen && (
              <>
                {/* Click outside backdrop */}
                <div
                  className="fixed inset-0 z-40 bg-black/25 backdrop-blur-[1px]"
                  onClick={() => setIsThreeDotOpen(false)}
                />

                {/* Settings Dropdown Card */}
                <div
                  className={`absolute right-0 top-12 z-50 w-72 sm:w-80 rounded-2xl p-4 shadow-2xl border transition-all animate-fadeIn ${
                    isDarkMode
                      ? 'bg-slate-900/98 text-slate-100 border-slate-700 shadow-slate-950/80'
                      : 'bg-white text-slate-800 border-slate-200 shadow-2xl'
                  }`}
                >
                  {/* Menu Header */}
                  <div className={`flex items-center justify-between pb-2.5 mb-2 border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-150'}`}>
                    <div className="flex items-center gap-2">
                      <Settings className={`w-4 h-4 ${isDarkMode ? 'text-sky-400' : 'text-blue-600'}`} />
                      <span className="text-xs font-black uppercase tracking-wider">
                        {isBangla ? 'অ্যাপ সেটিংস ও মেনু' : 'App Settings & Menu'}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsThreeDotOpen(false)}
                      className={`w-6 h-6 rounded-full flex items-center justify-center transition-colors cursor-pointer ${
                        isDarkMode ? 'bg-slate-800 hover:bg-slate-700 text-slate-300' : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                      }`}
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* 1. Dark Mode Toggle */}
                  <div className={`flex items-center justify-between py-2 border-b ${isDarkMode ? 'border-slate-800/80' : 'border-slate-100'}`}>
                    <div className="flex items-center gap-2.5">
                      <div className={`w-7 h-7 rounded-xl flex items-center justify-center ${isDarkMode ? 'bg-amber-950/60 text-amber-400' : 'bg-amber-50 text-amber-600'}`}>
                        {isDarkMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
                      </div>
                      <div>
                        <div className="text-xs font-black leading-tight">
                          {isBangla ? 'ডার্ক মোড' : 'Dark Mode'}
                        </div>
                        <div className={`text-[10px] font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                          {isDarkMode ? (isBangla ? 'বর্তমানে চালু' : 'Active') : (isBangla ? 'বর্তমানে বন্ধ' : 'Disabled')}
                        </div>
                      </div>
                    </div>
                    <button
                      id="threedot-darkmode-toggle"
                      type="button"
                      onClick={() => {
                        if (onUpdateSettings) {
                          onUpdateSettings({ ...settings, darkMode: !isDarkMode });
                        }
                      }}
                      className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                        isDarkMode ? 'bg-indigo-600' : 'bg-slate-300'
                      }`}
                    >
                      <span
                        className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                          isDarkMode ? 'translate-x-5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>

                  {/* 2. Language Switcher */}
                  <div className={`flex items-center justify-between py-2 border-b ${isDarkMode ? 'border-slate-800/80' : 'border-slate-100'}`}>
                    <div className="flex items-center gap-2.5">
                      <div className={`w-7 h-7 rounded-xl flex items-center justify-center ${isDarkMode ? 'bg-sky-950/60 text-sky-400' : 'bg-sky-50 text-sky-600'}`}>
                        <Globe className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-black leading-tight">
                          {isBangla ? 'ভাষা' : 'Language'}
                        </div>
                        <div className={`text-[10px] font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                          {isBangla ? 'বাংলা (BD)' : 'English (US)'}
                        </div>
                      </div>
                    </div>
                    <div className={`flex items-center gap-1 p-0.5 rounded-xl border ${isDarkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-100 border-slate-200'}`}>
                      <button
                        type="button"
                        onClick={() => onUpdateSettings && onUpdateSettings({ ...settings, language: 'bn' })}
                        className={`px-2 py-1 text-[10px] font-black rounded-lg transition-all ${
                          isBangla
                            ? 'bg-blue-600 text-white shadow-xs'
                            : isDarkMode ? 'text-slate-400 hover:text-white' : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        বাংলা
                      </button>
                      <button
                        type="button"
                        onClick={() => onUpdateSettings && onUpdateSettings({ ...settings, language: 'en' })}
                        className={`px-2 py-1 text-[10px] font-black rounded-lg transition-all ${
                          !isBangla
                            ? 'bg-blue-600 text-white shadow-xs'
                            : isDarkMode ? 'text-slate-400 hover:text-white' : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        ENG
                      </button>
                    </div>
                  </div>

                  {/* 3. Theme Colors Palette */}
                  <div className={`py-2 border-b ${isDarkMode ? 'border-slate-800/80' : 'border-slate-100'}`}>
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <Palette className={`w-4 h-4 ${isDarkMode ? 'text-emerald-400' : 'text-emerald-600'}`} />
                        <span className="text-xs font-black">
                          {isBangla ? 'অ্যাপের থিম কালার' : 'Theme Color'}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">
                        {settings.theme || 'blue'}
                      </span>
                    </div>
                    <div className="grid grid-cols-6 gap-2 pt-1">
                      {[
                        { id: 'blue', label: 'নীল', color: '#0072ce' },
                        { id: 'purple', label: 'বেগুনী', color: '#a825ea' },
                        { id: 'green', label: 'সবুজ', color: '#059669' },
                        { id: 'orange', label: 'কমলা', color: '#ea580c' },
                        { id: 'red', label: 'লাল', color: '#dc2626' },
                        { id: 'dark', label: 'ডার্ক', color: '#1e293b' },
                      ].map((themeItem) => {
                        const isSelected = (settings.theme || 'blue') === themeItem.id;
                        return (
                          <button
                            key={themeItem.id}
                            type="button"
                            onClick={() => {
                              if (onUpdateSettings) {
                                onUpdateSettings({ ...settings, theme: themeItem.id as any });
                              }
                            }}
                            title={themeItem.label}
                            style={{ backgroundColor: themeItem.color }}
                            className={`w-7 h-7 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-xs ${
                              isSelected
                                ? 'ring-2 ring-offset-2 ring-blue-500 scale-110 shadow-md'
                                : 'opacity-80 hover:opacity-100 hover:scale-105'
                            }`}
                          >
                            {isSelected && <Check className="w-3.5 h-3.5 text-white stroke-[3]" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* 4. Sound Toggle */}
                  <div className={`flex items-center justify-between py-2 border-b ${isDarkMode ? 'border-slate-800/80' : 'border-slate-100'}`}>
                    <div className="flex items-center gap-2.5">
                      <div className={`w-7 h-7 rounded-xl flex items-center justify-center ${isDarkMode ? 'bg-teal-950/60 text-teal-400' : 'bg-teal-50 text-teal-600'}`}>
                        {settings.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                      </div>
                      <div>
                        <div className="text-xs font-black leading-tight">
                          {isBangla ? 'লেনদেন সাউন্ড' : 'Sound Effects'}
                        </div>
                        <div className={`text-[10px] font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                          {settings.soundEnabled ? (isBangla ? 'শব্দ চালু আছে' : 'Sound Active') : (isBangla ? 'শব্দ বন্ধ' : 'Muted')}
                        </div>
                      </div>
                    </div>
                    <button
                      id="threedot-sound-toggle"
                      type="button"
                      onClick={() => {
                        if (onUpdateSettings) {
                          onUpdateSettings({ ...settings, soundEnabled: !settings.soundEnabled });
                        }
                      }}
                      className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                        settings.soundEnabled ? 'bg-teal-600' : 'bg-slate-300'
                      }`}
                    >
                      <span
                        className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                          settings.soundEnabled ? 'translate-x-5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>

                  {/* 5. Notifications Toggle */}
                  <div className={`flex items-center justify-between py-2 border-b ${isDarkMode ? 'border-slate-800/80' : 'border-slate-100'}`}>
                    <div className="flex items-center gap-2.5">
                      <div className={`w-7 h-7 rounded-xl flex items-center justify-center ${isDarkMode ? 'bg-rose-950/60 text-rose-400' : 'bg-rose-50 text-rose-600'}`}>
                        {settings.notificationsEnabled ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
                      </div>
                      <div>
                        <div className="text-xs font-black leading-tight">
                          {isBangla ? 'অফার নোটিফিকেশন' : 'Notifications'}
                        </div>
                        <div className={`text-[10px] font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                          {settings.notificationsEnabled ? (isBangla ? 'নোটিফিকেশন চালু' : 'Enabled') : (isBangla ? 'নোটিফিকেশন বন্ধ' : 'Muted')}
                        </div>
                      </div>
                    </div>
                    <button
                      id="threedot-notifications-toggle"
                      type="button"
                      onClick={() => {
                        if (onUpdateSettings) {
                          onUpdateSettings({ ...settings, notificationsEnabled: !settings.notificationsEnabled });
                        }
                      }}
                      className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                        settings.notificationsEnabled ? 'bg-rose-600' : 'bg-slate-300'
                      }`}
                    >
                      <span
                        className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                          settings.notificationsEnabled ? 'translate-x-5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>

                  {/* 6. Live Refresh Data Action */}
                  {onRefreshData && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsRefreshing(true);
                        onRefreshData();
                        setTimeout(() => {
                          setIsRefreshing(false);
                          setIsThreeDotOpen(false);
                        }, 500);
                      }}
                      className={`w-full flex items-center justify-between py-2 border-b transition-colors text-left cursor-pointer ${
                        isDarkMode ? 'border-slate-800/80 hover:text-sky-300' : 'border-slate-100 hover:text-blue-600'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className={`w-7 h-7 rounded-xl flex items-center justify-center ${isDarkMode ? 'bg-sky-950/60 text-sky-400' : 'bg-sky-50 text-sky-600'}`}>
                          <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
                        </div>
                        <div>
                          <div className="text-xs font-black leading-tight">
                            {isBangla ? 'ডেটা ও ব্যালেন্স সিঙ্ক' : 'Sync Live Balance'}
                          </div>
                          <div className={`text-[10px] font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                            {isRefreshing ? (isBangla ? 'আপডেট হচ্ছে...' : 'Syncing...') : (isBangla ? 'সর্বশেষ ডেটা আনুন' : 'Fetch latest data')}
                          </div>
                        </div>
                      </div>
                      <span className="text-[10px] font-black text-sky-500">
                        {isRefreshing ? '...' : (isBangla ? 'সিঙ্ক' : 'Sync')}
                      </span>
                    </button>
                  )}

                  {/* 7. Android APK Download & Install Option */}
                  {onOpenAndroidApk && (
                    <button
                      id="threedot-download-apk-btn"
                      type="button"
                      onClick={() => {
                        setIsThreeDotOpen(false);
                        onOpenAndroidApk();
                      }}
                      className="w-full mt-2.5 py-2.5 px-3.5 rounded-xl flex items-center justify-between text-xs font-black transition-all cursor-pointer shadow-md bg-gradient-to-r from-emerald-600 via-teal-600 to-green-600 hover:from-emerald-700 hover:to-teal-700 text-white border border-emerald-400 active:scale-98"
                    >
                      <div className="flex items-center gap-2">
                        <Smartphone className="w-4 h-4 text-emerald-200" />
                        <span>{isBangla ? 'অ্যান্ড্রয়েড অ্যাপ (APK) ডাউনলোড' : 'Download Android APK'}</span>
                      </div>
                      <span className="px-1.5 py-0.5 bg-white/20 text-white rounded text-[10px] font-black uppercase">
                        APK
                      </span>
                    </button>
                  )}

                  {/* 8. Change App Logo Option (User Request #3) */}
                  <button
                    id="threedot-change-logo-btn"
                    type="button"
                    onClick={() => {
                      setIsThreeDotOpen(false);
                      setIsLogoModalOpen(true);
                    }}
                    className={`w-full mt-2 py-2 px-3 rounded-xl flex items-center justify-between text-xs font-black transition-all cursor-pointer border ${
                      isDarkMode
                        ? 'bg-indigo-950/40 hover:bg-indigo-900/60 text-indigo-300 border-indigo-800/60'
                        : 'bg-indigo-50/90 hover:bg-indigo-100 text-indigo-700 border-indigo-200/80'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-indigo-500" />
                      <span>{isBangla ? 'এপসের লোগো পরিবর্তন' : 'Change App Logo'}</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 opacity-60" />
                  </button>

                  {/* 9. App Lock & PIN Recovery Option (User Request #4) */}
                  <button
                    id="threedot-app-lock-recovery-btn"
                    type="button"
                    onClick={() => {
                      setIsThreeDotOpen(false);
                      setIsAppLockModalOpen(true);
                    }}
                    className={`w-full mt-2 py-2 px-3 rounded-xl flex items-center justify-between text-xs font-black transition-all cursor-pointer border ${
                      isDarkMode
                        ? 'bg-amber-950/40 hover:bg-amber-900/60 text-amber-300 border-amber-800/60'
                        : 'bg-amber-50/90 hover:bg-amber-100 text-amber-800 border-amber-200/80'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <KeyRound className="w-4 h-4 text-amber-500" />
                      <span>{isBangla ? 'অ্যাপ লক ও পিন রিকভারি' : 'App Lock & PIN Recovery'}</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 opacity-60" />
                  </button>

                  {/* 10. Full Profile & Settings Drawer Shortcut */}
                  <button
                    id="threedot-open-drawer-btn"
                    type="button"
                    onClick={() => {
                      setIsThreeDotOpen(false);
                      onOpenDrawer();
                    }}
                    className={`w-full mt-2 py-2.5 px-3.5 rounded-xl flex items-center justify-between text-xs font-black transition-all cursor-pointer shadow-xs ${
                      isDarkMode
                        ? 'bg-slate-800 hover:bg-slate-750 text-sky-300 border border-slate-700 active:scale-98'
                        : 'bg-gradient-to-r from-blue-50 to-sky-50 hover:from-blue-100 hover:to-sky-100 text-blue-700 border border-blue-200 active:scale-98'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Settings className="w-4 h-4 text-[#0072ce]" />
                      <span>{isBangla ? 'সম্পূর্ণ প্রোফাইল ও সেটিংস ড্রয়ার' : 'Open Full Settings Drawer'}</span>
                    </div>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Harmonious, Color-Integrated Balance Pill (Shifted right to align under the profile name) */}
      <div className="mt-2.5 flex items-center ml-12 sm:ml-14">
        <button
          id="header-balance-pill-btn"
          type="button"
          onClick={() => setShowBalance(!showBalance)}
          className="relative inline-flex items-center gap-2 bg-white/18 hover:bg-white/28 text-white px-3.5 sm:px-4 h-8 rounded-full font-bold text-xs sm:text-sm backdrop-blur-md border border-white/30 shadow-xs overflow-hidden group cursor-pointer select-none"
        >
          {/* Subtle round badge for Currency Symbol matching header theme */}
          <span className="w-5 h-5 rounded-full bg-white/95 text-blue-600 flex items-center justify-center font-black text-xs shadow-xs shrink-0">
            ৳
          </span>
          <span className="tracking-tight text-white font-bold">
            {showBalance ? (
              <span className="font-mono font-black text-white text-sm sm:text-base">
                {formatTk(currentBal.amount)}
              </span>
            ) : (
              <span className="text-white/95 font-semibold">{isBangla ? 'ব্যালেন্স দেখুন' : 'Tap for Balance'}</span>
            )}
          </span>
          <div className="text-white/80 group-hover:text-white transition-colors ml-0.5">
            {showBalance ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
          </div>
        </button>
      </div>

      {/* App Logo Customization Modal */}
      <AppLogoModal
        isOpen={isLogoModalOpen}
        onClose={() => setIsLogoModalOpen(false)}
        settings={settings}
        onUpdateSettings={(updated) => {
          if (onUpdateSettings) onUpdateSettings(updated);
        }}
      />

      {/* App Lock & PIN Recovery Modal */}
      <AppLockRecoveryModal
        isOpen={isAppLockModalOpen}
        onClose={() => setIsAppLockModalOpen(false)}
        user={user}
        onUpdateUser={(updated) => {
          if (onUpdateUser) onUpdateUser(updated);
        }}
      />
    </header>
  );
};

