import React, { useState } from 'react';
import {
  Smartphone,
  CheckCircle2,
  XCircle,
  Clock,
  Phone,
  Copy,
  Check,
  Search,
  ArrowRight,
  ShieldCheck,
  Trash2,
  MessageCircle,
} from 'lucide-react';
import { RechargeRequest, OperatorType, SocialCommunityLinks } from '../types';
import { OperatorLogo } from './OperatorLogos';
import { openWhatsAppChat } from '../utils';

interface AdminRechargeSectionProps {
  requests: RechargeRequest[];
  onApproveRequest: (requestId: string, userPhone?: string, operatorName?: string) => void;
  onCancelRequest: (requestId: string, userPhone?: string, amount?: number, operatorName?: string) => void;
  onDeleteRequest?: (requestId: string) => void;
  socialLinks?: SocialCommunityLinks;
  onShowToast: (msg: string) => void;
}

export const AdminRechargeSection: React.FC<AdminRechargeSectionProps> = ({
  requests = [],
  onApproveRequest,
  onCancelRequest,
  onDeleteRequest,
  socialLinks,
  onShowToast,
}) => {
  const [filterStatus, setFilterStatus] = useState<'pending' | 'success' | 'all'>('pending');
  const [selectedOperator, setSelectedOperator] = useState<OperatorType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    onShowToast(`নম্বর কপি হয়েছে: ${text}`);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const pendingCount = requests.filter((r) => r.status === 'pending').length;
  const successCount = requests.filter((r) => r.status === 'success').length;

  const filteredRequests = requests.filter((req) => {
    if (filterStatus !== 'all' && req.status !== filterStatus) return false;
    if (selectedOperator !== 'all' && req.operator !== selectedOperator) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchPhone = req.recipientPhone?.toLowerCase().includes(q) || req.userPhone?.toLowerCase().includes(q);
      const matchName = req.userName?.toLowerCase().includes(q);
      const matchOp = req.operatorName?.toLowerCase().includes(q);
      if (!matchPhone && !matchName && !matchOp) return false;
    }
    return true;
  });

  const handleOpenCustomerWhatsApp = (req: RechargeRequest) => {
    const waPhone = req.recipientPhone.startsWith('880')
      ? req.recipientPhone
      : req.recipientPhone.startsWith('0')
      ? `88${req.recipientPhone}`
      : `880${req.recipientPhone}`;
    const text = `আসসালামু আলাইকুম, আপনার ৳${req.amount} (${req.operatorName}) মোবাইল রিচার্জ সংক্রান্ত তথ্য:`;
    const url = `https://wa.me/${waPhone}?text=${encodeURIComponent(text)}`;
    openWhatsAppChat(url);
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      {/* 1. Overview & Search Header */}
      <section className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-extrabold text-slate-900 text-sm leading-tight">
                মোবাইল রিচার্জ রিকোয়েস্ট হাব
              </h2>
              <p className="text-[10px] text-slate-500 font-medium">
                ফায়ারস্টোর থেকে সরাসরি জমা হওয়া রিচার্জ রিকোয়েস্ট নিয়ন্ত্রণ
              </p>
            </div>
          </div>
          <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 font-bold text-xs">
            পেন্ডিং: {pendingCount}
          </span>
        </div>

        {/* Filters */}
        <div className="flex gap-1.5 bg-slate-100 p-1 rounded-xl">
          <button
            type="button"
            onClick={() => setFilterStatus('pending')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              filterStatus === 'pending'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            পেন্ডিং ({pendingCount})
          </button>
          <button
            type="button"
            onClick={() => setFilterStatus('success')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              filterStatus === 'success'
                ? 'bg-white text-emerald-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            সাকসেস ({successCount})
          </button>
          <button
            type="button"
            onClick={() => setFilterStatus('all')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              filterStatus === 'all'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            সকল ({requests.length})
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="রিচার্জ নম্বর, ইউজার নাম বা অপারেটর দিয়ে খুঁজুন..."
            className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 outline-none focus:border-blue-600 focus:bg-white"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
        </div>
      </section>

      {/* 2. Requests List */}
      <div className="space-y-2.5">
        {filteredRequests.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-slate-200 text-slate-500 space-y-2">
            <Smartphone className="w-10 h-10 text-slate-300 mx-auto" />
            <p className="font-bold text-xs text-slate-700">কোনো রিচার্জ রিকোয়েস্ট পাওয়া যায়নি</p>
            <p className="text-[11px] text-slate-400">গ্রাহকরা রিচার্জ করলে এখানে স্বয়ংক্রিয়ভাবে ভেসে উঠবে।</p>
          </div>
        ) : (
          filteredRequests.map((req) => (
            <div
              key={req.id}
              className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-xs hover:border-blue-300 transition-all space-y-2.5"
            >
              {/* Header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <OperatorLogo operator={req.operator} className="w-6 h-6" />
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-xs text-slate-900">{req.operatorName}</span>
                      <span className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded-md font-bold uppercase">
                        {req.connectionType}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400">{req.timestamp || 'আজ, এইমাত্র'}</span>
                  </div>
                </div>

                <span
                  className={`px-2 py-0.5 rounded-full font-bold text-[10px] border ${
                    req.status === 'success'
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      : req.status === 'cancelled'
                      ? 'bg-rose-50 text-rose-700 border-rose-200'
                      : 'bg-amber-50 text-amber-700 border-amber-200 animate-pulse'
                  }`}
                >
                  {req.status === 'success' ? 'সাকসেস' : req.status === 'cancelled' ? 'বাতিল' : 'পেন্ডিং'}
                </span>
              </div>

              {/* Details Box */}
              <div className="bg-slate-50 rounded-xl p-2.5 border border-slate-100 space-y-1.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">রিচার্জ নম্বর:</span>
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono font-extrabold text-sm text-blue-700">{req.recipientPhone}</span>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(req.recipientPhone, req.id)}
                      className="p-1 text-slate-400 hover:text-blue-600 bg-white border border-slate-200 rounded-md transition-colors cursor-pointer"
                      title="নম্বর কপি করুন"
                    >
                      {copiedId === req.id ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-500">টাকার পরিমাণ:</span>
                  <span className="font-extrabold text-sm text-slate-900">৳{req.amount}</span>
                </div>

                <div className="flex items-center justify-between border-t border-slate-200/60 pt-1 text-[11px]">
                  <span className="text-slate-500">রিকোয়েস্টার ইউজার:</span>
                  <span className="font-medium text-slate-700">{req.userName} ({req.userPhone})</span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 pt-1">
                {req.status === 'pending' && (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        onApproveRequest(req.id, req.userPhone, req.operatorName);
                        onShowToast(`রিচার্জ #${req.id} সাকসেস করা হয়েছে!`);
                      }}
                      className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1 shadow-xs transition-colors cursor-pointer"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>সাকসেস করুন</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        onCancelRequest(req.id, req.userPhone, req.amount, req.operatorName);
                        onShowToast('রিচার্জ বাতিল ও গ্রাহকের ব্যালেন্স রিফান্ড হয়েছে');
                      }}
                      className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                    >
                      বাতিল ও রিফান্ড
                    </button>
                  </>
                )}

                <button
                  type="button"
                  onClick={() => handleOpenCustomerWhatsApp(req)}
                  className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-xl transition-colors cursor-pointer"
                  title="গ্রাহকের সাথে হোয়াটসঅ্যাপে যোগাযোগ করুন"
                >
                  <MessageCircle className="w-4 h-4" />
                </button>

                {onDeleteRequest && (
                  <button
                    type="button"
                    onClick={() => {
                      onDeleteRequest(req.id);
                      onShowToast('রেকর্ডটি মুছে ফেলা হয়েছে');
                    }}
                    className="p-1.5 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 text-slate-400 rounded-xl transition-colors cursor-pointer"
                    title="মুছে ফেলুন"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
