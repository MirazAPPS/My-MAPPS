import React from 'react';

/**
 * 1. Tally Khata Official Logo (টালি খাতা)
 * Recreated accurately from the user-uploaded `unnamed.png`
 */
export const TallyKhataLogo: React.FC<{ className?: string }> = ({ className = 'w-10 h-10' }) => {
  return (
    <svg
      viewBox="0 0 512 512"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        {/* Ring Gradient */}
        <linearGradient id="tkRingGrad" x1="0" y1="0" x2="512" y2="512" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#0B3C7B" />
          <stop offset="50%" stopColor="#0E5AA7" />
          <stop offset="75%" stopColor="#00A859" />
          <stop offset="100%" stopColor="#008844" />
        </linearGradient>

        {/* Pi Symbol Gradient */}
        <linearGradient id="tkPiGrad" x1="180" y1="140" x2="330" y2="300" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#0D3B75" />
          <stop offset="45%" stopColor="#0E5DAE" />
          <stop offset="80%" stopColor="#00A859" />
          <stop offset="100%" stopColor="#05B362" />
        </linearGradient>

        {/* Soft shadow for book */}
        <filter id="tkBookShadow" x="80" y="60" width="352" height="260" filterUnits="userSpaceOnUse">
          <feDropShadow dx="0" dy="6" stdDeviation="6" floodColor="#000" floodOpacity="0.15" />
        </filter>
      </defs>

      {/* Outer Border Ring */}
      <circle
        cx="256"
        cx-cy="256"
        cy="256"
        r="244"
        stroke="url(#tkRingGrad)"
        strokeWidth="24"
        fill="#FFFFFF"
      />

      {/* Inner White Background */}
      <circle cx="256" cy="256" r="230" fill="#FFFFFF" />

      {/* Open Book Graphic */}
      <g filter="url(#tkBookShadow)">
        {/* Book Spine / Cover Base */}
        <path
          d="M106 100 C180 84 250 115 256 126 C262 115 332 84 406 100 L400 286 C330 270 262 296 256 308 C250 296 182 270 112 286 Z"
          fill="#0B3B7A"
        />

        {/* Book White Pages Left */}
        <path
          d="M116 94 C182 78 248 106 256 118 L256 298 C248 286 182 258 116 274 Z"
          fill="#FFFFFF"
          stroke="#0B3B7A"
          strokeWidth="3"
        />

        {/* Book White Pages Right */}
        <path
          d="M256 118 C264 106 330 78 396 94 L396 274 C330 258 264 286 256 298 Z"
          fill="#FFFFFF"
          stroke="#0B3B7A"
          strokeWidth="3"
        />

        {/* Red Margin Line on Left Page */}
        <line x1="154" y1="92" x2="146" y2="270" stroke="#E53935" strokeWidth="2.5" />

        {/* Left Page Horizontal Ruled Lines */}
        <line x1="126" y1="126" x2="248" y2="138" stroke="#D0DBE5" strokeWidth="2" />
        <line x1="124" y1="156" x2="248" y2="168" stroke="#D0DBE5" strokeWidth="2" />
        <line x1="122" y1="186" x2="248" y2="198" stroke="#D0DBE5" strokeWidth="2" />
        <line x1="120" y1="216" x2="248" y2="228" stroke="#D0DBE5" strokeWidth="2" />
        <line x1="118" y1="246" x2="248" y2="258" stroke="#D0DBE5" strokeWidth="2" />

        {/* Right Page Ledger Table Header Grid */}
        <line x1="264" y1="138" x2="386" y2="126" stroke="#0E488F" strokeWidth="2" />
        <line x1="264" y1="168" x2="388" y2="156" stroke="#D0DBE5" strokeWidth="1.8" />
        <line x1="264" y1="198" x2="390" y2="186" stroke="#D0DBE5" strokeWidth="1.8" />
        <line x1="264" y1="228" x2="392" y2="216" stroke="#D0DBE5" strokeWidth="1.8" />
        <line x1="264" y1="258" x2="394" y2="246" stroke="#D0DBE5" strokeWidth="1.8" />

        {/* Ledger Vertical Columns */}
        <line x1="305" y1="134" x2="307" y2="260" stroke="#0E488F" strokeWidth="1.8" />
        <line x1="337" y1="130" x2="340" y2="258" stroke="#0E488F" strokeWidth="1.8" />
        <line x1="365" y1="126" x2="369" y2="252" stroke="#0E488F" strokeWidth="1.8" />
      </g>

      {/* Stylized Pi Logo Symbol in the Center */}
      <g filter="drop-shadow(0px 8px 10px rgba(0,0,0,0.18))">
        <path
          d="M178 198 C192 152 230 144 330 144 C342 144 348 152 338 166 C326 182 296 186 280 188 C256 190 238 200 230 220 L198 296 C190 316 166 312 176 290 L196 238 C194 246 172 248 166 228 C160 210 170 200 178 198 Z"
          fill="url(#tkPiGrad)"
        />
        <path
          d="M268 186 C284 186 310 176 332 196 C336 200 326 230 300 274 C286 298 274 316 250 308 C238 304 246 282 258 258 L278 214 C268 214 260 216 252 208 C246 202 252 186 268 186 Z"
          fill="url(#tkPiGrad)"
        />
      </g>

      {/* "ট্যালি খাতা" Brand Typography */}
      <text
        x="256"
        y="390"
        textAnchor="middle"
        fill="#0B3C7B"
        style={{
          fontFamily: 'system-ui, -apple-system, sans-serif',
          fontWeight: 900,
          fontSize: '76px',
          letterSpacing: '-1px',
        }}
      >
        ট্যালি <tspan fill="#00A859">খাতা</tspan>
      </text>

      {/* Decorative center divider badge */}
      <circle cx="250" cy="425" r="7" fill="#0B3C7B" />
      <circle cx="262" cy="425" r="7" fill="#00A859" />
      <line x1="130" y1="425" x2="236" y2="425" stroke="#0B3C7B" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="276" y1="425" x2="382" y2="425" stroke="#00A859" strokeWidth="2.5" strokeLinecap="round" />

      {/* Subtitle Slogan */}
      <text
        x="256"
        y="455"
        textAnchor="middle"
        fill="#005B94"
        style={{
          fontFamily: 'system-ui, -apple-system, sans-serif',
          fontWeight: 700,
          fontSize: '20px',
        }}
      >
        হিসাব রাখুন সহজে, ব্যবসা করুন এগিয়ে
      </text>
    </svg>
  );
};

/**
 * 2. Drive Offers Multi-SIM Logo (ড্রাইভ অফার)
 * Recreated accurately from the user-uploaded `creative-flat-mode-phone-sim-card-logo-icon-vector-29214166.jpg`
 */
export const DriveOfferSimsLogo: React.FC<{ className?: string }> = ({ className = 'w-10 h-10' }) => {
  return (
    <svg
      viewBox="0 0 500 500"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        {/* Soft shadow under the sim cards */}
        <radialGradient id="simShadow" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
          <stop offset="0%" stopColor="#1E293B" stopOpacity="0.4" />
          <stop offset="60%" stopColor="#1E293B" stopOpacity="0.15" />
          <stop offset="100%" stopColor="#1E293B" stopOpacity="0" />
        </radialGradient>

        <linearGradient id="limeSim" x1="0" y1="0" x2="250" y2="350" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#D4E633" />
          <stop offset="100%" stopColor="#B4CB1D" />
        </linearGradient>

        <linearGradient id="blueSim" x1="100" y1="50" x2="350" y2="400" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#3AA3E8" />
          <stop offset="100%" stopColor="#1E7DC5" />
        </linearGradient>

        <linearGradient id="orangeSim" x1="150" y1="100" x2="450" y2="450" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#FF6B3D" />
          <stop offset="50%" stopColor="#F95428" />
          <stop offset="100%" stopColor="#E03A10" />
        </linearGradient>

        {/* Chip Gold/White Metallic Gradient */}
        <linearGradient id="chipMetal" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="100%" stopColor="#F1F5F9" />
        </linearGradient>
      </defs>

      {/* Oval Drop Shadow on the floor */}
      <ellipse cx="245" cy="435" rx="100" ry="18" fill="url(#simShadow)" />

      {/* 1. BACK LIME GREEN SIM CARD (Tilted Left) */}
      <g transform="translate(45, 45) rotate(-18 160 220)">
        <path
          d="M 40 40 
             L 170 40 
             L 210 80 
             L 210 320 
             Q 210 335 195 335 
             L 40 335 
             Q 25 335 25 320 
             L 25 55 
             Q 25 40 40 40 Z"
          fill="url(#limeSim)"
        />
      </g>

      {/* 2. MIDDLE BLUE SIM CARD (Upright / Slight tilt) */}
      <g transform="translate(75, 40) rotate(-6 180 220)">
        <path
          d="M 40 40 
             L 170 40 
             L 210 80 
             L 210 320 
             Q 210 335 195 335 
             L 40 335 
             Q 25 335 25 320 
             L 25 55 
             Q 25 40 40 40 Z"
          fill="url(#blueSim)"
        />
      </g>

      {/* 3. FRONT ORANGE SIM CARD (Angled Forward Right) */}
      <g transform="translate(110, 48) rotate(24 180 220)">
        {/* SIM Body */}
        <path
          d="M 40 40 
             L 165 40 
             L 215 90 
             L 215 320 
             Q 215 340 195 340 
             L 40 340 
             Q 20 340 20 320 
             L 20 60 
             Q 20 40 40 40 Z"
          fill="url(#orangeSim)"
          filter="drop-shadow(-4px 8px 12px rgba(0,0,0,0.25))"
        />

        {/* Micro Chip Plate (White / Light Metal) */}
        <rect
          x="62"
          y="150"
          width="96"
          height="115"
          rx="22"
          fill="url(#chipMetal)"
          stroke="#D1431B"
          strokeWidth="3.5"
        />

        {/* Chip Contact Traces (Orange/Coral Lines matching image) */}
        <g stroke="#E5471E" strokeWidth="3.5" strokeLinecap="round">
          {/* Inner Chip Frame */}
          <rect x="75" y="165" width="70" height="85" rx="14" fill="none" strokeWidth="3.5" />
          
          {/* Horizontal Divider Line */}
          <line x1="75" y1="207" x2="145" y2="207" />
          
          {/* Vertical Connecting Lines */}
          <line x1="110" y1="165" x2="110" y2="250" />
          
          {/* Outer pin channels */}
          <line x1="62" y1="185" x2="75" y2="185" />
          <line x1="62" y1="230" x2="75" y2="230" />
          <line x1="145" y1="185" x2="158" y2="185" />
          <line x1="145" y1="230" x2="158" y2="230" />
        </g>
      </g>
    </svg>
  );
};

/**
 * 3. Add Money Logo (অ্যাড মানি)
 * Crisp, vibrant vector designed for pure white background box
 */
export const AddMoneyServiceLogo: React.FC<{ className?: string }> = ({ className = 'w-10 h-10' }) => {
  return (
    <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
      <defs>
        <linearGradient id="addMoneyWallet" x1="10" y1="20" x2="85" y2="90" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#10B981" />
          <stop offset="100%" stopColor="#059669" />
        </linearGradient>
        <linearGradient id="addMoneyBadge" x1="50" y1="10" x2="90" y2="50" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#34D399" />
          <stop offset="100%" stopColor="#059669" />
        </linearGradient>
      </defs>
      
      {/* Wallet Body */}
      <rect x="16" y="26" width="68" height="52" rx="14" fill="url(#addMoneyWallet)" />
      
      {/* Card inserting inside */}
      <rect x="26" y="16" width="48" height="22" rx="6" fill="#A7F3D0" />
      <rect x="32" y="22" width="20" height="4" rx="2" fill="#047857" />

      {/* Wallet Flap */}
      <path
        d="M 52 42 H 84 Q 86 42 86 44 V 60 Q 86 62 84 62 H 52 Q 46 62 46 52 Q 46 42 52 42 Z"
        fill="#047857"
      />
      <circle cx="56" cy="52" r="4.5" fill="#FDE047" stroke="#FEF08A" strokeWidth="1.5" />

      {/* Plus Bubble */}
      <circle cx="74" cy="24" r="16" fill="url(#addMoneyBadge)" stroke="#FFFFFF" strokeWidth="3" />
      <path d="M 74 16 V 32 M 66 24 H 82" stroke="#FFFFFF" strokeWidth="3.5" strokeLinecap="round" />
    </svg>
  );
};

/**
 * 4. Mobile Recharge Logo (মোবাইল রিচার্জ)
 * Crisp, vibrant vector designed for pure white background box
 */
export const MobileRechargeServiceLogo: React.FC<{ className?: string }> = ({ className = 'w-10 h-10' }) => {
  return (
    <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
      <defs>
        <linearGradient id="rechargePhone" x1="20" y1="10" x2="80" y2="90" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#3B82F6" />
          <stop offset="100%" stopColor="#1D4ED8" />
        </linearGradient>
        <linearGradient id="rechargeFlash" x1="40" y1="30" x2="70" y2="70" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#FACC15" />
          <stop offset="100%" stopColor="#EA580C" />
        </linearGradient>
      </defs>

      {/* Smartphone Body */}
      <rect x="26" y="12" width="48" height="76" rx="12" fill="url(#rechargePhone)" />
      
      {/* Screen area */}
      <rect x="31" y="20" width="38" height="58" rx="6" fill="#EFF6FF" />
      
      {/* Speaker grill & Home line */}
      <rect x="42" y="15" width="16" height="2.5" rx="1.25" fill="#93C5FD" />
      <rect x="43" y="81" width="14" height="3" rx="1.5" fill="#93C5FD" />

      {/* Electric Flash / Recharge Bolt in the center of the screen */}
      <path
        d="M 52 28 L 40 48 H 50 L 46 68 L 62 46 H 52 L 56 28 Z"
        fill="url(#rechargeFlash)"
        filter="drop-shadow(0 2px 4px rgba(234, 88, 12, 0.4))"
      />

      {/* Radiating Signal Waves */}
      <path d="M 76 34 Q 84 48 76 62" stroke="#3B82F6" strokeWidth="3" strokeLinecap="round" />
      <path d="M 82 26 Q 94 48 82 70" stroke="#60A5FA" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
};
