import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { DriveOffer, OperatorType, SocialCommunityLinks, Transaction } from '../types';
import {
  Gift,
  ArrowRight,
  ArrowUpRight,
  ArrowDownLeft,
  Volume2,
  Trash2,
  Globe,
  Phone,
  Calendar,
  ShoppingBag,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Clock,
  Eye,
  EyeOff,
  Activity,
  CheckCircle2,
  Clock3,
  FileText,
} from 'lucide-react';
import { OperatorLogo, BKashLogo, NagadLogo, RocketLogo, UpayLogo } from './OperatorLogos';
import { speakText, isTodayTransaction } from '../utils';

interface PromotionalOffersProps {
  offers: DriveOffer[];
  socialLinks?: SocialCommunityLinks;
  transactions?: Transaction[];
  language?: 'bn' | 'en';
  onSelectOffer: (offer: DriveOffer) => void;
  onSeeAll?: () => void;
  onSelectTransaction?: (trx: Transaction) => void;
  onDeleteTransaction?: (id: string) => void;
}

// Convert numbers to Bengali digits
const toBangla = (num: number | string): string => {
  const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return String(num).replace(/\d/g, (d) => bnDigits[parseInt(d, 10)]);
};

// Default showcase offers across operators when none exist yet
const defaultShowcaseOffers: DriveOffer[] = [
  {
    id: 'demo-gp-promo',
    operator: 'gp',
    operatorName: 'গ্রামীণফোন',
    packageName: 'কম্বো প্যাক',
    internetGB: 50,
    minutes: 1500,
    validityDays: 30,
    regularPriceTK: 899,
    priceTK: 699,
    cashbackTK: 200,
    isPopular: true,
  },
  {
    id: 'demo-bl-promo',
    operator: 'banglalink',
    operatorName: 'বাংলালিংক',
    packageName: 'ধামাকা কম্বো',
    internetGB: 40,
    minutes: 1000,
    validityDays: 30,
    regularPriceTK: 799,
    priceTK: 580,
    cashbackTK: 219,
    isPopular: true,
  },
  {
    id: 'demo-robi-promo',
    operator: 'robi',
    operatorName: 'রবি',
    packageName: 'মেগা বান্ডেল',
    internetGB: 45,
    minutes: 1200,
    validityDays: 30,
    regularPriceTK: 850,
    priceTK: 640,
    cashbackTK: 210,
    isPopular: true,
  },
  {
    id: 'demo-airtel-promo',
    operator: 'airtel',
    operatorName: 'এয়ারটেল',
    packageName: 'সুপার প্যাক',
    internetGB: 35,
    minutes: 800,
    validityDays: 30,
    regularPriceTK: 699,
    priceTK: 499,
    cashbackTK: 200,
    isPopular: true,
  },
  {
    id: 'demo-teletalk-promo',
    operator: 'teletalk',
    operatorName: 'টেলিটক',
    packageName: 'স্পেশাল প্যাক',
    internetGB: 30,
    minutes: 600,
    validityDays: 30,
    regularPriceTK: 550,
    priceTK: 390,
    cashbackTK: 160,
    isPopular: true,
  },
];

export const PromotionalOffers: React.FC<PromotionalOffersProps> = ({
  offers,
  transactions = [],
  language = 'bn',
  onSelectOffer,
  onSeeAll,
  onSelectTransaction,
  onDeleteTransaction,
}) => {
  const isBangla = language !== 'en';

  // Live midnight ticker: automatically updates at 12:00 AM midnight or every 10 seconds
  const [midnightTicker, setMidnightTicker] = useState(Date.now());
  useEffect(() => {
    const timer = setInterval(() => {
      setMidnightTicker(Date.now());
    }, 10000);
    return () => clearInterval(timer);
  }, []);

  // Filter transactions to strictly display TODAY's hits (pending, success, failed)
  // All hits from previous days automatically clear from the home page at 12:00 AM midnight
  const todayTransactions = useMemo(() => {
    return transactions.filter((trx) => isTodayTransaction(trx));
  }, [transactions, midnightTicker]);

  // Section hide/show state with localStorage persistence
  const [isSectionHidden, setIsSectionHidden] = useState<boolean>(() => {
    try {
      return localStorage.getItem('hide_home_today_transactions') === 'true';
    } catch {
      return false;
    }
  });

  const toggleSectionHidden = () => {
    setIsSectionHidden((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('hide_home_today_transactions', String(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  // Filter state for the 3 stat buttons: 'all' (হিস্টোরি), 'hits' (আজকের হিট), 'pending' (পেন্ডিং)
  const [trxFilter, setTrxFilter] = useState<'all' | 'hits' | 'pending'>('all');

  const todayHitsCount = useMemo(() => {
    return todayTransactions.filter((t) => t.status === 'success').length;
  }, [todayTransactions]);

  const todayPendingCount = useMemo(() => {
    return todayTransactions.filter(
      (t) => t.status === 'pending' || (!t.status && t.type !== 'failed')
    ).length;
  }, [todayTransactions]);

  const filteredTodayTransactions = useMemo(() => {
    if (trxFilter === 'hits') {
      return todayTransactions.filter((t) => t.status === 'success');
    }
    if (trxFilter === 'pending') {
      return todayTransactions.filter(
        (t) => t.status === 'pending' || (!t.status && t.type !== 'failed')
      );
    }
    return todayTransactions;
  }, [todayTransactions, trxFilter]);

  // Unified list of offers to display: uses real offers if available, otherwise rich showcase offers
  const displayOffers = useMemo(() => {
    return offers && offers.length > 0 ? offers : defaultShowcaseOffers;
  }, [offers]);

  // Carousel Slider state & auto-slide controls
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const sliderRef = useRef<HTMLDivElement>(null);

  // Smoothly scroll container to slide at index
  const scrollToSlide = useCallback((index: number) => {
    if (!sliderRef.current) return;
    const container = sliderRef.current;
    const children = Array.from(container.children) as HTMLElement[];
    if (children[index]) {
      const targetChild = children[index];
      targetChild.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
        inline: 'start',
      });
      setCurrentSlideIndex(index);
    }
  }, []);

  const handleNextSlide = useCallback(() => {
    const next = (currentSlideIndex + 1) % displayOffers.length;
    scrollToSlide(next);
  }, [currentSlideIndex, displayOffers.length, scrollToSlide]);

  const handlePrevSlide = useCallback(() => {
    const prev = (currentSlideIndex - 1 + displayOffers.length) % displayOffers.length;
    scrollToSlide(prev);
  }, [currentSlideIndex, displayOffers.length, scrollToSlide]);

  // Auto-slide effect: automatically moves to the next banner one after another every 3 seconds
  useEffect(() => {
    if (displayOffers.length <= 1 || isPaused) return;

    const timer = setInterval(() => {
      setCurrentSlideIndex((prev) => {
        const next = (prev + 1) % displayOffers.length;
        if (sliderRef.current) {
          const children = Array.from(sliderRef.current.children) as HTMLElement[];
          if (children[next]) {
            children[next].scrollIntoView({
              behavior: 'smooth',
              block: 'nearest',
              inline: 'start',
            });
          }
        }
        return next;
      });
    }, 3000);

    return () => clearInterval(timer);
  }, [displayOffers.length, isPaused]);

  // Sync current slide index on manual scroll / touch swipe
  const handleScroll = () => {
    if (!sliderRef.current) return;
    const container = sliderRef.current;
    const scrollLeft = container.scrollLeft;
    const children = Array.from(container.children) as HTMLElement[];
    let closestIndex = 0;
    let minDiff = Infinity;
    children.forEach((child, index) => {
      const diff = Math.abs((child.offsetLeft - container.offsetLeft) - scrollLeft);
      if (diff < minDiff) {
        minDiff = diff;
        closestIndex = index;
      }
    });
    if (closestIndex !== currentSlideIndex) {
      setCurrentSlideIndex(closestIndex);
    }
  };

  const getOperatorName = (op: OperatorType): string => {
    if (isBangla) {
      switch (op) {
        case 'gp':
          return 'গ্রামীণফোন';
        case 'robi':
          return 'রবি';
        case 'banglalink':
          return 'বাংলালিংক';
        case 'airtel':
          return 'এয়ারটেল';
        case 'teletalk':
          return 'টেলিটক';
        case 'skitto':
          return 'স্কিটো';
        default:
          return 'ড্রাইভ অফার';
      }
    } else {
      switch (op) {
        case 'gp':
          return 'Grameenphone';
        case 'robi':
          return 'Robi';
        case 'banglalink':
          return 'Banglalink';
        case 'airtel':
          return 'Airtel';
        case 'teletalk':
          return 'Teletalk';
        case 'skitto':
          return 'Skitto';
        default:
          return String(op).toUpperCase();
      }
    }
  };

  const getOperatorEnglishName = (op: OperatorType): string => {
    switch (op) {
      case 'gp':
        return 'Grameenphone';
      case 'banglalink':
        return 'Banglalink';
      case 'robi':
        return 'Robi';
      case 'airtel':
        return 'Airtel';
      case 'teletalk':
        return 'Teletalk';
      case 'skitto':
        return 'Skitto';
      default:
        return String(op).toUpperCase();
    }
  };

  const getCustomBannerGradient = (op: OperatorType) => {
    switch (op) {
      case 'gp':
        return 'from-[#005ed9] via-[#0072CE] to-[#004b99] border-[#0091ff]/60 shadow-[0_10px_25px_rgba(0,114,206,0.35)]';
      case 'banglalink':
        return 'from-[#e65100] via-[#FF5B00] to-[#bf360c] border-[#ff9100]/60 shadow-[0_10px_25px_rgba(255,91,0,0.35)]';
      case 'robi':
        return 'from-[#b71c1c] via-[#ED1C24] to-[#7f0000] border-[#ff5252]/60 shadow-[0_10px_25px_rgba(237,28,36,0.35)]';
      case 'airtel':
        return 'from-[#c62828] via-[#E30613] to-[#800000] border-[#ff5252]/60 shadow-[0_10px_25px_rgba(227,6,19,0.35)]';
      case 'teletalk':
        return 'from-[#00695c] via-[#008752] to-[#004d40] border-[#26a69a]/60 shadow-[0_10px_25px_rgba(0,135,82,0.35)]';
      case 'skitto':
        return 'from-[#6a1b9a] via-[#7B1FA2] to-[#38006b] border-[#ba68c8]/60 shadow-[0_10px_25px_rgba(123,31,162,0.35)]';
      default:
        return 'from-[#005ed9] via-[#0072CE] to-[#004b99] border-[#0091ff]/60 shadow-[0_10px_25px_rgba(0,114,206,0.35)]';
    }
  };

  const renderTrxIcon = (trx: Transaction) => {
    if (trx.type === 'add_money') {
      if (trx.paymentMethod === 'bKash') return <BKashLogo className="w-10 h-10" />;
      if (trx.paymentMethod === 'Nagad') return <NagadLogo className="w-10 h-10" />;
      if (trx.paymentMethod === 'Rocket') return <RocketLogo className="w-10 h-10" />;
      if (trx.paymentMethod === 'Upay') return <UpayLogo className="w-10 h-10" />;
      return (
        <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs">
          <ArrowDownLeft className="w-5 h-5 text-emerald-600" />
        </div>
      );
    }
    if (trx.operator) {
      return <OperatorLogo operator={trx.operator} className="w-10 h-10 shrink-0" />;
    }
    return (
      <div className="w-10 h-10 rounded-2xl bg-purple-100 text-purple-700 flex items-center justify-center font-bold text-xs">
        <ArrowUpRight className="w-5 h-5 text-purple-600" />
      </div>
    );
  };

  return (
    <div className="px-4 py-2 space-y-6">
      {/* 1. Promotional Offers Section */}
      <div>
        {/* Header with Title and 'সব দেখুন' / 'See All' Link */}
        <div className="flex items-center justify-between mb-3 px-1">
          <div className="flex items-center gap-2">
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
            </span>
            <h2 className="text-xl font-black text-slate-950 tracking-tight flex items-center gap-1.5">
              <span>{isBangla ? 'প্রমোশনাল অফার' : 'Promotional Offers'}</span>
              <span className="text-xs font-black uppercase tracking-wider bg-rose-100 text-rose-700 border border-rose-300 px-2.5 py-0.5 rounded-full shadow-2xs">
                {isBangla ? 'হট ডিল' : 'Hot Deals'}
              </span>
            </h2>
          </div>
          <div className="flex items-center gap-2">
            {/* Prev / Next Slide Navigation Buttons */}
            {displayOffers.length > 1 && (
              <div className="flex items-center gap-1 bg-slate-100 p-0.5 rounded-full border border-slate-200">
                <button
                  type="button"
                  onClick={handlePrevSlide}
                  title={isBangla ? 'পূর্ববর্তী ব্যানার' : 'Previous Banner'}
                  className="w-6 h-6 rounded-full flex items-center justify-center text-slate-700 hover:bg-white hover:text-indigo-600 active:scale-90 transition-all cursor-pointer"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={handleNextSlide}
                  title={isBangla ? 'পরবর্তী ব্যানার' : 'Next Banner'}
                  className="w-6 h-6 rounded-full flex items-center justify-center text-slate-700 hover:bg-white hover:text-indigo-600 active:scale-90 transition-all cursor-pointer"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            <button
              type="button"
              onClick={onSeeAll}
              className="text-sm font-black text-indigo-700 hover:text-indigo-800 active:scale-95 transition-all cursor-pointer"
            >
              {isBangla ? 'সব দেখুন' : 'See All'}
            </button>
          </div>
        </div>

        {/* Carousel Container with Pause on Hover/Touch */}
        <div
          className="relative group/slider"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
          onTouchStart={() => setIsPaused(true)}
          onTouchEnd={() => setIsPaused(false)}
        >
          {/* Horizontal Slider / Promotional Flight Banner Carousel */}
          <div
            ref={sliderRef}
            onScroll={handleScroll}
            className="flex gap-3.5 overflow-x-auto pb-2 snap-x snap-mandatory no-scrollbar -mx-1 px-1 scroll-smooth"
          >
            {displayOffers.map((offer, idx) => {
              const bgGradient = getCustomBannerGradient(offer.operator);
              const opName = getOperatorName(offer.operator);
              const opEnglishName = getOperatorEnglishName(offer.operator);

              // Calculated regular price and savings
              const regularPrice =
                offer.regularPriceTK && offer.regularPriceTK > offer.priceTK
                  ? offer.regularPriceTK
                  : Math.round(offer.priceTK * 1.15) || offer.priceTK + 100;
              const saveAmount = regularPrice > offer.priceTK ? regularPrice - offer.priceTK : 0;

              // Specs formatting for Data (Blue block) and Minutes (Green block)
              const dataAmountText =
                offer.internetGB && offer.internetGB > 0
                  ? isBangla
                    ? `${toBangla(offer.internetGB)} জিবি`
                    : `${offer.internetGB} GB`
                  : isBangla
                  ? '৫০ জিবি'
                  : '50 GB';

              const minutesAmountText =
                offer.minutes && offer.minutes > 0
                  ? isBangla
                    ? `${toBangla(offer.minutes)} মিনিট`
                    : `${offer.minutes} Min`
                  : offer.sms && offer.sms > 0
                  ? isBangla
                    ? `${toBangla(offer.sms)} এসএমএস`
                    : `${offer.sms} SMS`
                  : isBangla
                  ? '১৫০০ মিনিট'
                  : '1500 Min';

              const validityDisplay = offer.validityDays
                ? isBangla
                  ? `${toBangla(offer.validityDays)} দিন`
                  : `${offer.validityDays} Days`
                : isBangla
                ? '৩০ দিন'
                : '30 Days';

              const priceText = isBangla ? `৳ ${toBangla(offer.priceTK)}` : `৳ ${offer.priceTK}`;
              const regPriceDisplay = isBangla ? `৳ ${toBangla(regularPrice)}` : `৳ ${regularPrice}`;

              const cashbackDisplay =
                offer.cashbackTK && offer.cashbackTK > 0
                  ? isBangla
                    ? `ক্যাশব্যাক ৳${toBangla(offer.cashbackTK)}`
                    : `Cashback ৳${offer.cashbackTK}`
                  : saveAmount > 0
                  ? isBangla
                    ? `ক্যাশব্যাক ৳${toBangla(saveAmount)}`
                    : `Cashback ৳${saveAmount}`
                  : isBangla
                  ? 'ক্যাশব্যাক ৳১০০'
                  : 'Cashback ৳100';

              // Audio pronunciation for offer
              const handlePronounce = (e: React.MouseEvent) => {
                e.stopPropagation();
                if (isBangla) {
                  const speech = `${opName} ${dataAmountText} ও ${minutesAmountText}, মাত্র ${toBangla(offer.priceTK)} টাকা, মেয়াদ ${validityDisplay}`;
                  speakText(speech, 'bn');
                } else {
                  const speech = `${opEnglishName} ${dataAmountText} and ${minutesAmountText}, only ${offer.priceTK} Taka, validity ${validityDisplay}`;
                  speakText(speech, 'en');
                }
              };

              return (
                <div
                  key={offer.id || idx}
                  id={`flight-banner-${offer.id || idx}`}
                  onClick={() => onSelectOffer(offer)}
                  className={`w-[325px] xs:w-[370px] sm:w-[440px] md:w-[480px] shrink-0 snap-start rounded-[24px] p-3 sm:p-4 text-white shadow-xl hover:shadow-2xl transition-all duration-300 cursor-pointer relative overflow-hidden flex flex-col justify-between select-none group border-2 border-white/40 active:scale-[0.99] bg-gradient-to-r ${bgGradient}`}
                >
                  {/* Halftone Dot Grid Pattern on Bottom Left */}
                  <div
                    className="absolute -bottom-2 -left-2 w-28 h-28 opacity-25 pointer-events-none"
                    style={{
                      backgroundImage: 'radial-gradient(circle, #ffffff 1.5px, transparent 1.5px)',
                      backgroundSize: '8px 8px',
                    }}
                  />

                  {/* Glossy Wave Curves & Ambient Lighting */}
                  <div className="absolute top-0 right-0 w-64 h-32 bg-white/10 rounded-full blur-2xl pointer-events-none" />
                  <div className="absolute -bottom-8 right-12 w-48 h-24 bg-cyan-400/25 rounded-full blur-xl pointer-events-none" />
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 pointer-events-none" />

                  {/* 1. Top Header Row: Operator Logo, Title & "বেশি ডাটা বেশি কথা" Slogan */}
                  <div className="flex items-center justify-between relative z-10 gap-2 mb-2">
                    {/* Left: Operator Logo + Vertical Bar + Category & Brand Name */}
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-[16px] bg-gradient-to-tr from-[#005ed9] to-[#00a2ff] border-2 border-white shadow-[0_0_12px_rgba(255,255,255,0.6)] flex items-center justify-center p-1 shrink-0 overflow-hidden">
                        <OperatorLogo operator={offer.operator} className="w-full h-full object-contain" />
                      </div>
                      <div className="h-7 w-[2px] bg-white/60 rounded-full shrink-0" />
                      <div className="min-w-0 leading-tight">
                        <h4 className="text-sm sm:text-base font-black text-white tracking-wide truncate drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]">
                          {offer.packageName || (isBangla ? 'কম্বো প্যাক' : 'Combo Pack')}
                        </h4>
                        <p className="text-[11px] sm:text-xs font-extrabold text-white/95 truncate">
                          {opEnglishName}
                        </p>
                      </div>
                    </div>

                    {/* Right: "বেশি ডাটা / বেশি কথা" with Sparkles + Sound Audio Button */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      <div className="text-right leading-tight pr-0.5">
                        <div className="text-[11px] sm:text-xs font-black text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)]">
                          <div className="flex items-center justify-end gap-1 text-[#ffe600]">
                            <span className="text-[10px]">✨</span>
                            <span>{isBangla ? 'বেশি ডাটা' : 'More Data'}</span>
                          </div>
                          <div>{isBangla ? 'বেশি কথা' : 'More Talk'}</div>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={handlePronounce}
                        title={isBangla ? 'উচ্চারণ শুনুন' : 'Pronounce Offer'}
                        className="w-6 h-6 rounded-full bg-white/20 hover:bg-white/35 active:scale-90 flex items-center justify-center backdrop-blur-xs shadow-xs transition-transform cursor-pointer border border-white/40 text-white shrink-0"
                      >
                        <Volume2 className="w-3.5 h-3.5 text-white" />
                      </button>
                    </div>
                  </div>

                  {/* 2. Middle Section: Double Pill (Data + Minutes) & 3D Red Price Tag */}
                  <div className="flex items-center justify-between gap-1.5 sm:gap-2 my-1 relative z-10">
                    {/* Yellow Framed Double Capsule: Data (Blue) + Minutes (Green) */}
                    <div className="p-0.5 sm:p-1 rounded-full bg-[#ffe600] shadow-[0_0_14px_rgba(255,230,0,0.45)] ring-2 ring-cyan-300 flex items-center gap-1 shrink-0 border-2 border-white/90">
                      {/* Blue Data Block */}
                      <div className="bg-gradient-to-r from-[#005ecb] to-[#007bf5] text-white px-2 sm:px-3 py-0.5 sm:py-1 rounded-full flex items-center gap-1 shadow-inner border border-white/40 shrink-0">
                        <Globe className="w-3.5 h-3.5 sm:w-4.5 sm:h-4.5 text-white stroke-[2.5] shrink-0" />
                        <span className="text-[14px] xs:text-[15px] sm:text-[19px] font-black text-white tracking-tight leading-none drop-shadow-[0_2px_3px_rgba(0,0,0,0.6)] whitespace-nowrap">
                          {dataAmountText}
                        </span>
                      </div>

                      {/* Green Minutes Block */}
                      <div className="bg-gradient-to-r from-[#00b050] to-[#00c853] text-white px-2 sm:px-3 py-0.5 sm:py-1 rounded-full flex items-center gap-1 shadow-inner border border-white/40 shrink-0">
                        <Phone className="w-3.5 h-3.5 sm:w-4.5 sm:h-4.5 text-white fill-white stroke-[2.5] shrink-0" />
                        <span className="text-[14px] xs:text-[15px] sm:text-[19px] font-black text-white tracking-tight leading-none drop-shadow-[0_2px_3px_rgba(0,0,0,0.6)] whitespace-nowrap">
                          {minutesAmountText}
                        </span>
                      </div>
                    </div>

                    {/* 3D Tilted Crimson Price Tag - Positioned inside banner */}
                    <div className="relative shrink-0 flex flex-col items-center transform -rotate-2 hover:rotate-0 transition-transform -mt-3.5 sm:-mt-5 mr-1 sm:mr-2 z-20">
                      {/* Top Ribbon "মাত্র" */}
                      <div className="bg-[#ffe600] text-rose-950 font-black text-[9px] sm:text-[10px] px-2 py-0.5 rounded-t-md shadow-xs border-t border-x border-yellow-200 leading-none uppercase tracking-wider z-20">
                        {isBangla ? 'মাত্র' : 'ONLY'}
                      </div>

                      {/* Main Crimson 3D Badge */}
                      <div className="bg-gradient-to-b from-[#ff0055] via-[#e6004c] to-[#c4003f] border-[2px] sm:border-[2.5px] border-[#ffe600] rounded-xl px-2 sm:px-2.5 py-0.5 sm:py-1 shadow-[0_5px_14px_rgba(230,0,76,0.65)] relative z-10 flex items-center justify-center">
                        <span className="text-lg sm:text-2xl font-black text-white tracking-tight leading-none drop-shadow-[0_2px_5px_rgba(0,0,0,0.8)] whitespace-nowrap">
                          {priceText}
                        </span>
                      </div>

                      {/* Regular Price with Red Strikethrough */}
                      <div className="bg-white text-slate-900 px-1.5 sm:px-2 py-0.5 rounded-full text-[8px] sm:text-[9px] font-black shadow-md flex items-center justify-center relative border border-slate-200 mt-0.5 z-10">
                        <span className="line-through decoration-rose-600 decoration-2 text-slate-800">
                          {regPriceDisplay}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* 3. Bottom Row: Validity + Cashback Capsule + Buy Button */}
                  <div className="flex items-center justify-between gap-2 relative z-10 pt-1 border-t border-white/20">
                    <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
                      {/* Validity */}
                      <div className="flex items-center gap-1 text-white shrink-0">
                        <Calendar className="w-3.5 h-3.5 text-white" />
                        <div className="leading-none">
                          <span className="text-[8px] text-white/80 font-bold block">
                            {isBangla ? 'মেয়াদ' : 'Validity'}
                          </span>
                          <span className="text-xs sm:text-sm font-black text-[#ffe600] drop-shadow-xs">
                            {validityDisplay}
                          </span>
                        </div>
                      </div>

                      <div className="h-4 w-[1px] bg-white/40 rounded-full shrink-0" />

                      {/* Glowing Cyan Cashback Capsule */}
                      <div className="px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full bg-cyan-950/50 border border-cyan-300/80 shadow-[0_0_10px_rgba(0,255,255,0.4)] flex items-center gap-1 backdrop-blur-xs shrink-0">
                        <Gift className="w-3 h-3 text-amber-300 fill-rose-600" />
                        <span className="text-[9px] sm:text-[11px] font-black text-white tracking-wide">
                          {cashbackDisplay}
                        </span>
                      </div>
                    </div>

                    {/* Glossy White Buy Button with Shopping Bag */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectOffer(offer);
                      }}
                      className="px-3.5 sm:px-4 py-1.5 rounded-full bg-white hover:bg-cyan-50 active:scale-95 text-[#005ed9] text-xs sm:text-sm font-black flex items-center gap-1 shadow-[0_4px_12px_rgba(0,94,217,0.4)] transition-all cursor-pointer border border-white/80 group-hover:scale-105 shrink-0"
                    >
                      <span>{isBangla ? 'কিনুন' : 'Buy'}</span>
                      <ShoppingBag className="w-3.5 h-3.5 text-[#005ed9]" />
                      <ChevronRight className="w-3.5 h-3.5 text-[#005ed9] stroke-[3]" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Floating Left/Right Arrows for quick slide */}
          {displayOffers.length > 1 && (
            <>
              <button
                type="button"
                onClick={handlePrevSlide}
                aria-label="Previous Banner"
                className="hidden sm:flex absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 hover:bg-black/60 text-white items-center justify-center backdrop-blur-xs transition-all opacity-0 group-hover/slider:opacity-100 z-30 cursor-pointer shadow-md"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={handleNextSlide}
                aria-label="Next Banner"
                className="hidden sm:flex absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 hover:bg-black/60 text-white items-center justify-center backdrop-blur-xs transition-all opacity-0 group-hover/slider:opacity-100 z-30 cursor-pointer shadow-md"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </>
          )}

          {/* Slide Indicator Dots */}
          {displayOffers.length > 1 && (
            <div className="flex items-center justify-center gap-1.5 mt-2">
              {displayOffers.map((_, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => scrollToSlide(idx)}
                  title={`Slide ${idx + 1}`}
                  className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
                    currentSlideIndex === idx
                      ? 'w-6 bg-gradient-to-r from-blue-600 to-indigo-600 shadow-xs'
                      : 'w-1.5 bg-slate-300 hover:bg-slate-400'
                  }`}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* 2. Today's Hits & Transactions Section (Auto resets at 12:00 AM midnight) */}
      <div id="home-today-transactions-section" className="transition-all duration-300">
        {isSectionHidden ? (
          /* Collapsed / Hidden Banner with Show button */
          <div className="bg-slate-50 hover:bg-slate-100/80 border border-slate-200/90 rounded-2xl p-3 flex items-center justify-between transition-all shadow-2xs">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
                <EyeOff className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <h4 className="text-xs font-black text-slate-800 truncate">
                  {isBangla ? 'আজকের হিট ও লেনদেন হিস্টোরি হাইড করা' : "Today's Hits & History Hidden"}
                </h4>
                <p className="text-[10px] text-slate-500 font-medium truncate">
                  {isBangla ? 'হোমপেজে তালিকা দেখতে পাশে চাপ দিন' : 'Tap to show on home screen'}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={toggleSectionHidden}
              className="py-1.5 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black flex items-center gap-1.5 cursor-pointer shadow-xs shrink-0 transition-transform active:scale-95"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>{isBangla ? 'দেখান' : 'Show'}</span>
            </button>
          </div>
        ) : (
          /* Full systematic layout with clean cards & Hide button */
          <div className="space-y-2.5">
            {/* Header with Title & Hide Toggle */}
            <div className="flex items-center justify-between px-1">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-7 h-7 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                  <Activity className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm font-black text-slate-900 leading-tight truncate">
                    {isBangla ? 'আজকের হিট ও লেনদেন হিস্টোরি' : "Today's Hits & Transactions"}
                  </h3>
                  <div className="flex items-center gap-1 text-[10px] text-slate-500 font-medium">
                    <Clock className="w-3 h-3 text-amber-600 shrink-0" />
                    <span>{isBangla ? 'রাত ১২টায় অটো রিসেট' : 'Auto resets at 12 AM'}</span>
                  </div>
                </div>
              </div>

              {/* Hide (হাইড করুন) Button */}
              <button
                type="button"
                onClick={toggleSectionHidden}
                title={isBangla ? 'এই অংশটি লুকান' : 'Hide this section'}
                className="py-1 px-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors shrink-0"
              >
                <EyeOff className="w-3.5 h-3.5 text-slate-500" />
                <span>{isBangla ? 'হাইড করুন' : 'Hide'}</span>
              </button>
            </div>

            {/* 3 Systematic Clean Stat Cards: আজকের হিট : 0 টি, লেনদেন হিস্টোরি: 0 টি, পেন্ডিং: 0 টি */}
            <div className="grid grid-cols-3 gap-1.5">
              {/* 1. আজকের হিট */}
              <button
                type="button"
                onClick={() => setTrxFilter(trxFilter === 'hits' ? 'all' : 'hits')}
                className={`py-1 px-1.5 rounded-lg border text-center transition-all cursor-pointer relative ${
                  trxFilter === 'hits'
                    ? 'bg-emerald-50 border-emerald-500 ring-1 ring-emerald-500/30 shadow-2xs'
                    : 'bg-white border-slate-200 hover:border-emerald-300 shadow-2xs'
                }`}
              >
                <div className="flex items-center justify-center gap-0.5 text-[10px] font-bold text-emerald-800 leading-tight whitespace-nowrap overflow-hidden">
                  <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600 shrink-0" />
                  <span className="truncate">{isBangla ? 'আজকের হিট' : 'Hits'}:</span>
                  <span className="font-black text-slate-900 ml-0.5">{toBangla(todayHitsCount)}</span>
                  <span className="text-[9px] text-slate-500 font-semibold">টি</span>
                </div>
              </button>

              {/* 2. লেনদেন হিস্টোরি */}
              <button
                type="button"
                onClick={() => setTrxFilter('all')}
                className={`py-1 px-1.5 rounded-lg border text-center transition-all cursor-pointer relative ${
                  trxFilter === 'all'
                    ? 'bg-blue-50 border-blue-500 ring-1 ring-blue-500/30 shadow-2xs'
                    : 'bg-white border-slate-200 hover:border-blue-300 shadow-2xs'
                }`}
              >
                <div className="flex items-center justify-center gap-0.5 text-[10px] font-bold text-blue-800 leading-tight whitespace-nowrap overflow-hidden">
                  <FileText className="w-2.5 h-2.5 text-blue-600 shrink-0" />
                  <span className="truncate">{isBangla ? 'লেনদেন হিস্টোরি' : 'History'}:</span>
                  <span className="font-black text-slate-900 ml-0.5">{toBangla(todayTransactions.length)}</span>
                  <span className="text-[9px] text-slate-500 font-semibold">টি</span>
                </div>
              </button>

              {/* 3. পেন্ডিং */}
              <button
                type="button"
                onClick={() => setTrxFilter(trxFilter === 'pending' ? 'all' : 'pending')}
                className={`py-1 px-1.5 rounded-lg border text-center transition-all cursor-pointer relative ${
                  trxFilter === 'pending'
                    ? 'bg-amber-50 border-amber-500 ring-1 ring-amber-500/30 shadow-2xs'
                    : 'bg-white border-slate-200 hover:border-amber-300 shadow-2xs'
                }`}
              >
                <div className="flex items-center justify-center gap-0.5 text-[10px] font-bold text-amber-800 leading-tight whitespace-nowrap overflow-hidden">
                  <Clock3 className="w-2.5 h-2.5 text-amber-600 shrink-0" />
                  <span className="truncate">{isBangla ? 'পেন্ডিং' : 'Pending'}:</span>
                  <span className="font-black text-slate-900 ml-0.5">{toBangla(todayPendingCount)}</span>
                  <span className="text-[9px] text-slate-500 font-semibold">টি</span>
                </div>
              </button>
            </div>

            {/* Transaction List or Clean Empty Box */}
            <div className="space-y-2">
              {filteredTodayTransactions.length === 0 ? (
                <div className="bg-white rounded-2xl p-4 text-center border border-slate-200/90 shadow-2xs">
                  <div className="w-10 h-10 mx-auto mb-1.5 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-400">
                    <Clock className="w-5 h-5 text-slate-500" />
                  </div>
                  <h4 className="text-xs font-black text-slate-800">
                    {trxFilter === 'hits'
                      ? (isBangla ? 'আজকে এখনো কোনো সফল হিট নেই' : 'No successful hits today')
                      : trxFilter === 'pending'
                      ? (isBangla ? 'বর্তমানে কোনো পেন্ডিং লেনদেন নেই' : 'No pending transactions')
                      : (isBangla ? 'আজকে কোনো লেনদেন বা হিট রেকর্ড নেই' : 'No transactions recorded today')}
                  </h4>
                  <p className="text-[10px] text-slate-500 font-medium mt-0.5">
                    {isBangla
                      ? 'রাত ১২:০০ টায় স্বয়ংক্রিয়ভাবে ক্লিয়ার হয়ে নতুন দিন শুরু হয়'
                      : 'Auto clears at 12:00 AM midnight for the new day'}
                  </p>
                </div>
              ) : (
                filteredTodayTransactions.slice(0, 10).map((trx) => {
                  const isSuccess = trx.status === 'success';
                  const isFailed = trx.status === 'failed' || trx.status === 'cancelled';

                  return (
                    <div
                      key={trx.id}
                      onClick={() => onSelectTransaction && onSelectTransaction(trx)}
                      className="w-full bg-white rounded-2xl p-3 border border-slate-200 shadow-2xs hover:border-indigo-400 hover:shadow-xs transition-all flex items-center justify-between cursor-pointer active:scale-[0.99]"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        {renderTrxIcon(trx)}
                        <div className="min-w-0">
                          <h4 className="font-black text-slate-900 text-xs sm:text-sm leading-tight truncate">
                            {trx.details || (isBangla ? 'মোবাইল রিচার্জ' : 'Mobile Recharge')}
                          </h4>
                          <p className="text-[10px] sm:text-xs text-slate-500 font-medium font-mono mt-0.5 truncate">
                            {trx.phoneNumber || trx.trxId} • {trx.timestamp}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <div className="text-right">
                          <div
                            className={`font-black text-sm sm:text-base ${
                              trx.type === 'add_money' ? 'text-emerald-700' : 'text-slate-900'
                            }`}
                          >
                            {trx.type === 'add_money' ? '+' : '-'}৳{isBangla ? toBangla(trx.amount) : trx.amount}
                          </div>
                          <span
                            className={`text-[10px] font-black px-2 py-0.5 rounded-full inline-flex items-center gap-0.5 mt-0.5 shadow-2xs ${
                              isSuccess
                                ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                                : isFailed
                                ? 'bg-rose-100 text-rose-900 border border-rose-300'
                                : 'bg-amber-100 text-amber-950 border border-amber-300 animate-pulse'
                            }`}
                          >
                            {isSuccess ? '✓ সফল' : isFailed ? '✕ বাতিল' : '⏳ পেন্ডিং'}
                          </span>
                        </div>

                        {onDeleteTransaction && (
                          <button
                            type="button"
                            title="এই রেকর্ডটি সরান"
                            onClick={(e) => {
                              e.stopPropagation();
                              onDeleteTransaction(trx.id);
                            }}
                            className="p-1.5 rounded-lg bg-slate-100 hover:bg-rose-100 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer shrink-0"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

