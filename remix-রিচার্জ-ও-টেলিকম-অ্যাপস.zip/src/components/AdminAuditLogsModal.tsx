import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  History,
  X,
  User,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  Lock,
  Unlock,
  Plus,
  RefreshCw,
  Search,
} from 'lucide-react';
import { ActivityAuditLog } from '../types';
import { subscribeAuditLogs } from '../lib/firebase';

interface AdminAuditLogsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdminAuditLogsModal: React.FC<AdminAuditLogsModalProps> = ({ isOpen, onClose }) => {
  const [logs, setLogs] = useState<ActivityAuditLog[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  useEffect(() => {
    if (!isOpen) return;
    setLoading(true);
    const unsub = subscribeAuditLogs((fetchedLogs) => {
      setLogs(fetchedLogs);
      setLoading(false);
    });

    return () => unsub();
  }, [isOpen]);

  if (!isOpen) return null;

  const filteredLogs = logs.filter((log) => {
    if (filterType !== 'all' && log.actionType !== filterType) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        (log.actorName && log.actorName.toLowerCase().includes(q)) ||
        (log.actorEmail && log.actorEmail.toLowerCase().includes(q)) ||
        (log.description && log.description.toLowerCase().includes(q)) ||
        (log.targetId && log.targetId.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const getActionBadge = (type: ActivityAuditLog['actionType']) => {
    switch (type) {
      case 'dealer_approved':
        return (
          <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-black border border-emerald-200">
            ✓ ডিলার অনুমোদন
          </span>
        );
      case 'dealer_permissions_updated':
        return (
          <span className="px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800 text-[10px] font-black border border-indigo-200">
            ⚙️ পারমিশন আপডেট
          </span>
        );
      case 'dealer_suspended':
        return (
          <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 text-[10px] font-black border border-amber-200">
            ⚠️ ডিলার স্থগিত
          </span>
        );
      case 'dealer_removed':
        return (
          <span className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-800 text-[10px] font-black border border-rose-200">
            ✕ ডিলার বাতিল
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-800 text-[10px] font-bold">
            {type}
          </span>
        );
    }
  };

  return (
    <div
      id="audit-logs-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="audit-logs-modal-card"
        className="bg-white rounded-3xl w-full max-w-xl p-5 border border-slate-200 shadow-2xl space-y-4 my-auto relative"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center shadow-xs">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-900 flex items-center gap-1.5">
                <span>অ্যাক্টিভিটি ও হিস্টোরি অডিট লগ</span>
                <span className="px-1.5 py-0.2 bg-amber-100 text-amber-800 rounded text-[9px] font-extrabold">
                  সুপার এডমিন
                </span>
              </h3>
              <p className="text-[10px] text-slate-500 font-medium">
                ডিলার অনুমোদন, পারমিশন পরিবর্তন ও সিস্টেম অ্যাকশনের সংরক্ষিত রেকর্ড
              </p>
            </div>
          </div>
          <button
            type="button"
            id="close-audit-logs-btn"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center text-slate-500 transition-colors cursor-pointer"
            title="বন্ধ করুন"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search & Filter Bar */}
        <div className="flex flex-col sm:flex-row gap-2 items-center justify-between">
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="লগ খুঁজুন (নাম, ইমেইল, আইডি)..."
              className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 outline-none focus:border-amber-500 focus:bg-white"
            />
          </div>

          <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto no-scrollbar">
            {[
              { key: 'all', label: 'সকল লগ' },
              { key: 'dealer_approved', label: 'অনুমোদন' },
              { key: 'dealer_permissions_updated', label: 'পারমিশন' },
              { key: 'dealer_suspended', label: 'স্থগিত' },
            ].map((f) => (
              <button
                key={f.key}
                type="button"
                onClick={() => setFilterType(f.key)}
                className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold transition-all shrink-0 cursor-pointer ${
                  filterType === f.key
                    ? 'bg-amber-600 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Log list */}
        <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
          {loading ? (
            <div className="py-12 text-center text-slate-400 text-xs flex flex-col items-center justify-center gap-2">
              <RefreshCw className="w-5 h-5 animate-spin text-amber-600" />
              <span>লগ ডেটা লোড হচ্ছে...</span>
            </div>
          ) : filteredLogs.length === 0 ? (
            <div className="py-10 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-slate-500 text-xs">
              কোনো অডিট লগ রেকর্ড পাওয়া যায়নি।
            </div>
          ) : (
            filteredLogs.map((log) => (
              <div
                key={log.id}
                className="p-3 bg-slate-50 hover:bg-amber-50/40 rounded-2xl border border-slate-200/80 transition-all space-y-1.5"
              >
                <div className="flex items-center justify-between flex-wrap gap-1">
                  <div className="flex items-center gap-1.5">
                    {getActionBadge(log.actionType)}
                    <span className="text-[10px] font-bold text-slate-800">
                      {log.actorName || log.actorEmail}
                    </span>
                  </div>
                  <span className="text-[9px] text-slate-500 font-mono">
                    {log.timestamp ? new Date(log.timestamp).toLocaleString('bn-BD') : 'তারিখ নেই'}
                  </span>
                </div>

                <p className="text-xs font-semibold text-slate-800 leading-snug">
                  {log.description}
                </p>

                {log.metadata && Object.keys(log.metadata).length > 0 && (
                  <div className="text-[10px] text-slate-600 bg-white p-2 rounded-xl border border-slate-200/60 font-mono">
                    {JSON.stringify(log.metadata)}
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
          <span>মোট রেকর্ড: {filteredLogs.length} টি</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-black rounded-xl cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
