import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  Download,
  Share2,
  CheckCircle2,
  ExternalLink,
  Copy,
  Check,
  X,
  Sparkles,
  ShieldCheck,
  Terminal,
  Layers,
  ArrowRight,
  Info,
  QrCode,
  GitPullRequest,
  Github,
} from 'lucide-react';

interface AndroidApkModalProps {
  isOpen: boolean;
  onClose: () => void;
  appName?: string;
  isDarkMode?: boolean;
  isBangla?: boolean;
}

export const AndroidApkModal: React.FC<AndroidApkModalProps> = ({
  isOpen,
  onClose,
  appName = 'M APPS',
  isDarkMode = false,
  isBangla = true,
}) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState<boolean>(false);
  const [installedSuccess, setInstalledSuccess] = useState<boolean>(false);
  const [copiedUrl, setCopiedUrl] = useState<boolean>(false);
  const [copiedCommand, setCopiedCommand] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'install' | 'android_studio' | 'github' | 'apk' | 'developer'>('android_studio');

  // Listen for beforeinstallprompt event
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    const handleAppInstalled = () => {
      setIsInstallable(false);
      setDeferredPrompt(null);
      setInstalledSuccess(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    // Check if already in standalone mode
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setInstalledSuccess(true);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  if (!isOpen) return null;

  const currentAppUrl = typeof window !== 'undefined' ? window.location.origin : 'https://m-apps.telecom.app';
  const pwabuilderUrl = `https://www.pwabuilder.com/?url=${encodeURIComponent(currentAppUrl)}`;

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setInstalledSuccess(true);
        setIsInstallable(false);
      }
      setDeferredPrompt(null);
    } else {
      // Fallback: alert instructions
      alert(
        isBangla
          ? 'আপনার ব্রাউজারের উপরে ডানদিকের ৩-ডট (⋮) মেন্যুতে চাপ দিয়ে "Install app" বা "Add to Home screen" চাপুন।'
          : 'Tap the 3-dot menu (⋮) in your mobile browser and select "Install app" or "Add to Home screen".'
      );
    }
  };

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(currentAppUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const bubblewrapCommand = `npx @bubblewrap/cli init --manifest=${currentAppUrl}/manifest.json\nnpx @bubblewrap/cli build`;

  const handleCopyCommand = () => {
    navigator.clipboard.writeText(bubblewrapCommand);
    setCopiedCommand(true);
    setTimeout(() => setCopiedCommand(false), 2000);
  };

  // Generate downloadable twa-manifest.json
  const handleDownloadTwaManifest = () => {
    const twaManifest = {
      packageId: 'com.mapps.telecom.recharge',
      host: typeof window !== 'undefined' ? window.location.host : 'mapps.app',
      name: 'M APPS',
      launcherName: 'M APPS',
      themeColor: '#2563eb',
      navigationColor: '#2563eb',
      backgroundColor: '#ffffff',
      enableNotifications: true,
      startUrl: '/',
      appVersionName: '1.0.0',
      appVersionCode: 1,
      shortcuts: [],
      generatorApp: 'bubblewrap-cli',
      webManifestUrl: `${currentAppUrl}/manifest.json`,
      fallbackType: 'customtabs',
      features: {
        locationDelegation: { enabled: false },
        playBilling: { enabled: false }
      },
      alphaDependencies: { enabled: false },
      enableSiteSettingsShortcut: true,
      isChromeOSOnly: false,
      isMetaQuest: false,
      fullScopeUrl: `${currentAppUrl}/`
    };

    const blob = new Blob([JSON.stringify(twaManifest, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'twa-manifest.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div
        className={`w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl border transition-all ${
          isDarkMode
            ? 'bg-slate-900 text-slate-100 border-slate-800'
            : 'bg-white text-slate-800 border-slate-200'
        } flex flex-col max-h-[92vh]`}
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-emerald-600 p-5 text-white relative flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white p-1 flex items-center justify-center text-white shadow-lg border border-white/50 shrink-0 overflow-hidden">
              <img src="/app-logo.png" alt="App Logo" className="w-full h-full object-contain" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg sm:text-xl font-black leading-tight">
                  অ্যান্ড্রয়েড অ্যাপ (APK) ডাউনলোড
                </h3>
                <span className="px-2 py-0.5 bg-emerald-400 text-slate-950 rounded-full text-[10px] font-black uppercase shadow-xs">
                  APK Ready
                </span>
              </div>
              <p className="text-xs text-blue-100 font-medium mt-0.5">
                {appName} মোবাইল রিচার্জ ও টেলিকম অ্যাপ ইনস্টল করুন
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors cursor-pointer"
            title="বন্ধ করুন"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className={`flex border-b px-4 pt-2 gap-2 text-xs font-bold overflow-x-auto ${isDarkMode ? 'border-slate-800 bg-slate-900' : 'border-slate-150 bg-slate-50'}`}>
          <button
            type="button"
            onClick={() => setActiveTab('android_studio')}
            className={`pb-2.5 px-3 border-b-2 whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'android_studio'
                ? 'border-orange-600 text-orange-600 font-black'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-orange-600" />
            <span>অ্যান্ড্রয়েড ফোল্ডার (APK বিল্ড)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('github')}
            className={`pb-2.5 px-3 border-b-2 whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'github'
                ? 'border-purple-600 text-purple-600 font-black'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Github className="w-3.5 h-3.5 text-purple-600" />
            <span>GitHub Actions (অটো APK)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('install')}
            className={`pb-2.5 px-3 border-b-2 whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'install'
                ? 'border-blue-600 text-blue-600 font-black'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>ফোনে ইনস্টল (WebAPK)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('apk')}
            className={`pb-2.5 px-3 border-b-2 whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'apk'
                ? 'border-blue-600 text-blue-600 font-black'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>PWABuilder (.APK)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('developer')}
            className={`pb-2.5 px-3 border-b-2 whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'developer'
                ? 'border-blue-600 text-blue-600 font-black'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>কমান্ড ও কনফিগ</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
          {/* TAB: Android Studio / Native Android Project */}
          {activeTab === 'android_studio' && (
            <div className="space-y-4 animate-fadeIn">
              {/* Alert explaining the frame issue and resolution */}
              <div className="p-4 bg-orange-50 dark:bg-orange-950/40 border border-orange-200 dark:border-orange-800 rounded-2xl space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-xl bg-orange-500 text-white flex items-center justify-center font-black text-xs shadow-md">
                    ✓
                  </div>
                  <h4 className="font-black text-sm text-orange-950 dark:text-orange-200">
                    এন্ড্রয়েড ফোল্ডার (`android/`) তৈরি সম্পন্ন হয়েছে!
                  </h4>
                </div>
                <p className="text-xs text-orange-900 dark:text-orange-300 leading-relaxed font-medium">
                  <strong>কেন আগের APK তে মোবাইল ফ্রেম দেখা যাচ্ছিল?</strong><br />
                  কোনো অনলাইন ওয়েবসাইট-টু-এপিকে টুল বা ব্রাউজার সিমুলেটর সাইটটি কনভার্ট করার সময় বাইরের প্রিভিউ ফ্রেমসহ ক্যাপচার করেছিল। এখন আমরা আপনার কোডে সম্পূর্ণ নিজস্ব <strong>`android/`</strong> নেটিভ সোর্স ফোল্ডার তৈরি করে দিয়েছি এবং ওয়েব ভিউকে ১০০% ফুল স্ক্রিন করে দিয়েছি। এখন আর কোনো ফ্রেম আসবে না!
                </p>
              </div>

              {/* Direct Download ZIP Button */}
              <a
                href="/mapps-android-project.zip"
                download="mapps-android-capacitor-project.zip"
                className="w-full flex items-center justify-center gap-2.5 p-3.5 bg-gradient-to-r from-orange-600 via-amber-600 to-orange-700 hover:from-orange-700 hover:to-orange-800 text-white font-black text-sm rounded-2xl shadow-lg shadow-orange-600/30 transition-all transform active:scale-95 cursor-pointer no-underline"
              >
                <Download className="w-5 h-5 animate-bounce" />
                <span>ডাউনলোড করুন Android & Capacitor প্রজেক্ট ZIP (১-ক্লিক)</span>
              </a>

              {/* Step-by-Step Android Studio Build Guide */}
              <div className={`p-4 rounded-2xl border ${isDarkMode ? 'bg-slate-800/60 border-slate-700' : 'bg-slate-50 border-slate-200'} space-y-3`}>
                <h4 className="font-black text-xs text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Terminal className="w-4 h-4 text-orange-600" />
                  <span>Android Studio দিয়ে ১-ক্লিকে APK তৈরির নিয়ম:</span>
                </h4>

                <div className="space-y-2.5 text-xs text-slate-700 dark:text-slate-300">
                  <div className="flex items-start gap-2.5 p-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="w-6 h-6 rounded-full bg-orange-100 text-orange-800 flex items-center justify-center font-black text-[11px] shrink-0 mt-0.5">
                      ১
                    </span>
                    <div>
                      <strong className="text-slate-900 dark:text-white block">প্রজেক্ট ওপেন করুন</strong>
                      <span>AI Studio-এর ডানদিকের মেনু থেকে কোড জিপ (ZIP) বা GitHub থেকে ডাউনলোড করে কম্পিউটারের <strong>Android Studio</strong> দিয়ে ভেতরের <code>android</code> ফোল্ডারটি ওপেন (Open) করুন।</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="w-6 h-6 rounded-full bg-orange-100 text-orange-800 flex items-center justify-center font-black text-[11px] shrink-0 mt-0.5">
                      ২
                    </span>
                    <div>
                      <strong className="text-slate-900 dark:text-white block">Gradle Sync হতে দিন</strong>
                      <span>Android Studio স্বয়ংক্রিয়ভাবে Gradle লাইব্রেরিগুলো ডাউনলোড করে বিল্ড প্রস্তুত করবে (১-২ মিনিট)।</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="w-6 h-6 rounded-full bg-orange-100 text-orange-800 flex items-center justify-center font-black text-[11px] shrink-0 mt-0.5">
                      ৩
                    </span>
                    <div>
                      <strong className="text-slate-900 dark:text-white block">Build APK চাপুন</strong>
                      <span>উপরের মেনু থেকে <strong>Build ➔ Build Bundle(s) / APK(s) ➔ Build APK(s)</strong> এ ক্লিক করুন। সাথে সাথে আপনার অরিজিনাল <strong>app-debug.apk</strong> ফাইল তৈরি হয়ে যাবে!</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-black text-[11px] shrink-0 mt-0.5">
                      ৪
                    </span>
                    <div>
                      <strong className="text-emerald-900 dark:text-emerald-300 block">ফোনে ইনস্টল করুন</strong>
                      <span>তৈরি হওয়া .apk ফাইলটি অ্যান্ড্রয়েড ফোনে ইনস্টল করুন। কোনো ফ্রেম ছাড়া সরাসরি ১০০% ফুলস্ক্রিনে নেটিভ অ্যাপের মতো চলবে।</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Native Configuration Details */}
              <div className="p-3.5 bg-slate-100 dark:bg-slate-800 rounded-2xl grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-semibold">প্যাকেজ আইডি</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white">com.mapps.telecom</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-semibold">নেটিভ সাপোর্ট</span>
                  <span className="font-bold text-emerald-600">Android 5.0 থেকে 15+</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-semibold">হার্ডওয়্যার এক্সিলারেশন</span>
                  <span className="font-bold text-blue-600">সুপার স্মুথ ও ফাস্ট</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-semibold">ক্যামেরা ও রশিদ আপলোড</span>
                  <span className="font-bold text-purple-600">ইন-অ্যাপ ফাইল পিকিং</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB: GitHub Actions Auto APK Build */}
          {activeTab === 'github' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="p-4 bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800 rounded-2xl space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-xl bg-purple-600 text-white flex items-center justify-center font-black text-xs shadow-md">
                    <Github className="w-4 h-4" />
                  </div>
                  <h4 className="font-black text-sm text-purple-950 dark:text-purple-200">
                    GitHub Actions দিয়ে ক্লাউডে স্বয়ংক্রিয় APK বিল্ড
                  </h4>
                </div>
                <p className="text-xs text-purple-900 dark:text-purple-300 leading-relaxed font-medium">
                  আপনার প্রজেক্টে ইতিমধ্যে <strong>`.github/workflows/build-apk.yml`</strong> ফাইলটি যুক্ত রয়েছে। আপনার কম্পিউটারে কোনো ভারী সফটওয়্যার বা Android Studio ছাড়াই সরাসরি GitHub ক্লাউডে মাত্র ৩ মিনিটে আপনার Android APK তৈরি হয়ে যাবে!
                </p>
              </div>

              {/* Step by step GitHub push and build guide */}
              <div className={`p-4 rounded-2xl border ${isDarkMode ? 'bg-slate-800/60 border-slate-700' : 'bg-slate-50 border-slate-200'} space-y-3`}>
                <h4 className="font-black text-xs text-slate-900 dark:text-white flex items-center gap-1.5">
                  <GitPullRequest className="w-4 h-4 text-purple-600" />
                  <span>GitHub-এ কানেক্ট ও APK পাওয়ার সহজ ৩টি ধাপ:</span>
                </h4>

                <div className="space-y-2.5 text-xs text-slate-700 dark:text-slate-300">
                  <div className="flex items-start gap-2.5 p-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="w-6 h-6 rounded-full bg-purple-100 text-purple-800 flex items-center justify-center font-black text-[11px] shrink-0 mt-0.5">
                      ১
                    </span>
                    <div>
                      <strong className="text-slate-900 dark:text-white block">সরাসরি GitHub Export অথবা ZIP ডাউনলোড</strong>
                      <span className="leading-relaxed">
                        AI Studio উইন্ডোর উপরে ডানদিকের <strong>সেটিংস / ৩-ডট (⋮) মেন্যু</strong> থেকে <strong>"Export to GitHub"</strong> চাপুন। যদি ব্রাউজারে পপআপ বা কানেকশন এরর দেখায়, তবে নিচে দেওয়া <strong>১-ক্লিকে প্রজেক্ট ZIP ডাউনলোড</strong> করে নিন।
                      </span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="w-6 h-6 rounded-full bg-purple-100 text-purple-800 flex items-center justify-center font-black text-[11px] shrink-0 mt-0.5">
                      ২
                    </span>
                    <div>
                      <strong className="text-slate-900 dark:text-white block">GitHub রিপোজিটরিতে কোড আপলোড</strong>
                      <span className="leading-relaxed">
                        আপনার <a href="https://github.com/new" target="_blank" rel="noopener noreferrer" className="text-purple-600 font-bold underline inline-flex items-center gap-0.5">GitHub.com/new <ExternalLink className="w-3 h-3 inline" /></a> এ গিয়ে একটি নতুন রিপোজিটরি তৈরি করুন এবং জিপ ফাইলের ভেতরের ফাইলগুলো আপলোড বা <code>git push</code> করে দিন।
                      </span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-black text-[11px] shrink-0 mt-0.5">
                      ৩
                    </span>
                    <div>
                      <strong className="text-emerald-900 dark:text-emerald-300 block">Actions ট্যাব থেকে APK ডাউনলোড</strong>
                      <span className="leading-relaxed">
                        GitHub রিপোজিটরির <strong>"Actions"</strong> ট্যাবে যান। সেখানে <strong>"Build and Release Android APK"</strong> রান শেষ হলে নিচে <strong>Artifacts</strong> সেকশনে <strong>`mapps-telecom-debug-apk`</strong> ফাইলটি পেয়ে যাবেন!
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Direct ZIP download backup */}
              <div className="pt-1">
                <a
                  href="/mapps-android-project.zip"
                  download="mapps-android-capacitor-project.zip"
                  className="w-full flex items-center justify-center gap-2 p-3 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs rounded-xl shadow-md transition-all cursor-pointer no-underline"
                >
                  <Download className="w-4 h-4" />
                  <span>সম্পূর্ণ সোর্সকোড ZIP ডাউনলোড করুন (সবকিছু প্রস্তুত করা আছে)</span>
                </a>
              </div>
            </div>
          )}
          {activeTab === 'install' && (
            <div className="space-y-4 animate-fadeIn">
              {installedSuccess ? (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-3 text-emerald-900">
                  <CheckCircle2 className="w-8 h-8 text-emerald-600 shrink-0" />
                  <div>
                    <h4 className="font-black text-sm">অ্যাপটি ইতিমধ্যে আপনার ডিভাইসে ইনস্টল করা আছে!</h4>
                    <p className="text-xs text-emerald-700 mt-0.5">
                      আপনি হোম স্ক্রিন থেকে সরাসরি নেটিভ অ্যাপ হিসেবে ব্যবহার করতে পারবেন।
                    </p>
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black shadow-md">
                        M
                      </div>
                      <div>
                        <h4 className="font-black text-sm text-slate-900">{appName} Android WebAPK</h4>
                        <span className="text-[11px] text-blue-700 font-semibold">আকার: ~২.৫ MB • সম্পূর্ণ অফিশিয়াল</span>
                      </div>
                    </div>
                    <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-[10px] font-black rounded-full">
                      অটো আপডেট
                    </span>
                  </div>

                  <p className="text-xs text-slate-700 leading-relaxed font-medium">
                    এই পদ্ধতিতে অ্যাপটি আপনার অ্যান্ড্রয়েড ফোনের হোম স্ক্রিনে অফিশিয়াল অ্যাপ হিসেবে যুক্ত হবে। কোনো ব্রাউজার অ্যাড্রেস বার থাকবে না এবং ফুল-স্ক্রিনে সুপার ফাস্ট চলবে!
                  </p>

                  <button
                    type="button"
                    onClick={handleInstallClick}
                    className="w-full max-w-[300px] mx-auto py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold text-[16px] rounded-xl shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 active:scale-98 transition-all cursor-pointer"
                  >
                    <Smartphone className="w-5 h-5" />
                    <span>📲 ফোনে ইনস্টল করুন</span>
                  </button>
                </div>
              )}

              {/* Step by step visual instructions */}
              <div className={`p-4 rounded-2xl border ${isDarkMode ? 'bg-slate-800/60 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                <h4 className="font-black text-xs text-slate-900 dark:text-white mb-2.5 flex items-center gap-1.5">
                  <Info className="w-4 h-4 text-blue-600" />
                  <span>ম্যানুয়ালি ইনস্টল করার ৩টি সহজ ধাপ:</span>
                </h4>
                <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center font-black text-[10px] shrink-0 mt-0.5">
                      ১
                    </span>
                    <span>আপনার মোবাইলের গুগল ক্রোম (Google Chrome) ব্রাউজারের উপরে ডানদিকের <strong>৩-ডট (⋮) মেন্যুতে</strong> চাপুন।</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center font-black text-[10px] shrink-0 mt-0.5">
                      ২
                    </span>
                    <span>মেনু থেকে <strong>"Install app"</strong> অথবা <strong>"Add to Home screen" (হোম স্ক্রিনে যোগ করুন)</strong> অপশনে চাপ দিন।</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center font-black text-[10px] shrink-0 mt-0.5">
                      ৩
                    </span>
                    <span>কনফার্ম করুন। কয়েক সেকেন্ডের মধ্যে আপনার ফোনের মেনুতে ও হোম স্ক্রিনে {appName} অ্যাপ তৈরি হয়ে যাবে!</span>
                  </div>
                </div>
              </div>

              {/* Share & Copy App Link */}
              <div className="flex items-center justify-between p-3 bg-slate-100 dark:bg-slate-800 rounded-xl">
                <div className="truncate mr-2">
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-bold">অ্যাপ লাইভ লিংক</span>
                  <span className="font-mono text-xs font-bold text-slate-800 dark:text-slate-200 truncate block">
                    {currentAppUrl}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleCopyUrl}
                  className="px-3 py-1.5 bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 rounded-lg text-xs font-bold border border-slate-200 dark:border-slate-600 flex items-center gap-1 shadow-2xs hover:bg-slate-50 transition-colors cursor-pointer shrink-0"
                >
                  {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedUrl ? 'কপি হয়েছে' : 'লিংক কপি'}</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: Direct APK Build & Download */}
          {activeTab === 'apk' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl space-y-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  <h4 className="font-black text-sm text-emerald-950 dark:text-emerald-200">
                    অফিশিয়াল PWABuilder দিয়ে সরাসরি .APK ফাইল ডাউনলোড
                  </h4>
                </div>
                <p className="text-xs text-emerald-800 dark:text-emerald-300 leading-relaxed font-medium">
                  মাইক্রোসফট ও গুগলের অফিশিয়াল <strong>PWABuilder</strong> টুল সম্পূর্ণ ফ্রিতে আপনার এই প্রজেক্ট থেকে সাইন্ড <strong>.APK (Android Application Package)</strong> এবং গুগল প্লে স্টোরের <strong>.AAB</strong> প্যাকেজ জেনারেট করে দেয়।
                </p>
                <div className="pt-2">
                  <a
                    href={pwabuilderUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full max-w-[300px] mx-auto py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-[16px] rounded-xl shadow-md shadow-emerald-600/25 flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>⚡ APK ডাউনলোড করুন</span>
                    <ExternalLink className="w-3.5 h-3.5 opacity-80" />
                  </a>
                </div>
              </div>

              {/* Alternative Online APK Builders */}
              <div className={`p-4 rounded-2xl border ${isDarkMode ? 'bg-slate-800/60 border-slate-700' : 'bg-slate-50 border-slate-200'} space-y-3`}>
                <h4 className="font-black text-xs text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-blue-600" />
                  <span>বিকল্প ১-ক্লিক APK জেনারেটর টুলস:</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <a
                    href={`https://web2application.com/`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between hover:border-blue-400 transition-colors"
                  >
                    <div>
                      <span className="font-bold block text-slate-900 dark:text-white">Web2App</span>
                      <span className="text-[10px] text-slate-500">অনলাইন ইনস্ট্যান্ট APK বিল্ডার</span>
                    </div>
                    <ExternalLink className="w-3.5 h-3.5 text-blue-600" />
                  </a>

                  <a
                    href={`https://appcreator24.com/`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between hover:border-blue-400 transition-colors"
                  >
                    <div>
                      <span className="font-bold block text-slate-900 dark:text-white">AppCreator24</span>
                      <span className="text-[10px] text-slate-500">ফ্রি অ্যান্ড্রয়েড APK মেকার</span>
                    </div>
                    <ExternalLink className="w-3.5 h-3.5 text-blue-600" />
                  </a>
                </div>

                <div className="p-2.5 bg-blue-50/70 dark:bg-blue-950/40 rounded-xl border border-blue-200 dark:border-blue-800 text-[11px] text-blue-900 dark:text-blue-200">
                  💡 <strong>টিপস:</strong> ওপরের যেকোনো টুলে গিয়ে আপনার অ্যাপের লিংক <code>{currentAppUrl}</code> পেস্ট করে "Generate APK" চাপলেই রেডিমেড ইনস্টলেবল .apk ফাইল ডাউনলোড হয়ে যাবে।
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Developer & Android TWA Build */}
          {activeTab === 'developer' && (
            <div className="space-y-4 animate-fadeIn">
              <div className={`p-4 rounded-2xl border ${isDarkMode ? 'bg-slate-800/60 border-slate-700' : 'bg-slate-50 border-slate-200'} space-y-3`}>
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-xs text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Terminal className="w-4 h-4 text-emerald-600" />
                    <span>Google Bubblewrap CLI (অ্যান্ড্রয়েড TWA বিল্ড)</span>
                  </h4>
                  <button
                    type="button"
                    onClick={handleCopyCommand}
                    className="text-[11px] text-emerald-600 font-bold flex items-center gap-1 hover:underline cursor-pointer"
                  >
                    {copiedCommand ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedCommand ? 'কপি হয়েছে' : 'কমান্ড কপি'}</span>
                  </button>
                </div>

                <div className="p-3 bg-slate-950 text-emerald-400 font-mono text-xs rounded-xl overflow-x-auto">
                  <pre>{bubblewrapCommand}</pre>
                </div>

                <p className="text-xs text-slate-600 dark:text-slate-400">
                  আপনার কম্পিউটারে Node.js ও Android SDK থাকলে এই ২ লাইনের কমান্ড চালালেই সরাসরি অফিশিয়াল সাইন্ড APK তৈরি হবে।
                </p>

                <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-xs text-slate-800 dark:text-slate-200 block">twa-manifest.json</span>
                    <span className="text-[10px] text-slate-500">অ্যান্ড্রয়েড প্রজেক্টের সম্পূর্ণ কনফিগারেশন</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleDownloadTwaManifest}
                    className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>কনফিগারেশন ফাইল ডাউনলোড</span>
                  </button>
                </div>
              </div>

              {/* Android Safety & Package Specs */}
              <div className="p-3.5 bg-slate-100 dark:bg-slate-800 rounded-2xl grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-semibold">প্যাকেজ আইডি</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white">com.mapps.recharge</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-semibold">ভার্সন</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white">1.0.0 (Code 1)</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-semibold">টার্গেট ওএস</span>
                  <span className="font-bold text-slate-900 dark:text-white">Android 7.0 থেকে Android 15+</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-semibold">সিকিউরিটি</span>
                  <span className="font-bold text-emerald-600 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> ১০০% ভেরিফাইড
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className={`p-4 border-t flex items-center justify-between ${isDarkMode ? 'border-slate-800 bg-slate-900' : 'border-slate-150 bg-slate-50'}`}>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-medium">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>সকল অ্যান্ড্রয়েড ডিভাইসে সাপোর্ট করে</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs rounded-xl transition-colors cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
export default AndroidApkModal;
