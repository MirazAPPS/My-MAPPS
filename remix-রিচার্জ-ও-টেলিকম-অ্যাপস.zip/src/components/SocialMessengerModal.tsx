import React, { useState } from 'react';
import {
  X,
  MessageCircle,
  Send,
  ExternalLink,
  Copy,
  Check,
  Phone,
  Sparkles,
  Users,
  Megaphone,
  Bot,
  ArrowRight,
  ShieldCheck,
  Globe,
  Share2,
} from 'lucide-react';
import { SocialCommunityLinks, DriveOffer, UserProfile } from '../types';

interface SocialMessengerModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'whatsapp' | 'telegram' | 'direct_msg' | 'ussd_tools';
  socialLinks: SocialCommunityLinks;
  user: UserProfile;
  offers: DriveOffer[];
}

export const SocialMessengerModal: React.FC<SocialMessengerModalProps> = ({
  isOpen,
  onClose,
  type,
  socialLinks,
  user,
  offers,
}) => {
  const [activeTab, setActiveTab] = useState<'hub' | 'quick_send' | 'templates'>(
    type === 'direct_msg' ? 'quick_send' : 'hub'
  );
  const [customPhone, setCustomPhone] = useState('');
  const [customMessage, setCustomMessage] = useState(
    `আসসালামু আলাইকুম, ${user.shopName || 'টেলিকম রিচার্জ'} থেকে যোগাযোগ করছি। আপনার কাঙ্ক্ষিত ড্রাইভ অফার বা রিচার্জের বিস্তারিত জানান।`
  );
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSendDirectWhatsApp = () => {
    if (!customPhone) return;
    const cleanPhone = customPhone.replace(/[^0-9]/g, '');
    const formatted = cleanPhone.startsWith('88') ? cleanPhone : `88${cleanPhone.replace(/^0/, '0')}`;
    const url = `https://wa.me/${formatted}?text=${encodeURIComponent(customMessage)}`;
    window.open(url, '_blank');
  };

  // USSD & Telecom Shortcodes Data
  const ussdCodes = [
    {
      operator: 'গ্রামীনফোন (GP)',
      color: 'border-blue-200 bg-blue-50/50',
      codes: [
        { label: 'ব্যালেন্স চেক', code: '*566#' },
        { label: 'মিনিট ব্যালেন্স', code: '*121*1*2#' },
        { label: 'ইন্টারনেট এমবি চেক', code: '*121*1*4#' },
        { label: 'নিজের নম্বর দেখা', code: '*2#' },
        { label: 'জরুরি ব্যালেন্স', code: '*121*1*3#' },
      ],
    },
    {
      operator: 'বাংলালিংক (Banglalink)',
      color: 'border-amber-200 bg-amber-50/50',
      codes: [
        { label: 'মেইন ব্যালেন্স', code: '*124#' },
        { label: 'ইন্টারনেট ডাটা চেক', code: '*5000*500#' },
        { label: 'মিনিট চেক', code: '*121*100#' },
        { label: 'নিজের নম্বর দেখা', code: '*511#' },
        { label: 'স্পেশাল অফার', code: '*888#' },
      ],
    },
    {
      operator: 'রবি (Robi)',
      color: 'border-rose-200 bg-rose-50/50',
      codes: [
        { label: 'মেইন ব্যালেন্স', code: '*222#' },
        { label: 'ইন্টারনেট ব্যালেন্স', code: '*3#' },
        { label: 'মিনিট চেক', code: '*222*2#' },
        { label: 'নিজের নম্বর দেখা', code: '*2#' },
        { label: 'ঝটপট লোন', code: '*8#' },
      ],
    },
    {
      operator: 'এয়ারটেল (Airtel)',
      color: 'border-red-200 bg-red-50/50',
      codes: [
        { label: 'মেইন ব্যালেন্স', code: '*778#' },
        { label: 'ডাটা ও এমবি চেক', code: '*3#' },
        { label: 'মিনিট চেক', code: '*778*5#' },
        { label: 'নিজের নম্বর দেখা', code: '*2#' },
        { label: 'জরুরি লোন', code: '*141#' },
      ],
    },
    {
      operator: 'টেলিটক (Teletalk)',
      color: 'border-emerald-200 bg-emerald-50/50',
      codes: [
        { label: 'মেইন ব্যালেন্স', code: '*152#' },
        { label: 'ডাটা ব্যালেন্স', code: '*152#' },
        { label: 'নিজের নম্বর দেখা', code: '*551#' },
        { label: 'হেল্পলাইন', code: '121' },
      ],
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="w-full max-w-[420px] bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-auto flex flex-col max-h-[90vh]">
        {/* Modal Top Header */}
        <div
          className={`p-4 text-white flex items-center justify-between ${
            type === 'whatsapp' || type === 'direct_msg'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-700'
              : type === 'telegram'
              ? 'bg-gradient-to-r from-sky-500 to-blue-600'
              : 'bg-gradient-to-r from-indigo-600 to-purple-700'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30">
              {type === 'whatsapp' || type === 'direct_msg' ? (
                <MessageCircle className="w-5 h-5 text-white" />
              ) : type === 'telegram' ? (
                <Send className="w-5 h-5 text-white" />
              ) : (
                <Phone className="w-5 h-5 text-white" />
              )}
            </div>
            <div>
              <h3 className="font-extrabold text-sm leading-tight">
                {type === 'whatsapp'
                  ? 'WhatsApp কমিউনিকেশন হাব'
                  : type === 'telegram'
                  ? 'Telegram চ্যানেল ও সাপোর্ট হাব'
                  : type === 'direct_msg'
                  ? 'সরাসরি WhatsApp বার্তা পাঠান'
                  : 'টেলিকম USSD কোড ও টুলস'}
              </h3>
              <p className="text-[10px] text-white/80 font-medium">
                {type === 'whatsapp'
                  ? 'সরাসরি চ্যাট, নোটিশ ও কাস্টমার কেয়ার'
                  : type === 'telegram'
                  ? 'অফিসিয়াল ড্রাইভ অফার গ্রুপ ও বট'
                  : type === 'direct_msg'
                  ? 'নম্বর সেভ না করেই যেকোনো গ্রাহককে মেসেজ পাঠান'
                  : 'সকল সিমের ব্যালেন্স, মিনিট ও এমবি চেকিং কোড'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-all cursor-pointer border border-white/25"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Sub Navigation Bar for WhatsApp/Telegram */}
        {(type === 'whatsapp' || type === 'direct_msg') && (
          <div className="flex border-b border-slate-200 bg-slate-50 px-3 pt-2 gap-1">
            <button
              type="button"
              onClick={() => setActiveTab('hub')}
              className={`flex-1 py-2 text-xs font-bold text-center border-b-2 transition-all cursor-pointer ${
                activeTab === 'hub'
                  ? 'border-emerald-600 text-emerald-700 bg-white rounded-t-xl'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              কমিউনিটি ও গ্রুপ
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('quick_send')}
              className={`flex-1 py-2 text-xs font-bold text-center border-b-2 transition-all cursor-pointer ${
                activeTab === 'quick_send'
                  ? 'border-emerald-600 text-emerald-700 bg-white rounded-t-xl'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              সরাসরি মেসেজ পাঠান
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('templates')}
              className={`flex-1 py-2 text-xs font-bold text-center border-b-2 transition-all cursor-pointer ${
                activeTab === 'templates'
                  ? 'border-emerald-600 text-emerald-700 bg-white rounded-t-xl'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              মেসেজ টেমপ্লেট
            </button>
          </div>
        )}

        {/* Scrollable Content Body */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1">
          {/* ============================================================ */}
          {/* 1. WHATSAPP HUB VIEW                                        */}
          {/* ============================================================ */}
          {(type === 'whatsapp' || type === 'direct_msg') && activeTab === 'hub' && (
            <div className="space-y-3 animate-fadeIn">
              {/* Card 1: Official WhatsApp Support */}
              <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs shrink-0">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900">
                      অফিসিয়াল WhatsApp হেল্পলাইন
                    </h4>
                    <p className="text-[11px] text-emerald-800 font-medium mt-0.5">
                      ২৪/৭ কাস্টমার সার্ভিস ও ইনস্ট্যান্ট সাপোর্ট
                    </p>
                  </div>
                </div>
                <a
                  href={socialLinks.whatsappSupport || 'https://wa.me/8801700000000'}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold rounded-xl shadow-xs transition-all flex items-center gap-1 shrink-0 active:scale-95"
                >
                  <span>চ্যাট করুন</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              {/* Card 2: WhatsApp Reseller Group */}
              <div className="p-3.5 rounded-2xl bg-white border border-slate-200 hover:border-emerald-300 shadow-2xs transition-all flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-teal-500 text-white flex items-center justify-center shadow-xs shrink-0">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900">
                      রিসেলার ও রিটেইলার গ্রুপ
                    </h4>
                    <p className="text-[10.5px] text-slate-500 font-medium mt-0.5">
                      সকল রিসেলারদের পারস্পরিক আলোচনা ও ডিসকাউন্ট
                    </p>
                  </div>
                </div>
                <a
                  href={socialLinks.whatsappGroup || 'https://chat.whatsapp.com/'}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 text-xs font-extrabold rounded-xl transition-all flex items-center gap-1 shrink-0"
                >
                  <span>যুক্ত হন</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              {/* Card 3: WhatsApp Channel */}
              <div className="p-3.5 rounded-2xl bg-white border border-slate-200 hover:border-emerald-300 shadow-2xs transition-all flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-green-600 text-white flex items-center justify-center shadow-xs shrink-0">
                    <Megaphone className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900">
                      ড্রাইভ অফার নোটিশ চ্যানেল
                    </h4>
                    <p className="text-[10.5px] text-slate-500 font-medium mt-0.5">
                      প্রতিদিনের নতুন ড্রাইভ অফারের নোটিফিকেশন
                    </p>
                  </div>
                </div>
                <a
                  href={socialLinks.whatsappGroup || 'https://whatsapp.com/channel/'}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-green-50 hover:bg-green-100 text-green-800 border border-green-200 text-xs font-extrabold rounded-xl transition-all flex items-center gap-1 shrink-0"
                >
                  <span>ফলো করুন</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              {/* Quick Action Button to Direct Sender */}
              <button
                type="button"
                onClick={() => setActiveTab('quick_send')}
                className="w-full py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer mt-2"
              >
                <span>নম্বর সেভ না করেই WhatsApp মেসেজ পাঠান</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* ============================================================ */}
          {/* 2. DIRECT WHATSAPP NUMBER SENDER                            */}
          {/* ============================================================ */}
          {(type === 'whatsapp' || type === 'direct_msg') && activeTab === 'quick_send' && (
            <div className="space-y-3.5 animate-fadeIn">
              <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-900 text-xs">
                💡 <span className="font-bold">নম্বর সেভ করার ঝামেলা নেই!</span> গ্রাহকের ফোন নম্বর ও মেসেজ লিখে নিচের বাটনে ক্লিক করলেই সরাসরি WhatsApp চ্যাট ওপেন হবে।
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  গ্রাহকের মোবাইল নম্বর (০১XXXXXXXXX)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">
                    +88
                  </span>
                  <input
                    type="tel"
                    value={customPhone}
                    onChange={(e) => setCustomPhone(e.target.value)}
                    placeholder="01712345678"
                    className="w-full pl-12 pr-3 py-2 text-xs font-extrabold bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  বার্তা / মেসেজ
                </label>
                <textarea
                  rows={4}
                  value={customMessage}
                  onChange={(e) => setCustomMessage(e.target.value)}
                  className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  placeholder="আপনার মেসেজ লিখুন..."
                />
              </div>

              <button
                type="button"
                onClick={handleSendDirectWhatsApp}
                disabled={!customPhone}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp এ মেসেজ পাঠান</span>
              </button>
            </div>
          )}

          {/* ============================================================ */}
          {/* 3. MESSAGE TEMPLATES                                        */}
          {/* ============================================================ */}
          {(type === 'whatsapp' || type === 'direct_msg') && activeTab === 'templates' && (
            <div className="space-y-3 animate-fadeIn">
              <p className="text-xs text-slate-500 font-medium">
                দ্রুত কাস্টমারকে পাঠানোর জন্য নিচের রেডিমেড মেসেজগুলো কপি করতে পারেন:
              </p>

              {[
                {
                  id: 'tmp-success',
                  title: '✅ রিচার্জ/ড্রাইভ অফার সফল মেসেজ',
                  text: `সম্মানিত গ্রাহক, আপনার নম্বরে কাঙ্ক্ষিত অফারটি সফলভাবে রিচার্জ সম্পন্ন হয়েছে। সাথে থাকার জন্য ধন্যবাদ! - ${user.shopName || 'টেলিকম'}`,
                },
                {
                  id: 'tmp-due',
                  title: '⏳ বাকি টাকা পরিশোধের তাগাদা',
                  text: `আসসালামু আলাইকুম। আপনার টেলিকম বাকি বিল পরিশোধের বিনীত অনুরোধ জানাচ্ছি। দ্রুত পরিশোধ করে নিরবচ্ছিন্ন সেবা গ্রহণ করুন।`,
                },
                {
                  id: 'tmp-offer-promo',
                  title: '🔥 আজকের সেরা ড্রাইভ অফার ডিসকাউন্ট',
                  text: `🔥 আজকের স্পেশাল ডিসকাউন্ট অফার! GP, Robi, Banglalink, Airtel সকল সিমে আকর্ষণীয় ক্যাশব্যাক ও ডাটা অফার চলছে। যোগাযোগ: ${user.phone}`,
                },
              ].map((tmpl) => (
                <div
                  key={tmpl.id}
                  className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-extrabold text-slate-900">
                      {tmpl.title}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleCopy(tmpl.text, tmpl.id)}
                      className="px-2 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer"
                    >
                      {copiedId === tmpl.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span className="text-emerald-600">কপি হয়েছে</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>কপি</span>
                        </>
                      )}
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-600 leading-relaxed bg-white p-2 rounded-xl border border-slate-100">
                    {tmpl.text}
                  </p>
                </div>
              ))}
            </div>
          )}

          {/* ============================================================ */}
          {/* 4. TELEGRAM HUB VIEW                                        */}
          {/* ============================================================ */}
          {type === 'telegram' && (
            <div className="space-y-3 animate-fadeIn">
              {/* Telegram Channel 1 */}
              <div className="p-3.5 rounded-2xl bg-sky-50/70 border border-sky-200 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-sky-500 text-white flex items-center justify-center shadow-xs shrink-0">
                    <Send className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900">
                      টেলিগ্রাম অফিশিয়াল চ্যানেল
                    </h4>
                    <p className="text-[11px] text-sky-800 font-medium mt-0.5">
                      লাইভ ড্রাইভ অফার ও নোটিফিকেশন আপডেট
                    </p>
                  </div>
                </div>
                <a
                  href={socialLinks.telegramChannel || 'https://t.me/'}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-sky-500 hover:bg-sky-600 text-white text-xs font-extrabold rounded-xl shadow-xs transition-all flex items-center gap-1 shrink-0"
                >
                  <span>জয়েন করুন</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              {/* Telegram Bot */}
              <div className="p-3.5 rounded-2xl bg-white border border-slate-200 hover:border-sky-300 shadow-2xs transition-all flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500 text-white flex items-center justify-center shadow-xs shrink-0">
                    <Bot className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900">
                      টেলিগ্রাম সাপোর্ট অটো-বট
                    </h4>
                    <p className="text-[10.5px] text-slate-500 font-medium mt-0.5">
                      অটোমেটেড হেল্প ও তাৎক্ষণিক অফার অনুসন্ধান
                    </p>
                  </div>
                </div>
                <a
                  href={socialLinks.telegramChannel || 'https://t.me/'}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-xs font-extrabold rounded-xl transition-all flex items-center gap-1 shrink-0"
                >
                  <span>স্টার্ট বট</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              {/* Telegram Reseller Community */}
              <div className="p-3.5 rounded-2xl bg-white border border-slate-200 hover:border-sky-300 shadow-2xs transition-all flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs shrink-0">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900">
                      রিসেলার আলোচনা গ্রুপ
                    </h4>
                    <p className="text-[10.5px] text-slate-500 font-medium mt-0.5">
                      টেলিকম ব্যবসায়ীদের সক্রিয় কমিউনিটি
                    </p>
                  </div>
                </div>
                <a
                  href={socialLinks.telegramGroup || 'https://t.me/'}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 text-xs font-extrabold rounded-xl transition-all flex items-center gap-1 shrink-0"
                >
                  <span>গ্রুপে আসুন</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          )}

          {/* ============================================================ */}
          {/* 5. USSD CODES & TOOLS VIEW                                  */}
          {/* ============================================================ */}
          {type === 'ussd_tools' && (
            <div className="space-y-4 animate-fadeIn">
              {/* NID Biometric Sim Check Card */}
              <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-between">
                <div>
                  <h4 className="font-extrabold text-xs text-amber-950">
                    🪪 NID দিয়ে সিম সংখ্যা যাচাই
                  </h4>
                  <p className="text-[10.5px] text-amber-800 mt-0.5">
                    আপনার এনআইডির শেষ ৪ ডিজিট লিখে ডায়াল করুন:
                  </p>
                </div>
                <span className="px-2.5 py-1 bg-amber-600 text-white font-mono font-extrabold text-xs rounded-xl shadow-xs">
                  *16001#
                </span>
              </div>

              {/* Operators USSD Accordion List */}
              <div className="space-y-3">
                {ussdCodes.map((op, idx) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-2xl border ${op.color} space-y-2`}
                  >
                    <h5 className="font-extrabold text-xs text-slate-900">
                      {op.operator}
                    </h5>
                    <div className="grid grid-cols-2 gap-1.5">
                      {op.codes.map((c, cIdx) => (
                        <div
                          key={cIdx}
                          className="p-2 bg-white rounded-xl border border-slate-100 flex items-center justify-between shadow-2xs"
                        >
                          <span className="text-[10.5px] font-bold text-slate-700 truncate mr-1">
                            {c.label}
                          </span>
                          <span className="font-mono text-[11px] font-extrabold text-indigo-700 bg-slate-50 px-1.5 py-0.5 rounded-md shrink-0">
                            {c.code}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer Close */}
        <div className="p-3 bg-slate-50 border-t border-slate-100 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl transition-colors cursor-pointer"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
