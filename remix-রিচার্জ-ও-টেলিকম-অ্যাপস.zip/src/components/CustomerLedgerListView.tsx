import React, { useState } from 'react';
import {
  ArrowLeft,
  Search,
  ShoppingCart,
  Wallet,
  CreditCard,
  Plus,
  ChevronRight,
  Trash2,
  X,
  Check,
  UserPlus,
  Coins,
} from 'lucide-react';
import { CustomerAccount } from '../types';

interface CustomerLedgerListViewProps {
  customers: CustomerAccount[];
  onBack: () => void;
  onSelectCustomer: (customer: CustomerAccount) => void;
  onAddCustomer: (newCustomer: CustomerAccount) => void;
  onDeleteCustomer: (id: string) => void;
}

export const CustomerLedgerListView: React.FC<CustomerLedgerListViewProps> = ({
  customers,
  onBack,
  onSelectCustomer,
  onAddCustomer,
  onDeleteCustomer,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // New Customer Form State
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [initialType, setInitialType] = useState<'zero' | 'due' | 'advance'>('zero');
  const [initialAmount, setInitialAmount] = useState('');

  // Calculate totals across all customers
  const totalBuy = customers.reduce(
    (acc, cust) => acc + (cust.transactions || []).reduce((tAcc, t) => tAcc + (Number(t.buyPrice) || 0), 0),
    0
  );
  const totalSell = customers.reduce(
    (acc, cust) =>
      acc +
      (cust.transactions || []).reduce((tAcc, t) => {
        if (t.itemName && t.itemName.includes('পূর্বের বাকি') && (Number(t.buyPrice) || 0) === 0) {
          return tAcc;
        }
        return tAcc + (Number(t.sellPrice) || 0);
      }, 0),
    0
  );
  const totalProfit = customers.reduce(
    (acc, cust) =>
      acc +
      (cust.transactions || []).reduce((tAcc, t) => {
        const buy = Number(t.buyPrice) || 0;
        const sell = Number(t.sellPrice) || 0;
        if (buy > 0 && sell > 0) {
          return tAcc + (sell - buy);
        }
        return tAcc;
      }, 0),
    0
  );
  const totalDeposit = customers.reduce(
    (acc, cust) => acc + (cust.transactions || []).reduce((tAcc, t) => tAcc + (Number(t.depositAmount) || 0), 0),
    0
  );
  // প্রতিটি কাস্টমারের বাকি = মোট বিক্রি − মোট জমা (সঠিক বিয়োগ)
  const totalDue = customers.reduce((acc, cust) => {
    const txs = cust.transactions || [];
    const custSell = txs.reduce((tAcc, t) => tAcc + (Number(t.sellPrice) || 0), 0);
    const custDeposit = txs.reduce((tAcc, t) => tAcc + (Number(t.depositAmount) || 0), 0);
    return acc + Math.max(0, custSell - custDeposit);
  }, 0);

  // প্রতিটি কাস্টমারের মোট অতিরিক্ত জমা/উদ্বৃত্ত (জমা > বিক্রি)
  const totalSurplus = customers.reduce((acc, cust) => {
    const txs = cust.transactions || [];
    const custSell = txs.reduce((tAcc, t) => tAcc + (Number(t.sellPrice) || 0), 0);
    const custDeposit = txs.reduce((tAcc, t) => tAcc + (Number(t.depositAmount) || 0), 0);
    return acc + Math.max(0, custDeposit - custSell);
  }, 0);

  const formatTk = (amount: number) => {
    if (amount < 0) {
      return `৳-${Math.abs(amount).toLocaleString('en-IN')}`;
    }
    return `৳${amount.toLocaleString('en-IN')}`;
  };

  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.phone.includes(searchQuery)
  );

  const handleCreateCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;

    const bgColors = ['bg-indigo-600', 'bg-emerald-600', 'bg-purple-600', 'bg-rose-600', 'bg-sky-600'];
    const randomBg = bgColors[Math.floor(Math.random() * bgColors.length)];
    const initialChar = name.trim().charAt(0);

    const initAmt = parseFloat(initialAmount) || 0;
    const initialTransactions = initAmt > 0 ? [
      {
        id: `CTX-INIT-${Date.now()}`,
        itemName: initialType === 'due' ? 'পূর্বের বাকি হিসাব' : 'অগ্রিম জমা',
        buyPrice: 0,
        sellPrice: initialType === 'due' ? initAmt : 0,
        depositAmount: initialType === 'advance' ? initAmt : 0,
        dueAmount: initialType === 'due' ? initAmt : 0,
        date: 'আজ',
        time: '১২:০০ PM',
        note: 'শুরু করার প্রাথমিক হিসাব',
      },
    ] : [];

    const newCust: CustomerAccount = {
      id: `CUST-${Date.now()}`,
      name,
      phone,
      avatarBg: randomBg,
      avatarText: initialChar,
      transactions: initialTransactions,
    };

    onAddCustomer(newCust);
    setName('');
    setPhone('');
    setInitialAmount('');
    setIsAddModalOpen(false);
  };

  return (
    <div className="w-full bg-[#f8fafc] pb-8 animate-fadeIn text-slate-900">
      {/* Uniform Premium Header */}
      <div
        className="bg-gradient-to-r from-[#1e1b4b] via-[#312e81] to-[#4338ca] text-white px-5 pb-5 rounded-b-[28px] shadow-md shadow-indigo-950/15"
        style={{
          paddingTop: 'max(14px, calc(env(safe-area-inset-top, 0px) + 10px))',
        }}
      >
        <div className="flex items-center justify-between mb-3">
          <button
            type="button"
            onClick={onBack}
            className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors cursor-pointer"
            title="ফিরে যান"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="text-center flex-1 pr-1">
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
              কাস্টমার হিসাব
            </h1>
            <p className="text-xs sm:text-sm text-indigo-200 mt-0.5 font-medium">
              আপনার সকল গ্রাহক ও বাকি খাতা
            </p>
          </div>

          <div className="w-9 h-9" />
        </div>
      </div>

      {/* ৫টি সুসংগঠিত সামারি কার্ড (দোকানের হিসাব ও ড্যাশবোর্ডের মতো অভিন্ন) */}
      <div className="px-4 -mt-3">
        <div className="bg-white rounded-3xl p-3.5 shadow-md border border-slate-100 space-y-2.5">
          {/* Row 1: মোট কেনা, মোট বিক্রি, মোট লাভ */}
          <div className="grid grid-cols-3 gap-2 text-center">
            {/* মোট কেনা */}
            <div className="flex flex-col items-center justify-center p-2 rounded-2xl bg-indigo-50/60 border border-indigo-100/50">
              <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center mb-1 shadow-2xs">
                <ShoppingCart className="w-4 h-4 stroke-[2.5]" />
              </div>
              <span className="text-[11px] font-bold text-slate-600">মোট কেনা</span>
              <span className="text-xs sm:text-sm font-black text-indigo-700 mt-0.5 tracking-tight">
                {formatTk(totalBuy)}
              </span>
              <span className="text-[9px] text-slate-400 font-medium">ক্রয় মূল্য</span>
            </div>

            {/* মোট বিক্রি */}
            <div className="flex flex-col items-center justify-center p-2 rounded-2xl bg-rose-50/60 border border-rose-100/50">
              <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center mb-1 shadow-2xs">
                <ShoppingCart className="w-4 h-4 stroke-[2.5]" />
              </div>
              <span className="text-[11px] font-bold text-slate-600">মোট বিক্রি</span>
              <span className="text-xs sm:text-sm font-black text-rose-600 mt-0.5 tracking-tight">
                {formatTk(totalSell)}
              </span>
              <span className="text-[9px] text-slate-400 font-medium">বিক্রয় মূল্য</span>
            </div>

            {/* মোট লাভ */}
            <div className="flex flex-col items-center justify-center p-2 rounded-2xl bg-emerald-50/60 border border-emerald-100/50">
              <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center mb-1 shadow-2xs">
                <Wallet className="w-4 h-4 stroke-[2.5]" />
              </div>
              <span className="text-[11px] font-bold text-slate-600">মোট লাভ</span>
              <span className="text-xs sm:text-sm font-black text-emerald-600 mt-0.5 tracking-tight">
                {totalProfit >= 0 ? `+${formatTk(totalProfit)}` : formatTk(totalProfit)}
              </span>
              <span className="text-[9px] text-emerald-600 font-medium">প্রফিট</span>
            </div>
          </div>

          {/* Row 2: মোট জমা ও মোট বাকি / জমা আছে */}
          <div className="grid grid-cols-2 gap-2 text-center">
            {/* মোট জমা */}
            <div className="flex items-center justify-between p-2.5 px-3 rounded-2xl bg-emerald-50/50 border border-emerald-100/60">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center shadow-2xs">
                  <Wallet className="w-3.5 h-3.5 stroke-[2.5]" />
                </div>
                <div className="text-left">
                  <span className="text-[11px] font-bold text-slate-600 block leading-tight">মোট জমা</span>
                  <span className="text-[9px] text-slate-400 font-medium">প্রাপ্ত নগদ</span>
                </div>
              </div>
              <span className="text-xs sm:text-sm font-black text-emerald-600 tracking-tight">
                {formatTk(totalDeposit)}
              </span>
            </div>

            {/* মোট বাকি অথবা জমা আছে */}
            {totalDue > 0 || totalSurplus === 0 ? (
              <div className="flex items-center justify-between p-2.5 px-3 rounded-2xl bg-amber-50/50 border border-amber-100/60">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center shadow-2xs">
                    <CreditCard className="w-3.5 h-3.5 stroke-[2.5]" />
                  </div>
                  <div className="text-left">
                    <span className="text-[11px] font-bold text-slate-600 block leading-tight">মোট বাকি</span>
                    <span className="text-[9px] text-slate-400 font-medium">পাওনা টাকা</span>
                  </div>
                </div>
                <span className="text-xs sm:text-sm font-black text-amber-600 tracking-tight">
                  {formatTk(totalDue)}
                </span>
              </div>
            ) : (
              <div className="flex items-center justify-between p-2.5 px-3 rounded-2xl bg-emerald-50/60 border border-emerald-200/80 shadow-2xs">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center shadow-2xs">
                    <Coins className="w-3.5 h-3.5 stroke-[2.5]" />
                  </div>
                  <div className="text-left">
                    <span className="text-[11px] font-bold text-slate-600 block leading-tight">জমা আছে</span>
                    <span className="text-[9px] text-emerald-600 font-medium">উদ্বৃত্ত জমা</span>
                  </div>
                </div>
                <span className="text-xs sm:text-sm font-black text-emerald-600 tracking-tight">
                  +{formatTk(totalSurplus)}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Uniform Primary Action Button: + নতুন গ্রাহক যোগ করুন */}
      <div className="px-4 mt-3.5">
        <button
          type="button"
          onClick={() => {
            setName('');
            setPhone('');
            setInitialAmount('');
            setInitialType('zero');
            setIsAddModalOpen(true);
          }}
          className="w-full py-3.5 sm:py-4 bg-[#4323d4] hover:bg-[#371cb8] text-white font-black text-sm sm:text-base rounded-2xl shadow-lg shadow-indigo-600/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer"
        >
          <Plus className="w-5 h-5" />
          <span>নতুন গ্রাহক যোগ করুন</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="px-4 mt-4">
        <div className="bg-white rounded-2xl p-2 px-3 border border-slate-200/80 shadow-2xs flex items-center gap-2">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="গ্রাহকের নাম বা নাম্বার দিয়ে খুঁজুন"
            className="w-full text-xs sm:text-sm font-semibold text-slate-800 outline-none placeholder:text-slate-400"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <span className="text-[11px] font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-xl shrink-0">
            {customers.length} জন গ্রাহক
          </span>
        </div>
      </div>

      {/* Customer List Section */}
      <div className="px-4 mt-4">
        <div className="flex items-center justify-between mb-2.5">
          <h2 className="text-sm sm:text-base font-extrabold text-slate-900">
            কাস্টমার তালিকা
          </h2>
          <span className="text-xs font-semibold text-slate-500">
            মোট কাস্টমার: {filteredCustomers.length}
          </span>
        </div>

        <div className="space-y-3">
          {filteredCustomers.length === 0 ? (
            <div className="p-8 text-center bg-white rounded-3xl border border-slate-200 text-slate-400 text-xs">
              কোনো কাস্টমার পাওয়া যায়নি
            </div>
          ) : (
            filteredCustomers.map((cust) => {
              // Net due for this customer: মোট বিক্রি − মোট জমা
              const txs = cust.transactions || [];
              const custSell = txs.reduce((tAcc, t) => tAcc + (Number(t.sellPrice) || 0), 0);
              const custDeposit = txs.reduce((tAcc, t) => tAcc + (Number(t.depositAmount) || 0), 0);
              const custNetDue = Math.max(0, custSell - custDeposit);

              let statusLabel = 'পরিশোধিত';
              let statusClass = 'text-slate-600';
              let displayAmount = '৳০';

              if (custNetDue > 0) {
                statusLabel = 'বাকি আছে';
                statusClass = 'text-amber-600';
                displayAmount = `৳${custNetDue.toLocaleString('en-IN')}`;
              } else if (custDeposit > custSell) {
                statusLabel = 'জমা আছে';
                statusClass = 'text-emerald-600';
                displayAmount = `+৳${(custDeposit - custSell).toLocaleString('en-IN')}`;
              }

              return (
                <div
                  key={cust.id}
                  className="bg-white rounded-2xl p-3.5 border border-slate-200/80 shadow-xs flex items-center justify-between hover:border-indigo-200 transition-all"
                >
                  {/* Left: Avatar & Info */}
                  <div
                    onClick={() => onSelectCustomer(cust)}
                    className="flex items-center gap-3 flex-1 cursor-pointer"
                  >
                    <div
                      className={`w-11 h-11 rounded-full ${
                        cust.avatarBg || 'bg-indigo-600'
                      } text-white flex items-center justify-center font-bold text-base shadow-xs shrink-0`}
                    >
                      {cust.avatarText || cust.name.charAt(0)}
                    </div>
                    <div>
                      <h3 className="text-sm font-extrabold text-slate-900 leading-tight">
                        {cust.name}
                      </h3>
                      <span className="text-xs text-slate-500 font-mono block mt-0.5">
                        {cust.phone}
                      </span>
                    </div>
                  </div>

                  {/* Right: Balance tag + Chevron button + Delete icon */}
                  <div className="flex items-center gap-2">
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block font-medium">
                        {statusLabel}
                      </span>
                      <span className={`text-xs sm:text-sm font-black ${statusClass}`}>
                        {displayAmount}
                      </span>
                    </div>

                    {/* Chevron Button to open Customer detail */}
                    <button
                      type="button"
                      onClick={() => onSelectCustomer(cust)}
                      className="w-8 h-8 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 flex items-center justify-center transition-colors cursor-pointer"
                      title="হিসাব দেখুন"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>

                    {/* Delete Button */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (window.confirm(`আপনি কি নিশ্চিত যে কাস্টমার '${cust.name}' এবং তার সমস্ত হিসাব ডিলিট করতে চান?`)) {
                          onDeleteCustomer(cust.id);
                        }
                      }}
                      className="w-8 h-8 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 flex items-center justify-center transition-colors cursor-pointer"
                      title="কাস্টমার ডিলিট করুন"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Add Customer Modal */}
      {isAddModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4"
          style={{
            paddingTop: 'max(16px, calc(env(safe-area-inset-top, 0px) + 12px))',
            paddingBottom: 'max(16px, calc(env(safe-area-inset-bottom, 0px) + 16px))',
          }}
        >
          <div className="bg-white rounded-3xl max-w-[400px] w-full p-5 shadow-2xl border border-slate-100 animate-fadeIn space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-indigo-600" />
                <h3 className="font-black text-slate-900 text-base">নতুন গ্রাহক যোগ করুন</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1 text-center">গ্রাহকের পূর্ণ নাম *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="যেমন: জামাল হোসেন বা সুজন আহমেদ"
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-indigo-600 text-center"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1 text-center">মোবাইল নাম্বার *</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-indigo-600 text-center"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1 text-center">শুরুর ব্যালেন্স টাইপ</label>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setInitialType('zero')}
                    className={`py-2 rounded-xl font-bold text-xs border cursor-pointer text-center ${
                      initialType === 'zero'
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-700'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    শূন্য (৳০)
                  </button>
                  <button
                    type="button"
                    onClick={() => setInitialType('due')}
                    className={`py-2 rounded-xl font-bold text-xs border cursor-pointer text-center ${
                      initialType === 'due'
                        ? 'bg-rose-50 border-rose-600 text-rose-700'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    আগের বাকি
                  </button>
                  <button
                    type="button"
                    onClick={() => setInitialType('advance')}
                    className={`py-2 rounded-xl font-bold text-xs border cursor-pointer text-center ${
                      initialType === 'advance'
                        ? 'bg-emerald-50 border-emerald-600 text-emerald-700'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    অগ্রিম জমা
                  </button>
                </div>
              </div>

              {initialType !== 'zero' && (
                <div>
                  <label className="font-bold text-slate-700 block mb-1 text-center">টাকার পরিমাণ (৳)</label>
                  <input
                    type="number"
                    value={initialAmount}
                    onChange={(e) => setInitialAmount(e.target.value)}
                    placeholder="0"
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 outline-none focus:border-indigo-600 text-center"
                  />
                </div>
              )}

              <button
                type="submit"
                className="w-full max-w-[300px] mx-auto py-3 bg-[#4323d4] hover:bg-[#381cb8] text-white font-semibold text-[16px] rounded-xl shadow-md shadow-indigo-700/20 flex items-center justify-center gap-1.5 transition-all mt-2 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>গ্রাহক সংরক্ষণ করুন</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
