import React, { useState, useRef } from 'react';
import {
  Sparkles,
  Upload,
  Image as ImageIcon,
  CheckCircle,
  RefreshCw,
  Trash2,
  Globe,
  Sliders,
  Smartphone,
  Eye,
  Layers,
  Palette,
  Check,
  ShieldCheck,
} from 'lucide-react';
import { AppSettings } from '../types';
import { MAppsLogo } from './MAppsLogo';

interface AppLogoSettingsSectionProps {
  settings: AppSettings;
  onUpdateSettings: (updated: AppSettings) => void;
  onShowToast?: (msg: string) => void;
}

export const AppLogoSettingsSection: React.FC<AppLogoSettingsSectionProps> = ({
  settings,
  onUpdateSettings,
  onShowToast,
}) => {
  // Local Form States
  const [appName, setAppName] = useState(settings.appName || 'M APPS');
  const [appTagline, setAppTagline] = useState(settings.appTagline || 'মোবাইল রিচার্জ অ্যাপ');
  const [appLogoUrl, setAppLogoUrl] = useState(settings.appLogoUrl || '');
  const [logoPreset, setLogoPreset] = useState<AppSettings['logoPreset']>(
    settings.logoPreset || 'default_vector'
  );
  const [imageUrlInput, setImageUrlInput] = useState('');
  const [activePreviewMode, setActivePreviewMode] = useState<'login' | 'header' | 'drawer'>('login');
  const [isSavedRecently, setIsSavedRecently] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Preset Logos List
  const presetOptions = [
    {
      id: 'default_vector' as const,
      name: 'M APPS মূল লোগো',
      badge: 'ডিফল্ট',
      description: 'অরিজিনাল এমারেল্ড ফোন ও ম্যাজেন্টা APPS ভেক্টর',
      color: 'from-emerald-500 to-pink-500',
    },
    {
      id: 'falcon' as const,
      name: 'গোল্ডেন ফ্যালকন টেলিকম',
      badge: 'গোল্ডেন',
      description: 'ভিআইপি ফ্যালকন ও শিল্ড সিম্বল',
      color: 'from-amber-500 to-yellow-600',
    },
    {
      id: 'emerald_5g' as const,
      name: 'এমারেল্ড ৫জি ফাস্ট',
      badge: '৫জি স্পিড',
      description: 'আল্ট্রা হাই-স্পিড ৫জি পালস ও রিং',
      color: 'from-emerald-600 to-teal-600',
    },
    {
      id: 'ruby_flash' as const,
      name: 'রুবি ফ্ল্যাশ রিচার্জ',
      badge: 'ফ্ল্যাশ',
      description: 'ইনস্ট্যান্ট পাওয়ার লাইটনিং বোল্ট',
      color: 'from-rose-500 to-red-600',
    },
    {
      id: 'golden_crown' as const,
      name: 'রয়্যাল ভিআইপি ক্রাউন',
      badge: 'রয়্যাল',
      description: 'এলিট ডিলার ও প্রিমিয়াম ক্রাউন লোগো',
      color: 'from-amber-600 to-orange-500',
    },
    {
      id: 'blue_tech' as const,
      name: 'সাইবার ব্লু টেলিকম',
      badge: 'মডার্ন',
      description: 'ডিজিটাল নেটওয়ার্ক টাওয়ার ও সিগন্যাল',
      color: 'from-blue-600 to-indigo-600',
    },
  ];

  // Handle File Upload from Device
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size limit (max 3MB for base64 storage)
    if (file.size > 3 * 1024 * 1024) {
      alert('ইমেজের সাইজ ৩ মেগাবাইটের কম হতে হবে!');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64Data = event.target?.result as string;
      if (base64Data) {
        setAppLogoUrl(base64Data);
        setLogoPreset('custom');
        if (onShowToast) onShowToast('লোগো সফলভাবে লোড হয়েছে! সংরক্ষণ বাটনে চাপুন।');
      }
    };
    reader.readAsDataURL(file);
  };

  // Handle URL Apply
  const handleApplyUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!imageUrlInput.trim()) return;
    setAppLogoUrl(imageUrlInput.trim());
    setLogoPreset('custom');
    setImageUrlInput('');
    if (onShowToast) onShowToast('অনলাইন ইমেজ লিংক সংযুক্ত হয়েছে!');
  };

  // Save Settings
  const handleSave = () => {
    const updated: AppSettings = {
      ...settings,
      appName: appName.trim() || 'M APPS',
      appTagline: appTagline.trim(),
      appLogoUrl: logoPreset === 'custom' ? appLogoUrl : undefined,
      logoPreset: logoPreset,
    };
    onUpdateSettings(updated);
    setIsSavedRecently(true);
    if (onShowToast) onShowToast('অ্যাপ লোগো ও ব্র্যান্ডিং সফলভাবে সেভ হয়েছে!');
    setTimeout(() => setIsSavedRecently(false), 3000);
  };

  // Reset to Default
  const handleResetToDefault = () => {
    if (confirm('আপনি কি ডিফল্ট "M APPS" লোগো ও ব্র্যান্ডিংয়ে ফিরে যেতে চান?')) {
      setAppName('M APPS');
      setAppTagline('মোবাইল রিচার্জ অ্যাপ');
      setAppLogoUrl('');
      setLogoPreset('default_vector');

      const updated: AppSettings = {
        ...settings,
        appName: 'M APPS',
        appTagline: 'মোবাইল রিচার্জ অ্যাপ',
        appLogoUrl: undefined,
        logoPreset: 'default_vector',
      };
      onUpdateSettings(updated);
      if (onShowToast) onShowToast('ডিফল্ট লোগো ও ব্র্যান্ডিং রিস্টোর করা হয়েছে!');
    }
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      {/* 1. Header Card with Live Preview */}
      <section className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-5 text-white shadow-lg border border-indigo-800/40 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-pink-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                <Palette className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm text-white">অ্যাপ লোগো ও ব্র্যান্ডিং কন্ট্রোল</h3>
                <p className="text-[10px] text-slate-300">
                  লগইন স্ক্রিন, হেডার ও সাইড ড্রয়ারের লোগো কাস্টমাইজ করুন
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleResetToDefault}
              className="text-[11px] font-bold text-slate-300 hover:text-white bg-white/10 hover:bg-white/20 px-2.5 py-1 rounded-xl transition-all flex items-center gap-1 border border-white/10 cursor-pointer"
              title="পূর্বাবস্থায় রিসেট করুন"
            >
              <RefreshCw className="w-3 h-3" />
              <span>রিসেট</span>
            </button>
          </div>

          {/* Live Preview Box with View Switcher */}
          <div className="mt-4 bg-white/5 rounded-2xl p-3.5 border border-white/10">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                <Eye className="w-3.5 h-3.5" />
                লাইভ প্রিভিউ (Live Preview)
              </span>

              {/* View Switcher Tabs */}
              <div className="flex bg-black/40 p-0.5 rounded-lg border border-white/10 text-[10px]">
                <button
                  type="button"
                  onClick={() => setActivePreviewMode('login')}
                  className={`px-2 py-0.5 rounded font-bold transition-all cursor-pointer ${
                    activePreviewMode === 'login' ? 'bg-emerald-500 text-slate-950 shadow-xs' : 'text-slate-400'
                  }`}
                >
                  লগইন স্ক্রিন
                </button>
                <button
                  type="button"
                  onClick={() => setActivePreviewMode('header')}
                  className={`px-2 py-0.5 rounded font-bold transition-all cursor-pointer ${
                    activePreviewMode === 'header' ? 'bg-emerald-500 text-slate-950 shadow-xs' : 'text-slate-400'
                  }`}
                >
                  হেডার বার
                </button>
                <button
                  type="button"
                  onClick={() => setActivePreviewMode('drawer')}
                  className={`px-2 py-0.5 rounded font-bold transition-all cursor-pointer ${
                    activePreviewMode === 'drawer' ? 'bg-emerald-500 text-slate-950 shadow-xs' : 'text-slate-400'
                  }`}
                >
                  ড্রয়ার মেনু
                </button>
              </div>
            </div>

            {/* Dynamic Live Mockup */}
            <div className="bg-slate-950/80 rounded-xl p-4 flex items-center justify-center border border-white/5 min-h-[160px]">
              {activePreviewMode === 'login' && (
                <div className="w-full max-w-[240px] bg-white rounded-2xl p-4 text-center shadow-lg border border-slate-200 animate-fadeIn">
                  <MAppsLogo
                    size="md"
                    showSubtitle={true}
                    customLogoUrl={logoPreset === 'custom' ? appLogoUrl : undefined}
                    appName={appName}
                    appTagline={appTagline}
                    logoPreset={logoPreset}
                  />
                  <div className="mt-3 pt-2 border-t border-slate-100 flex justify-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    <span className="w-1.5 h-1.5 rounded-full bg-pink-500" />
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                  </div>
                </div>
              )}

              {activePreviewMode === 'header' && (
                <div className="w-full max-w-[280px] bg-gradient-to-r from-purple-700 via-indigo-600 to-pink-600 rounded-2xl p-3 text-white shadow-lg animate-fadeIn flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-9 h-9 rounded-xl bg-white p-1 flex items-center justify-center shadow-xs">
                      <MAppsLogo
                        size="xs"
                        showSubtitle={false}
                        customLogoUrl={logoPreset === 'custom' ? appLogoUrl : undefined}
                        appName={appName}
                        logoPreset={logoPreset}
                      />
                    </div>
                    <div>
                      <span className="font-extrabold text-xs block leading-tight">{appName}</span>
                      <span className="text-[9px] text-white/80 block">{appTagline}</span>
                    </div>
                  </div>
                  <div className="px-2 py-1 rounded-full bg-white/20 text-[10px] font-bold">
                    ৳ ৫,৪৫০
                  </div>
                </div>
              )}

              {activePreviewMode === 'drawer' && (
                <div className="w-full max-w-[260px] bg-white rounded-2xl p-3.5 text-slate-900 shadow-lg border border-slate-200 animate-fadeIn">
                  <div className="flex items-center gap-2.5 pb-2.5 border-b border-slate-100">
                    <div className="w-10 h-10 rounded-xl bg-slate-50 p-1 border border-slate-100 flex items-center justify-center">
                      <MAppsLogo
                        size="xs"
                        showSubtitle={false}
                        customLogoUrl={logoPreset === 'custom' ? appLogoUrl : undefined}
                        appName={appName}
                        logoPreset={logoPreset}
                      />
                    </div>
                    <div>
                      <h4 className="font-black text-xs text-slate-900">{appName}</h4>
                      <p className="text-[9px] text-slate-500">{appTagline}</p>
                    </div>
                  </div>
                  <div className="mt-2 text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-1 rounded-lg">
                    ✓ অ্যাক্টিভ অ্যাপ ব্র্যান্ডিং
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* 2. Choose Logo Source: Device Upload / Online URL / Preset Gallery */}
      <section className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
          <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Upload className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-extrabold text-slate-900 text-sm">১. কাস্টম লোগো আপলোড বা নির্বাচন</h3>
            <p className="text-[10px] text-slate-500 font-medium">
              আপনার প্রতিষ্ঠানের নিজস্ব লোগো আপলোড করুন অথবা রেডিমেড স্টাইল বাছুন
            </p>
          </div>
        </div>

        {/* Upload Buttons & Options */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {/* Option A: Device File Upload */}
          <div className="p-3.5 bg-slate-50 hover:bg-slate-100/80 border-2 border-dashed border-indigo-200 rounded-2xl transition-all text-center flex flex-col items-center justify-center">
            <input
              type="file"
              ref={fileInputRef}
              accept="image/png, image/jpeg, image/webp, image/svg+xml"
              onChange={handleFileUpload}
              className="hidden"
            />
            <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center mb-2 shadow-2xs">
              <Upload className="w-5 h-5" />
            </div>
            <span className="font-extrabold text-xs text-slate-900 block mb-0.5">
              ডিভাইস থেকে লোগো আপলোড
            </span>
            <span className="text-[10px] text-slate-500 block mb-2.5">
              PNG, JPG, SVG বা WebP ফাইল
            </span>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all cursor-pointer"
            >
              ফাইল সিলেক্ট করুন
            </button>
          </div>

          {/* Option B: Direct Image URL */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-1.5 mb-1 text-slate-800 text-xs font-bold">
                <Globe className="w-3.5 h-3.5 text-emerald-600" />
                <span>ইন্টারনেট ইমেজ লিংক (URL)</span>
              </div>
              <p className="text-[10px] text-slate-500 mb-2">
                অনলাইন ইমেজের সরাসরি ওয়েব লিংক পেস্ট করুন
              </p>
              <input
                type="url"
                value={imageUrlInput}
                onChange={(e) => setImageUrlInput(e.target.value)}
                placeholder="https://example.com/logo.png"
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 font-mono outline-none focus:border-indigo-600 mb-2"
              />
            </div>
            <button
              type="button"
              onClick={handleApplyUrl}
              disabled={!imageUrlInput.trim()}
              className="w-full py-1.5 bg-slate-800 hover:bg-slate-900 disabled:opacity-40 text-white font-bold text-xs rounded-xl transition-all cursor-pointer"
            >
              লিংক যুক্ত করুন
            </button>
          </div>
        </div>

        {/* Current Custom Logo Status if active */}
        {logoPreset === 'custom' && appLogoUrl && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-white border border-emerald-200 p-1 shrink-0 flex items-center justify-center overflow-hidden">
                <img src={appLogoUrl} alt="Custom Logo" className="w-full h-full object-contain" />
              </div>
              <div className="min-w-0">
                <span className="font-extrabold text-xs text-emerald-950 block">কাস্টম লোগো সিলেক্টেড</span>
                <span className="text-[10px] text-emerald-700 block truncate">ইউজার আপলোডকৃত ইমেজ সক্রিয়</span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                setAppLogoUrl('');
                setLogoPreset('default_vector');
              }}
              className="p-1.5 rounded-lg bg-rose-100 hover:bg-rose-200 text-rose-700 transition-colors cursor-pointer shrink-0"
              title="কাস্টম লোগো মুছুন"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Option C: 6 Ready-made Pro Vector Presets */}
        <div className="pt-2">
          <label className="block text-slate-800 text-xs font-extrabold mb-2 flex items-center justify-between">
            <span>অথবা রেডিমেড প্রিমিয়াম লোগো স্টাইল পছন্দ করুন:</span>
            <span className="text-[10px] text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded font-bold">
              ৬টি ভেক্টর স্টাইল
            </span>
          </label>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {presetOptions.map((preset) => {
              const isSelected = logoPreset === preset.id;
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => {
                    setLogoPreset(preset.id);
                    if (onShowToast) onShowToast(`"${preset.name}" লোগো নির্বাচন করা হয়েছে!`);
                  }}
                  className={`p-2.5 rounded-2xl border text-left transition-all cursor-pointer relative flex flex-col justify-between ${
                    isSelected
                      ? 'bg-gradient-to-br from-indigo-50/80 to-purple-50/80 border-indigo-600 ring-2 ring-indigo-600/30 shadow-sm'
                      : 'bg-slate-50/60 hover:bg-white border-slate-200 text-slate-700'
                  }`}
                >
                  {isSelected && (
                    <div className="absolute top-2 right-2 w-4 h-4 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                      <Check className="w-2.5 h-2.5" />
                    </div>
                  )}

                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-9 h-9 rounded-xl bg-white p-1 shadow-2xs border border-slate-100 flex items-center justify-center shrink-0">
                      <MAppsLogo size="xs" showSubtitle={false} logoPreset={preset.id} />
                    </div>
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700">
                      {preset.badge}
                    </span>
                  </div>

                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900 leading-tight">
                      {preset.name}
                    </h4>
                    <p className="text-[9px] text-slate-500 line-clamp-1 mt-0.5">
                      {preset.description}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* 3. App Name & Tagline Form */}
      <section className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
          <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <Sliders className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-extrabold text-slate-900 text-sm">২. অ্যাপের নাম ও ট্যাগলাইন পরিবর্তন</h3>
            <p className="text-[10px] text-slate-500 font-medium">
              অ্যাপের টাইটেল ও সাবটাইটেল নিজের মতো সাজিয়ে নিন
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {/* App Name Input */}
          <div>
            <label className="block text-slate-800 text-xs font-bold mb-1">
              অ্যাপের নাম (App Title) <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={appName}
              onChange={(e) => setAppName(e.target.value)}
              placeholder="যেমন: M APPS অথবা মেসার্স মিরাজ টেলিকম"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs font-bold focus:bg-white focus:border-indigo-600 focus:ring-2 focus:ring-indigo-100 outline-none"
            />
          </div>

          {/* App Tagline Input */}
          <div>
            <label className="block text-slate-800 text-xs font-bold mb-1">
              ট্যাগলাইন / সাব-টাইটেল (App Tagline)
            </label>
            <input
              type="text"
              value={appTagline}
              onChange={(e) => setAppTagline(e.target.value)}
              placeholder="যেমন: মোবাইল রিচার্জ অ্যাপ অথবা ২৪ ঘণ্টা অটো রিচার্জ"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-xs font-medium focus:bg-white focus:border-indigo-600 focus:ring-2 focus:ring-indigo-100 outline-none"
            />
          </div>
        </div>

        {/* Save Changes Button */}
        <div className="pt-2">
          <button
            type="button"
            onClick={handleSave}
            className="w-full py-3.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 hover:from-emerald-700 hover:to-indigo-700 active:scale-[0.99] text-white font-extrabold text-sm rounded-2xl shadow-lg shadow-emerald-600/25 flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <CheckCircle className="w-4 h-4" />
            <span>লোগো ও ব্র্যান্ডিং সংরক্ষণ করুন (Save Branding)</span>
          </button>
        </div>

        {isSavedRecently && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-center gap-2 text-emerald-800 text-xs font-bold animate-fadeIn">
            <CheckCircle className="w-4 h-4 text-emerald-600" />
            <span>✓ লোগো ও ব্র্যান্ডিং সফলভাবে সেভ করা হয়েছে এবং সর্বত্র আপডেট হয়েছে!</span>
          </div>
        )}
      </section>
    </div>
  );
};
