import React, { useState, useEffect, useMemo } from 'react';
import {
  DollarSign,
  CheckCircle2,
  Clock,
  AlertCircle,
  Receipt,
  ArrowLeft,
  Phone,
  Search,
  Database,
  Calendar,
  Sparkles,
  RefreshCw,
  Wallet,
  Zap,
  Tag,
  Info,
  Trash2,
} from 'lucide-react';
import { Transaction, DriveOrder, RechargeRequest } from '../types';
import { OperatorLogo, BKashLogo, NagadLogo, RocketLogo, UpayLogo } from './OperatorLogos';
import { getOperatorBnName, isTodayTransaction, toBangla } from '../utils';

interface TransactionsViewProps {
  transactions: Transaction[];
  orders?: DriveOrder[];
  rechargeRequests?: RechargeRequest[];
  onBackToHome?: () => void;
  onDeleteTransaction?: (txId: string) => void;
  onClearPendingTransactions?: () => void;
}

export const TransactionsView: React.FC<TransactionsViewProps> = ({
  transactions,
  orders = [],
  rechargeRequests = [],
  onBackToHome,
  onDeleteTransaction,
  onClearPendingTransactions,
}) => {
  // 'today' = আজকের লেনদেন (auto resets after 12:00 AM midnight)
  // 'all_cloud' = ফায়ারবেস ক্লাউড স্টোরেজে থাকা সমস্ত অতীত রেকর্ড
  const [viewScope, setViewScope] = useState<'today' | 'all_cloud'>('today');
  const [filterType, setFilterType] = useState<'all' | 'drive' | 'recharge' | 'add_money'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTrx, setSelectedTrx] = useState<Transaction | null>(null);

  // Pure logic helper: accurately resolves status based on authoritative state & record data
  const resolveStatus = (item: Transaction | null): 'success' | 'pending' | 'failed' => {
    if (!item) return 'pending';
    if (orders && orders.length > 0) {
      const matchedOrder = orders.find((o) => o.id === item.id);
      if (matchedOrder) {
        if (matchedOrder.status === 'success') return 'success';
        if (matchedOrder.status === 'cancelled') return 'failed';
        return 'pending';
      }
    }
    if (rechargeRequests && rechargeRequests.length > 0) {
      const matchedRc = rechargeRequests.find((r) => r.id === item.id);
      if (matchedRc) {
        if (matchedRc.status === 'success') return 'success';
        if (matchedRc.status === 'cancelled') return 'failed';
        return 'pending';
      }
    }
    const s = String(item.status || '').toLowerCase().trim();
    if (s === 'success' || s === 'approved' || s === 'completed' || s === 'সফল') return 'success';
    if (s === 'cancelled' || s === 'failed' || s === 'rejected' || s === 'বাতিল') return 'failed';
    return 'pending';
  };

  // Live midnight rollover ticker (re-evaluates isTodayTransaction every 30s)
  const [, setMidnightTicker] = useState(Date.now());
  useEffect(() => {
    const interval = setInterval(() => {
      setMidnightTicker(Date.now());
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  // Filter transactions based on viewScope (Today vs All Firebase Cloud)
  const scopedTransactions = useMemo(() => {
    if (viewScope === 'today') {
      return transactions.filter((tx) => isTodayTransaction(tx));
    }
    return transactions;
  }, [transactions, viewScope]);

  // Apply category and search filter
  const displayedTransactions = useMemo(() => {
    let result = scopedTransactions;

    if (filterType !== 'all') {
      result = result.filter((t) => t.type === filterType);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter((t) => {
        const phoneMatch = t.phoneNumber && t.phoneNumber.toLowerCase().includes(q);
        const detailsMatch = t.details && t.details.toLowerCase().includes(q);
        const trxIdMatch = t.trxId && t.trxId.toLowerCase().includes(q);
        const pkgMatch = t.packageName && t.packageName.toLowerCase().includes(q);
        const opMatch = t.operator && t.operator.toLowerCase().includes(q);
        return phoneMatch || detailsMatch || trxIdMatch || pkgMatch || opMatch;
      });
    }

    return result;
  }, [scopedTransactions, filterType, searchQuery]);

  // Stats calculation for the current view
  const stats = useMemo(() => {
    const totalCount = scopedTransactions.length;
    const totalAmount = scopedTransactions.reduce((acc, t) => acc + (t.amount || 0), 0);
    const totalCashback = scopedTransactions.reduce((acc, t) => acc + (t.cashback || 0), 0);
    return { totalCount, totalAmount, totalCashback };
  }, [scopedTransactions]);

  const renderIcon = (trx: Transaction) => {
    if (trx.type === 'add_money') {
      if (trx.paymentMethod === 'bKash') return <BKashLogo className="w-8 h-8" />;
      if (trx.paymentMethod === 'Nagad') return <NagadLogo className="w-8 h-8" />;
      if (trx.paymentMethod === 'Rocket') return <RocketLogo className="w-8 h-8" />;
      if (trx.paymentMethod === 'Upay') return <UpayLogo className="w-8 h-8" />;
      return (
        <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs">
          <Wallet className="w-4 h-4" />
        </div>
      );
    }
    if (trx.operator) {
      return <OperatorLogo operator={trx.operator} className="w-8 h-8" />;
    }
    return (
      <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-bold text-xs">
        <Zap className="w-4 h-4" />
      </div>
    );
  };

  return (
    <div
      className="px-3.5 sm:px-4 py-4 pb-8 w-full animate-fadeIn"
      style={{
        paddingTop: 'max(14px, calc(env(safe-area-inset-top, 0px) + 12px))',
      }}
    >
      {/* 1. Header with Back Button */}
      <div className="flex items-center justify-between mb-3.5">
        <div className="flex items-center gap-2.5">
          {onBackToHome && (
            <button
              type="button"
              onClick={onBackToHome}
              className="w-9 h-9 rounded-full bg-white border border-slate-200 hover:bg-slate-100 flex items-center justify-center text-slate-700 shadow-xs transition-all active:scale-95 cursor-pointer"
              title="হোমে ফিরে যান"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-[#0072CE]" />
              <span>লেনদেন হিস্টোরি</span>
            </h2>
            <span className="text-[11px] text-slate-500 font-medium">
              আজকের সকল কেনাবেচা ও ফায়ারবেস ক্লাউড রেকর্ড
            </span>
          </div>
        </div>

        {onBackToHome && (
          <button
            type="button"
            onClick={onBackToHome}
            className="text-xs font-bold text-slate-600 hover:text-slate-900 bg-white px-3 py-1.5 rounded-full border border-slate-200 shadow-2xs transition-all active:scale-95 cursor-pointer"
          >
            হোম পেজ
          </button>
        )}
      </div>

      {/* 2. Primary Mode Toggle: আজকের লেনদেন (স্বয়ংক্রিয় রিসেট) vs সকল রেকর্ড (ফায়ারবেস) */}
      <div className="bg-slate-100/90 p-1 rounded-2xl flex items-center gap-1 mb-3 border border-slate-200/80 shadow-2xs">
        <button
          type="button"
          onClick={() => setViewScope('today')}
          className={`flex-1 py-2 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            viewScope === 'today'
              ? 'bg-[#0072CE] text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>আজকের লেনদেন</span>
          <span
            className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
              viewScope === 'today'
                ? 'bg-white/20 text-white'
                : 'bg-slate-200 text-slate-700'
            }`}
          >
            {toBangla(transactions.filter((t) => isTodayTransaction(t)).length)}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setViewScope('all_cloud')}
          className={`flex-1 py-2 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            viewScope === 'all_cloud'
              ? 'bg-[#0072CE] text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          <span>সকল রেকর্ড (ফায়ারবেস)</span>
          <span
            className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
              viewScope === 'all_cloud'
                ? 'bg-white/20 text-white'
                : 'bg-slate-200 text-slate-700'
            }`}
          >
            {toBangla(transactions.length)}
          </span>
        </button>
      </div>

      {/* 3. Reassuring Midnight Notice Banner */}
      {viewScope === 'today' ? (
        <div className="bg-sky-50/80 border border-sky-200 rounded-2xl p-2.5 mb-3 flex items-start gap-2.5 text-sky-950 text-xs">
          <div className="w-6 h-6 rounded-full bg-sky-100 flex items-center justify-center shrink-0 mt-0.5 text-[#0072CE]">
            <Clock className="w-3.5 h-3.5" />
          </div>
          <div className="leading-tight">
            <p className="font-extrabold text-[11px] text-sky-950">
              আজকে যা লেনদেন হয়েছে সব একসাথে নিচে প্রদর্শিত হচ্ছে
            </p>
            <p className="text-[10px] text-sky-800 mt-0.5">
              রাত ১২:০০ টায় তালিকা স্বয়ংক্রিয়ভাবে মুছে নতুন দিনের জন্য প্রস্তুত হবে। সমস্ত রেকর্ড ফায়ারবেসে নিরাপদে স্থায়ীভাবে সংরক্ষিত থাকবে।
            </p>
          </div>
        </div>
      ) : (
        <div className="bg-emerald-50/80 border border-emerald-200 rounded-2xl p-2.5 mb-3 flex items-start gap-2.5 text-emerald-950 text-xs">
          <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center shrink-0 mt-0.5 text-emerald-700">
            <Database className="w-3.5 h-3.5" />
          </div>
          <div className="leading-tight">
            <p className="font-extrabold text-[11px] text-emerald-950">
              ফায়ারবেস ক্লাউড ডাটাবেজ রেকর্ড (আজীবন স্থায়ী)
            </p>
            <p className="text-[10px] text-emerald-700 mt-0.5">
              রাত ১২টার পর ফ্রন্টএন্ড হিস্ট্রি ক্লিয়ার হলেও সকল রেকর্ড এখানে আজীবন সুরক্ষিত থাকে।
            </p>
          </div>
        </div>
      )}

      {/* 4. Quick Summary Strip (আজকের বা নির্বাচিত হিস্টোরির মোট হিসাব) */}
      <div className="grid grid-cols-3 gap-2 mb-3">
        <div className="bg-white rounded-2xl p-2.5 border border-slate-200/80 shadow-2xs text-center">
          <span className="text-[10px] text-slate-500 font-bold block">মোট লেনদেন</span>
          <span className="text-sm font-black text-slate-900 mt-0.5 block">
            {toBangla(stats.totalCount)} টি
          </span>
        </div>
        <div className="bg-white rounded-2xl p-2.5 border border-slate-200/80 shadow-2xs text-center">
          <span className="text-[10px] text-slate-500 font-bold block">মোট কেনাবেচা</span>
          <span className="text-sm font-black text-[#0072CE] mt-0.5 block">
            ৳{toBangla(stats.totalAmount)}
          </span>
        </div>
        <div className="bg-white rounded-2xl p-2.5 border border-slate-200/80 shadow-2xs text-center">
          <span className="text-[10px] text-slate-500 font-bold block">মোট ক্যাশব্যাক</span>
          <span className="text-sm font-black text-emerald-600 mt-0.5 block">
            ৳{toBangla(stats.totalCashback)}
          </span>
        </div>
      </div>

      {/* 5. Search Bar (কোন নাম্বারে কিনেছে তা দিয়ে সরাসরি খোঁজার সুবিধা) */}
      <div className="relative mb-3">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="কোন নাম্বারে কিনেছে (নম্বর বা বিবরণ দিয়ে খুঁজুন)..."
          className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-3.5 py-2 text-xs font-semibold text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-[#0072CE] focus:ring-1 focus:ring-[#0072CE] transition-all shadow-2xs"
        />
        {searchQuery && (
          <button
            type="button"
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-700 font-bold"
          >
            ✕
          </button>
        )}
      </div>

      {/* 6. Filter Chips */}
      <div className="flex gap-1.5 overflow-x-auto pb-1.5 no-scrollbar mb-3">
        {[
          { key: 'all', label: 'সকল লেনদেন' },
          { key: 'drive', label: 'ড্রাইভ অফার' },
          { key: 'recharge', label: 'মোবাইল রিচার্জ' },
          { key: 'add_money', label: 'অ্যাড মানি' },
        ].map((tab) => (
          <button
            key={tab.key}
            type="button"
            onClick={() => setFilterType(tab.key as any)}
            className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
              filterType === tab.key
                ? 'bg-[#0072CE] text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* 6.5. Pending Cleanup Banner if any pending items exist */}
      {displayedTransactions.some((t) => resolveStatus(t) === 'pending') && onClearPendingTransactions && (
        <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-3 mb-3 flex items-center justify-between gap-2 shadow-xs">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-600 shrink-0 animate-pulse" />
            <div>
              <span className="text-xs font-black text-amber-950 block">
                {toBangla(displayedTransactions.filter((t) => resolveStatus(t) === 'pending').length)}টি লেনদেন পেন্ডিং অবস্থায় আছে
              </span>
              <span className="text-[10px] font-bold text-amber-800 block">
                এডমিনে অর্ডার শেষ হয়ে থাকলে বা বাতিল করতে চাইলে সব পেন্ডিং ক্লিয়ার করুন
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClearPendingTransactions}
            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 active:scale-95 text-white text-xs font-black rounded-xl shadow-xs transition-all shrink-0 flex items-center gap-1 cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>পেন্ডিং ক্লিয়ার</span>
          </button>
        </div>
      )}

      {/* 7. Transactions List: শাড়িবদ্ধভাবে সুন্দর কার্ড ডিসপ্লে (কোন নাম্বারে কিনেছে, কত টাকায় কিনেছে) */}
      <div className="space-y-2.5">
        {displayedTransactions.length === 0 ? (
          <div className="text-center py-10 bg-white rounded-2xl border border-slate-200/80 p-6 space-y-1.5 shadow-2xs">
            <div className="w-10 h-10 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-2">
              <Calendar className="w-5 h-5" />
            </div>
            <p className="font-black text-slate-800 text-xs">
              {viewScope === 'today'
                ? 'আজকে এখনো কোনো লেনদেন হয়নি'
                : 'কোনো লেনদেন রেকর্ড পাওয়া যায়নি'}
            </p>
            <p className="text-[11px] text-slate-500 max-w-[280px] mx-auto">
              {viewScope === 'today'
                ? 'আজ নতুন কোনো ড্রাইভ, রিচার্জ বা অ্যাড মানি সম্পন্ন হলে স্বয়ংক্রিয়ভাবে এখানে শাড়িবদ্ধভাবে যুক্ত হবে।'
                : 'উপরে ফিল্টার বা সার্চ পরিবর্তন করে দেখতে পারেন।'}
            </p>
            {viewScope === 'today' && transactions.length > 0 && (
              <button
                type="button"
                onClick={() => setViewScope('all_cloud')}
                className="mt-2 text-xs font-bold text-purple-700 bg-purple-50 hover:bg-purple-100 px-3 py-1.5 rounded-full inline-flex items-center gap-1 transition-all cursor-pointer"
              >
                <Database className="w-3.5 h-3.5" />
                <span>পূর্বের সমস্ত ফায়ারবেস রেকর্ড দেখুন</span>
              </button>
            )}
          </div>
        ) : (
          displayedTransactions.map((item) => {
            const isDrive = item.type === 'drive';
            const isRecharge = item.type === 'recharge';
            const isAddMoney = item.type === 'add_money';

            const opBn = item.operator ? getOperatorBnName(item.operator) : (item.operatorName || 'টেলিকম');

            // Build specifications / details text
            const specsList: string[] = [];
            if (item.internetGB && item.internetGB > 0) specsList.push(`${toBangla(item.internetGB)} জিবি`);
            if (item.minutes && item.minutes > 0) specsList.push(`${toBangla(item.minutes)} মিনিট`);
            if (item.sms && item.sms > 0) specsList.push(`${toBangla(item.sms)} এসএমএস`);
            const specsText = specsList.length > 0 ? specsList.join(' + ') : '';

            const titleText = isDrive
              ? `${opBn} ${specsText || item.packageName || item.details || 'ড্রাইভ অফার'}`
              : isRecharge
              ? `${opBn} প্রিপেইড রিচার্জ`
              : (item.details || 'অ্যাড মানি');

            return (
              <div
                key={item.id}
                onClick={() => setSelectedTrx(item)}
                id={`history-row-${item.id}`}
                className="w-full text-left bg-white rounded-2xl p-3.5 border-2 border-slate-200/90 shadow-xs hover:shadow-sm hover:border-purple-300 transition-all space-y-2.5 cursor-pointer active:scale-[0.99]"
              >
                {/* 1st Row: Operator/Gateway Logo + Title/Type + Status */}
                <div className="flex items-center justify-between gap-2 pb-2 border-b border-slate-200">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="p-0.5 rounded-xl shrink-0">
                      {renderIcon(item)}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs sm:text-sm font-black text-slate-950 truncate">
                          {titleText}
                        </span>
                        <span
                          className={`text-[10px] font-black px-2 py-0.5 rounded-md border ${
                            isDrive
                              ? 'bg-purple-100 text-purple-800 border-purple-300'
                              : isRecharge
                              ? 'bg-blue-100 text-blue-800 border-blue-300'
                              : 'bg-emerald-100 text-emerald-800 border-emerald-300'
                          }`}
                        >
                          {isDrive ? 'ড্রাইভ অফার' : isRecharge ? 'মোবাইল রিচার্জ' : 'অ্যাড মানি'}
                        </span>
                      </div>
                      <div className="text-xs text-slate-600 font-bold flex items-center gap-1 mt-0.5">
                        <Clock className="w-3.5 h-3.5 text-slate-500" />
                        <span>{item.time || item.timestamp}</span>
                        {item.validityDays && (
                          <>
                            <span className="text-slate-400 font-black">•</span>
                            <span className="text-purple-800 font-black">
                              মেয়াদ: {toBangla(item.validityDays)} দিন
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Status Badge & Actions */}
                  <div className="shrink-0 flex items-center gap-1.5">
                    {resolveStatus(item) === 'success' ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-black border border-emerald-300 shadow-2xs">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                        <span>সফল</span>
                      </span>
                    ) : resolveStatus(item) === 'pending' ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-100 text-amber-950 text-xs font-black border border-amber-300 shadow-2xs animate-pulse">
                        <Clock className="w-3.5 h-3.5 text-amber-700" />
                        <span>পেন্ডিং</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-rose-100 text-rose-950 text-xs font-black border border-rose-300 shadow-2xs">
                        <AlertCircle className="w-3.5 h-3.5 text-rose-700" />
                        <span>বাতিল</span>
                      </span>
                    )}

                    {onDeleteTransaction && (
                      <button
                        type="button"
                        title="এই রেকর্ডটি ডিলিট করুন"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteTransaction(item.id);
                        }}
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-rose-100 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {/* 2nd Row: সুন্দরভাবে শাড়িবদ্ধভাবে "কোন নাম্বারে কিনেছে" এবং "কত টাকায় কিনেছে" */}
                <div className="bg-slate-50 rounded-xl p-2.5 border-2 border-slate-200 flex items-center justify-between gap-3">
                  {/* কোন নাম্বারে কিনেছে */}
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="w-8 h-8 rounded-lg bg-white border-2 border-slate-200 flex items-center justify-center text-purple-700 shrink-0 shadow-2xs">
                      <Phone className="w-4 h-4" />
                    </div>
                    <div className="truncate">
                      <span className="text-[11px] text-slate-700 font-extrabold block leading-none">
                        কোন নাম্বারে কিনেছে
                      </span>
                      <span className="text-xs sm:text-sm font-mono font-black text-slate-950 tracking-wide mt-0.5 block">
                        {item.phoneNumber || 'N/A'}
                      </span>
                    </div>
                  </div>

                  {/* কত টাকায় কিনেছে */}
                  <div className="text-right shrink-0">
                    <span className="text-[11px] text-slate-700 font-extrabold block leading-none">
                      কত টাকায় কিনেছে
                    </span>
                    <div className="flex items-center justify-end gap-1.5 mt-0.5">
                      <span
                        className={`text-base sm:text-lg font-black ${
                          isAddMoney ? 'text-emerald-700' : 'text-purple-800'
                        }`}
                      >
                        {isAddMoney ? '+' : ''}৳{toBangla(item.amount)}
                      </span>

                      {item.cashback && item.cashback > 0 ? (
                        <span className="text-xs font-black text-emerald-900 bg-emerald-100 px-2 py-0.5 rounded-md border border-emerald-300">
                          ক্যাশব্যাক ৳{toBangla(item.cashback)}
                        </span>
                      ) : null}
                    </div>
                  </div>
                </div>

                {/* Additional Price Context if regular price was higher */}
                {item.regularPriceTK && item.regularPriceTK > item.amount && (
                  <div className="text-[10px] font-semibold text-slate-500 flex items-center gap-1 px-1">
                    <Tag className="w-3 h-3 text-slate-400" />
                    <span>রেগুলার মূল্য ছিল:</span>
                    <span className="line-through text-slate-400">৳{toBangla(item.regularPriceTK)}</span>
                    <span className="text-emerald-600 font-black">
                      (সাশ্রয় ৳{toBangla(item.regularPriceTK - item.amount)})
                    </span>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* 8. Digital Payment Receipt Modal (ডিজিটাল রসিদ) - NO COPY OPTION */}
      {selectedTrx && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl p-5 max-w-sm w-full shadow-2xl border border-slate-100 space-y-4">
            <div className="text-center pb-3 border-b border-dashed border-slate-200">
              <div className="w-12 h-12 rounded-full bg-purple-50 text-purple-700 mx-auto flex items-center justify-center mb-2">
                <Receipt className="w-6 h-6" />
              </div>
              <h3 className="font-black text-slate-900 text-lg">ডিজিটাল পেমেন্ট রসিদ</h3>
              <p className="text-xs text-slate-400">টেলিকম রিচার্জ ও ড্রাইভ সার্ভিস</p>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">সার্ভিস টাইপ:</span>
                <span className="font-black text-slate-800 uppercase">
                  {selectedTrx.type === 'drive'
                    ? 'ড্রাইভ অফার'
                    : selectedTrx.type === 'recharge'
                    ? 'মোবাইল রিচার্জ'
                    : 'অ্যাড মানি'}
                </span>
              </div>

              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">বিবরণ / প্যাকেজ:</span>
                <span className="font-bold text-slate-800 text-right max-w-[200px]">
                  {selectedTrx.details}
                </span>
              </div>

              {selectedTrx.phoneNumber && (
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">গ্রাহক নম্বর:</span>
                  <span className="font-mono font-black text-slate-900">
                    {selectedTrx.phoneNumber}
                  </span>
                </div>
              )}

              {selectedTrx.operatorName && (
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">অপারেটর:</span>
                  <span className="font-bold text-slate-800">
                    {selectedTrx.operatorName}
                  </span>
                </div>
              )}

              {selectedTrx.validityDays && (
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">মেয়াদ:</span>
                  <span className="font-bold text-slate-800">
                    {toBangla(selectedTrx.validityDays)} দিন
                  </span>
                </div>
              )}

              {selectedTrx.trxId && (
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">ট্রানজেকশন আইডি:</span>
                  <span className="font-mono font-bold text-purple-700">
                    {selectedTrx.trxId}
                  </span>
                </div>
              )}

              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">সময় ও তারিখ:</span>
                <span className="text-slate-700 font-medium">
                  {selectedTrx.time || selectedTrx.timestamp} ({selectedTrx.date || 'আজ'})
                </span>
              </div>

              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">স্ট্যাটাস:</span>
                <span
                  className={`font-bold ${
                    resolveStatus(selectedTrx) === 'success'
                      ? 'text-emerald-600'
                      : resolveStatus(selectedTrx) === 'pending'
                      ? 'text-amber-600'
                      : 'text-rose-600'
                  }`}
                >
                  {resolveStatus(selectedTrx) === 'success'
                    ? 'সফল'
                    : resolveStatus(selectedTrx) === 'pending'
                    ? 'পেন্ডিং'
                    : 'বাতিল'}
                </span>
              </div>

              {selectedTrx.cashback && selectedTrx.cashback > 0 ? (
                <div className="flex justify-between py-1 border-b border-slate-100">
                  <span className="text-slate-500">ক্যাশব্যাক:</span>
                  <span className="font-black text-emerald-700">
                    ৳{toBangla(selectedTrx.cashback)}
                  </span>
                </div>
              ) : null}

              <div className="flex justify-between pt-2 border-t-2 border-slate-200 text-sm">
                <span className="font-bold text-slate-900">মোট মূল্য:</span>
                <span className="font-black text-purple-700 text-base">
                  ৳{toBangla(selectedTrx.amount)}
                </span>
              </div>
            </div>

            <div className="flex gap-2">
              {onDeleteTransaction && (
                <button
                  type="button"
                  onClick={() => {
                    onDeleteTransaction(selectedTrx.id);
                    setSelectedTrx(null);
                  }}
                  className="flex-1 py-3 bg-rose-50 hover:bg-rose-100 active:scale-95 text-rose-700 border border-rose-200 font-black text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <Trash2 className="w-4 h-4 text-rose-600" />
                  <span>মুছে ফেলুন</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => setSelectedTrx(null)}
                className="flex-1 py-3 bg-purple-700 hover:bg-purple-800 active:scale-95 text-white font-black text-xs rounded-xl transition-all cursor-pointer shadow-xs"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
