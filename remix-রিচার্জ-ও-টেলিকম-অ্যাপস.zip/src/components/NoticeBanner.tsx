import React from 'react';
import { Volume2 } from 'lucide-react';
import { speakText } from '../utils';

interface NoticeBannerProps {
  notice: string;
  title?: string;
  enabled?: boolean;
}

export const NoticeBanner: React.FC<NoticeBannerProps> = ({
  notice,
  title = 'নোটিশ',
  enabled = true,
}) => {
  if (!notice || enabled === false) return null;

  return (
    <div className="mx-4 mt-3 bg-gradient-to-r from-amber-100/90 via-amber-50 to-orange-100/90 border-2 border-amber-300/90 rounded-2xl py-2 px-3 flex items-center gap-2.5 overflow-hidden shadow-xs">
      <button
        type="button"
        onClick={() => speakText(`${title}: ${notice}`, 'bn')}
        title="নোটিশ শুনুন"
        className="shrink-0 text-amber-950 bg-amber-300 hover:bg-amber-400 active:scale-90 p-1.5 rounded-xl cursor-pointer transition-transform shadow-2xs"
      >
        <Volume2 className="w-4 h-4 animate-pulse" />
      </button>
      {title && (
        <span className="shrink-0 text-xs font-black bg-amber-400 text-amber-950 px-2.5 py-0.5 rounded-lg border border-amber-500/40 shadow-2xs">
          {title}
        </span>
      )}
      <div className="overflow-hidden relative flex-1">
        <div className="whitespace-nowrap inline-block animate-marquee text-xs sm:text-sm font-black text-amber-950 tracking-tight">
          {notice}
        </div>
      </div>
    </div>
  );
};
