import React, { useState } from 'react';
import {
  ShieldCheck,
  Plus,
  TrendingUp,
  Users,
  UserPlus,
  UserCheck,
  UserX,
  RefreshCw,
  Bell,
  Save,
  Trash2,
  CheckCircle2,
  Share2,
  MessageCircle,
  Send,
  Youtube,
  PhoneCall,
  Headphones,
  AlertCircle,
  ExternalLink,
  ShieldAlert,
  Copy,
  Check,
  Smartphone,
  KeyRound,
  Store,
  Wallet,
  ArrowLeft,
  Search,
  Filter,
  Layers,
  Sparkles,
  ChevronRight,
  Clock,
  Radio,
  FileText,
  BadgePercent,
  CheckCircle,
  Folder,
  FolderOpen,
  FolderPlus,
  FolderTree,
  Mail,
  Palette,
  ShoppingBag,
  History,
  X,
} from 'lucide-react';
import {
  DriveOffer,
  OperatorType,
  UserProfile,
  SocialCommunityLinks,
  SupportTicket,
  AppSettings,
  DriveOrder,
  AddMoneyRequest,
  RechargeRequest,
  PaymentNumbersConfig,
  SUPER_ADMIN_EMAIL,
  SUPER_ADMIN_EMAILS,
} from '../types';
import { OperatorLogo } from './OperatorLogos';
import { TelecomAiModal } from './TelecomAiModal';
import { AppFoldersSection } from './AppFoldersSection';
import { SocialMessengerModal } from './SocialMessengerModal';
import { AppLogoSettingsSection } from './AppLogoSettingsSection';
import { AdminDriveOrdersSection } from './AdminDriveOrdersSection';
import { AdminAddMoneySection } from './AdminAddMoneySection';
import { AdminRechargeSection } from './AdminRechargeSection';
import { AdminPendingUsersSection } from './AdminPendingUsersSection';
import { AdminUsersSection } from './AdminUsersSection';
import { AdminSocialSupportSection } from './AdminSocialSupportSection';
import { AdminAuditLogsModal } from './AdminAuditLogsModal';
import {
  getFormattedTodayDate,
  getOperatorBnName,
  formatSingleOfferShareText,
  shareContent,
  cleanBDPhoneForDial,
} from '../utils';

export interface AdminPanelViewProps {
  user: UserProfile;
  offers: DriveOffer[];
  orders?: DriveOrder[];
  addMoneyRequests?: AddMoneyRequest[];
  rechargeRequests?: RechargeRequest[];
  onAddOffer: (newOffer: DriveOffer) => void;
  onDeleteOffer: (id: string) => void;
  onUpdateBalance: (main: number, drive: number, bank: number) => void;
  currentNotice: string;
  onUpdateNotice: (notice: string) => void;
  socialLinks: SocialCommunityLinks;
  onUpdateSocialLinks: (links: SocialCommunityLinks) => void;
  supportTickets: SupportTicket[];
  onResolveTicket: (id: string) => void;
  onReplyTicket?: (
    id: string,
    replyText: string,
    status?: 'pending' | 'in_progress' | 'replied' | 'resolved'
  ) => void;
  onDeleteTicket?: (id: string) => void;
  users?: UserProfile[];
  onAddUser?: (newUser: UserProfile) => void;
  onUpdateUser?: (updated: UserProfile) => void;
  onDeleteUser?: (phone: string) => void;
  onApproveUser?: (phone: string, roleDecision?: 'user' | 'dealer') => void;
  onRejectUser?: (phone: string) => void;
  onToggleBlockUser?: (phone: string, isBlocked: boolean, reason?: string) => void;
  onAdjustBalance?: (
    phone: string,
    balanceType: 'main' | 'drive' | 'bank',
    amount: number,
    mode: 'add' | 'deduct' | 'set',
    note?: string
  ) => void;
  onApproveOrder?: (order: DriveOrder) => void;
  onCancelOrder?: (orderId: string, requesterPhone?: string) => void;
  onApproveAddMoney?: (req: AddMoneyRequest) => void;
  onRejectAddMoney?: (id: string) => void;
  onDeleteAddMoney?: (id: string) => void;
  onApproveRecharge?: (id: string) => void;
  onCancelRecharge?: (id: string, userPhone?: string, amount?: number) => void;
  onDeleteRecharge?: (id: string) => void;
  settings?: AppSettings;
  onUpdateSettings?: (settings: AppSettings) => void;
  paymentNumbers?: PaymentNumbersConfig;
  onUpdatePaymentNumbers?: (numbers: PaymentNumbersConfig) => void;
  onOpenProfileEdit?: () => void;
  onBackToHome?: () => void;
  onClose?: () => void;
}

export const AdminPanelView: React.FC<AdminPanelViewProps> = ({
  user,
  offers,
  orders = [],
  addMoneyRequests = [],
  rechargeRequests = [],
  onAddOffer,
  onDeleteOffer,
  onUpdateBalance,
  currentNotice,
  onUpdateNotice,
  socialLinks,
  onUpdateSocialLinks,
  paymentNumbers,
  onUpdatePaymentNumbers,
  supportTickets,
  onResolveTicket,
  onReplyTicket,
  onDeleteTicket,
  users = [],
  onAddUser,
  onUpdateUser,
  onDeleteUser,
  onApproveUser,
  onRejectUser,
  onToggleBlockUser,
  onAdjustBalance,
  onApproveOrder,
  onCancelOrder,
  onApproveAddMoney,
  onRejectAddMoney,
  onDeleteAddMoney,
  onApproveRecharge,
  onCancelRecharge,
  onDeleteRecharge,
  settings,
  onUpdateSettings,
  onOpenProfileEdit,
  onBackToHome,
  onClose,
}) => {
  // Super Admin & Dealer Role Logic
  const isSuperAdmin =
    user.isSuperAdmin === true ||
    user.appRole === 'super_admin' ||
    (user.email && SUPER_ADMIN_EMAILS.some((em) => em.toLowerCase() === user.email?.toLowerCase().trim())) ||
    user.phone === '01869875883' ||
    user.phone === '01918458908';

  const isDealerUser = !isSuperAdmin && (user.accountType === 'Dealer' || user.appRole === 'dealer');
  const isDealerSuspended = isDealerUser && user.dealerStatus === 'suspended';
  const dealerPermissions = user.dealerPermissions || {};

  // Audit Logs Modal State
  const [showAuditLogsModal, setShowAuditLogsModal] = useState(false);

  // Navigation Tabs
  const [activeAdminTab, setActiveAdminTab] = useState<
    'orders' | 'add_money' | 'recharge' | 'pending_users' | 'users' | 'offers' | 'branding' | 'social_support' | 'tickets' | 'balance' | 'notice'
  >('orders');

  // User Folder Navigation & Create User Form State
  const [selectedUserFolder, setSelectedUserFolder] = useState<
    'all' | 'Retailer' | 'Dealer' | 'Reseller' | 'Personal' | 'admin' | null
  >(null);
  const [isCreateUserOpen, setIsCreateUserOpen] = useState(false);

  // Drive Offer Folder Navigation & Create Offer Form State
  const [selectedOfferFolder, setSelectedOfferFolder] = useState<
    OperatorType | 'all' | null
  >(null);
  const [isCreateOfferOpen, setIsCreateOfferOpen] = useState(false);

  // Search & Filter states
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [offerSearchQuery, setOfferSearchQuery] = useState('');
  const [ticketFilter, setTicketFilter] = useState<'all' | 'pending' | 'replied' | 'resolved'>('all');
  const [activeReplyTicketId, setActiveReplyTicketId] = useState<string | null>(null);
  const [replyDraftMap, setReplyDraftMap] = useState<Record<string, string>>({});
  const [replyStatusMap, setReplyStatusMap] = useState<Record<string, 'replied' | 'resolved' | 'in_progress'>>({});
  const [deletingOfferId, setDeletingOfferId] = useState<string | null>(null);
  const [deletingUserPhone, setDeletingUserPhone] = useState<string | null>(null);
  const [adminToast, setAdminToast] = useState<string | null>(null);
  const [isAdminAiModalOpen, setIsAdminAiModalOpen] = useState(false);
  const [messengerModalType, setMessengerModalType] = useState<'whatsapp' | 'telegram' | 'direct_msg' | 'ussd_tools' | null>(null);

  const showToast = (msg: string) => {
    setAdminToast(msg);
    setTimeout(() => setAdminToast(null), 3000);
  };

  // New User Form State
  const [newUserName, setNewUserName] = useState('');
  const [newUserPhone, setNewUserPhone] = useState('');
  const [newUserPin, setNewUserPin] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserShop, setNewUserShop] = useState('');
  const [newUserAccountType, setNewUserAccountType] = useState<UserProfile['accountType']>('Retailer');
  const [newUserRole, setNewUserRole] = useState<'user' | 'admin'>('user');
  const [newUserMainBal, setNewUserMainBal] = useState('');
  const [newUserDriveBal, setNewUserDriveBal] = useState('');
  const [userCreatedSuccess, setUserCreatedSuccess] = useState(false);
  const [userCreateError, setUserCreateError] = useState('');
  const [copiedUserPhone, setCopiedUserPhone] = useState<string | null>(null);

  // New Offer Form State
  const [operator, setOperator] = useState<OperatorType>('gp');
  const [packageName, setPackageName] = useState('কম্বো প্যাক');
  const [offerDate, setOfferDate] = useState(getFormattedTodayDate());
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [minutes, setMinutes] = useState('');
  const [internetGB, setInternetGB] = useState('');
  const [sms, setSms] = useState('');
  const [validityDays, setValidityDays] = useState('30');
  const [regularPriceTK, setRegularPriceTK] = useState('');
  const [priceTK, setPriceTK] = useState('');
  const [cashbackTK, setCashbackTK] = useState('0');
  const [division, setDivision] = useState('All Bangladesh');
  const [offerSuccess, setOfferSuccess] = useState(false);

  // Auto-calculate Cashback when Regular Price or Current Price changes
  const handleRegularPriceChange = (val: string) => {
    setRegularPriceTK(val);
    const reg = parseFloat(val);
    const curr = parseFloat(priceTK);
    if (!isNaN(reg) && !isNaN(curr) && reg > curr) {
      setCashbackTK(String(reg - curr));
    } else {
      setCashbackTK('0');
    }
  };

  const handlePriceChange = (val: string) => {
    setPriceTK(val);
    const curr = parseFloat(val);
    const reg = parseFloat(regularPriceTK);
    if (!isNaN(reg) && !isNaN(curr) && reg > curr) {
      setCashbackTK(String(reg - curr));
    } else {
      setCashbackTK('0');
    }
  };

  // Social Links & Admin Contact Form State
  const [adminContactNumber, setAdminContactNumber] = useState(
    socialLinks.adminContactNumber || settings?.adminContactNumber || socialLinks.supportPhone || ''
  );
  const [waGroup, setWaGroup] = useState(socialLinks.whatsappGroup);
  const [waSupport, setWaSupport] = useState(socialLinks.whatsappSupportNumber);
  const [tgChannel, setTgChannel] = useState(socialLinks.telegramChannel);
  const [tgSupport, setTgSupport] = useState(socialLinks.telegramSupport);
  const [fbPage, setFbPage] = useState(socialLinks.facebookPage);
  const [ytChannel, setYtChannel] = useState(socialLinks.youtubeChannel);
  const [supportPhone, setSupportPhone] = useState(socialLinks.supportPhone);
  const [supportHours, setSupportHours] = useState(socialLinks.supportHours);
  const [emergencyNotice, setEmergencyNotice] = useState(socialLinks.emergencyNotice || '');
  const [socialSaved, setSocialSaved] = useState(false);

  // Balance Form State
  const [mainBal, setMainBal] = useState('');
  const [driveBal, setDriveBal] = useState('');
  const [bankBal, setBankBal] = useState('');
  const [balSaved, setBalSaved] = useState(false);

  // Notice State
  const [noticeInput, setNoticeInput] = useState(currentNotice);
  const [noticeSaved, setNoticeSaved] = useState(false);

  // Handlers
  const handleCreateOffer = (e: React.FormEvent) => {
    e.preventDefault();
    const opNames: Record<OperatorType, string> = {
      gp: 'Grameenphone',
      robi: 'Robi',
      banglalink: 'Banglalink',
      teletalk: 'Teletalk',
      airtel: 'Airtel',
      skitto: 'Skitto',
    };

    const cleanWa = (whatsappNumber || socialLinks.whatsappSupportNumber || '').replace(/[^0-9]/g, '');
    const formattedWa = cleanWa.startsWith('880')
      ? `+${cleanWa}`
      : cleanWa.startsWith('0')
      ? `+88${cleanWa}`
      : cleanWa ? `+880${cleanWa}` : '+8801712345678';

    const parsedRegular = parseFloat(regularPriceTK) || 0;
    const parsedPrice = parseFloat(priceTK) || 0;
    const calculatedCashback = parseFloat(cashbackTK) || (parsedRegular > parsedPrice ? parsedRegular - parsedPrice : 0);

    const newOffer: DriveOffer = {
      id: `${operator}-${Date.now()}`,
      operator,
      operatorName: opNames[operator],
      packageName: packageName.trim() || 'ড্রাইভ অফার',
      date: offerDate.trim() || getFormattedTodayDate(),
      whatsappNumber: formattedWa,
      minutes: parseInt(minutes) || 0,
      internetGB: parseInt(internetGB) || 0,
      sms: parseInt(sms) || 0,
      validityDays: parseInt(validityDays) || 30,
      regularPriceTK: parsedRegular > 0 ? parsedRegular : parsedPrice,
      priceTK: parsedPrice,
      cashbackTK: calculatedCashback,
      division,
      isPopular: true,
    };

    onAddOffer(newOffer);
    setOfferSuccess(true);
    setMinutes('');
    setInternetGB('');
    setSms('');
    setValidityDays('30');
    setRegularPriceTK('');
    setPriceTK('');
    setCashbackTK('0');
    setTimeout(() => setOfferSuccess(false), 2500);
  };

  const handleSaveSocialLinks = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSocialLinks({
      adminContactNumber: adminContactNumber.trim(),
      whatsappGroup: waGroup,
      whatsappSupportNumber: waSupport,
      telegramChannel: tgChannel,
      telegramSupport: tgSupport,
      facebookPage: fbPage,
      youtubeChannel: ytChannel,
      supportPhone,
      supportHours,
      emergencyNotice,
    });
    setSocialSaved(true);
    setTimeout(() => setSocialSaved(false), 2500);
  };

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    setUserCreateError('');
    if (!newUserName.trim() || !newUserPhone.trim()) return;

    const formattedPhone = newUserPhone.replace(/[^0-9]/g, '');
    if (formattedPhone.length < 11) {
      setUserCreateError('১১ ডিজিটের সঠিক মোবাইল নাম্বার প্রদান করুন');
      return;
    }

    // Check if phone already registered
    const phoneExists = users.some(
      (u) => u.phone.replace(/[^0-9]/g, '') === formattedPhone
    );
    if (phoneExists) {
      setUserCreateError(`মোবাইল নাম্বার (${newUserPhone}) ইতিমধ্যে অন্য গ্রাহকের নিবন্ধিত রয়েছে! ১ নাম্বারে ১ অ্যাকাউন্ট।`);
      return;
    }

    // PIN validation (exact PIN required)
    const pinClean = newUserPin.trim();
    if (!pinClean || pinClean.length < 4) {
      setUserCreateError('গ্রাহকের জন্য ৪ সংখ্যার গোপন পিন কোড প্রদান করুন (যেমন: 1986)');
      return;
    }

    const createdUser: UserProfile = {
      name: newUserName.trim(),
      email: newUserEmail.trim() || undefined,
      phone: formattedPhone,
      pin: pinClean,
      shopName: newUserShop.trim() || 'টেলিকম শপ',
      mainBalance: parseFloat(newUserMainBal) || 0,
      driveBalance: parseFloat(newUserDriveBal) || 0,
      bankBalance: 0,
      accountType: newUserAccountType,
      role: newUserRole,
      status: 'approved',
      registeredAt: new Date().toISOString(),
    };

    if (onAddUser) {
      onAddUser(createdUser);
    }
    setUserCreatedSuccess(true);
    setNewUserName('');
    setNewUserPhone('');
    setNewUserPin('');
    setNewUserEmail('');
    setNewUserShop('');
    setNewUserMainBal('');
    setNewUserDriveBal('');
    setTimeout(() => setUserCreatedSuccess(false), 3000);
  };

  const handleSaveBalances = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateBalance(
      mainBal !== '' ? (parseFloat(mainBal) || 0) : user.mainBalance,
      driveBal !== '' ? (parseFloat(driveBal) || 0) : user.driveBalance,
      bankBal !== '' ? (parseFloat(bankBal) || 0) : user.bankBalance
    );
    setBalSaved(true);
    setMainBal('');
    setDriveBal('');
    setBankBal('');
    setTimeout(() => setBalSaved(false), 2500);
  };

  const handleSaveNotice = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateNotice(noticeInput);
    setNoticeSaved(true);
    setTimeout(() => setNoticeSaved(false), 2500);
  };

  const pendingTicketsCount = supportTickets.filter((t) => t.status === 'pending').length;
  const repliedTicketsCount = supportTickets.filter((t) => t.status === 'replied' || t.status === 'in_progress').length;
  const resolvedTicketsCount = supportTickets.filter((t) => t.status === 'resolved').length;

  const handleSendTicketReply = (ticketId: string) => {
    const draft = (replyDraftMap[ticketId] || '').trim();
    if (!draft) {
      showToast('⚠️ অনুগ্রহ করে উত্তরের বিবরণ লিখুন');
      return;
    }
    const targetStatus = replyStatusMap[ticketId] || 'resolved';
    if (onReplyTicket) {
      onReplyTicket(ticketId, draft, targetStatus);
    } else {
      onResolveTicket(ticketId);
    }
    showToast('✓ উত্তর সফলভাবে রেকর্ড ও সেভ করা হয়েছে!');
    setActiveReplyTicketId(null);
  };

  // User Folders Definition
  const userFolders = [
    {
      id: 'all' as const,
      name: 'সকল গ্রাহক ফোল্ডার',
      desc: 'সিস্টেমের সকল নিবন্ধিত অ্যাকাউন্ট ও ব্যালেন্স',
      icon: Users,
      badgeColor: 'bg-indigo-100 text-indigo-800 border-indigo-200',
      folderBg: 'bg-indigo-50/70 hover:bg-indigo-50 border-indigo-200/80',
      iconBg: 'bg-indigo-600 text-white',
      badgeLabel: 'সকল ইউজার',
      usersList: users,
      count: users.length,
      totalBalance: users.reduce((sum, u) => sum + (u.mainBalance + u.driveBalance), 0),
    },
    {
      id: 'Retailer' as const,
      name: 'রিটেইলার ফোল্ডার',
      desc: 'দোকানদার ও রিটেইল সিম রিচার্জার অ্যাকাউন্ট',
      icon: Store,
      badgeColor: 'bg-purple-100 text-purple-800 border-purple-200',
      folderBg: 'bg-purple-50/70 hover:bg-purple-50 border-purple-200/80',
      iconBg: 'bg-purple-600 text-white',
      badgeLabel: 'রিটেইলার',
      usersList: users.filter((u) => u.accountType === 'Retailer'),
      count: users.filter((u) => u.accountType === 'Retailer').length,
      totalBalance: users.filter((u) => u.accountType === 'Retailer').reduce((sum, u) => sum + (u.mainBalance + u.driveBalance), 0),
    },
    {
      id: 'Dealer' as const,
      name: 'ডিলার ফোল্ডার',
      desc: 'জেলা ও উপজেলা ডিলার ও ডিস্ট্রিবিউটর অ্যাকাউন্ট',
      icon: ShieldCheck,
      badgeColor: 'bg-amber-100 text-amber-800 border-amber-200',
      folderBg: 'bg-amber-50/70 hover:bg-amber-50 border-amber-200/80',
      iconBg: 'bg-amber-600 text-white',
      badgeLabel: 'ডিলার',
      usersList: users.filter((u) => u.accountType === 'Dealer'),
      count: users.filter((u) => u.accountType === 'Dealer').length,
      totalBalance: users.filter((u) => u.accountType === 'Dealer').reduce((sum, u) => sum + (u.mainBalance + u.driveBalance), 0),
    },
    {
      id: 'Reseller' as const,
      name: 'রিসেলার ফোল্ডার',
      desc: 'সাব-অ্যাডমিন ও রিটেল রিসেলার অ্যাকাউন্ট',
      icon: TrendingUp,
      badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      folderBg: 'bg-emerald-50/70 hover:bg-emerald-50 border-emerald-200/80',
      iconBg: 'bg-emerald-600 text-white',
      badgeLabel: 'রিসেলার',
      usersList: users.filter((u) => u.accountType === 'Reseller'),
      count: users.filter((u) => u.accountType === 'Reseller').length,
      totalBalance: users.filter((u) => u.accountType === 'Reseller').reduce((sum, u) => sum + (u.mainBalance + u.driveBalance), 0),
    },
    {
      id: 'Personal' as const,
      name: 'পার্সোনাল গ্রাহক ফোল্ডার',
      desc: 'ব্যক্তিগত গ্রাহক ও সাধারণ ইউজার অ্যাকাউন্ট',
      icon: Smartphone,
      badgeColor: 'bg-sky-100 text-sky-800 border-sky-200',
      folderBg: 'bg-sky-50/70 hover:bg-sky-50 border-sky-200/80',
      iconBg: 'bg-sky-600 text-white',
      badgeLabel: 'পার্সোনাল',
      usersList: users.filter((u) => u.accountType === 'Personal' || (!u.accountType && u.role !== 'admin')),
      count: users.filter((u) => u.accountType === 'Personal' || (!u.accountType && u.role !== 'admin')).length,
      totalBalance: users.filter((u) => u.accountType === 'Personal' || (!u.accountType && u.role !== 'admin')).reduce((sum, u) => sum + (u.mainBalance + u.driveBalance), 0),
    },
    {
      id: 'admin' as const,
      name: 'অ্যাডমিন ও কন্ট্রোলার ফোল্ডার',
      desc: 'সুপার অ্যাডমিন ও কন্ট্রোল প্যানেল স্টাফ',
      icon: KeyRound,
      badgeColor: 'bg-rose-100 text-rose-800 border-rose-200',
      folderBg: 'bg-rose-50/70 hover:bg-rose-50 border-rose-200/80',
      iconBg: 'bg-rose-600 text-white',
      badgeLabel: 'অ্যাডমিন',
      usersList: users.filter((u) => u.role === 'admin'),
      count: users.filter((u) => u.role === 'admin').length,
      totalBalance: users.filter((u) => u.role === 'admin').reduce((sum, u) => sum + (u.mainBalance + u.driveBalance), 0),
    },
  ];

  // Active User Folder Details & Filtered List
  const activeUserFolderObj = userFolders.find((f) => f.id === selectedUserFolder);
  const currentFolderUsers = activeUserFolderObj
    ? activeUserFolderObj.usersList.filter((u) => {
        const q = userSearchQuery.toLowerCase();
        return (
          u.name.toLowerCase().includes(q) ||
          u.phone.includes(userSearchQuery) ||
          (u.shopName && u.shopName.toLowerCase().includes(q))
        );
      })
    : [];

  // Drive Offer Folders Definition
  const offerFolders = [
    {
      id: 'all' as const,
      name: 'সকল ড্রাইভ অফার ফোল্ডার',
      desc: 'সকল অপারেটরের চলমান লাইভ ড্রাইভ প্যাক',
      badgeColor: 'bg-indigo-100 text-indigo-800 border-indigo-200',
      folderBg: 'bg-indigo-50/70 hover:bg-indigo-50 border-indigo-200/80',
      iconBg: 'bg-indigo-600 text-white',
      offersList: offers,
      count: offers.length,
    },
    {
      id: 'gp' as const,
      name: 'গ্রামীণফোন ড্রাইভ ফোল্ডার',
      desc: 'GP মিনিট, ইন্টারনেট ও ক্যাশব্যাক বান্ডেল',
      badgeColor: 'bg-sky-100 text-sky-800 border-sky-200',
      folderBg: 'bg-sky-50/70 hover:bg-sky-50 border-sky-200/80',
      iconBg: 'bg-sky-600 text-white',
      offersList: offers.filter((o) => o.operator === 'gp'),
      count: offers.filter((o) => o.operator === 'gp').length,
    },
    {
      id: 'robi' as const,
      name: 'রবি ড্রাইভ ফোল্ডার',
      desc: 'Robi কম্বো, বান্ডেল ও ওটিপি প্যাক',
      badgeColor: 'bg-rose-100 text-rose-800 border-rose-200',
      folderBg: 'bg-rose-50/70 hover:bg-rose-50 border-rose-200/80',
      iconBg: 'bg-rose-600 text-white',
      offersList: offers.filter((o) => o.operator === 'robi'),
      count: offers.filter((o) => o.operator === 'robi').length,
    },
    {
      id: 'banglalink' as const,
      name: 'বাংলালিংক ড্রাইভ ফোল্ডার',
      desc: 'BL স্পেশাল ইন্টারনেট ও মিনিট ডিল',
      badgeColor: 'bg-amber-100 text-amber-800 border-amber-200',
      folderBg: 'bg-amber-50/70 hover:bg-amber-50 border-amber-200/80',
      iconBg: 'bg-amber-600 text-white',
      offersList: offers.filter((o) => o.operator === 'banglalink'),
      count: offers.filter((o) => o.operator === 'banglalink').length,
    },
    {
      id: 'airtel' as const,
      name: 'এয়ারটেল ড্রাইভ ফোল্ডার',
      desc: 'Airtel ফ্যামিলি, ফ্রেন্ডস ও কম্বো প্যাক',
      badgeColor: 'bg-red-100 text-red-800 border-red-200',
      folderBg: 'bg-red-50/70 hover:bg-red-50 border-red-200/80',
      iconBg: 'bg-red-600 text-white',
      offersList: offers.filter((o) => o.operator === 'airtel'),
      count: offers.filter((o) => o.operator === 'airtel').length,
    },
    {
      id: 'teletalk' as const,
      name: 'টেলিটক ড্রাইভ ফোল্ডার',
      desc: 'Teletalk সাশ্রয়ী মিনিট ও ডাটা প্যাক',
      badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      folderBg: 'bg-emerald-50/70 hover:bg-emerald-50 border-emerald-200/80',
      iconBg: 'bg-emerald-600 text-white',
      offersList: offers.filter((o) => o.operator === 'teletalk'),
      count: offers.filter((o) => o.operator === 'teletalk').length,
    },
    {
      id: 'skitto' as const,
      name: 'স্কিটো ড্রাইভ ফোল্ডার',
      desc: 'Skitto ডিজিটাল ডাটা ডিল ও কম্বো',
      badgeColor: 'bg-pink-100 text-pink-800 border-pink-200',
      folderBg: 'bg-pink-50/70 hover:bg-pink-50 border-pink-200/80',
      iconBg: 'bg-pink-600 text-white',
      offersList: offers.filter((o) => o.operator === 'skitto'),
      count: offers.filter((o) => o.operator === 'skitto').length,
    },
  ];

  // Active Offer Folder Details & Filtered List
  const activeOfferFolderObj = offerFolders.find((f) => f.id === selectedOfferFolder);
  const currentFolderOffers = activeOfferFolderObj
    ? activeOfferFolderObj.offersList.filter((off) => {
        const q = offerSearchQuery.toLowerCase();
        return (
          (off.packageName && off.packageName.toLowerCase().includes(q)) ||
          (off.operatorName && off.operatorName.toLowerCase().includes(q)) ||
          off.priceTK.toString().includes(offerSearchQuery) ||
          off.internetGB.toString().includes(offerSearchQuery) ||
          off.minutes.toString().includes(offerSearchQuery)
        );
      })
    : [];

  const filteredTickets = supportTickets.filter((tkt) => {
    if (ticketFilter === 'pending') return tkt.status === 'pending';
    if (ticketFilter === 'replied') return tkt.status === 'replied' || tkt.status === 'in_progress';
    if (ticketFilter === 'resolved') return tkt.status === 'resolved';
    return true;
  });

  const pendingUsersList = (users || []).filter((u) => u.status === 'pending');
  const pendingUsersCount = pendingUsersList.length;
  const pendingOrdersCount = (orders || []).filter((o) => o.status === 'pending').length;
  const pendingAddMoneyCount = (addMoneyRequests || []).filter((r) => r.status === 'pending').length;
  const pendingRechargeCount = (rechargeRequests || []).filter((r) => r.status === 'pending').length;
  const totalPendingNotifications = pendingOrdersCount + pendingAddMoneyCount + pendingRechargeCount + pendingTicketsCount + pendingUsersCount;

  const backAction = onBackToHome || onClose;

  return (
    <div className="w-full bg-slate-50 text-slate-900 pb-8 animate-fadeIn">
      {/* 1. Header Bar with Orange Rounded Shade */}
      <header
        className="sticky top-0 z-30 bg-gradient-to-r from-amber-700 via-orange-600 to-rose-700 text-white pb-4 px-4 rounded-b-[24px] shadow-md shadow-orange-950/15 transition-all duration-300"
        style={{
          paddingTop: 'max(14px, calc(env(safe-area-inset-top, 0px) + 12px))',
        }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            {backAction && (
              <button
                type="button"
                id="admin-back-btn"
                onClick={backAction}
                className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-md flex items-center justify-center text-white transition-all active:scale-95 cursor-pointer shrink-0 border border-white/30"
                title="ফিরে যান"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-300 shrink-0" />
                <h1 className="font-extrabold text-white text-sm tracking-tight leading-tight">
                  অ্যাডমিন কন্ট্রোল প্যানেল
                </h1>
              </div>
              <p className="text-[10px] text-white/85 font-medium">
                ফায়ারস্টোর লাইভ সিঙ্ক ও রিকোয়েস্ট নিয়ন্ত্রণ
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {totalPendingNotifications > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-rose-500 text-white font-black text-[10px] animate-pulse shadow-xs flex items-center gap-1">
                <Bell className="w-3 h-3" />
                <span>{totalPendingNotifications}</span>
              </span>
            )}

            {/* Admin Profile Button to change photo directly */}
            {onOpenProfileEdit ? (
              <button
                id="admin-header-profile-btn"
                type="button"
                onClick={onOpenProfileEdit}
                title="অ্যাডমিনের প্রোফাইল এডিট করতে ক্লিক করুন"
                className="w-7 h-7 rounded-full overflow-hidden bg-white text-orange-600 font-black text-xs flex items-center justify-center border-2 border-white/60 shadow-xs hover:scale-105 active:scale-95 transition-all cursor-pointer"
              >
                {user.profileImage ? (
                  <img src={user.profileImage} alt="Admin" className="w-full h-full object-cover" />
                ) : (
                  <ShieldCheck className="w-4 h-4 text-orange-600" />
                )}
              </button>
            ) : null}

            {isSuperAdmin ? (
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  id="header-audit-logs-btn"
                  onClick={() => setShowAuditLogsModal(true)}
                  className="px-2.5 py-1 rounded-full bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-[10px] shadow-sm flex items-center gap-1 transition-all active:scale-95 cursor-pointer"
                  title="সকল অ্যাক্টিভিটি ও ডিলার অডিট লগ দেখুন"
                >
                  <History className="w-3 h-3 text-slate-900" />
                  <span>অডিট লগ</span>
                </button>
              </div>
            ) : isDealerUser && isDealerSuspended ? (
              <div className="flex items-center gap-1">
                <span className="px-1.5 py-0.5 rounded-md bg-rose-600 text-white font-bold text-[9px] shadow-2xs">
                  স্থগিত
                </span>
              </div>
            ) : null}
          </div>
        </div>

        {/* Quick KPI Stats Summary Cards */}
        <div className="grid grid-cols-5 gap-1.5 mt-3.5 pt-2.5 border-t border-white/20">
          <button
            type="button"
            onClick={() => setActiveAdminTab('orders')}
            className={`p-1.5 sm:p-2 rounded-xl text-left transition-all backdrop-blur-xs cursor-pointer ${
              activeAdminTab === 'orders'
                ? 'bg-white text-orange-950 shadow-md ring-2 ring-white font-bold'
                : 'bg-white/95 text-slate-800 hover:bg-white border border-white/40 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between text-purple-600 mb-0.5">
              <ShoppingBag className="w-3.5 h-3.5" />
              <span className={`font-extrabold text-xs ${pendingOrdersCount > 0 ? 'text-rose-600 font-black' : 'text-slate-900'}`}>{pendingOrdersCount}</span>
            </div>
            <span className="text-[9px] font-bold text-slate-600 block truncate">অর্ডার</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveAdminTab('add_money')}
            className={`p-1.5 sm:p-2 rounded-xl text-left transition-all backdrop-blur-xs cursor-pointer ${
              activeAdminTab === 'add_money'
                ? 'bg-white text-orange-950 shadow-md ring-2 ring-white font-bold'
                : 'bg-white/95 text-slate-800 hover:bg-white border border-white/40 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between text-emerald-600 mb-0.5">
              <Wallet className="w-3.5 h-3.5" />
              <span className={`font-extrabold text-xs ${pendingAddMoneyCount > 0 ? 'text-rose-600 font-black' : 'text-slate-900'}`}>{pendingAddMoneyCount}</span>
            </div>
            <span className="text-[9px] font-bold text-slate-600 block truncate">অ্যাড মানি</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveAdminTab('recharge')}
            className={`p-1.5 sm:p-2 rounded-xl text-left transition-all backdrop-blur-xs cursor-pointer ${
              activeAdminTab === 'recharge'
                ? 'bg-white text-orange-950 shadow-md ring-2 ring-white font-bold'
                : 'bg-white/95 text-slate-800 hover:bg-white border border-white/40 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between text-blue-600 mb-0.5">
              <Smartphone className="w-3.5 h-3.5" />
              <span className={`font-extrabold text-xs ${pendingRechargeCount > 0 ? 'text-rose-600 font-black' : 'text-slate-900'}`}>{pendingRechargeCount}</span>
            </div>
            <span className="text-[9px] font-bold text-slate-600 block truncate">রিচার্জ</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveAdminTab('pending_users')}
            className={`p-1.5 sm:p-2 rounded-xl text-left transition-all backdrop-blur-xs cursor-pointer ${
              activeAdminTab === 'pending_users'
                ? 'bg-white text-orange-950 shadow-md ring-2 ring-white font-bold'
                : pendingUsersCount > 0
                ? 'bg-amber-100 text-amber-950 border border-amber-300 shadow-xs ring-1 ring-amber-400 animate-pulse'
                : 'bg-white/95 text-slate-800 hover:bg-white border border-white/40 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between text-amber-600 mb-0.5">
              <UserPlus className="w-3.5 h-3.5" />
              <span className={`font-extrabold text-xs ${pendingUsersCount > 0 ? 'text-rose-600 font-black' : 'text-slate-900'}`}>{pendingUsersCount}</span>
            </div>
            <span className="text-[9px] font-bold text-slate-600 block truncate">পেন্ডিং ইউজার</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveAdminTab('users')}
            className={`p-1.5 sm:p-2 rounded-xl text-left transition-all backdrop-blur-xs cursor-pointer ${
              activeAdminTab === 'users'
                ? 'bg-white text-orange-950 shadow-md ring-2 ring-white font-bold'
                : 'bg-white/95 text-slate-800 hover:bg-white border border-white/40 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between text-orange-600 mb-0.5">
              <Users className="w-3.5 h-3.5" />
              <span className="font-extrabold text-xs text-slate-900">{users.length}</span>
            </div>
            <span className="text-[9px] font-bold text-slate-600 block truncate">ইউজার</span>
          </button>
        </div>
      </header>

      {/* Admin Toast Notification */}
      {adminToast && (
        <div className="mx-4 mt-2 p-3 bg-slate-900 text-white text-xs font-bold rounded-2xl shadow-lg flex items-center justify-between gap-2 border border-slate-700 animate-fadeIn z-30">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{adminToast}</span>
          </div>
          <button
            type="button"
            onClick={() => setAdminToast(null)}
            className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Dealer Suspended Warning Banner */}
      {isDealerSuspended && (
        <div className="mx-4 mt-2 p-3.5 bg-rose-50 border border-rose-200 text-rose-900 rounded-2xl flex items-start gap-2.5 shadow-xs">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div className="text-xs">
            <p className="font-black text-rose-950">আপনার ডিলার এক্সেস সাময়িকভাবে স্থগিত করা হয়েছে</p>
            <p className="text-[11px] text-rose-700 mt-0.5">
              কারণ: {user.dealerSuspendedReason || 'সুপার এডমিন কর্তৃক স্থগিত'}। বিস্তারিত তথ্যের জন্য সুপার এডমিনের সাথে যোগাযোগ করুন।
            </p>
          </div>
        </div>
      )}

      {/* 2. Main Organized Tab Selector Bar */}
      <div className="px-4 pt-3 pb-1">
        <div className="grid grid-cols-4 sm:grid-cols-6 gap-1 bg-slate-200/70 p-1.5 rounded-2xl border border-slate-200">
          {[
            { key: 'orders', label: 'অর্ডার', icon: ShoppingBag, count: pendingOrdersCount, alert: pendingOrdersCount > 0, highlight: pendingOrdersCount > 0, allowed: isSuperAdmin || (!isDealerSuspended && dealerPermissions.manageOrders !== false) },
            { key: 'add_money', label: 'অ্যাড মানি', icon: Wallet, count: pendingAddMoneyCount, alert: pendingAddMoneyCount > 0, highlight: pendingAddMoneyCount > 0, allowed: isSuperAdmin || (!isDealerSuspended && dealerPermissions.manageAddMoney !== false) },
            { key: 'recharge', label: 'রিচার্জ', icon: Smartphone, count: pendingRechargeCount, alert: pendingRechargeCount > 0, highlight: pendingRechargeCount > 0, allowed: isSuperAdmin || (!isDealerSuspended && dealerPermissions.manageRecharge !== false) },
            { key: 'pending_users', label: 'পেন্ডিং নিবন্ধন', icon: UserCheck, count: pendingUsersCount, alert: pendingUsersCount > 0, highlight: pendingUsersCount > 0, allowed: isSuperAdmin },
            { key: 'users', label: 'সকল ইউজার', icon: Users, count: users.length, allowed: isSuperAdmin || (!isDealerSuspended && Boolean(dealerPermissions.viewUsers)) },
            { key: 'offers', label: 'ড্রাইভ', icon: Layers, count: offers.length, allowed: isSuperAdmin || (!isDealerSuspended && dealerPermissions.manageOffers !== false) },
            { key: 'branding', label: 'লোগো', icon: Palette, allowed: isSuperAdmin },
            { key: 'tickets', label: 'অভিযোগ', icon: Headphones, count: pendingTicketsCount, alert: pendingTicketsCount > 0, allowed: isSuperAdmin || (!isDealerSuspended && dealerPermissions.manageTickets !== false) },
            { key: 'social_support', label: 'সোশ্যাল', icon: Share2, allowed: isSuperAdmin },
            { key: 'balance', label: 'ব্যালেন্স', icon: Wallet, allowed: isSuperAdmin },
            { key: 'notice', label: 'নোটিশ', icon: Bell, allowed: isSuperAdmin },
          ]
            .filter((t) => t.allowed)
            .map((tab) => {
              const Icon = tab.icon;
              const isActive = activeAdminTab === tab.key;
              return (
                <button
                  key={tab.key}
                  type="button"
                  id={`admin-tab-${tab.key}`}
                  onClick={() => setActiveAdminTab(tab.key as any)}
                  className={`py-1.5 px-1 rounded-xl text-[10px] font-extrabold flex flex-col items-center justify-center gap-0.5 transition-all cursor-pointer ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/20 ring-1 ring-white'
                      : tab.highlight
                      ? 'bg-gradient-to-r from-amber-500/20 to-rose-500/20 text-indigo-950 border border-amber-300 hover:bg-white'
                      : 'bg-white/70 text-slate-600 hover:bg-white hover:text-slate-900'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : tab.highlight ? 'text-rose-600' : 'text-slate-500'}`} />
                  <span className="truncate">{tab.label}</span>
                  {tab.alert && (
                    <span className="w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white inline-block shrink-0 animate-pulse" />
                  )}
                </button>
              );
            })}
        </div>
      </div>

      {/* 3. Tab Contents */}
      <main className="p-4 space-y-4">
        {/* ========================================================= */}
        {/* TAB 0: PENDING DRIVE ORDERS MANAGEMENT                    */}
        {/* ========================================================= */}
        {activeAdminTab === 'orders' && (
          <AdminDriveOrdersSection
            orders={orders}
            onApproveOrder={onApproveOrder || (() => {})}
            onCancelOrder={onCancelOrder || (() => {})}
            socialLinks={socialLinks}
            onShowToast={showToast}
          />
        )}

        {/* ========================================================= */}
        {/* TAB: ADD MONEY REQUESTS                                   */}
        {/* ========================================================= */}
        {activeAdminTab === 'add_money' && (
          <AdminAddMoneySection
            requests={addMoneyRequests}
            onApproveRequest={onApproveAddMoney || (() => {})}
            onRejectRequest={onRejectAddMoney || (() => {})}
            onDeleteRequest={onDeleteAddMoney}
            socialLinks={socialLinks}
            paymentNumbers={paymentNumbers}
            onUpdatePaymentNumbers={onUpdatePaymentNumbers}
            onShowToast={showToast}
          />
        )}

        {/* ========================================================= */}
        {/* TAB: RECHARGE REQUESTS                                    */}
        {/* ========================================================= */}
        {activeAdminTab === 'recharge' && (
          <AdminRechargeSection
            requests={rechargeRequests}
            onApproveRequest={onApproveRecharge || (() => {})}
            onCancelRequest={onCancelRecharge || (() => {})}
            onDeleteRequest={onDeleteRecharge}
            socialLinks={socialLinks}
            onShowToast={showToast}
          />
        )}

        {/* ========================================================= */}
        {/* TAB: PENDING USER REGISTRATIONS                           */}
        {/* ========================================================= */}
        {activeAdminTab === 'pending_users' && (
          <AdminPendingUsersSection
            pendingUsers={pendingUsersList}
            onApproveUser={onApproveUser || (() => {})}
            onRejectUser={onRejectUser || (() => {})}
            onDeleteUser={onDeleteUser}
            onShowToast={showToast}
          />
        )}
        {/* ========================================================= */}
        {/* TAB 1: USERS & RETAILERS MANAGEMENT                       */}
        {/* ========================================================= */}
        {activeAdminTab === 'users' && (
          <AdminUsersSection
            users={users}
            currentUser={user}
            currentAdminPhone={user.phone}
            onAddUser={onAddUser}
            onUpdateUser={onUpdateUser}
            onDeleteUser={onDeleteUser}
            onToggleBlockUser={onToggleBlockUser}
            onAdjustBalance={onAdjustBalance}
            onShowToast={showToast}
            onOpenAuditLogs={() => setShowAuditLogsModal(true)}
          />
        )}

        {/* ========================================================= */}

        {/* ========================================================= */}
        {/* TAB 2: DRIVE OFFERS MANAGEMENT                           */}
        {/* ========================================================= */}
        {activeAdminTab === 'offers' && (
          <div className="space-y-4 animate-fadeIn">
            {/* Create Offer Form */}
            <section className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
                    <Plus className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="font-extrabold text-slate-900 text-sm leading-tight">
                      নতুন ড্রাইভ অফার প্রকাশ করুন
                    </h2>
                    <p className="text-[10px] text-slate-500 font-medium">
                      প্যাক তৈরি করে গ্রাহকদের কাছে তাৎক্ষণিক লাইভ করুন
                    </p>
                  </div>
                </div>
              </div>

              <form onSubmit={handleCreateOffer} className="space-y-3.5">
                {/* 1. Operator Selection */}
                <div>
                  <label className="text-[11px] font-extrabold text-slate-700 block mb-1.5">
                    অপারেটর নির্বাচন করুন *
                  </label>
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                    {(['gp', 'robi', 'banglalink', 'airtel', 'teletalk', 'skitto'] as OperatorType[]).map((op) => (
                      <button
                        key={op}
                        type="button"
                        onClick={() => setOperator(op)}
                        className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1.5 text-xs font-black transition-all cursor-pointer ${
                          operator === op
                            ? 'border-indigo-600 bg-indigo-50 text-indigo-900 shadow-xs ring-2 ring-indigo-200'
                            : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <OperatorLogo operator={op} size="sm" />
                        <span className="uppercase text-[10px]">{getOperatorBnName(op)}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* 2. Package Type, Date & WhatsApp Helpline */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <div>
                    <label className="text-xs font-black text-slate-700 block mb-1">
                      প্যাকেজের ধরণ
                    </label>
                    <select
                      id="package-type-select"
                      value={packageName}
                      onChange={(e) => setPackageName(e.target.value)}
                      className="w-full py-1.5 px-3 bg-slate-50 border border-slate-300 rounded-xl font-black text-sm text-slate-900 outline-none focus:border-indigo-600 focus:bg-white cursor-pointer"
                    >
                      <option value="কম্বো প্যাক">কম্বো প্যাক (Combo Pack)</option>
                      <option value="বান্ডেল প্যাক">বান্ডেল প্যাক (Bundle Pack)</option>
                      <option value="ডাটা প্যাক">ডাটা প্যাক (Data Pack)</option>
                      <option value="মিনিট প্যাক">মিনিট প্যাক (Minute Pack)</option>
                      <option value="ফ্যামিলি প্যাক">ফ্যামিলি প্যাক (Family Pack)</option>
                      <option value="গিফট প্যাক">গিফট প্যাক (Gift Pack)</option>
                      <option value="ওটিপি প্যাক">ওটিপি প্যাক (OTP Pack)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-black text-slate-700 flex items-center justify-between mb-1">
                      <span>অফার তারিখ</span>
                      <span className="text-[10px] text-purple-700 font-extrabold bg-purple-50 px-1.5 py-0.2 rounded-md">Live</span>
                    </label>
                    <input
                      type="text"
                      value={offerDate}
                      onChange={(e) => setOfferDate(e.target.value)}
                      placeholder="দিন/মাস/বছর"
                      className="w-full py-1.5 px-3 bg-slate-50 border border-slate-300 rounded-xl font-black text-sm text-slate-900 outline-none focus:border-indigo-600 focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-black text-slate-700 flex items-center justify-between mb-1">
                      <span>এডমিন WhatsApp নম্বর</span>
                      <span className="text-[10px] text-slate-500 font-bold">অর্ডার গ্রহণ</span>
                    </label>
                    <div className="flex items-center rounded-xl bg-slate-50 border border-slate-300 focus-within:border-emerald-600 focus-within:bg-white overflow-hidden transition-all">
                      <div className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-100 border-r border-slate-300 text-slate-800 text-xs font-black select-none shrink-0">
                        <span>🇧🇩 +880</span>
                      </div>
                      <input
                        type="tel"
                        id="drive-offer-whatsapp"
                        value={whatsappNumber}
                        onChange={(e) => setWhatsappNumber(e.target.value.replace(/[^0-9]/g, ''))}
                        placeholder="17XXXXXXXX"
                        className="w-full px-2.5 py-1.5 bg-transparent font-black text-sm text-slate-900 outline-none placeholder:text-slate-400 placeholder:font-normal"
                      />
                    </div>
                  </div>
                </div>

                {/* 3. Specs: Internet GB, Talk Time, SMS, Validity (All with optional clarity) */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div>
                    <label className="text-xs font-black text-slate-700 block mb-1">
                      ইন্টারনেট (GB) <span className="text-[10px] text-slate-400 font-normal">(ঐচ্ছিক)</span>
                    </label>
                    <input
                      type="number"
                      value={internetGB}
                      onChange={(e) => setInternetGB(e.target.value)}
                      placeholder="0"
                      className="w-full py-1.5 px-3 bg-slate-50 border border-slate-300 rounded-xl font-black text-sm text-slate-900 outline-none focus:border-indigo-600 focus:bg-white placeholder:text-slate-300"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-black text-slate-700 block mb-1">
                      টকটাইম (মিনিট) <span className="text-[10px] text-slate-400 font-normal">(ঐচ্ছিক)</span>
                    </label>
                    <input
                      type="number"
                      value={minutes}
                      onChange={(e) => setMinutes(e.target.value)}
                      placeholder="0"
                      className="w-full py-1.5 px-3 bg-slate-50 border border-slate-300 rounded-xl font-black text-sm text-slate-900 outline-none focus:border-indigo-600 focus:bg-white placeholder:text-slate-300"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-black text-slate-700 block mb-1">
                      এসএমএস (SMS) <span className="text-[10px] text-slate-400 font-normal">(ঐচ্ছিক)</span>
                    </label>
                    <input
                      type="number"
                      value={sms}
                      onChange={(e) => setSms(e.target.value)}
                      placeholder="0"
                      className="w-full py-1.5 px-3 bg-slate-50 border border-slate-300 rounded-xl font-black text-sm text-slate-900 outline-none focus:border-indigo-600 focus:bg-white placeholder:text-slate-300"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-black text-slate-700 block mb-1">
                      মেয়াদ (দিন)
                    </label>
                    <input
                      type="number"
                      value={validityDays}
                      onChange={(e) => setValidityDays(e.target.value)}
                      placeholder="30"
                      className="w-full py-1.5 px-3 bg-slate-50 border border-slate-300 rounded-xl font-black text-sm text-slate-900 outline-none focus:border-indigo-600 focus:bg-white"
                    />
                  </div>
                </div>

                {/* 4. Pricing, Cashback calculation & Division */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                  <div>
                    <label className="text-xs font-black text-slate-700 block mb-1">
                      রেগুলার দাম (৳) <span className="text-[10px] text-rose-500 font-normal">❌</span>
                    </label>
                    <input
                      type="number"
                      value={regularPriceTK}
                      onChange={(e) => handleRegularPriceChange(e.target.value)}
                      placeholder="যেমন: 999"
                      className="w-full py-1.5 px-3 bg-slate-50 border border-slate-300 rounded-xl font-black text-sm text-slate-900 outline-none focus:border-indigo-600 focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-black text-slate-700 block mb-1">
                      বর্তমান দাম (৳) * <span className="text-[10px] text-emerald-600 font-normal">✅</span>
                    </label>
                    <input
                      type="number"
                      required
                      value={priceTK}
                      onChange={(e) => handlePriceChange(e.target.value)}
                      placeholder="যেমন: 899"
                      className="w-full py-1.5 px-3 bg-slate-50 border border-emerald-400 rounded-xl font-black text-sm text-emerald-950 outline-none focus:border-emerald-600 focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-black text-slate-700 flex items-center justify-between mb-1">
                      <span>ক্যাশব্যাক (৳)</span>
                      <span className="text-[10px] text-emerald-700 font-extrabold bg-emerald-50 px-1.5 py-0.2 rounded-md">ক্যাশব্যাক</span>
                    </label>
                    <input
                      type="number"
                      value={cashbackTK}
                      onChange={(e) => setCashbackTK(e.target.value)}
                      placeholder="0"
                      className="w-full py-1.5 px-3 bg-emerald-50/70 border border-emerald-300 rounded-xl font-black text-sm text-emerald-900 outline-none focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-black text-slate-700 block mb-1">বিভাগ / এলাকা</label>
                    <select
                      value={division}
                      onChange={(e) => setDivision(e.target.value)}
                      className="w-full py-1.5 px-3 bg-slate-50 border border-slate-300 rounded-xl font-black text-sm text-slate-900 outline-none focus:border-indigo-600 focus:bg-white cursor-pointer"
                    >
                      <option value="All Bangladesh">সারাদেশ (All BD)</option>
                      <option value="Dhaka">ঢাকা বিভাগ</option>
                      <option value="Chittagong">চট্টগ্রাম বিভাগ</option>
                      <option value="Rajshahi">রাজশাহী বিভাগ</option>
                      <option value="Khulna">খুলনা বিভাগ</option>
                      <option value="Sylhet">সিলেট বিভাগ</option>
                      <option value="Barisal">বরিশাল বিভাগ</option>
                      <option value="Rangpur">রংপুর বিভাগ</option>
                      <option value="Mymensingh">ময়মনসিংহ বিভাগ</option>
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  id="admin-create-offer-btn"
                  className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-extrabold text-xs rounded-xl shadow-md shadow-purple-600/20 flex items-center justify-center gap-2 transition-all active:scale-98 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>ড্রাইভ অফার লাইভ পাবলিশ করুন</span>
                </button>

                {offerSuccess && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-emerald-800 text-xs font-bold animate-fadeIn">
                    <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>অফার সফলভাবে যোগ হয়েছে এবং গ্রাহক অ্যাপে লাইভ দৃশ্যমান!</span>
                  </div>
                )}
              </form>
            </section>

            {/* FOLDER VIEW: OUTSIDE (Operator Offer Folder Cards Grid) */}
            {!selectedOfferFolder ? (
              <section className="space-y-3">
                {/* AI Assistant Quick Banner */}
                <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-700 via-indigo-700 to-pink-600 text-white shadow-md flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 shrink-0">
                      <Sparkles className="w-5 h-5 text-amber-300 animate-pulse" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-xs leading-tight">
                        টেলিকম AI অফার জেনারেটর
                      </h4>
                      <p className="text-[10px] text-white/80 font-medium mt-0.5">
                        চ্যাটজিপিটি বা জেমিনাই এর মতো ১-ক্লিকে অফার লিস্ট বানিয়ে অ্যাপে যোগ করুন
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setIsAdminAiModalOpen(true)}
                    className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-purple-950 font-black text-xs rounded-xl shadow-xs transition-all shrink-0 active:scale-95 cursor-pointer"
                  >
                    AI অফার খুলুন
                  </button>
                </div>

                <div className="flex items-center justify-between px-1">
                  <div className="flex items-center gap-1.5">
                    <Folder className="w-4 h-4 text-purple-600" />
                    <h3 className="text-xs font-extrabold text-slate-900">
                      ড্রাইভ অফার ফোল্ডার সমূহ (ক্লিক করে ভেতরে দেখুন)
                    </h3>
                  </div>
                  <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                    মোট ফোল্ডার: {offerFolders.length} টি
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {offerFolders.map((fld) => {
                    return (
                      <div
                        key={fld.id}
                        id={`offer-folder-${fld.id}`}
                        onClick={() => {
                          setSelectedOfferFolder(fld.id);
                          setOfferSearchQuery('');
                        }}
                        className={`p-4 rounded-2xl border transition-all cursor-pointer hover:shadow-md hover:scale-[1.01] active:scale-98 ${fld.folderBg} flex flex-col justify-between gap-3 group`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-2.5">
                            {fld.id === 'all' ? (
                              <div className={`w-10 h-10 rounded-xl ${fld.iconBg} flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform`}>
                                <Layers className="w-5 h-5" />
                              </div>
                            ) : (
                              <div className="group-hover:scale-105 transition-transform">
                                <OperatorLogo operator={fld.id as OperatorType} size="md" />
                              </div>
                            )}
                            <div>
                              <h4 className="font-extrabold text-slate-900 text-xs leading-tight group-hover:text-purple-700 transition-colors">
                                {fld.name}
                              </h4>
                              <p className="text-[10px] text-slate-500 font-medium line-clamp-1 mt-0.5">
                                {fld.desc}
                              </p>
                            </div>
                          </div>
                          <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${fld.badgeColor} shrink-0`}>
                            {fld.count} টি অফার
                          </span>
                        </div>

                        <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px]">
                          <span className="font-bold text-slate-600">
                            স্ট্যাটাস: লাইভ সক্রিয়
                          </span>
                          <span className="font-extrabold text-purple-700 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                            <span>ফোল্ডার খুলুন</span>
                            <ChevronRight className="w-3.5 h-3.5" />
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            ) : (
              /* FOLDER VIEW: INSIDE (Specific Operator Folder's Offers List) */
              <section className="bg-white rounded-3xl p-5 border border-purple-200 shadow-xs space-y-4 animate-fadeIn">
                {/* Folder Inside Header Bar */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      id="back-to-offer-folders-btn"
                      onClick={() => {
                        setSelectedOfferFolder(null);
                        setOfferSearchQuery('');
                      }}
                      className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-extrabold flex items-center gap-1 transition-all active:scale-95 cursor-pointer"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>সকল ফোল্ডার</span>
                    </button>
                    <div className="flex items-center gap-1.5">
                      <FolderOpen className="w-4 h-4 text-purple-600" />
                      <h3 className="text-xs font-black text-slate-900">
                        {activeOfferFolderObj?.name}
                      </h3>
                    </div>
                  </div>

                  <span className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full border ${activeOfferFolderObj?.badgeColor}`}>
                    মোট অফার: {currentFolderOffers.length} টি
                  </span>
                </div>

                {/* Inside Folder Search Bar */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    id="search-folder-offer-input"
                    value={offerSearchQuery}
                    onChange={(e) => setOfferSearchQuery(e.target.value)}
                    placeholder={`${activeOfferFolderObj?.name}-এ GB, মিনিট, মূল্য বা নাম দিয়ে খুঁজুন...`}
                    className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 outline-none focus:border-purple-600 focus:bg-white transition-all placeholder:text-slate-400"
                  />
                </div>

                {/* Offers List inside Folder */}
                <div className="space-y-2.5 max-h-[520px] overflow-y-auto pr-0.5">
                  {currentFolderOffers.length === 0 ? (
                    <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-slate-400 text-xs space-y-1">
                      <Folder className="w-8 h-8 mx-auto text-slate-300 mb-1" />
                      <p className="font-bold">এই ফোল্ডারে কোনো অফার পাওয়া যায়নি।</p>
                      <p className="text-[10px]">উপরে নতুন অফার তৈরি বা সার্চ ফিল্টার চেক করুন।</p>
                    </div>
                  ) : (
                    currentFolderOffers.map((off) => (
                      <div
                        key={off.id}
                        className="p-3 bg-slate-50/80 hover:bg-slate-50 rounded-2xl border border-slate-200/80 flex items-center justify-between gap-3 transition-all"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <OperatorLogo operator={off.operator} size="sm" />
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <h5 className="font-extrabold text-xs text-slate-900">
                                {off.internetGB > 0 ? `${off.internetGB}GB` : ''}{' '}
                                {off.minutes > 0 ? `+ ${off.minutes} Min` : ''}
                              </h5>
                              {off.packageName && (
                                <span className="text-[9px] font-extrabold px-1.5 py-0.5 rounded-md bg-purple-50 text-purple-700 border border-purple-200">
                                  {off.packageName}
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-500 block truncate mt-0.5">
                              {off.date ? `${off.date} • ` : ''}{off.validityDays} দিন • ৳{off.priceTK} (রেগুলার: ৳{off.regularPriceTK || off.priceTK}, ক্যাশব্যাক: ৳{off.cashbackTK})
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={async () => {
                              const text = formatSingleOfferShareText(off);
                              await shareContent(`${getOperatorBnName(off.operator)} ড্রাইভ অফার`, text, showToast);
                            }}
                            className="p-1.5 text-purple-700 bg-white hover:bg-purple-50 border border-slate-200 rounded-lg transition-colors cursor-pointer"
                            title="অফার শেয়ার / কপি করুন"
                          >
                            <Share2 className="w-3.5 h-3.5" />
                          </button>
                          {off.whatsappNumber && (
                            <a
                              href={`https://wa.me/${off.whatsappNumber.replace(/[^0-9]/g, '')}`}
                              target="_blank"
                              rel="noreferrer"
                              className="p-1.5 text-emerald-600 bg-white hover:bg-emerald-50 border border-slate-200 rounded-lg transition-colors"
                              title="WhatsApp টেস্ট করুন"
                            >
                              <MessageCircle className="w-3.5 h-3.5" />
                            </a>
                          )}
                          {deletingOfferId === off.id ? (
                            <div className="flex items-center gap-1 bg-rose-50 p-1 rounded-lg border border-rose-200 animate-fadeIn">
                              <span className="text-[9px] font-bold text-rose-700">মুছবেন?</span>
                              <button
                                type="button"
                                onClick={() => {
                                  onDeleteOffer(off.id);
                                  setDeletingOfferId(null);
                                  showToast('অফারটি সফলভাবে ডিলিট করা হয়েছে');
                                }}
                                className="px-1.5 py-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded text-[9px] font-extrabold cursor-pointer"
                              >
                                হ্যাঁ
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeletingOfferId(null)}
                                className="px-1.5 py-0.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded text-[9px] font-bold cursor-pointer"
                              >
                                না
                              </button>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setDeletingOfferId(off.id)}
                              className="p-1.5 text-rose-500 bg-white hover:bg-rose-50 border border-slate-200 rounded-lg transition-colors cursor-pointer"
                              title="অফার ডিলিট করুন"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </section>
            )}
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 3: CUSTOMER SUPPORT TICKETS                           */}
        {/* ========================================================= */}
        {activeAdminTab === 'tickets' && (
          <div className="space-y-4 animate-fadeIn">
            <section className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-3.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Headphones className="w-4 h-4 text-rose-600" />
                  <h3 className="text-sm font-extrabold text-slate-900">
                    গ্রাহক অভিযোগ ও সাপোর্ট রিকোয়েস্ট
                  </h3>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-bold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded-full">
                    পেন্ডিং: {pendingTicketsCount}
                  </span>
                </div>
              </div>

              {/* Status Filter Tabs */}
              <div className="grid grid-cols-4 gap-1 bg-slate-100 p-1 rounded-xl">
                {[
                  { id: 'all', label: `সকল (${supportTickets.length})` },
                  { id: 'pending', label: `পেন্ডিং (${pendingTicketsCount})` },
                  { id: 'replied', label: `জবাব দেওয়া (${repliedTicketsCount})` },
                  { id: 'resolved', label: `সমাধান (${resolvedTicketsCount})` },
                ].map((flt) => (
                  <button
                    key={flt.id}
                    type="button"
                    onClick={() => setTicketFilter(flt.id as any)}
                    className={`py-1.5 px-1 text-center text-[10px] font-black rounded-lg transition-all cursor-pointer truncate ${
                      ticketFilter === flt.id
                        ? 'bg-white text-slate-900 shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {flt.label}
                  </button>
                ))}
              </div>

              {/* Tickets List */}
              <div className="space-y-3 max-h-[560px] overflow-y-auto pr-0.5">
                {filteredTickets.length === 0 ? (
                  <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-slate-400 text-xs">
                    কোনো সাপোর্ট টিকেট নেই।
                  </div>
                ) : (
                  filteredTickets.map((tkt) => {
                    const cleanPhone = cleanBDPhoneForDial(tkt.phone);
                    const isReplying = activeReplyTicketId === tkt.id;
                    const currentDraft = replyDraftMap[tkt.id] || '';
                    const selectedStatus = replyStatusMap[tkt.id] || 'resolved';

                    return (
                      <div
                        key={tkt.id}
                        className={`p-4 rounded-2xl border transition-all space-y-3 ${
                          tkt.status === 'pending'
                            ? 'bg-rose-50/50 border-rose-200 shadow-xs'
                            : tkt.status === 'replied'
                            ? 'bg-teal-50/40 border-teal-200'
                            : tkt.status === 'in_progress'
                            ? 'bg-blue-50/40 border-blue-200'
                            : 'bg-slate-50/80 border-slate-200 opacity-95'
                        }`}
                      >
                        {/* Header */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs font-black text-slate-900 bg-white px-2 py-0.5 rounded-md border border-slate-200">
                              {tkt.id}
                            </span>
                            <span className="text-[10px] text-slate-500 font-bold">
                              {tkt.createdAt}
                            </span>
                          </div>

                          <div className="flex items-center gap-1.5">
                            <span
                              className={`text-[9px] font-black px-2.5 py-0.5 rounded-full ${
                                tkt.status === 'resolved'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : tkt.status === 'replied'
                                  ? 'bg-teal-100 text-teal-800'
                                  : tkt.status === 'in_progress'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-rose-100 text-rose-800 animate-pulse'
                              }`}
                            >
                              {tkt.status === 'resolved'
                                ? '✓ সমাধান সম্পন্ন'
                                : tkt.status === 'replied'
                                ? '💬 জবাব দেওয়া হয়েছে'
                                : tkt.status === 'in_progress'
                                ? '⏳ প্রক্রিয়াধীন'
                                : '⚠️ জরুরি পেন্ডিং'}
                            </span>

                            {onDeleteTicket && (
                              <button
                                type="button"
                                onClick={() => {
                                  if (window.confirm(`টিকেট ${tkt.id} মুছে ফেলতে চান?`)) {
                                    onDeleteTicket(tkt.id);
                                    showToast('✓ টিকেট মুছে ফেলা হয়েছে');
                                  }
                                }}
                                className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-100/60 rounded-md transition-colors cursor-pointer"
                                title="টিকেট মুছে ফেলুন"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Customer & Issue Content */}
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-black text-slate-900">
                              👤 {tkt.customerName}
                            </span>
                            <span className="font-mono font-bold text-slate-700 bg-white px-2 py-0.5 rounded-md border border-slate-200">
                              📞 {cleanPhone}
                            </span>
                          </div>

                          <p className="text-xs text-slate-900 bg-white p-3 rounded-xl border border-slate-200 font-semibold leading-relaxed">
                            {tkt.message}
                          </p>

                          {tkt.trxId && (
                            <div className="text-[11px] font-mono text-indigo-700 font-black bg-indigo-50 px-2 py-1 rounded-lg border border-indigo-200/70 inline-flex items-center gap-1">
                              <span>🆔 ট্রানজেকশন ID:</span>
                              <span className="select-all">{tkt.trxId}</span>
                            </div>
                          )}
                        </div>

                        {/* Existing Recorded Reply (if any) */}
                        {tkt.adminReply && !isReplying && (
                          <div className="p-3 bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200 rounded-xl space-y-1.5">
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-black text-emerald-900 flex items-center gap-1">
                                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                <span>রেকর্ডকৃত জবাব:</span>
                              </span>
                              {tkt.adminReplyAt && (
                                <span className="text-[9px] text-emerald-700 font-bold">
                                  {tkt.adminReplyAt}
                                </span>
                              )}
                            </div>
                            <p className="text-xs font-black text-emerald-950 bg-white/90 p-2.5 rounded-lg border border-emerald-100 leading-relaxed">
                              {tkt.adminReply}
                            </p>
                            <div className="flex items-center justify-between text-[9px] text-emerald-800 font-bold">
                              <span>প্রেরক: {tkt.adminName || 'অফিসিয়াল সাপোর্ট'}</span>
                              <button
                                type="button"
                                onClick={() => {
                                  setActiveReplyTicketId(tkt.id);
                                  setReplyDraftMap((prev) => ({
                                    ...prev,
                                    [tkt.id]: tkt.adminReply || '',
                                  }));
                                  setReplyStatusMap((prev) => ({
                                    ...prev,
                                    [tkt.id]: tkt.status === 'resolved' ? 'resolved' : 'replied',
                                  }));
                                }}
                                className="text-teal-700 hover:text-teal-900 underline cursor-pointer"
                              >
                                জবাব পরিবর্তন / পুনরায় পাঠান
                              </button>
                            </div>
                          </div>
                        )}

                        {/* Reply Form Box (Always visible if pending without reply, or when replying) */}
                        {(isReplying || (!tkt.adminReply && tkt.status === 'pending')) && (
                          <div className="p-3.5 bg-white rounded-2xl border-2 border-indigo-500/30 shadow-xs space-y-2.5">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-black text-indigo-950 flex items-center gap-1.5">
                                <MessageCircle className="w-4 h-4 text-indigo-600" />
                                <span>গ্রাহককে জবাব দিন ও রেকর্ড করুন</span>
                              </span>
                              {isReplying && tkt.adminReply && (
                                <button
                                  type="button"
                                  onClick={() => setActiveReplyTicketId(null)}
                                  className="text-[10px] text-slate-500 hover:text-slate-800 font-bold cursor-pointer"
                                >
                                  বাতিল
                                </button>
                              )}
                            </div>

                            {/* Quick Response Templates */}
                            <div className="space-y-1">
                              <span className="text-[10px] font-bold text-slate-500 block">
                                দ্রুত জবাব টেমপ্লেট:
                              </span>
                              <div className="flex flex-wrap gap-1">
                                {[
                                  {
                                    label: '✅ অফার চালু হয়েছে',
                                    text: 'আসসালামু আলাইকুম, আপনার ড্রাইভ অফারটি সফলভাবে চালু করে দেওয়া হয়েছে। ধন্যবাদ সাথে থাকার জন্য।',
                                  },
                                  {
                                    label: '💰 টাকা যোগ হয়েছে',
                                    text: 'আসসালামু আলাইকুম, আপনার পাঠানো ট্রানজেকশন যাচাই করে ব্যালেন্স যুক্ত করে দেওয়া হয়েছে। চেক করুন।',
                                  },
                                  {
                                    label: '⏳ প্রসেসিং চলছে',
                                    text: 'আপনার আবেদনটি পেয়েছি, বর্তমানে যাচাই প্রক্রিয়া চলমান আছে। অনুগ্রহ করে কিছুক্ষণ অপেক্ষা করুন।',
                                  },
                                  {
                                    label: '❌ ভুল TrxID',
                                    text: 'আপনার দেওয়া ট্রানজেকশন আইডি বা নম্বরটি সঠিক পাওয়া যায়নি। অনুগ্রহ করে সঠিক TrxID লিখে জানান।',
                                  },
                                ].map((tmpl, idx) => (
                                  <button
                                    key={idx}
                                    type="button"
                                    onClick={() =>
                                      setReplyDraftMap((prev) => ({
                                        ...prev,
                                        [tkt.id]: tmpl.text,
                                      }))
                                    }
                                    className="px-2 py-1 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 text-[10px] font-bold rounded-lg transition-colors cursor-pointer"
                                  >
                                    {tmpl.label}
                                  </button>
                                ))}
                              </div>
                            </div>

                            {/* Textarea */}
                            <div>
                              <textarea
                                rows={2}
                                value={currentDraft}
                                onChange={(e) =>
                                  setReplyDraftMap((prev) => ({
                                    ...prev,
                                    [tkt.id]: e.target.value,
                                  }))
                                }
                                placeholder="এখানে গ্রাহকের জন্য সমাধানের উত্তর লিখুন..."
                                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 outline-none focus:border-indigo-600 focus:bg-white resize-none"
                              />
                            </div>

                            {/* Status Selector & Save Button */}
                            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                                {[
                                  { key: 'resolved', label: '✓ সমাধান' },
                                  { key: 'replied', label: '💬 জবাব' },
                                  { key: 'in_progress', label: '⏳ প্রসেসিং' },
                                ].map((st) => (
                                  <button
                                    key={st.key}
                                    type="button"
                                    onClick={() =>
                                      setReplyStatusMap((prev) => ({
                                        ...prev,
                                        [tkt.id]: st.key as any,
                                      }))
                                    }
                                    className={`px-2 py-1 rounded-lg text-[10px] font-black transition-all cursor-pointer ${
                                      selectedStatus === st.key
                                        ? 'bg-indigo-600 text-white shadow-2xs'
                                        : 'text-slate-600 hover:text-slate-900'
                                    }`}
                                  >
                                    {st.label}
                                  </button>
                                ))}
                              </div>

                              <button
                                type="button"
                                onClick={() => handleSendTicketReply(tkt.id)}
                                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black flex items-center gap-1 shadow-xs transition-all active:scale-95 cursor-pointer ml-auto"
                              >
                                <Save className="w-3.5 h-3.5" />
                                <span>জবাব রেকর্ড ও সেভ করুন</span>
                              </button>
                            </div>
                          </div>
                        )}

                        {/* Action Bar */}
                        <div className="pt-2 border-t border-slate-200/70 flex items-center justify-between gap-2">
                          <div className="flex items-center gap-1.5">
                            <a
                              href={`tel:${cleanPhone}`}
                              className="px-2.5 py-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors"
                            >
                              <PhoneCall className="w-3.5 h-3.5" />
                              <span>কল দিন</span>
                            </a>
                            <a
                              href={`https://wa.me/88${cleanPhone.replace(/^0/, '')}?text=${encodeURIComponent(
                                currentDraft
                                  ? `আসসালামু আলাইকুম ${tkt.customerName},\n${currentDraft}`
                                  : `আসসালামু আলাইকুম ${tkt.customerName}, আপনার সাপোর্ট অভিযোগ (${tkt.id}) সংক্রান্ত ব্যাপারে যোগাযোগ করছি।`
                              )}`}
                              target="_blank"
                              rel="noreferrer"
                              className="px-2.5 py-1.5 bg-green-50 text-green-700 hover:bg-green-100 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors"
                            >
                              <MessageCircle className="w-3.5 h-3.5" />
                              <span>WhatsApp</span>
                            </a>
                          </div>

                          {!isReplying && tkt.adminReply && (
                            <button
                              type="button"
                              onClick={() => {
                                setActiveReplyTicketId(tkt.id);
                                setReplyDraftMap((prev) => ({
                                  ...prev,
                                  [tkt.id]: tkt.adminReply || '',
                                }));
                              }}
                              className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                            >
                              <Send className="w-3.5 h-3.5" />
                              <span>জবাব লিখুন</span>
                            </button>
                          )}

                          {tkt.status === 'pending' && !tkt.adminReply && (
                            <button
                              type="button"
                              onClick={() => onResolveTicket(tkt.id)}
                              className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-[11px] font-bold flex items-center gap-1 transition-all active:scale-95 cursor-pointer"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>সরাসরি সমাধান চিহ্নিত করুন</span>
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </section>
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 4: SOCIAL MEDIA & SUPPORT CHANNELS                   */}
        {/* ========================================================= */}
        {activeAdminTab === 'social_support' && (
          <div className="space-y-4 animate-fadeIn">
            <AdminSocialSupportSection
              socialLinks={socialLinks}
              onUpdateSocialLinks={onUpdateSocialLinks}
              currentNotice={currentNotice}
              onUpdateNotice={onUpdateNotice}
              onShowToast={showToast}
            />
          </div>
        )}

        {/* ========================================================= */}
        {/* TAB 5: ACCOUNT BALANCE CONTROL                           */}
        {/* ========================================================= */}
        {activeAdminTab === 'balance' && (
          <form onSubmit={handleSaveBalances} className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                  <Wallet className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="font-extrabold text-slate-900 text-sm leading-tight">
                    অ্যাকাউন্ট ব্যালেন্স নিয়ন্ত্রণ ও সমন্বয়
                  </h2>
                  <p className="text-[10px] text-slate-500 font-medium">
                    মেইন, ড্রাইভ ও ব্যাংক ব্যালেন্সের তাৎক্ষণিক মান আপডেট করুন
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-3.5">
              {/* 1. Main Balance */}
              <div className="p-4 rounded-2xl bg-emerald-50/60 border border-emerald-200 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-extrabold text-emerald-900 flex items-center gap-1.5">
                    <Wallet className="w-4 h-4 text-emerald-600" />
                    <span>মেইন ব্যালেন্স (Main Balance ৳)</span>
                  </label>
                  <span className="text-[10px] font-bold text-emerald-700 bg-white px-2 py-0.5 rounded-full border border-emerald-200">
                    রিচার্জ ব্যালেন্স
                  </span>
                </div>
                <input
                  type="number"
                  value={mainBal}
                  onChange={(e) => setMainBal(e.target.value)}
                  placeholder={`বর্তমান: ৳${user.mainBalance.toLocaleString('bn-BD')}`}
                  className="w-full p-3 bg-white border border-emerald-300 rounded-xl font-mono font-black text-lg text-emerald-950 outline-none focus:border-emerald-600 placeholder:text-slate-400"
                />
                <div className="flex items-center gap-1.5 pt-1">
                  {[500, 1000, 5000].map((inc) => (
                    <button
                      key={inc}
                      type="button"
                      onClick={() => setMainBal((prev) => ((parseFloat(prev) || 0) + inc).toString())}
                      className="px-2.5 py-1 bg-white hover:bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-lg border border-emerald-200 transition-colors cursor-pointer"
                    >
                      +{inc} ৳
                    </button>
                  ))}
                </div>
              </div>

              {/* 2. Drive Balance */}
              <div className="p-4 rounded-2xl bg-purple-50/60 border border-purple-200 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-extrabold text-purple-900 flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-purple-600" />
                    <span>ড্রাইভ ব্যালেন্স (Drive Balance ৳)</span>
                  </label>
                  <span className="text-[10px] font-bold text-purple-700 bg-white px-2 py-0.5 rounded-full border border-purple-200">
                    অফার ক্রয়ের ব্যালেন্স
                  </span>
                </div>
                <input
                  type="number"
                  value={driveBal}
                  onChange={(e) => setDriveBal(e.target.value)}
                  placeholder={`বর্তমান: ৳${user.driveBalance.toLocaleString('bn-BD')}`}
                  className="w-full p-3 bg-white border border-purple-300 rounded-xl font-mono font-black text-lg text-purple-950 outline-none focus:border-purple-600 placeholder:text-slate-400"
                />
                <div className="flex items-center gap-1.5 pt-1">
                  {[500, 1000, 5000].map((inc) => (
                    <button
                      key={inc}
                      type="button"
                      onClick={() => setDriveBal((prev) => ((parseFloat(prev) || 0) + inc).toString())}
                      className="px-2.5 py-1 bg-white hover:bg-purple-100 text-purple-800 text-[10px] font-bold rounded-lg border border-purple-200 transition-colors cursor-pointer"
                    >
                      +{inc} ৳
                    </button>
                  ))}
                </div>
              </div>

              {/* 3. Bank Balance */}
              <div className="p-4 rounded-2xl bg-sky-50/60 border border-sky-200 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-extrabold text-sky-900 flex items-center gap-1.5">
                    <Store className="w-4 h-4 text-sky-600" />
                    <span>ব্যাংক ব্যালেন্স (Bank Balance ৳)</span>
                  </label>
                  <span className="text-[10px] font-bold text-sky-700 bg-white px-2 py-0.5 rounded-full border border-sky-200">
                    ব্যাংকিং ফান্ড
                  </span>
                </div>
                <input
                  type="number"
                  value={bankBal}
                  onChange={(e) => setBankBal(e.target.value)}
                  placeholder={`বর্তমান: ৳${user.bankBalance.toLocaleString('bn-BD')}`}
                  className="w-full p-3 bg-white border border-sky-300 rounded-xl font-mono font-black text-lg text-sky-950 outline-none focus:border-sky-600 placeholder:text-slate-400"
                />
              </div>
            </div>

            <button
              type="submit"
              id="admin-save-balance-btn"
              className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold text-xs rounded-xl shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all active:scale-98 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>ব্যালেন্স পরিবর্তন সংরক্ষণ করুন</span>
            </button>

            {balSaved && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-emerald-800 text-xs font-bold animate-fadeIn">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>ব্যালেন্স সফলভাবে আপডেট করা হয়েছে!</span>
              </div>
            )}
          </form>
        )}

        {/* ========================================================= */}
        {/* TAB 6: HOMEPAGE NOTICE BOARD                             */}
        {/* ========================================================= */}
        {activeAdminTab === 'notice' && (
          <form onSubmit={handleSaveNotice} className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
                  <Bell className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="font-extrabold text-slate-900 text-sm leading-tight">
                    হোম স্ক্রীন স্ক্রোলিং নোটিশ বোর্ড
                  </h2>
                  <p className="text-[10px] text-slate-500 font-medium">
                    গ্রাহকদের হোম স্ক্রিনে চলমান জরুরি ঘোষণা বা অফার বার্তা
                  </p>
                </div>
              </div>
            </div>

            {/* Live Notice Preview */}
            <div className="p-3 bg-indigo-50/70 rounded-2xl border border-indigo-100 space-y-1.5">
              <span className="text-[10px] font-extrabold text-indigo-700 uppercase tracking-wider block">
                লাইভ প্রিভিউ (গ্রাহক স্ক্রিনে যেমন দেখাবে):
              </span>
              <div className="bg-white p-2.5 rounded-xl border border-indigo-200 flex items-center gap-2 text-xs font-medium text-indigo-900 overflow-hidden">
                <Bell className="w-3.5 h-3.5 text-indigo-600 shrink-0 animate-bounce" />
                <span className="truncate">{noticeInput || 'কোনো নোটিশ সেট করা নেই'}</span>
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-700 block mb-1">
                নোটিশ বার্তা লিখুন *
              </label>
              <textarea
                rows={4}
                required
                value={noticeInput}
                onChange={(e) => setNoticeInput(e.target.value)}
                placeholder="সম্মানিত গ্রাহক, ড্রাইভ অফার চালু আছে। যেকোনো প্রয়োজনে কাস্টমার কেয়ারে যোগাযোগ করুন..."
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 outline-none focus:border-indigo-600 focus:bg-white leading-relaxed"
              />
            </div>

            {/* Quick Templates */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-slate-400 block">কুইক টেমপ্লেট:</span>
              <div className="flex items-center gap-1.5 flex-wrap">
                {[
                  '🔥 সেরা ড্রাইভ অফার ও ক্যাশব্যাক লাইভ চালু রয়েছে!',
                  '⚡ অটো অ্যাড মানি ও সকল অপারেটরে মোবাইল রিচার্জ সচল।',
                  '📢 জরুরি নোটিশ: রাত ১২টা থেকে ১টা পর্যন্ত সিস্টেম মেইনটেনেন্স চলবে।',
                ].map((tmpl, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setNoticeInput(tmpl)}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-medium rounded-lg transition-colors cursor-pointer text-left truncate max-w-full"
                  >
                    {tmpl}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              id="admin-save-notice-btn"
              className="w-full py-3 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-extrabold text-xs rounded-xl shadow-md shadow-amber-500/20 flex items-center justify-center gap-2 transition-all active:scale-98 cursor-pointer"
            >
              <Bell className="w-4 h-4" />
              <span>নোটিশ প্রকাশ করুন</span>
            </button>

            {noticeSaved && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-emerald-800 text-xs font-bold animate-fadeIn">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>নোটিশ সফলভাবে আপডেট ও প্রকাশিত হয়েছে!</span>
              </div>
            )}
          </form>
        )}

        {/* ========================================================= */}
        {/* TAB 7: APP LOGO & BRANDING SETTINGS                      */}
        {/* ========================================================= */}
        {activeAdminTab === 'branding' && settings && onUpdateSettings && (
          <AppLogoSettingsSection
            settings={settings}
            onUpdateSettings={onUpdateSettings}
            onShowToast={showToast}
          />
        )}
      </main>

      {/* Admin Dedicated Telecom AI Offer Generator Modal */}
      <TelecomAiModal
        isOpen={isAdminAiModalOpen}
        onClose={() => setIsAdminAiModalOpen(false)}
        user={user}
        offers={offers}
        onAddOffer={(newOff) => {
          onAddOffer(newOff);
          showToast(`"${newOff.title}" অফারটি সফলভাবে যুক্ত হয়েছে`);
        }}
        isAdmin={true}
      />

      {/* Admin Social Messenger & USSD Tools Modal */}
      {messengerModalType && (
        <SocialMessengerModal
          isOpen={!!messengerModalType}
          onClose={() => setMessengerModalType(null)}
          type={messengerModalType}
          socialLinks={socialLinks}
          user={user}
          offers={offers}
        />
      )}

      {/* Admin Activity & Dealer Audit Logs Modal */}
      <AdminAuditLogsModal
        isOpen={showAuditLogsModal}
        onClose={() => setShowAuditLogsModal(false)}
      />
    </div>
  );
};
