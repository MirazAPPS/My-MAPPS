import React from 'react';
import { Home, ClipboardList, DollarSign, Headphones, ShieldAlert } from 'lucide-react';

export type TabType = 'home' | 'khata' | 'transactions' | 'support' | 'admin';

interface BottomNavProps {
  activeTab: TabType;
  onChangeTab: (tab: TabType) => void;
  userRole?: 'user' | 'admin';
  isDarkMode?: boolean;
  theme?: 'purple' | 'blue' | 'green' | 'orange' | 'red' | 'dark';
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  userRole = 'user',
  isDarkMode = false,
  theme = 'blue',
}) => {
  const isAdmin = userRole === 'admin';

  const getActiveThemeBg = () => {
    switch (theme) {
      case 'purple':
        return 'bg-gradient-to-r from-[#6366f1] to-[#7c3aed] text-white shadow-indigo-500/25 ring-indigo-300';
      case 'green':
        return 'bg-gradient-to-r from-[#047857] to-[#0d9488] text-white shadow-emerald-500/25 ring-emerald-300';
      case 'orange':
        return 'bg-gradient-to-r from-[#ea580c] to-[#f97316] text-white shadow-orange-500/25 ring-orange-300';
      case 'red':
        return 'bg-gradient-to-r from-[#dc2626] to-[#e11d48] text-white shadow-rose-500/25 ring-rose-300';
      case 'dark':
        return 'bg-slate-800 text-white shadow-slate-900/50 ring-slate-600';
      case 'blue':
      default:
        return 'bg-[#1d4ed8] text-white shadow-blue-600/25 ring-blue-300';
    }
  };

  const navItems = [
    {
      id: 'tab-home',
      key: 'home' as TabType,
      label: 'হোম',
      icon: Home,
    },
    {
      id: 'tab-khata',
      key: 'khata' as TabType,
      label: 'টালি খাতা',
      icon: ClipboardList,
    },
    {
      id: 'tab-transactions',
      key: 'transactions' as TabType,
      label: 'লেনদেন',
      icon: DollarSign,
    },
    {
      id: 'tab-support',
      key: 'support' as TabType,
      label: 'সাপোর্ট',
      icon: Headphones,
    },
    ...(isAdmin
      ? [
          {
            id: 'tab-admin',
            key: 'admin' as TabType,
            label: 'অ্যাডমিন',
            icon: ShieldAlert,
          },
        ]
      : []),
  ];

  return (
    <nav
      className={`w-full ${
        isDarkMode
          ? 'bg-slate-900 border-slate-800 text-slate-300'
          : 'bg-white border-slate-200 text-slate-800'
      } border-t px-1 sm:px-2 pt-1.5 transition-colors select-none shadow-[0_-2px_10px_rgba(0,0,0,0.05)]`}
      style={{
        paddingBottom: 'max(6px, calc(env(safe-area-inset-bottom, 0px) + 4px))',
      }}
    >
      <div className={`grid ${isAdmin ? 'grid-cols-5' : 'grid-cols-4'} items-center`}>
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.key;
          return (
            <button
              key={item.key}
              id={item.id}
              type="button"
              onClick={() => onChangeTab(item.key)}
              className="flex flex-col items-center justify-center py-1 relative group transition-transform active:scale-95 cursor-pointer"
            >
              {/* Active Indicator Icon */}
              <div
                className={`flex items-center justify-center transition-all duration-200 ${
                  isActive
                    ? item.key === 'admin'
                      ? 'bg-rose-600 text-white px-3.5 py-1 rounded-full shadow-sm shadow-rose-500/30'
                      : `${getActiveThemeBg()} px-3.5 py-1 rounded-full shadow-sm`
                    : item.key === 'admin'
                    ? isDarkMode
                      ? 'text-rose-400 p-1'
                      : 'text-rose-600 p-1'
                    : isDarkMode
                    ? 'text-slate-400 group-hover:text-slate-200 p-1'
                    : 'text-slate-600 group-hover:text-slate-900 p-1'
                }`}
              >
                <Icon className="w-5 h-5 stroke-[2.2]" />
              </div>

              {/* Label */}
              <span
                className={`text-[11px] font-bold mt-0.5 tracking-tight transition-colors ${
                  isActive
                    ? item.key === 'admin'
                      ? isDarkMode ? 'text-rose-400 font-black' : 'text-rose-700 font-black'
                      : isDarkMode ? 'text-sky-400 font-black' : 'text-blue-700 font-black'
                    : isDarkMode
                    ? 'text-slate-400 group-hover:text-slate-200'
                    : 'text-slate-600 group-hover:text-slate-900'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
