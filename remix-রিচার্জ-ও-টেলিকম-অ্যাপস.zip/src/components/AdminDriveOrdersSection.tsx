import React, { useState } from 'react';
import {
  ShoppingBag,
  CheckCircle2,
  XCircle,
  Clock,
  Phone,
  MessageCircle,
  Copy,
  Check,
  Search,
  Filter,
  ArrowRight,
  ShieldCheck,
  ExternalLink,
  Trash2,
  User,
  Sparkles,
  BookOpen,
} from 'lucide-react';
import { DriveOrder, OperatorType, SocialCommunityLinks } from '../types';
import { OperatorLogo } from './OperatorLogos';
import {
  getWhatsAppDriveOrderUrl,
  openWhatsAppChat,
  getOperatorBnName,
  getFormattedTodayDate,
} from '../utils';

interface AdminDriveOrdersSectionProps {
  orders: DriveOrder[];
  onApproveOrder: (order: DriveOrder) => void;
  onCancelOrder: (orderId: string, requesterPhone?: string) => void;
  socialLinks?: SocialCommunityLinks;
  onShowToast: (msg: string) => void;
}

export const AdminDriveOrdersSection: React.FC<AdminDriveOrdersSectionProps> = ({
  orders = [],
  onApproveOrder,
  onCancelOrder,
  socialLinks,
  onShowToast,
}) => {
  const [filterStatus, setFilterStatus] = useState<'pending' | 'success' | 'all'>('pending');
  const [selectedOperator, setSelectedOperator] = useState<OperatorType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [cancellingOrderId, setCancellingOrderId] = useState<string | null>(null);
  const [approvingOrderId, setApprovingOrderId] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    onShowToast(`নম্বর কপি হয়েছে: ${text}`);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const pendingOrders = orders.filter((o) => o.status === 'pending');
  const successOrders = orders.filter((o) => o.status === 'success');

  const filteredOrders = orders.filter((order) => {
    // Status filter
    if (filterStatus !== 'all' && order.status !== filterStatus) return false;

    // Operator filter
    if (selectedOperator !== 'all' && order.operator !== selectedOperator) return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchPhone = order.customerPhone?.toLowerCase().includes(q);
      const matchRequester = order.requesterPhone?.toLowerCase().includes(q) || order.requesterName?.toLowerCase().includes(q);
      const matchId = order.id?.toLowerCase().includes(q);
      const matchTitle = order.title?.toLowerCase().includes(q) || order.details?.toLowerCase().includes(q);
      const matchOp = order.operatorName?.toLowerCase().includes(q);
      if (!matchPhone && !matchRequester && !matchId && !matchTitle && !matchOp) return false;
    }

    return true;
  });

  const handleApprove = (order: DriveOrder) => {
    setApprovingOrderId(order.id);
    onApproveOrder(order);
    onShowToast(`অর্ডার #${order.id} সাকসেস করা হয়েছে এবং লেজারে যুক্ত হয়েছে!`);
    setTimeout(() => setApprovingOrderId(null), 800);
  };

  const handleCancel = (orderId: string, requesterPhone?: string) => {
    onCancelOrder(orderId, requesterPhone);
    setCancellingOrderId(null);
    onShowToast(`অর্ডারটি ক্যানসেল ও মুছে ফেলা হয়েছে`);
  };

  const handleOpenCustomerWhatsApp = (order: DriveOrder) => {
    const waPhone = order.customerPhone.startsWith('880')
      ? order.customerPhone
      : order.customerPhone.startsWith('0')
      ? `88${order.customerPhone}`
      : `880${order.customerPhone}`;
    const text = `আসসালামু আলাইকুম, আপনার ড্রাইভ অর্ডার #${order.id} (${order.details || order.title}) সংক্রান্ত তথ্য:`;
    const url = `https://wa.me/${waPhone}?text=${encodeURIComponent(text)}`;
    openWhatsAppChat(url);
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      {/* 1. Header & Live Counter Banner */}
      <div className="bg-gradient-to-r from-[#004b99] via-[#005ed9] to-[#0072CE] rounded-3xl p-5 text-white shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/15 backdrop-blur-xs flex items-center justify-center text-amber-300 shadow-inner">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black leading-tight">পেন্ডিং ড্রাইভ অর্ডার</h2>
                {pendingOrders.length > 0 && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-500 text-white animate-pulse">
                    {pendingOrders.length} টি নতুন
                  </span>
                )}
              </div>
              <p className="text-[11px] text-sky-100 mt-0.5">
                গ্রাহকের ড্রাইভ রিকোয়েস্ট অনুমোদন (সাকসেস) বা বাতিল (ক্যানসেল) করুন
              </p>
            </div>
          </div>
        </div>

        {/* Quick KPI Summary Grid */}
        <div className="grid grid-cols-3 gap-2 pt-1 border-t border-white/15">
          <div
            onClick={() => setFilterStatus('pending')}
            className={`p-2.5 rounded-2xl text-center cursor-pointer transition-all ${
              filterStatus === 'pending'
                ? 'bg-white text-slate-900 shadow-md font-black'
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <div className="text-base font-black text-amber-500">{pendingOrders.length}</div>
            <span className="text-[10px] opacity-90 block">পেন্ডিং অর্ডার</span>
          </div>

          <div
            onClick={() => setFilterStatus('success')}
            className={`p-2.5 rounded-2xl text-center cursor-pointer transition-all ${
              filterStatus === 'success'
                ? 'bg-white text-slate-900 shadow-md font-black'
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <div className="text-base font-black text-emerald-500">{successOrders.length}</div>
            <span className="text-[10px] opacity-90 block">সফল অর্ডার</span>
          </div>

          <div
            onClick={() => setFilterStatus('all')}
            className={`p-2.5 rounded-2xl text-center cursor-pointer transition-all ${
              filterStatus === 'all'
                ? 'bg-white text-slate-900 shadow-md font-black'
                : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            <div className="text-base font-black text-indigo-400">{orders.length}</div>
            <span className="text-[10px] opacity-90 block">মোট অর্ডার</span>
          </div>
        </div>
      </div>

      {/* 2. Filter & Search Controls */}
      <div className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs space-y-3">
        {/* Status Filter Tabs */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-2xl">
          {[
            { key: 'pending', label: 'পেন্ডিং অর্ডার', count: pendingOrders.length, alert: pendingOrders.length > 0 },
            { key: 'success', label: 'সাকসেস / সম্পন্ন', count: successOrders.length },
            { key: 'all', label: 'সকল অর্ডার', count: orders.length },
          ].map((tab) => (
            <button
              key={tab.key}
              type="button"
              onClick={() => setFilterStatus(tab.key as any)}
              className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                filterStatus === tab.key
                  ? 'bg-white text-purple-900 shadow-xs font-extrabold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>{tab.label}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                  filterStatus === tab.key
                    ? 'bg-purple-100 text-purple-800'
                    : 'bg-slate-200 text-slate-700'
                }`}
              >
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        {/* Operator Pill Selector */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 no-scrollbar">
          {[
            { id: 'all', label: 'সব অপারেটর' },
            { id: 'gp', label: 'GP' },
            { id: 'robi', label: 'Robi' },
            { id: 'banglalink', label: 'Banglalink' },
            { id: 'airtel', label: 'Airtel' },
            { id: 'teletalk', label: 'Teletalk' },
            { id: 'skitto', label: 'Skitto' },
          ].map((op) => (
            <button
              key={op.id}
              type="button"
              onClick={() => setSelectedOperator(op.id as any)}
              className={`px-3 py-1.5 rounded-xl text-[11px] font-bold shrink-0 transition-all cursor-pointer ${
                selectedOperator === op.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {op.label}
            </button>
          ))}
        </div>

        {/* Search input */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="গ্রাহকের নম্বর, প্যাকেজের নাম বা অর্ডার আইডি দিয়ে খুঁজুন..."
            className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 outline-none focus:border-purple-600 focus:bg-white transition-all"
          />
        </div>
      </div>

      {/* 3. Order List */}
      <div className="space-y-3">
        {filteredOrders.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-slate-200 space-y-2">
            <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
              <ShoppingBag className="w-6 h-6" />
            </div>
            <h3 className="font-bold text-sm text-slate-800">কোনো অর্ডার পাওয়া যায়নি</h3>
            <p className="text-xs text-slate-500 max-w-xs mx-auto">
              {filterStatus === 'pending'
                ? 'বর্তমানে কোনো পেন্ডিং অর্ডার নেই। গ্রাহক অফার কনফার্ম করলে এখানে দেখা যাবে।'
                : 'খোঁজার ফিল্টারে কোনো অর্ডার মিলছে না।'}
            </p>
          </div>
        ) : (
          filteredOrders.map((order) => {
            const isPending = order.status === 'pending';
            const isSuccess = order.status === 'success';

            return (
              <div
                key={order.id}
                id={`drive-order-card-${order.id}`}
                className={`bg-white rounded-3xl p-4 border transition-all shadow-xs space-y-3.5 ${
                  isPending
                    ? 'border-amber-300 ring-1 ring-amber-100'
                    : 'border-slate-200 opacity-90'
                }`}
              >
                  {/* Top Header of Card: [লোগো] > জিপি > 1/9/2026 */}
                  <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-slate-100">
                    <div className="flex items-center gap-2">
                      <OperatorLogo operator={order.operator} className="w-7 h-7 shrink-0 shadow-2xs" />
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-black text-xs text-slate-900">
                            {getOperatorBnName(order.operator)} &gt; {order.date || order.timestamp || getFormattedTodayDate()}
                          </span>
                          {order.packageName && (
                            <span className="text-[9px] font-black px-1.5 py-0.2 bg-purple-50 text-purple-700 rounded-md border border-purple-200">
                              {order.packageName}
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono block">
                          #{order.id} • {order.timestamp}
                        </span>
                      </div>
                    </div>

                    {/* Status Badge */}
                    <div>
                      {isPending && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-amber-50 text-amber-800 border border-amber-200 animate-pulse">
                          <Clock className="w-3 h-3 text-amber-600" />
                          <span>পেন্ডিং রিকোয়েস্ট</span>
                        </span>
                      )}
                      {isSuccess && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>কনফার্মড / সফল</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Main Order Details Box matching Requested Structure */}
                  <div className="bg-slate-50/90 rounded-2xl p-3.5 space-y-2.5 border border-slate-200/70 text-xs">
                    {/* Line 1: 50 জিবি 1500 মিনিট | 500 এসএমএস | মেয়াদ 30 দিন */}
                    <div className="text-xs font-black text-slate-900 leading-snug">
                      {[
                        order.internetGB && order.internetGB > 0 ? `${order.internetGB} জিবি` : null,
                        order.minutes && order.minutes > 0 ? `${order.minutes} মিনিট` : null,
                      ]
                        .filter(Boolean)
                        .join(' ') || order.title || order.details}
                      {order.sms && order.sms > 0 ? ` | ${order.sms} এসএমএস` : ''}
                      {order.validityDays ? ` | মেয়াদ: ${order.validityDays} দিন` : ''}
                    </div>

                    {/* Line 2: রেগুলার দাম: 999৳❌ | বর্তমান দাম: 899৳✅ | ক্যাশব্যাক: 100৳ */}
                    <div className="text-[11px] font-bold text-slate-700 flex flex-wrap items-center gap-x-2 gap-y-1 bg-white p-2 rounded-xl border border-slate-200">
                      {order.regularPriceTK && order.regularPriceTK > 0 ? (
                        <>
                          <span className="text-slate-500">
                            রেগুলার দাম: {order.regularPriceTK}৳ ❌
                          </span>
                          <span className="text-slate-300">|</span>
                        </>
                      ) : null}
                      <span className="text-slate-900 font-extrabold">
                        বর্তমান দাম: {order.amount}৳ ✅
                      </span>
                      {order.cashback > 0 && (
                        <>
                          <span className="text-slate-300">|</span>
                          <span className="text-emerald-700 font-extrabold bg-emerald-50 px-1.5 py-0.5 rounded-md border border-emerald-200">
                            ক্যাশব্যাক: {order.cashback}৳
                          </span>
                        </>
                      )}
                    </div>

                    {/* Line 3: নম্বর: 01301035400 with Copy and WhatsApp triggers */}
                    <div className="flex items-center justify-between bg-white p-2.5 rounded-xl border border-slate-200">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center">
                          <Phone className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <span className="text-[10px] font-bold text-slate-500 block">নম্বর:</span>
                          <span className="font-black text-slate-900 text-sm font-mono tracking-wide">
                            {order.customerPhone}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => copyToClipboard(order.customerPhone, `phone-${order.id}`)}
                          className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                          title="নম্বর কপি করুন"
                        >
                          {copiedId === `phone-${order.id}` ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                          <span className="hidden sm:inline">কপি</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleOpenCustomerWhatsApp(order)}
                          className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                          title="গ্রাহকের সাথে WhatsApp এ চ্যাট করুন"
                        >
                          <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                          <span>WhatsApp</span>
                        </button>
                      </div>
                    </div>

                    {order.requesterName && (
                      <div className="flex justify-between items-center pt-0.5 text-[10px] text-slate-500">
                        <span>রিকোয়েস্টার: {order.requesterName}</span>
                        <span>খরচ: ৳{order.netCost}</span>
                      </div>
                    )}
                  </div>

                {/* Action Buttons */}
                {isPending ? (
                  <div className="flex items-center gap-2 pt-1">
                    {/* 1. Success Button */}
                    <button
                      type="button"
                      id={`order-approve-btn-${order.id}`}
                      onClick={() => handleApprove(order)}
                      disabled={approvingOrderId === order.id}
                      className="flex-1 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 active:scale-[0.98] text-white font-extrabold text-xs rounded-2xl shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>সাকসেস (Success)</span>
                    </button>

                    {/* 2. Cancel Button */}
                    {cancellingOrderId === order.id ? (
                      <div className="flex-1 flex gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleCancel(order.id, order.requesterPhone || order.customerPhone)}
                          className="flex-1 py-3 bg-rose-600 hover:bg-rose-700 text-white font-black text-xs rounded-2xl transition-all cursor-pointer"
                        >
                          নিশ্চিত মুছে ফেলুন
                        </button>
                        <button
                          type="button"
                          onClick={() => setCancellingOrderId(null)}
                          className="px-3 py-3 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-2xl transition-all cursor-pointer"
                        >
                          না
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        id={`order-cancel-btn-${order.id}`}
                        onClick={() => setCancellingOrderId(order.id)}
                        className="py-3 px-4 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 font-extrabold text-xs rounded-2xl flex items-center justify-center gap-1.5 transition-all active:scale-[0.98] cursor-pointer"
                        title="অর্ডারটি ক্যানসেল ও মুছে ফেলুন"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>ক্যানসেল (Cancel)</span>
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="flex items-center justify-between pt-1 text-xs">
                    <div className="flex items-center gap-1 text-emerald-700 font-bold">
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>কাস্টমার লেজার ও হিসাবের খাতায় স্বয়ংক্রিয়ভাবে যুক্ত হয়েছে</span>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleCancel(order.id)}
                      className="text-slate-400 hover:text-rose-600 text-[11px] font-medium transition-colors p-1"
                      title="অর্ডার রেকর্ডটি মুছুন"
                    >
                      রেকর্ড মুছুন
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
