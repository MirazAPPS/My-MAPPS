import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  type Unsubscribe,
} from 'firebase/firestore';
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInAnonymously,
  onAuthStateChanged,
  signOut,
  type User as FirebaseUser,
} from 'firebase/auth';
import {
  SUPER_ADMIN_EMAIL,
  SUPER_ADMIN_EMAILS,
  type AppUserRole,
  type DealerPermissions,
  type ActivityAuditLog,
  type DriveOffer,
  type DriveOrder,
  type Transaction,
  type ShopTransaction,
  type CustomerAccount,
  type CustomerTransaction,
  type UserProfile,
  type AppSettings,
  type SocialCommunityLinks,
  type SupportTicket,
  type AddMoneyRequest,
  type RechargeRequest,
  type PaymentNumbersConfig,
} from '../types';

// Provided Firebase Configuration
const metaEnv = (typeof import.meta !== 'undefined' && (import.meta as any).env) || {};

export const firebaseConfig = {
  apiKey: metaEnv.VITE_FIREBASE_API_KEY || 'AIzaSyAD084ptpo4FxCF7dL3a1nd_',
  authDomain: metaEnv.VITE_FIREBASE_AUTH_DOMAIN || 'm-apps-ef8a8.firebaseapp.com',
  projectId: metaEnv.VITE_FIREBASE_PROJECT_ID || 'm-apps-ef8a8',
  storageBucket: metaEnv.VITE_FIREBASE_STORAGE_BUCKET || 'm-apps-ef8a8.firebasestorage.app',
  messagingSenderId: metaEnv.VITE_FIREBASE_MESSAGING_SENDER_ID || '175940391835',
  appId: metaEnv.VITE_FIREBASE_APP_ID || '1:175940391835:web:b18d77c32c102ab189c1d3',
  measurementId: metaEnv.VITE_FIREBASE_MEASUREMENT_ID || 'G-16F1MNY14S',
};

// Initialize Firebase App
export const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Firestore with robust connection and offline cache fallback
export const db = (() => {
  try {
    return initializeFirestore(app, {
      experimentalForceLongPolling: true,
      localCache: persistentLocalCache({
        tabManager: persistentMultipleTabManager(),
      }),
    });
  } catch {
    try {
      return initializeFirestore(app, {
        experimentalForceLongPolling: true,
      });
    } catch {
      return getFirestore(app);
    }
  }
})();

// Initialize Firebase Auth
export const auth = getAuth(app);

// User profile sanitizer preserving custom PIN and metadata
export const sanitizeUserProfile = (user: Partial<UserProfile>): Record<string, any> => {
  const isSuper =
    (user.email && user.email.toLowerCase().trim() === SUPER_ADMIN_EMAIL.toLowerCase()) ||
    user.isSuperAdmin === true ||
    user.appRole === 'super_admin';

  const appRole: AppUserRole = isSuper
    ? 'super_admin'
    : user.appRole === 'dealer' || user.accountType === 'Dealer'
    ? 'dealer'
    : 'user';

  return {
    ...user,
    email: user.email ? user.email.toLowerCase().trim() : '',
    pin: user.pin ? String(user.pin).trim() : '',
    appRole: appRole,
    isSuperAdmin: isSuper,
    role: isSuper ? 'admin' : (user.role || 'user'),
    status: user.status || (isSuper ? 'approved' : 'pending'),
    updatedAt: serverTimestamp(),
  };
};

/* =========================================================================
   1. USERS COLLECTION (/users)
   ========================================================================= */
export const syncUserProfileToFirestore = async (
  userId: string,
  profile: Partial<UserProfile>
) => {
  try {
    const userRef = doc(db, 'users', userId);
    const safeData = sanitizeUserProfile(profile);
    await setDoc(userRef, safeData, { merge: true });
  } catch (err) {
    console.warn('[Firestore] syncUserProfileToFirestore non-fatal:', err);
  }
};

export const subscribeUserProfile = (
  userId: string,
  callback: (profile: Partial<UserProfile> | null) => void
): Unsubscribe => {
  const userRef = doc(db, 'users', userId);
  return onSnapshot(
    userRef,
    (snap) => {
      if (snap.exists()) {
        callback(snap.data() as Partial<UserProfile>);
      } else {
        callback(null);
      }
    },
    (error) => {
      console.warn('[Firestore] subscribeUserProfile listener error:', error);
    }
  );
};

export const subscribeUsersList = (
  callback: (users: UserProfile[]) => void
): Unsubscribe => {
  const usersColl = collection(db, 'users');
  return onSnapshot(
    usersColl,
    (snapshot) => {
      const users: UserProfile[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        const isSuper =
          (data.email && SUPER_ADMIN_EMAILS.some((em) => em.toLowerCase() === String(data.email).toLowerCase().trim())) ||
          (data.email && String(data.email).toLowerCase().trim() === SUPER_ADMIN_EMAIL.toLowerCase()) ||
          data.isSuperAdmin === true ||
          data.appRole === 'super_admin';

        const computedAppRole: AppUserRole = isSuper
          ? 'super_admin'
          : data.appRole === 'dealer' || data.accountType === 'Dealer'
          ? 'dealer'
          : 'user';

        users.push({
          name: data.name || 'User',
          phone: data.phone || docSnap.id,
          email: data.email || '',
          pin: data.pin ? String(data.pin).trim() : '',
          shopName: data.shopName || '',
          mainBalance: Number(data.mainBalance) || 0,
          driveBalance: Number(data.driveBalance) || 0,
          bankBalance: Number(data.bankBalance) || 0,
          accountType: data.accountType || data.userRole || 'User',
          userRole: data.userRole || data.accountType || 'User',
          appRole: computedAppRole,
          isSuperAdmin: isSuper,
          dealerPermissions: data.dealerPermissions || undefined,
          dealerStatus: data.dealerStatus || (computedAppRole === 'dealer' ? 'active' : undefined),
          dealerSuspendedReason: data.dealerSuspendedReason || '',
          dealerSuspendedAt: data.dealerSuspendedAt || '',
          role: isSuper ? 'admin' : (data.role || (computedAppRole === 'dealer' ? 'admin' : 'user')),
          profileImage: data.profileImage || data.avatarUrl || '',
          avatarUrl: data.avatarUrl || data.profileImage || '',
          division: data.division || '',
          currentAddress: data.currentAddress || '',
          isBlocked: Boolean(data.isBlocked),
          blockReason: data.blockReason || '',
          status: data.status || (isSuper ? 'approved' : 'pending'),
          registeredAt: data.registeredAt || '',
          serialNumber: Number(data.serialNumber) || undefined,
          requestMessage: data.requestMessage || '',
        });
      });
      callback(users);
    },
    (error) => {
      console.warn('[Firestore] subscribeUsersList error:', error);
    }
  );
};

export const updateUserProfileInFirestore = async (
  phoneOrId: string,
  updates: Partial<UserProfile>
) => {
  try {
    const userRef = doc(db, 'users', phoneOrId);
    await setDoc(
      userRef,
      {
        ...updates,
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
  } catch (err) {
    console.warn('[Firestore] updateUserProfileInFirestore error:', err);
  }
};

export const toggleUserBlockInFirestore = async (
  phoneOrId: string,
  isBlocked: boolean,
  blockReason?: string
) => {
  try {
    const userRef = doc(db, 'users', phoneOrId);
    await setDoc(
      userRef,
      {
        isBlocked,
        blockReason: blockReason || (isBlocked ? 'এডমিন কর্তৃক ব্লক করা হয়েছে' : ''),
        blockedAt: isBlocked ? serverTimestamp() : null,
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
  } catch (err) {
    console.warn('[Firestore] toggleUserBlockInFirestore error:', err);
  }
};

export const addBalanceToUserInFirestore = async (
  phoneOrId: string,
  balanceType: 'main' | 'drive' | 'bank',
  amount: number,
  note?: string
): Promise<{ success: boolean; message: string; newBalance?: number }> => {
  try {
    const userRef = doc(db, 'users', phoneOrId);
    const userSnap = await getDoc(userRef);
    if (!userSnap.exists()) {
      return { success: false, message: 'ইউজার খুঁজে পাওয়া যায়নি' };
    }
    const uData = userSnap.data();
    const balanceKey = balanceType === 'drive' ? 'driveBalance' : balanceType === 'bank' ? 'bankBalance' : 'mainBalance';
    const current = Number(uData[balanceKey]) || 0;
    const newBal = current + amount;

    await updateDoc(userRef, {
      [balanceKey]: newBal,
      updatedAt: serverTimestamp(),
    });

    // Log transaction in user's transactions subcollection
    const txId = `ADMBAL-${Date.now()}`;
    const txRef = doc(db, 'users', phoneOrId, 'transactions', txId);
    await setDoc(txRef, {
      id: txId,
      type: 'add_money',
      amount: amount,
      phoneNumber: phoneOrId,
      status: 'success',
      date: new Date().toLocaleDateString('bn-BD'),
      time: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', hour12: true }),
      createdAtMs: Date.now(),
      timestamp: 'আজ, এইমাত্র',
      details: note || `এডমিন কর্তৃক ${balanceType === 'drive' ? 'ড্রাইভ' : balanceType === 'bank' ? 'ব্যাংক' : 'মেইন'} ব্যালেন্স যোগ (৳${amount})`,
      createdAt: serverTimestamp(),
    });

    return { success: true, message: `৳${amount} সফলভাবে যোগ করা হয়েছে! নতুন ব্যালেন্স: ৳${newBal}`, newBalance: newBal };
  } catch (err: any) {
    console.error('addBalanceToUserInFirestore error:', err);
    return { success: false, message: err?.message || 'ব্যালেন্স যোগে সমস্যা হয়েছে' };
  }
};

export const approveUserInFirestore = async (
  phoneOrId: string,
  role?: 'user' | 'admin',
  accountType?: string,
  actor?: { email: string; name: string; phone?: string }
) => {
  try {
    const userRef = doc(db, 'users', phoneOrId);
    const updatePayload: Record<string, any> = {
      status: 'approved',
      approvedAt: serverTimestamp(),
    };
    if (role) updatePayload.role = role;
    if (accountType) updatePayload.accountType = accountType;
    if (role === 'admin' || accountType === 'Dealer') {
      updatePayload.appRole = 'dealer';
      updatePayload.dealerStatus = 'active';
      updatePayload.dealerPermissions = {
        manageOffers: true,
        manageOrders: true,
        manageAddMoney: true,
        manageRecharge: true,
        manageTickets: true,
        viewUsers: false,
      };
    }
    await setDoc(
      userRef,
      updatePayload,
      { merge: true }
    );

    if (actor) {
      await logActivityAuditToFirestore({
        actorEmail: actor.email,
        actorPhone: actor.phone,
        actorName: actor.name,
        actorRole: 'super_admin',
        actionType: role === 'admin' ? 'dealer_permissions_updated' : 'user_approved',
        description: `গ্রাহক ${phoneOrId} অনুমোদন করা হয়েছে (${role === 'admin' ? 'ডিলার' : 'সাধারণ ইউজার'})`,
        targetId: phoneOrId,
        targetType: 'user',
        metadata: { role, accountType },
      });
    }
  } catch (err) {
    console.warn('[Firestore] approveUserInFirestore error:', err);
  }
};

export const rejectUserInFirestore = async (
  phoneOrId: string,
  actor?: { email: string; name: string; phone?: string }
) => {
  try {
    const userRef = doc(db, 'users', phoneOrId);
    await setDoc(
      userRef,
      {
        status: 'rejected',
        rejectedAt: serverTimestamp(),
      },
      { merge: true }
    );

    if (actor) {
      await logActivityAuditToFirestore({
        actorEmail: actor.email,
        actorPhone: actor.phone,
        actorName: actor.name,
        actorRole: 'super_admin',
        actionType: 'user_rejected',
        description: `গ্রাহক নিবন্ধন প্রত্যাখ্যান করা হয়েছে (${phoneOrId})`,
        targetId: phoneOrId,
        targetType: 'user',
      });
    }
  } catch (err) {
    console.warn('[Firestore] rejectUserInFirestore error:', err);
  }
};

export const deleteUserFromFirestore = async (phoneOrId: string) => {
  try {
    const userRef = doc(db, 'users', phoneOrId);
    await deleteDoc(userRef);
  } catch (err) {
    console.warn('[Firestore] deleteUserFromFirestore error:', err);
  }
};

/**
 * Clear/Delete all registered users from Firestore except preserving clean slate
 */
export const clearAllRegisteredUsersFromFirestore = async (): Promise<number> => {
  try {
    const usersColl = collection(db, 'users');
    const snap = await getDocs(usersColl);
    let count = 0;
    for (const docSnap of snap.docs) {
      await deleteDoc(doc(db, 'users', docSnap.id));
      count++;
    }
    return count;
  } catch (err) {
    console.warn('[Firestore] clearAllRegisteredUsersFromFirestore error:', err);
    return 0;
  }
};

/* =========================================================================
   1.1 DEALER & ROLE MANAGEMENT (Super Admin authority only)
   ========================================================================= */

// Helper to check if Dealer permissions are still active (not expired)
export const isDealerPermissionActive = (permissions?: DealerPermissions): boolean => {
  if (!permissions) return false;
  if (!permissions.expiresAt) return true; // permanent until revoked
  const expiryTime = new Date(permissions.expiresAt).getTime();
  if (isNaN(expiryTime)) return true;
  return Date.now() < expiryTime;
};

// Check if actor has specific permission
export const hasActorPermission = (
  user: UserProfile,
  permission: keyof Omit<DealerPermissions, 'expiresAt' | 'grantedAt' | 'grantedBy'>
): boolean => {
  if (
    user.appRole === 'super_admin' ||
    user.isSuperAdmin ||
    (user.email && SUPER_ADMIN_EMAILS.some((em) => em.toLowerCase() === user.email?.toLowerCase().trim())) ||
    user.email?.toLowerCase().trim() === SUPER_ADMIN_EMAIL.toLowerCase()
  ) {
    return true;
  }
  if (user.appRole === 'dealer') {
    if (user.dealerStatus === 'suspended' || user.isBlocked) {
      return false;
    }
    if (!isDealerPermissionActive(user.dealerPermissions)) {
      return false;
    }
    return Boolean(user.dealerPermissions?.[permission]);
  }
  return false;
};

// Log audit activity to Firestore
export const logActivityAuditToFirestore = async (
  log: Omit<ActivityAuditLog, 'id' | 'timestamp'>
) => {
  try {
    const logId = `LOG-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const logRef = doc(db, 'audit_logs', logId);
    await setDoc(logRef, {
      ...log,
      id: logId,
      timestamp: new Date().toISOString(),
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    console.warn('[Firestore] logActivityAuditToFirestore error:', err);
  }
};

// Subscribe to audit logs (Super Admin only)
export const subscribeAuditLogs = (
  callback: (logs: ActivityAuditLog[]) => void
): Unsubscribe => {
  const auditColl = collection(db, 'audit_logs');
  const q = query(auditColl, orderBy('createdAt', 'desc'), limit(100));
  return onSnapshot(
    q,
    (snapshot) => {
      const logs: ActivityAuditLog[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        logs.push({
          id: docSnap.id,
          actorEmail: data.actorEmail || '',
          actorPhone: data.actorPhone || '',
          actorName: data.actorName || '',
          actorRole: data.actorRole || 'user',
          actionType: data.actionType || 'user_created',
          description: data.description || '',
          targetId: data.targetId || '',
          targetType: data.targetType || 'user',
          timestamp: data.timestamp || '',
          metadata: data.metadata || {},
        });
      });
      callback(logs);
    },
    (error) => {
      console.warn('[Firestore] subscribeAuditLogs error:', error);
    }
  );
};

// Approve user as Dealer (Super Admin only)
export const approveUserAsDealerInFirestore = async (
  targetPhoneOrId: string,
  permissions: DealerPermissions,
  actor: { email: string; name: string; phone?: string }
) => {
  try {
    const userRef = doc(db, 'users', targetPhoneOrId);
    const safePermissions: DealerPermissions = {
      ...permissions,
      grantedAt: new Date().toISOString(),
      grantedBy: actor.email || SUPER_ADMIN_EMAIL,
    };

    await setDoc(
      userRef,
      {
        appRole: 'dealer',
        accountType: 'Dealer',
        userRole: 'Dealer',
        role: 'admin', // allows accessing privileged views
        dealerStatus: 'active',
        dealerPermissions: safePermissions,
        status: 'approved',
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );

    await logActivityAuditToFirestore({
      actorEmail: actor.email,
      actorPhone: actor.phone,
      actorName: actor.name,
      actorRole: 'super_admin',
      actionType: 'dealer_approved',
      description: `ব্যবহারকারী ${targetPhoneOrId}-কে ডিলার হিসেবে অনুমোদন ও পারমিশন সেট করা হয়েছে`,
      targetId: targetPhoneOrId,
      targetType: 'dealer',
      metadata: { permissions: safePermissions },
    });
  } catch (err) {
    console.error('[Firestore] approveUserAsDealerInFirestore error:', err);
    throw err;
  }
};

// Update Dealer permissions (Super Admin only)
export const updateDealerPermissionsInFirestore = async (
  targetPhoneOrId: string,
  permissions: DealerPermissions,
  actor: { email: string; name: string; phone?: string }
) => {
  try {
    const userRef = doc(db, 'users', targetPhoneOrId);
    const safePermissions: DealerPermissions = {
      ...permissions,
      grantedAt: new Date().toISOString(),
      grantedBy: actor.email || SUPER_ADMIN_EMAIL,
    };

    await setDoc(
      userRef,
      {
        dealerPermissions: safePermissions,
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );

    await logActivityAuditToFirestore({
      actorEmail: actor.email,
      actorPhone: actor.phone,
      actorName: actor.name,
      actorRole: 'super_admin',
      actionType: 'dealer_permissions_updated',
      description: `ডিলার ${targetPhoneOrId}-এর পারমিশন আপডেট করা হয়েছে`,
      targetId: targetPhoneOrId,
      targetType: 'dealer',
      metadata: { permissions: safePermissions },
    });
  } catch (err) {
    console.error('[Firestore] updateDealerPermissionsInFirestore error:', err);
    throw err;
  }
};

// Suspend Dealer (Super Admin only)
export const suspendDealerInFirestore = async (
  targetPhoneOrId: string,
  reason: string,
  actor: { email: string; name: string; phone?: string }
) => {
  try {
    const userRef = doc(db, 'users', targetPhoneOrId);
    await setDoc(
      userRef,
      {
        dealerStatus: 'suspended',
        dealerSuspendedReason: reason || 'সুপার এডমিন কর্তৃক সাময়িকভাবে স্থগিত',
        dealerSuspendedAt: new Date().toISOString(),
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );

    await logActivityAuditToFirestore({
      actorEmail: actor.email,
      actorPhone: actor.phone,
      actorName: actor.name,
      actorRole: 'super_admin',
      actionType: 'dealer_suspended',
      description: `ডিলার ${targetPhoneOrId}-কে স্থগিত করা হয়েছে (${reason || 'সুপার এডমিন কর্তৃক'})`,
      targetId: targetPhoneOrId,
      targetType: 'dealer',
      metadata: { reason },
    });
  } catch (err) {
    console.error('[Firestore] suspendDealerInFirestore error:', err);
    throw err;
  }
};

// Reactivate Dealer (Super Admin only)
export const reactivateDealerInFirestore = async (
  targetPhoneOrId: string,
  actor: { email: string; name: string; phone?: string }
) => {
  try {
    const userRef = doc(db, 'users', targetPhoneOrId);
    await setDoc(
      userRef,
      {
        dealerStatus: 'active',
        dealerSuspendedReason: '',
        dealerSuspendedAt: '',
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );

    await logActivityAuditToFirestore({
      actorEmail: actor.email,
      actorPhone: actor.phone,
      actorName: actor.name,
      actorRole: 'super_admin',
      actionType: 'dealer_approved',
      description: `ডিলার ${targetPhoneOrId}-কে পুনরায় সক্রিয় করা হয়েছে`,
      targetId: targetPhoneOrId,
      targetType: 'dealer',
    });
  } catch (err) {
    console.error('[Firestore] reactivateDealerInFirestore error:', err);
    throw err;
  }
};

// Remove Dealer role, demote to normal user (Super Admin only)
export const removeDealerRoleInFirestore = async (
  targetPhoneOrId: string,
  actor: { email: string; name: string; phone?: string }
) => {
  try {
    const userRef = doc(db, 'users', targetPhoneOrId);
    await setDoc(
      userRef,
      {
        appRole: 'user',
        accountType: 'Retailer',
        userRole: 'User',
        role: 'user',
        dealerStatus: 'pending',
        dealerPermissions: {},
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );

    await logActivityAuditToFirestore({
      actorEmail: actor.email,
      actorPhone: actor.phone,
      actorName: actor.name,
      actorRole: 'super_admin',
      actionType: 'dealer_removed',
      description: `ডিলার ${targetPhoneOrId}-এর ডিলার পদ বাতিল করে সাধারণ গ্রাহকে নামিয়ে দেওয়া হয়েছে`,
      targetId: targetPhoneOrId,
      targetType: 'dealer',
    });
  } catch (err) {
    console.error('[Firestore] removeDealerRoleInFirestore error:', err);
    throw err;
  }
};

/* =========================================================================
   2. OFFERS COLLECTION (/offers)
   ========================================================================= */
export const subscribeOffers = (
  callback: (offers: DriveOffer[]) => void
): Unsubscribe => {
  const offersColl = collection(db, 'offers');
  return onSnapshot(
    offersColl,
    (snapshot) => {
      const offersList: DriveOffer[] = [];
      snapshot.forEach((docSnap) => {
        offersList.push({
          id: docSnap.id,
          ...(docSnap.data() as Omit<DriveOffer, 'id'>),
        });
      });
      callback(offersList);
    },
    (error) => {
      console.warn('[Firestore] subscribeOffers error:', error);
    }
  );
};

export const addOfferToFirestore = async (offer: DriveOffer) => {
  try {
    const offerRef = doc(db, 'offers', String(offer.id));
    await setDoc(offerRef, {
      ...offer,
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    console.warn('[Firestore] addOfferToFirestore error:', err);
  }
};

export const deleteOfferFromFirestore = async (offerId: string) => {
  try {
    const offerRef = doc(db, 'offers', String(offerId));
    await deleteDoc(offerRef);
  } catch (err) {
    console.warn('[Firestore] deleteOfferFromFirestore error:', err);
  }
};

/* =========================================================================
   3. CUSTOMERS COLLECTION (/customers or /users/{userId}/customers)
   ========================================================================= */
export const subscribeCustomers = (
  userId: string,
  callback: (customers: CustomerAccount[]) => void
): Unsubscribe => {
  const customersColl = collection(db, 'users', userId || 'guest_user', 'customers');
  return onSnapshot(
    customersColl,
    (snapshot) => {
      const list: CustomerAccount[] = [];
      snapshot.forEach((docSnap) => {
        list.push({
          id: docSnap.id,
          ...(docSnap.data() as Omit<CustomerAccount, 'id'>),
        });
      });
      callback(list);
    },
    (error) => {
      console.warn('[Firestore] subscribeCustomers error:', error);
    }
  );
};

export const saveCustomerToFirestore = async (
  userId: string,
  customer: CustomerAccount
) => {
  try {
    const custRef = doc(db, 'users', userId || 'guest_user', 'customers', String(customer.id));
    await setDoc(custRef, {
      ...customer,
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    console.warn('[Firestore] saveCustomerToFirestore error:', err);
  }
};

export const deleteCustomerFromFirestore = async (
  userId: string,
  customerId: string
) => {
  try {
    const custRef = doc(db, 'users', userId || 'guest_user', 'customers', String(customerId));
    await deleteDoc(custRef);
  } catch (err) {
    console.warn('[Firestore] deleteCustomerFromFirestore error:', err);
  }
};

/* =========================================================================
   4. DRIVE ORDERS COLLECTION (/drive_orders)
   ========================================================================= */
export const subscribeGlobalDriveOrders = (
  callback: (orders: DriveOrder[]) => void
): Unsubscribe => {
  const ordersColl = collection(db, 'drive_orders');
  return onSnapshot(
    ordersColl,
    (snapshot) => {
      const ordersList: DriveOrder[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        ordersList.push({
          id: docSnap.id,
          offerId: data.offerId || '',
          operator: data.operator || 'gp',
          operatorName: data.operatorName || 'Grameenphone',
          packageName: data.packageName || '',
          title: data.title || '',
          customerPhone: data.customerPhone || '',
          requesterPhone: data.requesterPhone || '',
          requesterName: data.requesterName || '',
          minutes: Number(data.minutes) || 0,
          internetGB: Number(data.internetGB) || 0,
          validityDays: Number(data.validityDays) || 30,
          amount: Number(data.amount) || 0,
          cashback: Number(data.cashback) || 0,
          netCost: Number(data.netCost) || (Number(data.amount) || 0) - (Number(data.cashback) || 0),
          status: (data.status as 'pending' | 'success' | 'cancelled') || 'pending',
          createdAt: data.createdAt ? (typeof data.createdAt === 'string' ? data.createdAt : data.createdAt.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString()) : new Date().toISOString(),
          timestamp: data.timestamp || 'আজ, এইমাত্র',
          details: data.details || '',
          notes: data.notes || '',
        });
      });
      callback(ordersList);
    },
    (error) => {
      console.warn('[Firestore] subscribeGlobalDriveOrders error:', error);
    }
  );
};

export const saveDriveOrderToFirestore = async (order: DriveOrder) => {
  try {
    const orderRef = doc(db, 'drive_orders', String(order.id));
    await setDoc(orderRef, {
      ...order,
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    console.warn('[Firestore] saveDriveOrderToFirestore error:', err);
  }
};

export const deleteDriveOrderFromFirestore = async (orderId: string) => {
  try {
    const orderRef = doc(db, 'drive_orders', String(orderId));
    await deleteDoc(orderRef);
  } catch (err) {
    console.warn('[Firestore] deleteDriveOrderFromFirestore error:', err);
  }
};

export const subscribeOrders = (
  userId: string,
  callback: (orders: DriveOrder[]) => void
): Unsubscribe => {
  return subscribeGlobalDriveOrders(callback);
};

export const addOrderToFirestore = async (userId: string, order: DriveOrder) => {
  return saveDriveOrderToFirestore(order);
};

/* =========================================================================
   5. TRANSACTIONS COLLECTION (/users/{userId}/transactions)
   ========================================================================= */
export const subscribeTransactions = (
  userId: string,
  callback: (transactions: Transaction[]) => void
): Unsubscribe => {
  const txColl = collection(db, 'users', userId || 'guest_user', 'transactions');
  return onSnapshot(
    txColl,
    (snapshot) => {
      const txs: Transaction[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        let createdAtMs = data.createdAtMs;
        if (!createdAtMs && data.createdAt?.toMillis) {
          createdAtMs = data.createdAt.toMillis();
        } else if (!createdAtMs && data.createdAt) {
          const parsed = new Date(data.createdAt).getTime();
          if (!isNaN(parsed)) createdAtMs = parsed;
        }
        txs.push({
          id: docSnap.id,
          ...data,
          createdAtMs,
        } as Transaction);
      });
      // Sort newest first
      txs.sort((a, b) => (b.createdAtMs || 0) - (a.createdAtMs || 0));
      callback(txs);
    },
    (error) => {
      console.warn('[Firestore] subscribeTransactions error:', error);
    }
  );
};

export const addTransactionToFirestore = async (
  userId: string,
  tx: Transaction
) => {
  try {
    const txRef = doc(db, 'users', userId || 'guest_user', 'transactions', String(tx.id));
    await setDoc(txRef, {
      ...tx,
      createdAtMs: tx.createdAtMs || Date.now(),
      createdAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    console.warn('[Firestore] addTransactionToFirestore error:', err);
  }
};

/* =========================================================================
   6. DAILY_ACCOUNTS COLLECTION (/users/{userId}/daily_accounts)
   ========================================================================= */
export const subscribeDailyAccounts = (
  userId: string,
  callback: (transactions: ShopTransaction[]) => void
): Unsubscribe => {
  const dailyColl = collection(db, 'users', userId || 'guest_user', 'daily_accounts');
  return onSnapshot(
    dailyColl,
    (snapshot) => {
      const list: ShopTransaction[] = [];
      snapshot.forEach((docSnap) => {
        list.push({
          id: docSnap.id,
          ...(docSnap.data() as Omit<ShopTransaction, 'id'>),
        });
      });
      callback(list);
    },
    (error) => {
      console.warn('[Firestore] subscribeDailyAccounts error:', error);
    }
  );
};

export const saveDailyAccountToFirestore = async (
  userId: string,
  item: ShopTransaction
) => {
  try {
    const itemRef = doc(db, 'users', userId || 'guest_user', 'daily_accounts', String(item.id));
    await setDoc(itemRef, {
      ...item,
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    console.warn('[Firestore] saveDailyAccountToFirestore error:', err);
  }
};

export const deleteDailyAccountFromFirestore = async (
  userId: string,
  itemId: string
) => {
  try {
    const itemRef = doc(db, 'users', userId || 'guest_user', 'daily_accounts', String(itemId));
    await deleteDoc(itemRef);
  } catch (err) {
    console.warn('[Firestore] deleteDailyAccountFromFirestore error:', err);
  }
};

/* =========================================================================
   7. APP_SETTINGS COLLECTION (/app_settings/global)
   ========================================================================= */
export const subscribeAppSettings = (
  callback: (data: {
    notice?: string;
    settings?: Partial<AppSettings>;
    socialLinks?: Partial<SocialCommunityLinks>;
    paymentNumbers?: Partial<PaymentNumbersConfig>;
  }) => void
): Unsubscribe => {
  const settingsRef = doc(db, 'app_settings', 'global');
  return onSnapshot(
    settingsRef,
    (snap) => {
      if (snap.exists()) {
        callback(snap.data() as any);
      }
    },
    (error) => {
      console.warn('[Firestore] subscribeAppSettings error:', error);
    }
  );
};

export const updateAppSettingsInFirestore = async (data: {
  notice?: string;
  settings?: Partial<AppSettings>;
  socialLinks?: Partial<SocialCommunityLinks>;
  paymentNumbers?: Partial<PaymentNumbersConfig>;
}) => {
  try {
    const settingsRef = doc(db, 'app_settings', 'global');
    await setDoc(settingsRef, {
      ...data,
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    console.warn('[Firestore] updateAppSettingsInFirestore error:', err);
  }
};

/* =========================================================================
   8. TICKETS COLLECTION (/tickets)
   ========================================================================= */
export const subscribeTickets = (
  callback: (tickets: SupportTicket[]) => void
): Unsubscribe => {
  const ticketsColl = collection(db, 'tickets');
  return onSnapshot(
    ticketsColl,
    (snapshot) => {
      const tickets: SupportTicket[] = [];
      snapshot.forEach((docSnap) => {
        tickets.push({
          id: docSnap.id,
          ...(docSnap.data() as Omit<SupportTicket, 'id'>),
        });
      });
      callback(tickets);
    },
    (error) => {
      console.warn('[Firestore] subscribeTickets error:', error);
    }
  );
};

export const addTicketToFirestore = async (ticket: SupportTicket) => {
  try {
    const ticketRef = doc(db, 'tickets', String(ticket.id));
    await setDoc(ticketRef, {
      ...ticket,
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    console.warn('[Firestore] addTicketToFirestore error:', err);
  }
};

export const updateTicketStatusInFirestore = async (
  ticketId: string,
  status: 'pending' | 'in_progress' | 'processing' | 'replied' | 'resolved' | 'rejected'
) => {
  try {
    const ticketRef = doc(db, 'tickets', String(ticketId));
    await updateDoc(ticketRef, {
      status,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    console.warn('[Firestore] updateTicketStatusInFirestore error:', err);
  }
};

export const replyTicketInFirestore = async (
  ticketId: string,
  replyData: {
    adminReply: string;
    status?: 'pending' | 'in_progress' | 'replied' | 'resolved';
    adminName?: string;
  }
) => {
  try {
    const ticketRef = doc(db, 'tickets', String(ticketId));
    await updateDoc(ticketRef, {
      adminReply: replyData.adminReply,
      adminReplyAt: new Date().toLocaleString('bn-BD', {
        day: 'numeric',
        month: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
      }),
      adminName: replyData.adminName || 'এডমিন সাপোর্ট',
      status: replyData.status || 'replied',
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    console.warn('[Firestore] replyTicketInFirestore error:', err);
  }
};

export const deleteTicketFromFirestore = async (ticketId: string) => {
  try {
    const ticketRef = doc(db, 'tickets', String(ticketId));
    await deleteDoc(ticketRef);
  } catch (err) {
    console.warn('[Firestore] deleteTicketFromFirestore error:', err);
  }
};

/* =========================================================================
   9. ADD MONEY REQUESTS COLLECTION (/add_money_requests)
   ========================================================================= */
export const subscribeAddMoneyRequests = (
  callback: (requests: AddMoneyRequest[]) => void
): Unsubscribe => {
  const coll = collection(db, 'add_money_requests');
  return onSnapshot(
    coll,
    (snapshot) => {
      const list: AddMoneyRequest[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        list.push({
          id: docSnap.id,
          userId: data.userId || '',
          userPhone: data.userPhone || '',
          userName: data.userName || '',
          gateway: data.gateway || 'bKash',
          amount: Number(data.amount) || 0,
          bonus: Number(data.bonus) || 0,
          totalCredit: Number(data.totalCredit) || Number(data.amount) || 0,
          balanceType: data.balanceType || 'main',
          trxId: data.trxId || '',
          senderNumber: data.senderNumber || '',
          status: (data.status as 'pending' | 'approved' | 'rejected') || 'pending',
          createdAt: data.createdAt ? (typeof data.createdAt === 'string' ? data.createdAt : data.createdAt.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString()) : new Date().toISOString(),
          timestamp: data.timestamp || 'আজ, এইমাত্র',
        });
      });
      callback(list);
    },
    (error) => {
      console.warn('[Firestore] subscribeAddMoneyRequests error:', error);
    }
  );
};

export const saveAddMoneyRequestToFirestore = async (request: AddMoneyRequest) => {
  try {
    const ref = doc(db, 'add_money_requests', String(request.id));
    await setDoc(ref, {
      ...request,
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    console.warn('[Firestore] saveAddMoneyRequestToFirestore error:', err);
  }
};

export const updateTransactionStatusInFirestore = async (
  firstArg: string,
  secondArg: string,
  thirdArg?: string,
  fourthArg?: string
) => {
  try {
    let userId: string;
    let txId: string;
    let status: 'success' | 'pending' | 'failed';
    let details: string | undefined;

    // Support both (txId, status, userId, details) AND (userId, txId, status, details)
    if (secondArg === 'success' || secondArg === 'pending' || secondArg === 'failed') {
      txId = firstArg;
      status = secondArg;
      userId = thirdArg || 'guest_user';
      details = fourthArg;
    } else {
      userId = firstArg || 'guest_user';
      txId = secondArg;
      status = (thirdArg as any) || 'success';
      details = fourthArg;
    }

    const txRef = doc(db, 'users', userId, 'transactions', String(txId));
    const updates: any = {
      status,
      updatedAt: serverTimestamp(),
    };
    if (details) {
      updates.details = details;
    }
    await setDoc(txRef, updates, { merge: true });
  } catch (err) {
    console.warn('[Firestore] updateTransactionStatusInFirestore error:', err);
  }
};

export const deleteTransactionFromFirestore = async (
  userId: string,
  txId: string
) => {
  try {
    const txRef = doc(db, 'users', userId || 'guest_user', 'transactions', String(txId));
    await deleteDoc(txRef);
  } catch (err) {
    console.warn('[Firestore] deleteTransactionFromFirestore error:', err);
  }
};

export const verifyAndProcessAddMoneyInFirestore = async (
  req: AddMoneyRequest
): Promise<{ success: boolean; message: string }> => {
  try {
    const cleanTrxId = req.trxId.trim().toUpperCase();
    if (!cleanTrxId || cleanTrxId.length < 4) {
      return { success: false, message: 'সঠিক ও পূর্ণাঙ্গ ট্রানজেকশন আইডি (TrxID) লিখুন।' };
    }
    if (!req.amount || req.amount < 10) {
      return { success: false, message: 'সর্বনিম্ন অ্যাড মানি ১০ টাকা।' };
    }

    // Check if this TrxID is already used in add_money_requests
    const coll = collection(db, 'add_money_requests');
    const q = query(coll, where('trxId', '==', cleanTrxId));
    const querySnap = await getDocs(q);

    if (!querySnap.empty) {
      const alreadyApproved = querySnap.docs.some((d) => d.data().status === 'approved');
      if (alreadyApproved) {
        return {
          success: false,
          message: `এই ট্রানজেকশন আইডি (${cleanTrxId}) পূর্বে সফলভাবে ভেরিফাই করে ব্যালেন্স যোগ করা হয়েছে! নতুন TrxID প্রদান করুন।`,
        };
      }
    }

    const totalCredit = req.totalCredit || req.amount;

    // 1. Save request to Firestore as approved
    const reqRef = doc(db, 'add_money_requests', String(req.id));
    await setDoc(reqRef, {
      ...req,
      trxId: cleanTrxId,
      status: 'approved',
      verifiedAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    }, { merge: true });

    // 2. Update user balance in Firestore
    const userRef = doc(db, 'users', req.userPhone);
    const userSnap = await getDoc(userRef);
    const balanceKey = req.balanceType === 'drive' ? 'driveBalance' : req.balanceType === 'bank' ? 'bankBalance' : 'mainBalance';

    if (userSnap.exists()) {
      const uData = userSnap.data();
      const current = Number(uData[balanceKey]) || 0;
      await updateDoc(userRef, {
        [balanceKey]: current + totalCredit,
        updatedAt: serverTimestamp(),
      });
    }

    // 3. Add transaction to user's transactions subcollection
    const txRef = doc(db, 'users', req.userPhone, 'transactions', String(req.id));
    await setDoc(txRef, {
      id: req.id,
      type: 'add_money',
      amount: req.amount,
      bonus: req.bonus || 0,
      totalCredit: totalCredit,
      phoneNumber: req.userPhone,
      paymentMethod: req.gateway,
      trxId: cleanTrxId,
      status: 'success',
      date: req.createdAt ? req.createdAt.slice(0, 10) : new Date().toLocaleDateString('bn-BD'),
      time: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', hour12: true }),
      createdAtMs: Date.now(),
      timestamp: 'আজ, এইমাত্র',
      details: `${req.gateway} অ্যাড মানি ভেরিফাইড (TrxID: ${cleanTrxId})`,
      createdAt: serverTimestamp(),
    }, { merge: true });

    return {
      success: true,
      message: `ডাটাবেজ ভেরিফিকেশন সফল! আপনার একাউন্টে ৳${totalCredit} স্বয়ংক্রিয়ভাবে যোগ করা হয়েছে।`,
    };
  } catch (err: any) {
    console.error('verifyAndProcessAddMoneyInFirestore error:', err);
    return {
      success: false,
      message: err?.message || 'ডাটাবেজ ভেরিফিকেশনে সমস্যা হয়েছে, অনুগ্রহ করে কিছুক্ষণ পর আবার চেষ্টা করুন।',
    };
  }
};

export const approveAddMoneyRequestInFirestore = async (
  requestId: string,
  userPhone: string,
  totalCredit: number,
  balanceType: 'main' | 'drive' | 'bank' = 'main'
) => {
  try {
    const reqRef = doc(db, 'add_money_requests', String(requestId));
    await updateDoc(reqRef, {
      status: 'approved',
      approvedAt: serverTimestamp(),
    });

    // Also update the target user's balance directly in Firestore
    const userRef = doc(db, 'users', userPhone);
    const userSnap = await getDoc(userRef);
    if (userSnap.exists()) {
      const uData = userSnap.data();
      const currentMain = Number(uData.mainBalance) || 0;
      const currentDrive = Number(uData.driveBalance) || 0;
      const currentBank = Number(uData.bankBalance) || 0;

      if (balanceType === 'drive') {
        await updateDoc(userRef, { driveBalance: currentDrive + totalCredit, updatedAt: serverTimestamp() });
      } else if (balanceType === 'bank') {
        await updateDoc(userRef, { bankBalance: currentBank + totalCredit, updatedAt: serverTimestamp() });
      } else {
        await updateDoc(userRef, { mainBalance: currentMain + totalCredit, updatedAt: serverTimestamp() });
      }
    }

    // Update transaction to success
    await updateTransactionStatusInFirestore(userPhone, requestId, 'success', 'অ্যাড মানি সফলভাবে অনুমোদিত');
  } catch (err) {
    console.warn('[Firestore] approveAddMoneyRequestInFirestore error:', err);
  }
};

export const rejectAddMoneyRequestInFirestore = async (requestId: string, userPhone?: string) => {
  try {
    const reqRef = doc(db, 'add_money_requests', String(requestId));
    await updateDoc(reqRef, {
      status: 'rejected',
      rejectedAt: serverTimestamp(),
    });

    if (userPhone) {
      await updateTransactionStatusInFirestore(userPhone, requestId, 'failed', 'অ্যাড মানি রিকোয়েস্ট বাতিল করা হয়েছে');
    }
  } catch (err) {
    console.warn('[Firestore] rejectAddMoneyRequestInFirestore error:', err);
  }
};

export const deleteAddMoneyRequestFromFirestore = async (requestId: string) => {
  try {
    const reqRef = doc(db, 'add_money_requests', String(requestId));
    await deleteDoc(reqRef);
  } catch (err) {
    console.warn('[Firestore] deleteAddMoneyRequestFromFirestore error:', err);
  }
};

/* =========================================================================
   10. RECHARGE REQUESTS COLLECTION (/recharge_requests)
   ========================================================================= */
export const subscribeRechargeRequests = (
  callback: (requests: RechargeRequest[]) => void
): Unsubscribe => {
  const coll = collection(db, 'recharge_requests');
  return onSnapshot(
    coll,
    (snapshot) => {
      const list: RechargeRequest[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        list.push({
          id: docSnap.id,
          userId: data.userId || '',
          userPhone: data.userPhone || '',
          userName: data.userName || '',
          operator: data.operator || 'gp',
          operatorName: data.operatorName || 'গ্রামীনফোন',
          connectionType: data.connectionType || 'prepaid',
          recipientPhone: data.recipientPhone || '',
          amount: Number(data.amount) || 0,
          status: (data.status as 'pending' | 'success' | 'cancelled') || 'pending',
          createdAt: data.createdAt ? (typeof data.createdAt === 'string' ? data.createdAt : data.createdAt.toDate ? data.createdAt.toDate().toISOString() : new Date().toISOString()) : new Date().toISOString(),
          timestamp: data.timestamp || 'আজ, এইমাত্র',
        });
      });
      callback(list);
    },
    (error) => {
      console.warn('[Firestore] subscribeRechargeRequests error:', error);
    }
  );
};

export const saveRechargeRequestToFirestore = async (request: RechargeRequest) => {
  try {
    const ref = doc(db, 'recharge_requests', String(request.id));
    await setDoc(ref, {
      ...request,
      updatedAt: serverTimestamp(),
    }, { merge: true });
  } catch (err) {
    console.warn('[Firestore] saveRechargeRequestToFirestore error:', err);
  }
};

export const approveRechargeRequestInFirestore = async (requestId: string, userPhone?: string, operatorName?: string) => {
  try {
    const reqRef = doc(db, 'recharge_requests', String(requestId));
    await updateDoc(reqRef, {
      status: 'success',
      approvedAt: serverTimestamp(),
    });

    if (userPhone) {
      await updateTransactionStatusInFirestore(
        userPhone,
        requestId,
        'success',
        `${operatorName || 'মোবাইল'} রিচার্জ সফল`
      );
    }
  } catch (err) {
    console.warn('[Firestore] approveRechargeRequestInFirestore error:', err);
  }
};

export const cancelRechargeRequestInFirestore = async (
  requestId: string,
  userPhone?: string,
  refundAmount?: number,
  operatorName?: string
) => {
  try {
    const reqRef = doc(db, 'recharge_requests', String(requestId));
    await updateDoc(reqRef, {
      status: 'cancelled',
      cancelledAt: serverTimestamp(),
    });

    if (userPhone && refundAmount && refundAmount > 0) {
      const userRef = doc(db, 'users', userPhone);
      const userSnap = await getDoc(userRef);
      if (userSnap.exists()) {
        const uData = userSnap.data();
        const currentMain = Number(uData.mainBalance) || 0;
        await updateDoc(userRef, { mainBalance: currentMain + refundAmount, updatedAt: serverTimestamp() });
      }

      await updateTransactionStatusInFirestore(
        userPhone,
        requestId,
        'failed',
        `${operatorName || 'মোবাইল'} রিচার্জ বাতিল (৳${refundAmount} রিফান্ড করা হয়েছে)`
      );
    }
  } catch (err) {
    console.warn('[Firestore] cancelRechargeRequestInFirestore error:', err);
  }
};

export const deleteRechargeRequestFromFirestore = async (requestId: string) => {
  try {
    const reqRef = doc(db, 'recharge_requests', String(requestId));
    await deleteDoc(reqRef);
  } catch (err) {
    console.warn('[Firestore] deleteRechargeRequestFromFirestore error:', err);
  }
};
