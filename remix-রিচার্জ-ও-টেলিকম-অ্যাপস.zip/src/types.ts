export type OperatorType = 'gp' | 'robi' | 'banglalink' | 'teletalk' | 'airtel' | 'skitto';

export interface DriveOffer {
  id: string;
  operator: OperatorType;
  operatorName: string;
  packageName?: string; // কম্বো প্যাক, বান্ডেল প্যাক, মিনিট প্যাক, ডাটা প্যাক, ফ্যামিলি প্যাক, গিফট প্যাক, ওটিপি প্যাক
  whatsappNumber?: string; // হোয়াটসঅ্যাপ নম্বর (বাংলাদেশ কান্ট্রি কোড সহ)
  date?: string; // যেমন: 1/9/2026
  minutes?: number;
  internetGB?: number;
  sms?: number;
  validityDays: number | string;
  regularPriceTK?: number; // রেগুলার দাম (৳)
  priceTK: number; // বর্তমান দাম (৳)
  cashbackTK: number; // ক্যাশব্যাক (৳) = রেগুলার দাম - বর্তমান দাম
  division?: string;
  title?: string;
  isPopular?: boolean;
}

export interface Transaction {
  id: string;
  type: 'recharge' | 'drive' | 'add_money';
  operator?: OperatorType;
  operatorName?: string;
  packageName?: string;
  phoneNumber?: string;
  amount: number;
  regularPriceTK?: number;
  cashback?: number;
  date?: string;
  time?: string;
  createdAtMs?: number;
  minutes?: number;
  internetGB?: number;
  sms?: number;
  validityDays?: number | string;
  status: 'success' | 'pending' | 'failed';
  timestamp: string;
  details: string;
  trxId?: string;
  paymentMethod?: 'bKash' | 'Nagad' | 'Rocket' | 'Upay';
}

export interface ShopTransaction {
  id: string;
  itemName: string;
  quantity?: string;
  buyPrice: number;
  sellPrice: number;
  depositAmount: number; // জমা
  dueAmount: number;     // বাকি/অবশিষ্ট
  profit?: number;       // লাভ
  date: string;
  dayOfWeek?: string;    // বার (যেমন: মঙ্গলবার, বুধবার)
  commissionTag?: string; // কমিশন (যেমন: C50, C55)
  time: string;
  category?: string;
  note?: string;
  createdAtMs?: number;
  linkedCustomerId?: string;
  linkedCustomerTrxId?: string;
  customerName?: string;
  customerPhone?: string;
}

export interface CustomerTransaction {
  id: string;
  itemName: string;
  quantity?: string;
  buyPrice?: number;
  sellPrice: number;     // বিক্রি
  depositAmount: number; // জমা
  dueAmount: number;     // বাকি অবশিষ্ট
  profit?: number;       // লাভ
  date: string;
  time: string;
  note?: string;
  createdAtMs?: number;
  linkedShopTrxId?: string;
}

export interface CustomerAccount {
  id: string;
  name: string;
  phone: string;
  avatarBg?: string;
  avatarText?: string;
  transactions: CustomerTransaction[];
}

export interface DriveOrder {
  id: string;
  offerId: string;
  operator: OperatorType;
  operatorName: string;
  packageName?: string;
  date?: string; // যেমন: 1/9/2026
  title: string;
  customerPhone: string;
  requesterPhone?: string;
  requesterName?: string;
  minutes?: number;
  internetGB?: number;
  sms?: number;
  validityDays: number | string;
  regularPriceTK?: number;
  amount: number;       // Current offer price
  cashback: number;     // Cashback amount
  netCost: number;      // Price - Cashback
  status: 'pending' | 'success' | 'cancelled';
  createdAt: string;
  timestamp: string;
  details?: string;
  notes?: string;
}

export interface TallyEntry {
  id: string;
  customerName: string;
  phoneNumber: string;
  type: 'due' | 'paid' | 'sale';
  amount: number;
  profit: number;
  note: string;
  date: string;
  status: 'pending' | 'cleared';
}

export type AppUserRole = 'super_admin' | 'dealer' | 'user';

export const SUPER_ADMIN_EMAIL = 'mmirazgp@gmail.com';
export const SUPER_ADMIN_EMAILS = ['mmirazgp@gmail.com', 'miraz1986.app@gmail.com'];
export const SUPER_ADMIN_NAME = 'Miraz Hossain';
export const SUPER_ADMIN_DEFAULT_PIN = '1986';
export const SUPER_ADMIN_PASSWORD = 'miraz1986';

export interface DealerPermissions {
  manageOffers?: boolean;
  manageRecharge?: boolean;
  manageOrders?: boolean;
  manageAddMoney?: boolean;
  manageTickets?: boolean;
  viewUsers?: boolean;
  // Temporary permission support with expiration timestamp in ISO format or ms
  expiresAt?: string; // ISO string e.g. "2026-09-20T04:30:00.000Z"
  grantedAt?: string;
  grantedBy?: string; // Super Admin Email/ID
}

export interface ActivityAuditLog {
  id: string;
  actorEmail: string;
  actorPhone?: string;
  actorName: string;
  actorRole: AppUserRole;
  actionType:
    | 'dealer_created'
    | 'dealer_approved'
    | 'dealer_suspended'
    | 'dealer_removed'
    | 'dealer_permissions_updated'
    | 'offer_created'
    | 'offer_updated'
    | 'offer_deleted'
    | 'recharge_approved'
    | 'recharge_cancelled'
    | 'order_approved'
    | 'order_cancelled'
    | 'add_money_approved'
    | 'add_money_rejected'
    | 'balance_adjusted'
    | 'user_blocked'
    | 'user_unblocked'
    | 'user_created'
    | 'user_approved'
    | 'user_rejected';
  description: string;
  targetId?: string;
  targetType?: 'user' | 'dealer' | 'offer' | 'order' | 'recharge' | 'add_money';
  timestamp: string;
  metadata?: Record<string, any>;
}

export type UserRoleCategory = 'User' | 'Seller' | 'Dealer' | 'Admin';

export interface UserProfile {
  name: string;
  phone: string;
  email?: string;
  pin: string;
  shopName?: string;
  mainBalance: number;
  driveBalance: number;
  bankBalance: number;
  accountType: 'Retailer' | 'Dealer' | 'Reseller' | 'Personal' | 'User' | 'Seller' | 'Admin';
  userRole?: UserRoleCategory;
  // 3 Primary Roles: super_admin, dealer, user (with legacy fallback support)
  appRole?: AppUserRole;
  role: 'user' | 'admin';
  dealerPermissions?: DealerPermissions;
  dealerStatus?: 'active' | 'suspended' | 'pending';
  dealerSuspendedReason?: string;
  dealerSuspendedAt?: string;
  isSuperAdmin?: boolean;
  profileImage?: string; // ব্যবহারকারীর আপলোড করা প্রোফাইল ছবি (Data URL / Image URL)
  avatarUrl?: string;
  division?: string;
  currentAddress?: string;
  isBlocked?: boolean;
  blockReason?: string;
  status?: 'pending' | 'approved' | 'rejected';
  registeredAt?: string;
  serialNumber?: number;
  requestMessage?: string;
}

export interface PaymentNumbersConfig {
  bKash: string;
  bKashType?: string;
  bKashEnabled?: boolean;
  Nagad: string;
  NagadType?: string;
  NagadEnabled?: boolean;
  Rocket: string;
  RocketType?: string;
  RocketEnabled?: boolean;
  Upay: string;
  UpayType?: string;
  UpayEnabled?: boolean;
  // ব্যাংক অ্যাকাউন্ট সেটিংস
  bankName?: string;
  bankAccountName?: string;
  bankAccountNumber?: string;
  bankBranchRouting?: string;
  bankType?: string;
  bankEnabled?: boolean;
}

export interface AppSettings {
  theme: 'purple' | 'blue' | 'green' | 'orange' | 'red' | 'dark';
  darkMode?: boolean;
  soundEnabled: boolean;
  notificationsEnabled: boolean;
  autoCopyOffers: boolean;
  language: 'bn' | 'en';
  shopName: string;
  adminContactNumber?: string;
  // App Logo & Branding Settings
  appName?: string;
  appTagline?: string;
  appLogoUrl?: string;
  logoPreset?: 'default_vector' | 'falcon' | 'emerald_5g' | 'ruby_flash' | 'golden_crown' | 'blue_tech' | 'custom';
  // Custom App Download / Share URL configured by Admin
  appDownloadUrl?: string;
  // Payment Gateway Numbers (bKash, Nagad, Rocket, Upay, Bank)
  paymentNumbers?: PaymentNumbersConfig;
}

export interface SocialCommunityLinks {
  adminContactNumber?: string;
  // Custom App Download / Share URL configured by Admin
  appDownloadUrl?: string;
  // ৪/ সোশ্যাল মিডিয়া চ্যানেল ও On/Off সুইচ
  noticeTitle?: string;
  noticeTitleEnabled?: boolean;
  whatsappGroup: string;
  whatsappGroupEnabled?: boolean;
  telegramChannel: string;
  telegramChannelEnabled?: boolean;
  youtubeChannel: string;
  youtubeChannelEnabled?: boolean;
  facebookPage: string;
  facebookPageEnabled?: boolean;

  // ৫/ হেল্প সাপোর্ট সেটিংস ও On/Off সুইচ (সময়: সকাল ১০টা - রাত ১০টা)
  supportPhone: string;
  supportPhoneEnabled?: boolean;
  digitalChatUrl?: string;
  digitalChatEnabled?: boolean;
  whatsappSupportNumber: string;
  whatsappSupportEnabled?: boolean;
  messengerId?: string;
  messengerEnabled?: boolean;
  imoNumber?: string;
  imoEnabled?: boolean;
  supportHours: string;
  emergencyNotice?: string;
  telegramSupport?: string;
}

export interface AddMoneyRequest {
  id: string;
  userId: string;
  userPhone: string;
  userName: string;
  gateway: 'bKash' | 'Nagad' | 'Rocket' | 'Upay';
  amount: number;
  bonus: number;
  totalCredit: number;
  balanceType: 'main' | 'drive' | 'bank';
  trxId: string;
  senderNumber?: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  timestamp: string;
}

export interface RechargeRequest {
  id: string;
  userId: string;
  userPhone: string;
  userName: string;
  operator: OperatorType;
  operatorName: string;
  connectionType: 'prepaid' | 'postpaid' | 'skitto';
  recipientPhone: string;
  amount: number;
  status: 'pending' | 'success' | 'cancelled';
  createdAt: string;
  timestamp: string;
}

export interface SupportTicket {
  id: string;
  customerName: string;
  phone: string;
  issueType: 'recharge_pending' | 'wrong_number' | 'offer_not_active' | 'balance_issue' | 'other';
  message: string;
  trxId?: string;
  createdAt: string;
  status: 'pending' | 'in_progress' | 'replied' | 'resolved';
  adminReply?: string;
  adminReplyAt?: string;
  adminName?: string;
}

