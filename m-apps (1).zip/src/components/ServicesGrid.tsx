import React from 'react';
import {
  TallyKhataLogo,
  DriveOfferSimsLogo,
  AddMoneyServiceLogo,
  MobileRechargeServiceLogo,
} from './ServiceLogos';

export type ServiceKey =
  | 'add_money'
  | 'recharge'
  | 'drive'
  | 'tally';

interface ServicesGridProps {
  onSelectService: (serviceKey: ServiceKey) => void;
  language?: 'bn' | 'en';
}

export const ServicesGrid: React.FC<ServicesGridProps> = ({
  onSelectService,
  language = 'bn',
}) => {
  const isBangla = language !== 'en';

  const services = [
    {
      id: 'service-add-money',
      key: 'add_money' as const,
      name: isBangla ? 'অ্যাড মানি' : 'Add Money',
      LogoComponent: AddMoneyServiceLogo,
    },
    {
      id: 'service-recharge',
      key: 'recharge' as const,
      name: isBangla ? 'মোবাইল রিচার্জ' : 'Recharge',
      LogoComponent: MobileRechargeServiceLogo,
    },
    {
      id: 'service-drive',
      key: 'drive' as const,
      name: isBangla ? 'ড্রাইভ অফার' : 'Drive Offers',
      LogoComponent: DriveOfferSimsLogo,
    },
    {
      id: 'service-tally',
      key: 'tally' as const,
      name: isBangla ? 'টালি খাতা' : 'Tally Khata',
      LogoComponent: TallyKhataLogo,
    },
  ];

  return (
    <div className="px-3 sm:px-4 py-2 sm:py-3">
      {/* Title */}
      <div className="flex items-center justify-between gap-1.5 sm:gap-2 mb-2 sm:mb-2.5 min-w-0">
        <h2 className="text-xs xs:text-sm sm:text-base md:text-lg font-black text-slate-950 tracking-tight leading-snug shrink-0 py-0.5">
          {isBangla ? 'সার্ভিস সমূহ' : 'Our Services'}
        </h2>
        <span className="text-[9.5px] xs:text-[10px] sm:text-xs font-black text-orange-800 bg-orange-100 px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full border border-orange-300 shadow-2xs shrink-0 whitespace-nowrap leading-none">
          {isBangla ? 'টেলিকম ও হিসাব সেবা' : 'Telecom & Ledger'}
        </span>
      </div>

      {/* Grid container - 4 columns on mobile with crisp contrast and bold labels */}
      <div className="grid grid-cols-4 gap-1.5 sm:gap-2">
        {services.map((item) => {
          const Logo = item.LogoComponent;
          return (
            <button
              key={item.key}
              id={item.id}
              type="button"
              onClick={() => onSelectService(item.key)}
              className="flex flex-col items-center justify-start text-center p-1.5 sm:p-2 rounded-2xl bg-white border-2 border-slate-200/90 shadow-sm hover:shadow-md hover:border-indigo-400 active:scale-95 transition-all group cursor-pointer"
            >
              {/* Logo Container with crisp boundary */}
              <div
                className="w-11 h-11 xs:w-12 xs:h-12 sm:w-14 sm:h-14 rounded-2xl bg-slate-50/80 flex items-center justify-center p-1 sm:p-1.5 shadow-xs border-2 border-slate-200 mb-1 sm:mb-1.5 transform group-hover:scale-105 transition-transform"
              >
                <Logo className="w-8 h-8 xs:w-9 xs:h-9 sm:w-10 sm:h-10 object-contain drop-shadow-xs" />
              </div>

              {/* Single Title: Shows clean readable title with no cut-off */}
              <span className="text-[10px] xs:text-[11px] sm:text-xs font-black text-slate-900 leading-snug block w-full text-center px-0.5 min-h-[28px] sm:min-h-[30px] flex items-center justify-center break-words line-clamp-2 py-0.5">
                {item.name}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};


