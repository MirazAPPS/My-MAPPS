import React, { useState } from 'react';
import {
  X,
  Plus,
  Sparkles,
  Rocket,
  CheckCircle2,
  Calendar,
  Phone,
  Layers,
  MapPin,
  Clock,
  Trash2,
} from 'lucide-react';
import { DriveOffer, OperatorType, UserProfile, SocialCommunityLinks } from '../types';
import { OperatorLogo } from './OperatorLogos';
import { getOperatorBnName, getFormattedTodayDate, playNotificationTone, speakText } from '../utils';
import { addOfferToFirestore } from '../lib/firebase';

interface QuickPublishOfferModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  socialLinks?: SocialCommunityLinks;
  onOfferPublished?: (newOffer: DriveOffer) => void;
  onShowToast?: (msg: string) => void;
}

export const QuickPublishOfferModal: React.FC<QuickPublishOfferModalProps> = ({
  isOpen,
  onClose,
  user,
  socialLinks,
  onOfferPublished,
  onShowToast,
}) => {
  const [operator, setOperator] = useState<OperatorType>('gp');
  const [packageName, setPackageName] = useState('কম্বো প্যাক');
  const [internetGB, setInternetGB] = useState('50');
  const [minutes, setMinutes] = useState('1500');
  const [sms, setSms] = useState('0');
  const [validityDays, setValidityDays] = useState('30');
  const [priceTK, setPriceTK] = useState('699');
  const [regularPriceTK, setRegularPriceTK] = useState('899');
  const [cashbackTK, setCashbackTK] = useState('200');
  const [division, setDivision] = useState('All Bangladesh');
  const [whatsappNumber, setWhatsappNumber] = useState(
    socialLinks?.adminContactNumber || socialLinks?.whatsappSupportNumber || user.phone || '01301035400'
  );
  const [isPopular, setIsPopular] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  // Auto calculate cashback
  const handlePriceChange = (newPrice: string, newRegular = regularPriceTK) => {
    setPriceTK(newPrice);
    const p = parseFloat(newPrice);
    const r = parseFloat(newRegular);
    if (!isNaN(p) && !isNaN(r) && r > p) {
      setCashbackTK(String(r - p));
    }
  };

  const handleRegularChange = (newRegular: string) => {
    setRegularPriceTK(newRegular);
    const p = parseFloat(priceTK);
    const r = parseFloat(newRegular);
    if (!isNaN(p) && !isNaN(r) && r > p) {
      setCashbackTK(String(r - p));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    const parsedPrice = parseFloat(priceTK) || 0;
    if (parsedPrice <= 0) {
      alert('অনুগ্রহ করে সঠিক বিক্রয় মূল্য প্রদান করুন!');
      return;
    }

    setIsSubmitting(true);

    const opEnglishNames: Record<OperatorType, string> = {
      gp: 'Grameenphone',
      banglalink: 'Banglalink',
      robi: 'Robi',
      airtel: 'Airtel',
      teletalk: 'Teletalk',
      skitto: 'Skitto',
    };

    const cleanWa = whatsappNumber.replace(/[^0-9]/g, '');
    const formattedWa = cleanWa.startsWith('880')
      ? `+${cleanWa}`
      : cleanWa.startsWith('0')
      ? `+88${cleanWa}`
      : cleanWa ? `+880${cleanWa}` : '+8801301035400';

    const pRegular = parseFloat(regularPriceTK) || parsedPrice;
    const pCashback = parseFloat(cashbackTK) || (pRegular > parsedPrice ? pRegular - parsedPrice : 0);

    const newOffer: DriveOffer = {
      id: `off-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      operator,
      operatorName: opEnglishNames[operator] || 'Telecom',
      packageName: packageName.trim() || 'কম্বো প্যাক',
      date: getFormattedTodayDate(),
      whatsappNumber: formattedWa,
      internetGB: parseFloat(internetGB) || 0,
      minutes: parseInt(minutes, 10) || 0,
      sms: parseInt(sms, 10) || 0,
      validityDays: parseInt(validityDays, 10) || 30,
      regularPriceTK: pRegular,
      priceTK: parsedPrice,
      cashbackTK: pCashback,
      division: division.trim() || 'All Bangladesh',
      isPopular,
      title: `${getOperatorBnName(operator)} ${internetGB ? `${internetGB} জিবি` : ''} ${minutes ? `+ ${minutes} মিনিট` : ''} ${packageName}`.trim(),
    };

    try {
      await addOfferToFirestore(newOffer);
      playNotificationTone();
      speakText('অফারটি সফলভাবে লাইভ পাবলিশ করা হয়েছে', 'bn');

      if (onOfferPublished) {
        onOfferPublished(newOffer);
      }

      if (onShowToast) {
        onShowToast(`🎉 ${getOperatorBnName(operator)} ${packageName} লাইভ পাবলিশ করা হয়েছে!`);
      }

      onClose();
    } catch (err) {
      console.error('Error publishing offer:', err);
      alert('অফার পাবলিশ করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-[460px] w-full overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[92vh] animate-fadeIn">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 px-4 py-3.5 text-white flex items-center justify-between shrink-0 shadow-md">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center text-white">
              <Rocket className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black text-white leading-tight">
                লাইভ ড্রাইভ অফার পাবলিশ করুন
              </h3>
              <p className="text-[10px] text-white/80 font-medium">
                আপনার নিজস্ব অফার ডেটাবেজে সরাসরি লাইভ যুক্ত করুন
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Container */}
        <form onSubmit={handleSubmit} className="p-4 overflow-y-auto space-y-3.5 no-scrollbar text-slate-800 dark:text-slate-100">
          {/* Operator Selection */}
          <div>
            <label className="text-xs font-black text-slate-700 dark:text-slate-300 block mb-1.5">
              অপারেটর নির্বাচন করুন *
            </label>
            <div className="grid grid-cols-6 gap-1.5">
              {(['gp', 'banglalink', 'robi', 'airtel', 'teletalk', 'skitto'] as OperatorType[]).map((op) => (
                <button
                  key={op}
                  type="button"
                  onClick={() => setOperator(op)}
                  className={`py-2 px-1 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                    operator === op
                      ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-950 dark:text-indigo-200 ring-2 ring-indigo-500/40 font-black shadow-xs'
                      : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <OperatorLogo operator={op} size="sm" />
                  <span className="text-[9.5px] font-black truncate w-full text-center">
                    {getOperatorBnName(op)}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Package Type & Validity */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="text-xs font-black text-slate-700 dark:text-slate-300 block mb-1">
                প্যাকেজের ধরন *
              </label>
              <select
                value={packageName}
                onChange={(e) => setPackageName(e.target.value)}
                className="w-full h-10 px-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-xs outline-none focus:border-indigo-600"
              >
                <option value="কম্বো প্যাক">কম্বো প্যাক</option>
                <option value="গিফট প্যাক">গিফট প্যাক</option>
                <option value="মাসিক প্যাক">মাসিক প্যাক</option>
                <option value="মেগা বান্ডেল">মেগা বান্ডেল</option>
                <option value="ধামাকা কম্বো">ধামাকা কম্বো</option>
                <option value="ইন্টারনেট প্যাক">ইন্টারনেট প্যাক</option>
                <option value="মিনিট প্যাক">মিনিট প্যাক</option>
                <option value="স্পেশাল অফার">স্পেশাল অফার</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-black text-slate-700 dark:text-slate-300 block mb-1">
                মেয়াদ (দিন) *
              </label>
              <select
                value={validityDays}
                onChange={(e) => setValidityDays(e.target.value)}
                className="w-full h-10 px-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-xs outline-none focus:border-indigo-600"
              >
                <option value="30">৩০ দিন (১ মাস)</option>
                <option value="15">১৫ দিন</option>
                <option value="7">৭ দিন</option>
                <option value="3">৩ দিন</option>
              </select>
            </div>
          </div>

          {/* Data & Talktime */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="text-xs font-black text-slate-700 dark:text-slate-300 block mb-1">
                ইন্টারনেট (GB) *
              </label>
              <input
                type="number"
                value={internetGB}
                onChange={(e) => setInternetGB(e.target.value)}
                placeholder="যেমন: ৫০"
                className="w-full h-10 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-black text-sm outline-none focus:border-indigo-600"
              />
            </div>

            <div>
              <label className="text-xs font-black text-slate-700 dark:text-slate-300 block mb-1">
                টকটাইম (মিনিট) *
              </label>
              <input
                type="number"
                value={minutes}
                onChange={(e) => setMinutes(e.target.value)}
                placeholder="যেমন: ১৫০০"
                className="w-full h-10 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-black text-sm outline-none focus:border-indigo-600"
              />
            </div>
          </div>

          {/* Pricing: Price, Regular Price, Cashback */}
          <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2.5">
            <div className="text-[11px] font-black text-indigo-700 dark:text-indigo-400">
              মূল্য ও ক্যাশব্যাক নির্ধারণ:
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-[10px] font-black text-slate-600 dark:text-slate-400 block mb-0.5">
                  বিক্রয় মূল্য (৳) *
                </label>
                <input
                  type="number"
                  value={priceTK}
                  onChange={(e) => handlePriceChange(e.target.value)}
                  placeholder="৬৯৯"
                  className="w-full h-9 px-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-black text-xs text-rose-600 outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] font-black text-slate-600 dark:text-slate-400 block mb-0.5">
                  রেগুলার মূল্য (৳)
                </label>
                <input
                  type="number"
                  value={regularPriceTK}
                  onChange={(e) => handleRegularChange(e.target.value)}
                  placeholder="৮৯৯"
                  className="w-full h-9 px-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg font-black text-xs text-slate-700 dark:text-slate-300 outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] font-black text-slate-600 dark:text-slate-400 block mb-0.5">
                  ক্যাশব্যাক (৳)
                </label>
                <input
                  type="number"
                  value={cashbackTK}
                  onChange={(e) => setCashbackTK(e.target.value)}
                  placeholder="২০০"
                  className="w-full h-9 px-2 bg-white dark:bg-slate-800 border border-emerald-300 dark:border-emerald-700 text-emerald-700 font-black text-xs outline-none"
                />
              </div>
            </div>
          </div>

          {/* Division & Admin WhatsApp */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="text-xs font-black text-slate-700 dark:text-slate-300 block mb-1">
                বিভাগ / এলাকা
              </label>
              <input
                type="text"
                value={division}
                onChange={(e) => setDivision(e.target.value)}
                placeholder="All Bangladesh"
                className="w-full h-10 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-bold text-xs outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-black text-slate-700 dark:text-slate-300 block mb-1">
                অর্ডার WhatsApp নম্বর
              </label>
              <input
                type="tel"
                value={whatsappNumber}
                onChange={(e) => setWhatsappNumber(e.target.value)}
                placeholder="01301035400"
                className="w-full h-10 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-black text-xs outline-none"
              />
            </div>
          </div>

          {/* Hot Deal / Popular Banner Toggle */}
          <label className="flex items-center gap-2 p-2.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800/50 cursor-pointer">
            <input
              type="checkbox"
              checked={isPopular}
              onChange={(e) => setIsPopular(e.target.checked)}
              className="w-4 h-4 rounded-md accent-purple-600"
            />
            <div className="text-xs">
              <span className="font-black text-purple-950 dark:text-purple-200 block">
                ⭐ হোমপেজ হট ডিল স্লাইডারে ফিচার করুন
              </span>
              <span className="text-[10px] text-purple-700 dark:text-purple-300">
                এই অফারটি হোমপেজের প্রমোশনাল স্লাইডারে একক আকর্ষণীয় ব্যানার হিসেবে দেখাবে
              </span>
            </div>
          </label>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 hover:from-indigo-700 hover:to-purple-700 active:scale-98 text-white font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 cursor-pointer transition-all"
            >
              <Rocket className="w-4 h-4 text-amber-300 animate-bounce" />
              <span>{isSubmitting ? 'পাবলিশ হচ্ছে...' : '🚀 লাইভ ডেটাবেজে পাবলিশ করুন'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
