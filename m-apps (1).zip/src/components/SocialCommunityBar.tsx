import React from 'react';
import {
  MessageCircle,
  Send,
  Youtube,
  Users,
} from 'lucide-react';
import { SocialCommunityLinks, DriveOffer, UserProfile } from '../types';

interface SocialCommunityBarProps {
  socialLinks: SocialCommunityLinks;
  offers?: DriveOffer[];
  user?: UserProfile;
  className?: string;
}

export const SocialCommunityBar: React.FC<SocialCommunityBarProps> = ({
  socialLinks,
  className,
}) => {
  const allChannels = [
    {
      id: 'chan-wa',
      name: 'WhatsApp',
      sub: 'গ্রুপ',
      icon: MessageCircle,
      url: socialLinks.whatsappGroup || 'https://chat.whatsapp.com',
      enabled: socialLinks.whatsappGroupEnabled !== false,
      badgeColor: 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 border-emerald-200/70 dark:border-emerald-800/60',
      iconColor: 'text-emerald-600 dark:text-emerald-400',
    },
    {
      id: 'chan-tg',
      name: 'Telegram',
      sub: 'গ্রুপ',
      icon: Send,
      url: socialLinks.telegramChannel || 'https://t.me',
      enabled: socialLinks.telegramChannelEnabled !== false,
      badgeColor: 'bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 hover:bg-sky-100 border-sky-200/70 dark:border-sky-800/60',
      iconColor: 'text-sky-600 dark:text-sky-400',
    },
    {
      id: 'chan-fb',
      name: 'Facebook',
      sub: 'পেজ',
      icon: Users,
      url: socialLinks.facebookPage || 'https://facebook.com',
      enabled: socialLinks.facebookPageEnabled !== false,
      badgeColor: 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 border-indigo-200/70 dark:border-indigo-800/60',
      iconColor: 'text-indigo-600 dark:text-indigo-400',
    },
    {
      id: 'chan-yt',
      name: 'YouTube',
      sub: 'চ্যানেল',
      icon: Youtube,
      url: socialLinks.youtubeChannel || 'https://youtube.com',
      enabled: socialLinks.youtubeChannelEnabled !== false,
      badgeColor: 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 hover:bg-rose-100 border-rose-200/70 dark:border-rose-800/60',
      iconColor: 'text-rose-600 dark:text-rose-400',
    },
  ];

  const channels = allChannels.filter(
    (c) => c.enabled !== false && Boolean(c.url && c.url.trim() !== '' && c.url !== '#')
  );

  if (channels.length === 0) return null;

  return (
    <div className={`w-full max-w-full overflow-hidden bg-white/95 dark:bg-slate-800/95 rounded-2xl px-3 py-2 border border-slate-200 dark:border-slate-700 shadow-xs ${className || 'mb-3'}`}>
      <div className="text-[10px] xs:text-[11px] sm:text-xs font-black text-slate-500 dark:text-slate-400 mb-1.5 px-0.5 text-center leading-snug py-0.5 truncate">
        অফিসিয়াল সোশ্যাল গ্রুপ ও চ্যানেল
      </div>
      <div className="flex items-center justify-between gap-1.5 sm:gap-2">
        {channels.map((chan) => {
          const Icon = chan.icon;
          return (
            <a
              key={chan.id}
              id={chan.id}
              href={chan.url || '#'}
              target={chan.url ? '_blank' : '_self'}
              rel="noreferrer"
              className={`flex-1 min-w-0 flex flex-col items-center justify-center py-1.5 px-1 rounded-xl border ${chan.badgeColor} active:scale-95 transition-all group shadow-xs`}
            >
              <div className="flex items-center gap-1 max-w-full">
                <Icon className={`w-3.5 h-3.5 shrink-0 ${chan.iconColor} group-hover:scale-110 transition-transform stroke-[2.5]`} />
                <span className="text-[11px] font-black tracking-tight text-slate-900 dark:text-slate-100 truncate">
                  {chan.name}
                </span>
              </div>
              <span className="text-[9px] sm:text-[10px] text-slate-600 dark:text-slate-300 font-bold leading-none mt-0.5 truncate max-w-full">
                {chan.sub}
              </span>
            </a>
          );
        })}
      </div>
    </div>
  );
};
